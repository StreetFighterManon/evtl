

#ifndef __SANPULLDRV_H__
#define __SANPULLDRV_H__

#include <unistd.h>
#include <vector>

#include <evtl/evtl_threadpool.h>

#include "sanpullimp.h"


struct pullthreadctrl : public evtl::ictrl<evtl::itask*>
{
	void circle_begin(void *arg, int64_t id)
	{}

	void circle_accompany(void *arg, int64_t id, evtl::itask * const & ptask)
	{}

	void circle_end(void *arg, int64_t id, int64_t taskcount, int64_t consumed_us)
	{
		usleep(2000);
	}
};

class sanpulldrv
{
public:
	sanpulldrv()
	{}

	void init()
	{
		for (int i = 0; i < 2; i++)
		{
			sanpullimp *p = new sanpullimp;
			p->set_loop(m_loop.ref());
			p->start_pull();
			p->set_threadpool(&m_threadpool);
			p->init();
			m_imp.push_back(p);
		}

		m_threadpool.set_poolname("pull");
		m_threadpool.make_thread(&m_control, 0, 2);
	}

	void run_bg()
	{
		m_loop.run_loop(evtl::simpeventloop<evtl::dynamic_loop>::background_thread, "pull-drv");
	}

	int64_t get_task_count()
	{
		int64_t total = 0;
		for (std::vector<sanpullimp *>::const_iterator iter = m_imp.begin(); iter != m_imp.end(); ++iter)
		{
			sanpullimp *p = *iter;
			total += p->get_task_count();
		}

		return total;
	}

	bool knock_door(std::shared_ptr<pulllink> ptr)
	{
		std::vector<sanpullimp *>::const_iterator iter = m_imp.begin();
		if (iter == m_imp.end())
			assert(false);

		sanpullimp *p = *iter;
		int64_t tsk_count = p->get_task_count();

		while (++iter != m_imp.end())
		{
			sanpullimp *tmp = *iter;
			int64_t n = tmp->get_task_count();

			if (n < tsk_count)
			{
				p = tmp;
				tsk_count = n;
			}
		}

		return p->async_knock(ptr);
	}

private:
	evtl::simpeventloop<evtl::dynamic_loop>  m_loop;
	std::vector<sanpullimp *>  m_imp;
	evtl::thread::ptpc_threadpool<>  m_threadpool;
	pullthreadctrl  m_control;
};


#endif


