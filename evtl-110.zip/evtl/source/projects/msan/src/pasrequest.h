

#ifndef __PASREQUEST_H__
#define __PASREQUEST_H__

#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_pcre2.h>

#include "passession_baseinfo.h"


class pasrequest
{
public:
	pasrequest(): m_recvbuf(nullptr)
	{}

	enum class searchres
	{
		success,
		need_receive,
		need_continue,
		error,
	};

	void set_sessbase(passess_baseinfo *base)
	{
		m_sessbase = base;
	}

	void set_rcvbuf(evtl::linearbuf<char> &buf)
	{
		m_recvbuf = &buf;
	}

	bool got() const
	{
		if (m_reqeust.isset())
			return true;
		return false;
	}

	searchres  search()
	{
		if (m_recvbuf == nullptr)
			assert(false);
		if (m_reqeust.isset())
			assert(false);

		ssize_t sz = m_recvbuf->size();
		if (sz <= 0)
		{
			ssize_t headsp = m_recvbuf->headspace();
			if (headsp <= 0)
				assert(false);

			ssize_t r = m_sessbase->m_itf->pas_read(m_recvbuf->headptr(), headsp);
			if (r > 0)
			{
				if (r > headsp)
					assert(false && "read exception");
				if (!m_recvbuf->head_eaten_whole(r))
					assert(false && "head eaten fail");

				return searchres::need_continue;
			}
			else
				return searchres::need_receive;
		}

		try
		{
			evtl::pcre2_8::regex  reg(R"(GET *(/\S+) *HTTP/1...*?\r\n\r\n)", 0, PCRE2_DOTALL | PCRE2_CASELESS);
			evtl::pcre2_8::match_results<char>  matches;
			bool br = evtl::pcre2_8::regex_search(m_recvbuf->dataptr(), m_recvbuf->dataptr() + sz, matches, reg);
			if (br)
			{
				if (matches.size() != 2)
					assert(false);

				const evtl::pcre2_8::sub_match<char> &sub_url = matches[1];
				const evtl::pcre2_8::sub_match<char> &sub_req = matches[0];
				if (!sub_url.matched || !sub_req.matched)
					assert(false);

				ssize_t reqsize = sub_req.size();
				if (reqsize <= 0)
					assert(false);

				m_reqeust.refer().extens_store_whole(sub_req.first, reqsize);
				m_reqeust.set();
				m_url = sub_url.str();

				ssize_t shtsz = sub_req.second - m_recvbuf->dataptr();
				if (shtsz <= 0)
					assert(false);

				if (!m_recvbuf->shit_whole(shtsz))
					assert(false);

				return searchres::success;
			}
			else
			{
				m_recvbuf->crowdct(1024*10, 1024*10);
				ssize_t headspace = m_recvbuf->headspace();
				if (headspace <= 0)
				{
					return searchres::error;
				}
				else
				{
					ssize_t rt = m_sessbase->m_itf->pas_read(m_recvbuf->headptr(), headspace);
					if (rt > 0)
						return searchres::need_continue;
					else
						return searchres::need_receive;
				}
			}
		}
		catch (std::exception &e)
		{
		}

		return searchres::error;
	}

	const evtl::linearbuf<char>& get_request() const
	{
		return m_reqeust.refer();
	}

	const std::string& get_url() const
	{
		return m_url;
	}

	void reset()
	{
		m_reqeust.reset();
		m_url.clear();
	}

private:
	passess_baseinfo   *m_sessbase;
	evtl::linearbuf<char>  *m_recvbuf;

	evtl::var<evtl::linearbuf<char>>  m_reqeust;
	std::string   m_url;
};


#endif


