

#ifndef __PASSESSION_BASEINFO_H__
#define __PASSESSION_BASEINFO_H__

#include "passitf.h"
#include "pulllink.h"


class passess_baseinfo
{
public:
	passess_baseinfo()
		: m_sessptr(nullptr), m_itf(nullptr),
		m_last_active_time_s(0)
	{}

	void *  m_sessptr;
	passitf  *m_itf;

	pulllink::intr_entrance     m_local_interrupt_cb;
	pulllink::intr_connector    m_connector;

	int64_t  m_last_active_time_s;
};


#endif


