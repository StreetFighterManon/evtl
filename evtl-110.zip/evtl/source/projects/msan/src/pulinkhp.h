

#ifndef __PULINKHP_H__
#define __PULINKHP_H__

#include <string>
#include <sstream>

#include "pulllink.h"


class pulinkana
{
public:
	pulinkana(const pulllink_ranid &pr): m_linkran(pr)
	{}

	evtl::linearbuf<char> get_httprequest() const
	{
		std::stringstream ss;
		ss << "GET " << m_linkran.m_pulllink->m_filepath << "?sanid=" << m_linkran.m_sanid << " HTTP/1.1\r\n"
			<< "Host: 127.0.0.1:2000\r\n"
			<< "User-Agent: msan\r\n"
			<< "Accept: */*\r\n"
			<< "Connection: Keep-Alive\r\n";

		if (m_linkran.m_pulllink->m_rangestart.isset())
		{
			if (m_linkran.m_pulllink->m_rangeend.isset())
			{
				ss << "Range: bytes=" << m_linkran.m_pulllink->m_rangestart.refer()
					<< "-" << m_linkran.m_pulllink->m_rangeend.refer()
					<< "\r\n";
			}
			else
			{
				ss << "Range: bytes=" << m_linkran.m_pulllink->m_rangestart.refer() << "-\r\n";
			}
		}

		ss << "\r\n";
		evtl::linearbuf<char>  buf;
		buf.extens_store_whole(ss.str());
		return buf;
	}

private:
	const pulllink_ranid  &m_linkran;
};


#endif


