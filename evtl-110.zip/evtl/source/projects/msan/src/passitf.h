

#ifndef __PASSITF_H__
#define __PASSITF_H__


struct passitf
{
	virtual ssize_t pas_read(void *buf, ssize_t nbytes) = 0;

	virtual ssize_t pas_write(const void *buf, ssize_t nbytes) = 0;
};


#endif


