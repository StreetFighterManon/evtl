

#ifndef __SANPULL_H__
#define __SANPULL_H__

#include <assert.h>
#include <vector>
#include <memory>

#include "sanpulldrv.h"
#include "pulllink.h"


class sanpull
{
public:
	sanpull()
	{}

	void init()
	{
		for (int i = 0; i < 1; i++)
		{
			sanpulldrv *p = new sanpulldrv;
			p->init();
			m_pulldrvs.push_back(p);
		}
	}

	void run_bg()
	{
		for (std::vector<sanpulldrv *>::const_iterator iter = m_pulldrvs.begin(); iter != m_pulldrvs.end(); ++iter)
		{
			sanpulldrv *p = *iter;
			assert(p != nullptr);
			p->run_bg();
		}
	}

	bool pull_knockdoor(std::shared_ptr<pulllink> ptr)
	{
		std::vector<sanpulldrv *>::const_iterator iter = m_pulldrvs.begin();
		if (iter == m_pulldrvs.end())
			assert(false);

		sanpulldrv *p = *iter;
		int64_t task_count = p->get_task_count();

		while (++iter != m_pulldrvs.end())
		{
			sanpulldrv *tmp = *iter;
			int64_t n = tmp->get_task_count();

			if (n < task_count)
			{
				p = tmp;
				task_count = n;
			}
		}

		return p->knock_door(ptr);
	}

private:
	std::vector<sanpulldrv *>  m_pulldrvs;
};


#endif


