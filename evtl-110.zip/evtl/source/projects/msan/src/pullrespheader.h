

#ifndef __PULLRESPHEADER_H__
#define __PULLRESPHEADER_H__

#include <evtl/evtl_pcre2.h>


class pullrespheader
{
public:
	pullrespheader(): m_recvbuf(nullptr), m_code(0), m_content_length(0),
		m_range_start(0), m_range_end(0), m_range_total(0)
	{}

	enum class searchresult
	{
		success,
		fail,
		error
	};

	bool got_header() const
	{
		return !m_header.empty();
	}

	void set_recvbuf(evtl::linearbuf<char> *buf)
	{
		m_recvbuf = buf;
	}

	searchresult search_header()
	{
		if (!m_header.empty())
			assert(false && "header got");
		if (m_recvbuf == nullptr)
			assert(false && "null recvbuf");

		if (m_recvbuf->empty())
			return searchresult::fail;

		try
		{
			evtl::pcre2_8::regex reg(R"(HTTP/1.. +(\d+) .*\r\n\r\n)");
			evtl::pcre2_8::match_results<char>  matches;
			bool br = evtl::pcre2_8::regex_search(m_recvbuf->dataptr(), m_recvbuf->dataptr() + m_recvbuf->size(), matches, reg);
			if (br)
			{
				if (matches.size() != 2)
					assert(false && "bad size");

				const evtl::pcre2_8::sub_match<char> &header = matches[0];
				const evtl::pcre2_8::sub_match<char> &code = matches[1];

				if (!header.matched || !code.matched)
					assert(false && "not matched");

				m_header = header.str();
				std::stringstream ss;
				ss << code.str();
				ss >> m_code;

				parse_header(header.first, header.second);

				ssize_t shitsz = header.second - m_recvbuf->dataptr();
				if (shitsz <= 0)
					assert(false);
				if (!m_recvbuf->shit_whole(shitsz))
					assert(false && "shit error");

				if (m_range_end < m_range_start)
					return searchresult::error;
				if (m_content_length > 0 && m_content_length != m_range_end - m_range_start + 1)
					return searchresult::error;

				return searchresult::success;
			}
			else
			{
				if (m_recvbuf->size() >= 1024*10)
					return searchresult::error;
				return searchresult::fail;
			}
		}
		catch (std::exception &e)
		{
			return searchresult::error;
		}
	}

	void parse_header(const char *first, const char *second)
	{
		try
		{
			evtl::pcre2_8::regex  reg(R"(\r\nsanid: *(\S+)\r\n)");
			evtl::pcre2_8::match_results<char>  matches;
			bool br = evtl::pcre2_8::regex_search(first, second, matches, reg);
			if (br)
			{
				if (matches.size() != 2)
					assert(false && "bad size");

				m_sanid = matches[1].str();
			}

			reg.assign(R"(\r\nContent-Length: *(\d+)\r\n)", 0, PCRE2_DOTALL | PCRE2_CASELESS);
			br = evtl::pcre2_8::regex_search(first, second, matches, reg);
			if (br)
			{
				if (matches.size() != 2)
					assert(false && "bad size");

				std::stringstream ss;
				ss << matches[1].str();
				ss >> m_content_length;

				if (m_content_length < 0)
					m_content_length = 0;
			}
			else
			{
				m_content_length = 0;
			}

			reg.assign(R"(\r\nContent-Range: *bytes +(\d+)-(\d+)/(\d+)\r\n)", 0, PCRE2_DOTALL | PCRE2_CASELESS);
			br = evtl::pcre2_8::regex_search(first, second, matches, reg);
			if (br)
			{
				if (matches.size() != 4)
					assert(false && "invalid match");

				std::stringstream ss;
				ss << matches[1].str();
				ss >> m_range_start;

				ss.str(""); ss.clear();
				ss << matches[2].str();
				ss >> m_range_end;

				ss.str(""); ss.clear();
				ss << matches[3].str();
				ss >> m_range_total;
			}
			else
			{
				m_range_start = 0;
				m_range_end = 0;
				m_range_total = 0;
			}
		}
		catch (std::exception &e)
		{
			m_sanid.clear();
			m_content_length = 0;
			m_range_start = 0;
			m_range_end = 0;
			m_range_total = 0;
		}
	}

	int get_respcode() const
	{
		return m_code;
	}

	int64_t get_contentlength() const
	{
		return m_content_length;
	}

	int64_t get_rangestart() const
	{
		return m_range_start;
	}

	int64_t get_rangeend() const
	{
		return m_range_end;
	}

	int64_t get_rangetotal() const
	{
		return m_range_total;
	}

	std::string get_sanid() const
	{
		return m_sanid;
	}

	void reset()
	{
		m_header.clear();
		m_code = 0;
		m_sanid.clear();
		m_content_length = 0;
		m_range_start = 0;
		m_range_end = 0;
		m_range_total = 0;
	}

private:
	evtl::linearbuf<char>  *m_recvbuf;

	std::string   m_header;
	int   m_code;
	std::string   m_sanid;
	int64_t   m_content_length;
	int64_t   m_range_start;
	int64_t   m_range_end;
	int64_t   m_range_total;
};


#endif


