

#ifndef __SANTIMER_H__
#define __SANTIMER_H__

#include <evtl/evtl_time.h>


class santimer
{
public:
	santimer(): m_last_active_ms(0)
	{}

	void set_cycle_ms(int64_t ms)
	{
		m_cycle_ms = ms;
	}

	bool is_active()
	{
		int64_t now_ms = evtl::timec::msec();
		if (now_ms - m_last_active_ms > m_cycle_ms || now_ms - m_last_active_ms < -2000)
		{
			m_last_active_ms = now_ms;
			return true;
		}
		return false;
	}

private:
	int64_t  m_cycle_ms;
	int64_t  m_last_active_ms;
};


#endif


