

#include <iostream>
using namespace std;

#include <evtl/evtl_watcher_io.h>
#include <evtl/evtl_watcher_timer.h>
#include <evtl/evtl_watcher_async.h>
#include <evtl/evtl_watcher_signal.h>
#include <evtl/evtl_watcher_periodic.h>
#include <evtl/evtl_signal.h>
#include <evtl/evtl_time.h>

#include <evtl/evtl_threadpool.h>
#include "pulliointerface.h"

#include "sanservices.h"


int main()
{
	evtl::signalc::sig_ignore(SIGPIPE);

	evtl::timec::background_update();

	sanservice  servs;
	servs.init();
	servs.run();

	return 0;
}


