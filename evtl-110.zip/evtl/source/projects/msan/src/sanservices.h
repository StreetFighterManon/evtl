

#ifndef __SANSERVICE_H__
#define __SANSERVICE_H__

#include <vector>

#include "sanfileget.h"
#include "acceptor.h"


class sanservice
{
public:
	sanservice()
	{}

	void init()
	{
		m_fileget.init();

		m_acceptor.set_address(evtl::makeipaddr("0.0.0.0", 2300));
		m_acceptor.set_callback(std::bind(&sanservice::accept_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_acceptor.start_accept();
	}

	void run()
	{
		m_fileget.run_bg();
		m_acceptor.run();
	}

private:
	void accept_callback(acceptor &acpt, std::vector<evtl::connection> &conn)
	{
		m_fileget.async_recvconn(conn);
	}

private:
	acceptor     m_acceptor;
	sanfileget   m_fileget;
};


#endif


