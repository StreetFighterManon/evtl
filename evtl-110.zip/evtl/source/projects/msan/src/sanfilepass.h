

#ifndef __SANFILEPASS_H__
#define __SANFILEPASS_H__

#include <vector>
#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_acceptor.h>

#include "sanfilepassdrv.h"
#include "pulllink.h"


class sanfilepass
{
public:
	sanfilepass()
	{}

	void set_linkconnector(pulllink::intr_connector ccb)
	{
		m_ccb = ccb;
	}

	void init()
	{
		for (int i = 0; i < 2; i++)
		{
			sanfilepassdrv *p = new sanfilepassdrv;
			p->set_linkconnector(m_ccb);
			p->init(i);
			m_passdrv.push_back(p);
		}
	}

	void run_bg()
	{
		for (std::vector<sanfilepassdrv *>::const_iterator iter = m_passdrv.begin(); iter != m_passdrv.end(); ++iter)
		{
			sanfilepassdrv *p = *iter;
			p->run_bg();
		}
	}

	void async_recvconn(std::vector<evtl::connection> &connections)
	{
		if (m_passdrv.empty())
			assert(false);

		std::vector<sanfilepassdrv *>::const_iterator iter = m_passdrv.begin();

		sanfilepassdrv *pdrv = *iter;
		int64_t sess_count = pdrv->get_session_count();

		for ( ; iter != m_passdrv.end(); ++iter)
		{
			sanfilepassdrv *p = *iter;
			int64_t n = p->get_session_count();

			if (n < sess_count)
			{
				pdrv = p;
				sess_count = n;
			}
		}

		if (pdrv == nullptr)
			assert(false);

		pdrv->async_recvconn(connections);
	}

private:
	pulllink::intr_connector  m_ccb;
	std::vector<sanfilepassdrv *>  m_passdrv;
};


#endif


