

#ifndef __PULLIOINTERFACE_H__
#define __PULLIOINTERFACE_H__


struct pulliointerface
{
	virtual ssize_t pul_read(void *buf, ssize_t nbytes) = 0;

	virtual ssize_t pul_write(const void *buf, ssize_t nbytes) = 0;

	virtual void update_recvtime() = 0;

	virtual int64_t get_last_recvtime_s() const = 0;

	virtual void update_link_count() = 0;
};


#endif


