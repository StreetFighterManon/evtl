

#ifndef __HTTPRESPONSE_H__
#define __HTTPRESPONSE_H__

#include <string>
#include <sstream>

#include <evtl/evtl_wrapper.h>

#include "passitf.h"


class httpcodedesc
{
public:
	static std::string get_desc(int code)
	{
		switch (code)
		{
		case 200:
			return "OK";
		case 206:
			return "Partial";
		case 400:
			return "Bad Request";
		case 404:
			return "Not Found";
		default:
			break;
		}

		return "Unknown";
	}
};


class httpresponse
{
public:
	httpresponse(): m_sessbase(nullptr)
	{
		m_startbyte = 0;
		m_endbyte = 0;
		m_totalsize = 0;
		m_content_length = 0;
	}

	bool retdata_isset()
	{
		return m_code.isset();
	}

	void set_sessbase(passess_baseinfo *base)
	{
		m_sessbase = base;
	}

	void set_code(int code)
	{
		m_code.set_assign(code);
	}

	void set_content_range(int64_t startbyte, int64_t endbyte, int64_t totallength)
	{
		m_startbyte = startbyte;
		m_endbyte = endbyte;
		m_totalsize = totallength;
	}

	void set_content_length(int64_t length)
	{
		m_content_length = length;
	}

	void set_msg(const std::string &str)
	{
		m_errstr = str;
	}

	void response()
	{
		if (!m_code.isset())
			assert(false);

		if (!m_response.isset())
		{
			std::stringstream ss;

			if (m_code == 404 || m_code == 400)
			{
				ss << "HTTP/1.1 " << m_code.refer() << " " << httpcodedesc::get_desc(m_code) << "\r\n"
					<< "Content-Length: 0\r\n"
					<< "Server: msan\r\n"
					<< "msg: " << m_errstr << "\r\n"
					<< "\r\n";
			}
			else if (m_code == 200 || m_code == 206)
			{
				if (m_content_length > 0)
				{
					if (m_endbyte - m_startbyte + 1 != m_content_length)
						assert(false && "invalid http response");

					ss << "HTTP/1.1 " << m_code.refer() << " " << httpcodedesc::get_desc(m_code) << "\r\n"
						<< "Content-Type: application/octet-stream\r\n"
						<< "Content-Range: bytes " << m_startbyte << "-" << m_endbyte << "/" << m_totalsize << "\r\n"
						<< "Content-Length: " << m_content_length << "\r\n"
						<< "Server: msan\r\n"
						<< "\r\n";
				}
				else
				{
					ss << "HTTP/1.1 " << m_code.refer() << " " << httpcodedesc::get_desc(m_code) << "\r\n"
						<< "Content-Type: application/octet-stream\r\n"
						<< "Content-Length: 0\r\n"
						<< "Server: msan\r\n"
						<< "\r\n";
				}
			}
			else
			{
				assert(false && "invalid httpcode");
			}

			evtl::linearbuf<char> buf;
			buf.extens_store_whole(ss.str());
			m_response.set_assign(std::move(buf));
		}

		evtl::linearbuf<char> &resp = m_response.refer();
		ssize_t sz = resp.size();
		if (sz > 0)
		{
			ssize_t r = m_sessbase->m_itf->pas_write(resp.dataptr(), sz);
			if (r > 0)
			{
				if (r > sz)
					assert(false && "write exception");
				if (!resp.shit_whole(r))
					assert(false && "shit error");
			}
		}
	}

	bool finished() const
	{
		if (m_response.isset() && m_response.refer().empty())
			return true;
		return false;
	}

	void reset()
	{
		m_code.reset();
		m_startbyte = 0;
		m_endbyte = 0;
		m_totalsize = 0;
		m_errstr.clear();
		m_response.reset();
	}

private:
	passess_baseinfo  *m_sessbase;
	evtl::var<int>  m_code;
	int64_t  m_startbyte;
	int64_t  m_endbyte;
	int64_t  m_totalsize;
	int64_t  m_content_length;

	std::string   m_errstr;

	evtl::dn_var<evtl::linearbuf<char>>  m_response;
};


#endif


