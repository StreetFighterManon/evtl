

#ifndef __SANPASESSION_H__
#define __SANPASESSION_H__

#include <utility>

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_watcher_io.h>
#include <evtl/evtl_acceptor.h>
#include <evtl/evtl_com.h>
#include <evtl/evtl_interface.h>
#include <evtl/evtl_threadpool.h>
#include <evtl/evtl_wasyncs.h>
#include <evtl/evtl_time.h>

#include "passprocess.h"
#include "passitf.h"
#include "passession_baseinfo.h"
#include "pulllink.h"


class sanpasession : public evtl::watcher_io<sanpasession>,
					public evtl::itask,
					public passitf
{
public:
	sanpasession(): m_threadpool(nullptr)
	{}

	typedef std::function<void (sanpasession *psess)>  recycle_callback_t;

	enum class complete_type
	{
		unknown,
		error,
		cycledone
	};

	void set_loop(evtl::looprefer loop)
	{
		m_loop = loop;
	}

	void set_connection(const evtl::connection &conn)
	{
		m_connection = conn;
	}

	void set_threadpool(evtl::thread::ptpc_threadpool<> *pool)
	{
		m_threadpool = pool;
	}

	void set_recycle_callback(recycle_callback_t cb)
	{
		m_recycle_cb = std::move(cb);
	}

	void set_local_interrupt(evtl::itc::interrupt_entrance<pulllink> cb)
	{
		m_baseinfo.m_local_interrupt_cb = std::move(cb);
	}

	void set_linkconnector(pulllink::intr_connector ccb)
	{
		m_baseinfo.m_connector = std::move(ccb);
	}

	void init()
	{
		m_baseinfo.m_sessptr = this;
		m_baseinfo.m_itf = this;
		m_process.set_sessbaseinfo(&m_baseinfo);

		m_complete_async.set(m_loop);
		m_complete_async.set_callback(std::bind(&sanpasession::complete_async_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_complete_async.start();
	}

	ssize_t pas_read(void *buf, ssize_t nbytes)
	{
		if (nbytes <= 0)
			assert(false);

		ssize_t rt = this->read(buf, nbytes);
		if (rt > 0)
		{
			if (rt > nbytes)
				assert(false && "read exception");

			_update_active_time();
		}
		else if (rt == 0)
		{
			m_iostatus.orset(evtl::com::rwresult_read_end, 0);
		}
		else
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
				m_iostatus.orset(evtl::com::rwresult_read_error, errno);
		}

		return rt;
	}

	ssize_t pas_write(const void *buf, ssize_t nbytes)
	{
		if (nbytes <= 0)
			assert(false);

		ssize_t rt = this->write(buf, nbytes);
		if (rt > 0)
		{
			if (rt > nbytes)
				assert(false && "read exception");

			_update_active_time();
		}
		else if (rt == 0)
		{
			assert(false && "write 0");
		}
		else
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
				m_iostatus.orset(evtl::com::rwresult_write_error, errno);
		}

		return rt;
	}

	void io_callback(sanpasession &watcher, int revents)
	{
		if (&watcher != this)
			assert(false);

		m_process.process();
		evtl::com::process_nextstep  step = m_process.get_nextstep();

		if (step == evtl::com::nextstep_wait_to_receive)
		{
			if (m_iostatus.readerror_raised())
			{
				this->stop();
				m_recycle_cb(this);
				return;
			}

			if (this->get_events() != ev::READ)
			{
				this->stop();
				this->set_events(ev::READ);
				this->start();
			}
			return;
		}

		if (step == evtl::com::nextstep_wait_to_send)
		{
			if (m_iostatus.writeerror_raised())
			{
				this->stop();
				m_recycle_cb(this);
				return;
			}
			if (this->get_events() != ev::READ)
			{
				this->stop();
				this->set_events(ev::READ);
				this->start();
			}
			return;
		}

		if (step == evtl::com::nextstep_continue)
		{
			if ((this->get_events() & ev::WRITE) == 0)
			{
				this->stop();
				this->set_events(ev::WRITE);
				this->start();
			}
			return;
		}

		if (step == evtl::com::nextstep_cycledone)
		{
			m_process.cycle_reset();

			if (this->get_events() != ev::WRITE)
			{
				this->stop();
				this->set_events(ev::WRITE);
				this->start();
			}
			return;
		}

		if (step == evtl::com::nextstep_error)
		{
			m_process.reset();
			this->stop();
			m_recycle_cb(this);
			return;
		}

		if (step == evtl::com::nextstep_other)
		{
			this->stop();
			if (!m_inpool)
			{
				const void *p = m_threadpool->add_task<>(this);
				if (p == nullptr)
					assert(false);

				m_inpool = true;
				m_threadrun = true;
			}
			else
			{
				assert(false);
			}
			return;
		}

		assert(false && "bad reach");
	}

	void run(void *)
	{
		if (!m_threadrun)
			return;

		m_process.process_inpool();
		evtl::com::process_nextstep  step = m_process.get_nextstep();

		switch (step)
		{
		case evtl::com::nextstep_wait_to_send:
			{
				if (m_iostatus.writeerror_raised())
				{
					m_process.pullfin_notify();
					m_threadrun = false;
					m_complete_async.set_value(complete_type::error);
					m_complete_async.send();
				}
				return;
			}
			break;
		case evtl::com::nextstep_continue:
			{
				return;
			}
			break;
		case evtl::com::nextstep_cycledone:
			{
				m_process.pullfin_notify();
				m_threadrun = false;
				m_complete_async.set_value(complete_type::cycledone);
				m_complete_async.send();
				return;
			}
			break;
		case evtl::com::nextstep_error:
			{
				m_process.pullfin_notify();
				m_threadrun = false;
				m_complete_async.set_value(complete_type::error);
				m_complete_async.send();
				return;
			}
			break;
		default:
			assert(false && "invalid step");
			break;
		}
	}

	bool needrecycle()
	{
		int64_t now_s = evtl::timec::fast_sec();
		if (now_s - m_baseinfo.m_last_active_time_s > 60 || now_s - m_baseinfo.m_last_active_time_s < -60)
			return true;
		return false;
	}

	void remove_from_threadpool()
	{
		if (m_inpool)
		{
			const void *p = m_threadpool->remove_task(this);
			if (p == nullptr)
				assert(false);

			m_inpool = false;
			m_threadrun = false;
		}
	}

	void pullfin_notify()
	{
		m_process.pullfin_notify();
	}

	void deinit()
	{
		this->stop_close();
		m_complete_async.stop();
		m_process.reset();
	}

private:
	void complete_async_callback(evtl::atom_simpwasync<complete_type, complete_type::unknown> &watcher, int revents)
	{
		if (&watcher != &m_complete_async)
			assert(false);

		if (m_inpool)
		{
			const void *p = m_threadpool->remove_task(this);
			if (p == nullptr)
				assert(false);

			m_inpool = false;
			m_threadrun = false;
		}
		else
		{
			assert(false);
		}

		complete_type type = watcher.get_value();
		if (type == complete_type::cycledone)
		{
			m_process.cycle_reset();
			watcher.reset_value();

			this->set_events(ev::WRITE);
			this->start();
		}
		else if (type == complete_type::error)
		{
			this->stop();
			watcher.stop();
			m_recycle_cb(this);
			return;
		}
		else
		{
			assert(false);
		}
	}

	void _update_active_time()
	{
		m_baseinfo.m_last_active_time_s = evtl::timec::fast_sec();
	}

private:
	passess_baseinfo  m_baseinfo;

	evtl::thread::ptpc_threadpool<>  *m_threadpool;
	evtl::boolflag<false>   m_inpool;
	evtl::boolflag<false>   m_threadrun;

	evtl::looprefer  m_loop;
	evtl::connection  m_connection;

	passprocess  m_process;
	evtl::com::rwstatus  m_iostatus;

	recycle_callback_t   m_recycle_cb;
	evtl::atom_simpwasync<complete_type, complete_type::unknown>     m_complete_async;
};


#endif


