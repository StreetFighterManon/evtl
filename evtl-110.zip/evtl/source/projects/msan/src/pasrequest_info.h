

#ifndef __PASREQUEST_INFO_H__
#define __PASREQUEST_INFO_H__

#include <cstdint>
#include <string>

#include <evtl/evtl_wrapper.h>


struct pasrequest_info
{
	pasrequest_info()
	{}

	void reset()
	{
		m_filepath.clear();
		m_rangebyte_start.reset();
		m_rangebyte_end.reset();
	}

	std::string  m_filepath;
	evtl::st_var<int64_t>  m_rangebyte_start;
	evtl::st_var<int64_t>  m_rangebyte_end;
};


#endif


