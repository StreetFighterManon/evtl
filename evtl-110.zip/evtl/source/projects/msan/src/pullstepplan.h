

#ifndef __PULLSTEPPLAN_H__
#define __PULLSTEPPLAN_H__

#include <evtl/evtl_com.h>


class pullstepplan
{
public:
	pullstepplan()
	{
		m_needwrite = false;
		m_needread = false;
		m_error = false;
	}

	void reset()
	{
		m_needwrite = false;
		m_needread = false;
		m_error = false;
	}

	void need_send()
	{
		m_needwrite = true;
	}

	void need_receive()
	{
		m_needread = true;
	}

	void set_error()
	{
		m_error = true;
	}

	evtl::com::process_nextstep get_nextstep() const
	{
		if (m_error)
			return evtl::com::nextstep_error;
		if (m_needwrite)
		{
			if (m_needread)
				return evtl::com::nextstep_wait_to_receive_send;
			else
				return evtl::com::nextstep_wait_to_send;
		}
		else
		{
			if (m_needread)
				return evtl::com::nextstep_wait_to_receive;
			else
				return evtl::com::nextstep_continue;
		}
	}

private:
	bool  m_needwrite;
	bool  m_needread;
	bool  m_error;
};


#endif


