

#ifndef __PULLPROCESS_H__
#define __PULLPROCESS_H__

#include <evtl/evtl_boundedbuf.h>
#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_com.h>
#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_time.h>
#include <evtl/evtl_wasyncs.h>

#include "pulllink.h"
#include "pullresponse.h"
#include "pulinkhp.h"
#include "pullstepplan.h"
#include "pulliointerface.h"
#include "santimer.h"


class pullprocess
{
public:
	pullprocess(): m_ioinf(nullptr), m_links(nullptr), m_linkcount(0)
	{}

	void set_interface(pulliointerface *ioif)
	{
		m_ioinf = ioif;
	}

	void set_links(evtl::queue_simpwasync<pulllink_ranid> *plinks)
	{
		m_links = plinks;
	}

	void init()
	{
		m_heatbeat_timer.set_cycle_ms(10*1000);
		m_response.set_ioinf(m_ioinf);
		m_response.set_rlinks(&m_wfrlinks);
		m_response.init();
	}

	void update_link_count()
	{
		int64_t n = m_wfslinks.size() + m_wfrlinks.size();
		if (m_response.link_located())
			n++;
		m_linkcount = n;
	}

	int64_t get_linkcount() const
	{
		return m_linkcount;
	}

	void process()
	{
		m_plan.reset();

		prepare_reqeust();
		prepare_heartbeat();

		send_request();
		receive_response();
	}

	evtl::com::process_nextstep get_nextstep() const
	{
		return m_plan.get_nextstep();
	}

	void handle_error()
	{
		_handle_error();
	}

private:
	void prepare_reqeust()
	{
		if (m_links == nullptr)
			assert(false && "null links");

		ssize_t n = m_wfslinks.size() + m_wfrlinks.size();
		if (n < 10)
		{
			pulllink_ranid lnk;
			if (m_links->popfront(lnk))
			{
				if (lnk.m_pulllink->m_local_fin)
				{
					lnk.m_pulllink->m_remote_fin = true;
					return;
				}

				pulinkana ana(lnk);

				pulllink_active act;
				act.m_link     = lnk;
				act.m_httprequest_backup = ana.get_httprequest();
				act.m_httprequest.set_assign(act.m_httprequest_backup);
				m_wfslinks.push_back(std::move(act));

				update_link_count();
			}
		}
	}

	void prepare_heartbeat()
	{
		//if (!m_heatbeat_timer.is_active())
		//	return;

		int64_t now_s = evtl::timec::fast_sec();
		if (now_s - m_ioinf->get_last_recvtime_s() >= 10 || now_s - m_ioinf->get_last_recvtime_s() <= -3)
		{
			if (m_wfslinks.empty() && m_wfrlinks.empty() && !m_response.link_located())
			{
				pulllink_ranid lnk;
				lnk.m_sanid = evtl::rand::cclock::str_realtime();
				lnk.m_pulllink = std::make_shared<pulllink>();
				lnk.m_pulllink->m_heartbeat = true;
				lnk.m_pulllink->m_filepath = "/tmp/sanpull_heatbeat";
				lnk.m_pulllink->m_local_interrupt = [](const evtl::itc::interrupt_message<pulllink> &message) -> bool
					{ return true; };
				lnk.m_pulllink->init_buffer(1, 1024*512);

				pulinkana ana(lnk);

				pulllink_active act;
				act.m_link	   = lnk;
				act.m_httprequest_backup = ana.get_httprequest();
				act.m_httprequest.set_assign(act.m_httprequest_backup);
				m_wfslinks.push_back(std::move(act));

				update_link_count();
			}
		}
	}

	void send_request()
	{
		std::list<pulllink_active>::iterator iter = m_wfslinks.begin();
		if (iter == m_wfslinks.end())
			return;
		else
		{
			evtl::dn_var<evtl::linearbuf<char>> &buf = iter->m_httprequest;
			if (!buf.isset())
				assert(false && "request unset");
			evtl::linearbuf<char> &sbuf = buf.refer();
			ssize_t sz = sbuf.size();
			if (sz > 0)
			{
				ssize_t rt = m_ioinf->pul_write(sbuf.dataptr(), sz);
				if (rt > 0)
				{
					if (rt > sz)
						assert(false && "write exception");
					if (!sbuf.shit_whole(rt))
						assert(false && "shit error");
				}
				else
				{
					m_plan.need_send();
				}

				if (sbuf.empty())
					m_wfrlinks.splice(m_wfrlinks.end(), m_wfslinks, iter);
			}
			else
			{
				m_wfrlinks.splice(m_wfrlinks.end(), m_wfslinks, iter);
			}
		}
	}

	void receive_response()
	{
		m_response.handle();

		pullresponse::handleresult result = m_response.get_result();
		if (result == pullresponse::handleresult::wait_receive)
		{
			m_plan.need_receive();
		}
		else if (result == pullresponse::handleresult::only_continue)
		{
		}
		else if (result == pullresponse::handleresult::one_complete)
		{
			handle_one_complete();
		}
		else if (result == pullresponse::handleresult::error)
		{
			m_plan.set_error();
		}
		else
		{
			assert(false && "invalid result");
		}
	}

	void handle_one_complete()
	{
		m_response.handle_one_complete();
	}

	void _handle_error()
	{
		m_wfslinks.splice(m_wfslinks.begin(), m_wfrlinks);
		for (std::list<pulllink_active>::iterator iter = m_wfslinks.begin(); iter != m_wfslinks.end(); ++iter)
		{
			iter->recovery();
		}

		m_response.handle_error();
	}

private:
	pulliointerface  *m_ioinf;
	pullstepplan   m_plan;

	evtl::queue_simpwasync<pulllink_ranid>  *m_links;
	std::list<pulllink_active>  m_wfslinks;
	std::list<pulllink_active>  m_wfrlinks;
	std::atomic<int64_t>  m_linkcount;
	pullresponse   m_response;

	santimer  m_heatbeat_timer;
};


#endif


