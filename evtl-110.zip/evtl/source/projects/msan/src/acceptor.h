

#ifndef __ACCEPTOR_H__
#define __ACCEPTOR_H__

#include <string>

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_acceptor.h>
#include <evtl/evtl_listener.h>


class acceptor : public evtl::acceptor<acceptor>
{
public:
	acceptor()
	{}

	void set_address(const evtl::address &addr)
	{
		m_listen.set_address(addr);
	}

	void start_accept()
	{
		m_listen.tcplisten(64);
		this->set_loop(m_loop.ref());
		this->set_listener(&m_listen);
		this->watch();
	}

	void run()
	{
		m_loop.run_loop(evtl::simpeventloop<evtl::dynamic_loop>::current_thread);
	}

	void run_bg()
	{
		m_loop.run_loop(evtl::simpeventloop<evtl::dynamic_loop>::background_thread, "accept", 4*1024*1024);
	}

private:
	evtl::simpeventloop<evtl::dynamic_loop>  m_loop;
	evtl::listener  m_listen;
};


#endif


