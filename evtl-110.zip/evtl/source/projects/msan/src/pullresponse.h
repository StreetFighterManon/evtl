

#ifndef __PULLRESPONSE_H__
#define __PULLRESPONSE_H__

#include <list>

#include "pullrespheader.h"
#include "pullrespbody.h"
#include "pulliointerface.h"


class pullresponse
{
public:
	pullresponse(): m_ioinf(nullptr), m_rlink(nullptr), m_result(handleresult::unknown),
		m_temprecvbuf(1024*64)
	{}

	enum class handleresult
	{
		unknown,
		wait_receive,
		only_continue,
		one_complete,
		error
	};

	void set_ioinf(pulliointerface *ioinf)
	{
		m_ioinf = ioinf;
	}

	void set_rlinks(std::list<pulllink_active> *link)
	{
		m_rlink = link;
	}

	void init()
	{
		m_header.set_recvbuf(&m_temprecvbuf);
		m_body.set_ioinf(m_ioinf);
		m_body.set_rlink(m_rlink);
		m_body.set_recvbuf(&m_temprecvbuf);
	}

	void handle()
	{
		set_result(handleresult::unknown);

		if (m_rlink->empty() && !m_body.link_located())
		{
			set_result(handleresult::only_continue);
			return;
		}

		if (!m_header.got_header())
		{
			pullrespheader::searchresult res = m_header.search_header();
			if (res == pullrespheader::searchresult::success)
			{
				if (!m_header.got_header())
					assert(false && "header not got");
			}
			else if (res == pullrespheader::searchresult::fail)
			{
				m_temprecvbuf.crowdct(1024*10, 1024*10);
				ssize_t headspace = m_temprecvbuf.headspace();
				if (headspace <= 0)
					assert(false);

				ssize_t sz = m_ioinf->pul_read(m_temprecvbuf.headptr(), headspace);
				if (sz > 0)
				{
					if (sz > headspace)
						assert(false);
					if (!m_temprecvbuf.head_eaten_whole(sz))
						assert(false);
					set_result(handleresult::only_continue);
				}
				else
				{
					set_result(handleresult::wait_receive);
				}
				return;
			}
			else if (res == pullrespheader::searchresult::error)
			{
				set_result(handleresult::error);
				return;
			}
			else
			{
				assert(false && "unknown error");
				return;
			}
		}

		if (!m_body.link_located())
		{
			m_body.set_respinfo(m_header.get_respcode(), m_header.get_sanid(), m_header.get_contentlength(), m_header.get_rangestart(), m_header.get_rangeend(), m_header.get_rangetotal());
			m_body.link_locate();
			m_body.init_recv();

			if (!m_body.link_located())
				assert(false && "unlocate");
		}

		m_body.handle();
		pullrespbody::pullresult result = m_body.get_handleresult();
		if (result == pullrespbody::pullresult::wait_receive)
		{
			set_result(handleresult::wait_receive);
		}
		else if (result == pullrespbody::pullresult::only_continue)
		{
			set_result(handleresult::only_continue);
		}
		else if (result == pullrespbody::pullresult::one_complete)
		{
			set_result(handleresult::one_complete);
		}
		else if (result == pullrespbody::pullresult::error)
		{
			set_result(handleresult::error);
		}
		else
		{
			assert(false && "invalid result");
		}
	}

	handleresult get_result() const
	{
		return m_result;
	}

	bool link_located() const
	{
		return m_body.link_located();
	}

	void handle_one_complete()
	{
		m_header.reset();
		m_body.handle_one_complete();
	}

	void handle_error()
	{
		m_temprecvbuf.clear();
		m_header.reset();
		m_body.handle_error();
	}

private:
	void set_result(handleresult result)
	{
		m_result = result;
	}

private:
	pulliointerface   *m_ioinf;
	std::list<pulllink_active>  *m_rlink;
	handleresult  m_result;

	evtl::linearbuf<char>  m_temprecvbuf;
	pullrespheader    m_header;
	pullrespbody      m_body;
};


#endif


