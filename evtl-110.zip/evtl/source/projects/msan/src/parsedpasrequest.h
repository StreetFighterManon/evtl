

#ifndef __PARSEDPASREQUEST_H__
#define __PARSEDPASREQUEST_H__

#include <string>
#include <sstream>

#include <evtl/evtl_pcre2.h>
#include <evtl/evtl_wrapper.h>

#include "pasrequest.h"
#include "pasrequest_info.h"


class parsedpasrequest
{
public:
	parsedpasrequest()
	{}

	bool is_parsed() const
	{
		return m_parsed;
	}

	void parse(const pasrequest &req)
	{
		m_parsed = true;

		std::string filepath = req.get_url();

		size_t pos = filepath.find('?');
		if (pos != std::string::npos)
		{
			filepath = filepath.substr(0, pos);
		}
		m_reqinfo.m_filepath = std::move(filepath);

		const evtl::linearbuf<char> &buf = req.get_request();
		if (buf.empty())
			return;

		try
		{
			evtl::pcre2_8::regex  reg(R"(\r\nRange: *bytes=(\d+)-(\d*))");
			evtl::pcre2_8::match_results<char>  matches;
			bool br = evtl::pcre2_8::regex_search(buf.dataptr(), buf.dataptr() + buf.size(), matches, reg);
			if (br)
			{
				if (matches.size() != 3)
					assert(false);

				const evtl::pcre2_8::sub_match<char> &sub_start = matches[1];
				const evtl::pcre2_8::sub_match<char> &sub_end = matches[2];
				if (!sub_start.matched || !sub_end.matched)
					assert(false);

				int64_t val = 0;
				std::stringstream ss;
				ss << sub_start.str();
				ss >> val;

				m_reqinfo.m_rangebyte_start.set_assign(val);

				std::string endstr = sub_end.str();
				if (!endstr.empty())
				{
					ss.str(""); ss.clear();
					ss << endstr;
					ss >> val;

					m_reqinfo.m_rangebyte_end.set_assign(val);
				}
			}
		}
		catch (std::exception &e)
		{}
	}

	void check()
	{
		m_is_valid = false;
		if (m_reqinfo.m_filepath.empty())
		{
			m_errstr = "empty filepath";
			return;
		}

		if (m_reqinfo.m_rangebyte_start.isset())
		{
			if (m_reqinfo.m_rangebyte_start < 0)
			{
				m_errstr = "invalid range";
				return;
			}

			if (m_reqinfo.m_rangebyte_end.isset())
			{
				if (m_reqinfo.m_rangebyte_end < m_reqinfo.m_rangebyte_start)
				{
					m_errstr = "invalid range";
					return;
				}
			}
		}

		m_is_valid = true;
	}

	bool is_valid() const
	{
		return m_is_valid;
	}

	std::string  get_errstr() const
	{
		return m_errstr;
	}

	const pasrequest_info& get_requestinfo() const
	{
		return m_reqinfo;
	}

	void reset()
	{
		m_parsed.reset();
		m_reqinfo.reset();
		m_is_valid.reset();
		m_errstr.clear();
	}

private:
	evtl::boolflag<false>  m_parsed;

	pasrequest_info   m_reqinfo;
	evtl::boolflag<false>  m_is_valid;
	std::string   m_errstr;
};


#endif


