

#ifndef __THREADPOOLCOM_H__
#define __THREADPOOLCOM_H__

#include <evtl/evtl_interface.h>


class threadpoolctrl : public evtl::ictrl<evtl::itask*>
{
public:
	void circle_begin(void *arg, int64_t id)
	{
	}

	void circle_accompany(void *arg, int64_t id, evtl::itask* const &ptask)
	{
	}

	void circle_end(void *arg, int64_t id, int64_t taskcount, int64_t consumed_us)
	{
		usleep(2000);
	}
};


#endif


