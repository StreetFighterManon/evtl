

#ifndef __SANPASS_H__
#define __SANPASS_H__

#include <vector>
#include <unordered_set>

#include <evtl/evtl_acceptor.h>
#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_wasyncs.h>
#include <evtl/evtl_threadpool.h>
#include <evtl/evtl_watcher_timer.h>

#include "sanpasession.h"
#include "pulllink.h"
#include "threadpoolcom.h"


class sanpass
{
public:
	sanpass(): m_id(0)
	{}

	void set_linkconnector(pulllink::intr_connector &&ccb)
	{
		m_ccb = ccb;
	}

	void set_loop(evtl::looprefer loop)
	{
		m_loop = loop;
	}

	void init(int id)
	{
		m_id = id;
		m_connection_async.init();

		std::stringstream ss;
		ss << "pass-" << m_id;
		m_threadpool.set_poolname(ss.str());
		m_threadpool.make_thread(&m_threadctrl, 0, 2);
	}

	void start()
	{
		m_connection_async.set(m_loop);
		m_connection_async.set_callback(std::bind(&sanpass::connection_async_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_connection_async.start();

		m_timer.set(m_loop, 0, 10);
		m_timer.set_callback(std::bind(&sanpass::timer_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_timer.again();
	}

	void async_get_connection(std::vector<evtl::connection> &conn)
	{
		m_connection_async.pushback(conn);
		m_connection_async.send();
	}

	int64_t get_session_count() const
	{
		return m_connection_async.atom_size() + m_sess_count;
	}

private:
	void connection_async_callback(evtl::queue_simpwasync<evtl::connection> &watcher, int revents)
	{
		if (&watcher != &m_connection_async)
			assert(false);

		evtl::connection  conn;
		if (!watcher.popfront(conn))
			return;
		if (conn.fd < 0)
			assert(false);

		watcher.send();

		sanpasession *psess = new sanpasession;
		psess->set_loop(m_loop);
		psess->set_connection(conn);
		psess->set_threadpool(&m_threadpool);
		psess->set_recycle_callback(std::bind(&sanpass::session_recycle, this, std::placeholders::_1));
		psess->set_local_interrupt(std::bind(&sanpass::local_interrupt, this, std::placeholders::_1));
		psess->set_linkconnector(m_ccb);
		psess->init();
		psess->set(m_loop);
		psess->set_callback();
		psess->set(conn.fd, ev::READ);
		psess->start();

		std::pair<std::unordered_set<sanpasession *>::const_iterator, bool> br = m_sessions.insert(psess);
		if (!br.second)
			assert(false && "insert failed");

		m_sess_count = m_sessions.size();
	}

	void timer_callback(evtl::simpwtimer &watcher, int revents)
	{
		if (&watcher != &m_timer)
			assert(false);

		for (std::unordered_set<sanpasession *>::iterator iter = m_sessions.begin(); iter != m_sessions.end(); )
		{
			sanpasession *p = *iter;
			if (p->needrecycle())
			{
				p->remove_from_threadpool();
				p->pullfin_notify();
				m_sessions.erase(iter++);
				m_sess_count = m_sessions.size();

				p->deinit();
				delete p;
			}
			else
			{
				++iter;
			}
		}
	}

	void session_recycle(sanpasession *psess)
	{
		size_t n = m_sessions.erase(psess);
		if (n <= 0)
			assert(false);

		m_sess_count = m_sessions.size();

		psess->deinit();
		delete psess;
	}

	bool local_interrupt(const evtl::itc::interrupt_message<pulllink> &msg)
	{
		if (msg.key == nullptr)
			assert(false);
		return true;
	}

private:
	int  m_id;
	pulllink::intr_connector  m_ccb;

	evtl::looprefer  m_loop;
	evtl::queue_simpwasync<evtl::connection>  m_connection_async;
	std::unordered_set<sanpasession *>   m_sessions;
	std::atomic<int64_t>  m_sess_count;
	evtl::simpwtimer   m_timer;

	evtl::thread::ptpc_threadpool<>   m_threadpool;
	threadpoolctrl  m_threadctrl;
};


#endif



