

#ifndef __PASSPROCESS_H__
#define __PASSPROCESS_H__

#include <evtl/evtl_com.h>
#include <evtl/evtl_linearbuf.h>

#include "passitf.h"
#include "parsedpasrequest.h"
#include "httpresponse.h"
#include "pulllinkcall.h"
#include "passession_baseinfo.h"
#include "passhttpbody.h"


class passprocess
{
public:
	passprocess()
		: m_sessbase(nullptr),
		m_nextstep(evtl::com::nextstep_unknown),
		m_recvbuf(1024*60)
	{}

	void set_sessbaseinfo(passess_baseinfo *info)
	{
		m_sessbase = info;
	}

	void process()
	{
		if (!m_request.got())
		{
			m_request.set_sessbase(m_sessbase);
			m_request.set_rcvbuf(m_recvbuf);
			pasrequest::searchres  res = m_request.search();
			if (res == pasrequest::searchres::success)
			{
				if (!m_request.got())
					assert(false);
			}
			else if (res == pasrequest::searchres::need_receive)
			{
				set_nextstep(evtl::com::nextstep_wait_to_receive);
				return;
			}
			else if (res == pasrequest::searchres::need_continue)
			{
				set_nextstep(evtl::com::nextstep_continue);
				return;
			}
			else if (res == pasrequest::searchres::error)
			{
				set_nextstep(evtl::com::nextstep_error);
				return;
			}
			else
			{
				assert(false);
				return;
			}
		}

		if (!m_parsed_request.is_parsed())
		{
			m_parsed_request.parse(m_request);
			if (!m_parsed_request.is_parsed())
				assert(false);
			m_parsed_request.check();
		}

		if (!m_parsed_request.is_valid())
		{
			if (!m_httpresponse.retdata_isset())
			{
				m_httpresponse.set_sessbase(m_sessbase);
				m_httpresponse.set_code(404);
				m_httpresponse.set_msg(m_parsed_request.get_errstr());
			}

			m_httpresponse.response();

			if (!m_httpresponse.finished())
				set_nextstep(evtl::com::nextstep_wait_to_send);
			else
				set_nextstep(evtl::com::nextstep_cycledone);
			return;
		}

		if (!m_linkcall.called())
		{
			m_linkcall.set_sessbase(m_sessbase);
			m_linkcall.set_request(m_parsed_request.get_requestinfo());
			if (!m_linkcall.call())
			{
				set_nextstep(evtl::com::nextstep_error);
				return;
			}
			set_nextstep(evtl::com::nextstep_other);
			return;
		}

		assert(false && "bad reach");
	}

	void process_inpool()
	{
		std::shared_ptr<pulllink> &linkptr = m_linkcall.get_linkptr();
		if (linkptr == nullptr)
			assert(false);

		if (!m_httpresponse.finished())
		{
			if (linkptr->m_got_header)
			{
				send_httpresponse(linkptr);
			}
			else
			{
				set_nextstep(evtl::com::nextstep_continue);
			}
			return;
		}

		if (!m_passbody.inited())
		{
			m_passbody.set_sessbase(m_sessbase);
			m_passbody.set_linkptr(m_linkcall.get_linkptr());
			m_passbody.init();
		}

		m_passbody.send();
		passhttpbody::sendresult result = m_passbody.get_result();
		if (result == passhttpbody::sendresult::needsend)
			set_nextstep(evtl::com::nextstep_wait_to_send);
		else if (result == passhttpbody::sendresult::over)
			set_nextstep(evtl::com::nextstep_cycledone);
		else if (result == passhttpbody::sendresult::error)
			set_nextstep(evtl::com::nextstep_error);
		else
			assert(false);
	}

	evtl::com::process_nextstep  get_nextstep() const
	{
		return m_nextstep;
	}

	void pullfin_notify()
	{
		std::shared_ptr<pulllink>  &ptr = m_linkcall.get_linkptr();
		if (ptr)
		{
			if (!ptr->m_local_fin)
			{
				ptr->m_local_fin = true;
				if (ptr->m_syn_ack)
				{
					if (!ptr->m_remote_fin)
						ptr->interrupt_remote(ptr, 0);
				}
			}
		}
	}

	void cycle_reset()
	{
		m_nextstep = evtl::com::nextstep_unknown;
		m_request.reset();
		m_parsed_request.reset();
		m_httpresponse.reset();
		m_linkcall.reset();
		m_passbody.reset();
	}

	void reset()
	{
		cycle_reset();
		m_recvbuf.clear();
	}

private:
	void set_nextstep(evtl::com::process_nextstep step)
	{
		m_nextstep = step;
	}

	void send_httpresponse(std::shared_ptr<pulllink> &linkptr)
	{
		if (!m_httpresponse.retdata_isset())
		{
			m_httpresponse.set_sessbase(m_sessbase);
			m_httpresponse.set_code(linkptr->m_code);
			m_httpresponse.set_content_range(linkptr->m_resp_rangestart, linkptr->m_resp_rangeend, linkptr->m_resp_totalsize);
			m_httpresponse.set_content_length(linkptr->m_content_length);
			m_httpresponse.set_msg("suen");
		}

		m_httpresponse.response();

		if (m_httpresponse.finished())
		{
			if (linkptr->m_code >= 200 && linkptr->m_code < 300)
				set_nextstep(evtl::com::nextstep_wait_to_send);
			else
				set_nextstep(evtl::com::nextstep_cycledone);
		}
		else
		{
			set_nextstep(evtl::com::nextstep_wait_to_send);
		}
	}

private:
	passess_baseinfo  *m_sessbase;
	evtl::com::process_nextstep  m_nextstep;

	evtl::linearbuf<char>  m_recvbuf;
	pasrequest   m_request;
	parsedpasrequest   m_parsed_request;
	httpresponse  m_httpresponse;
	pulllinkcall  m_linkcall;
	passhttpbody  m_passbody;
};


#endif


