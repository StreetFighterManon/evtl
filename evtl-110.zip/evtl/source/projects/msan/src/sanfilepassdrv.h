

#ifndef __SANFILEPASSDRV_H__
#define __SANFILEPASSDRV_H__

#include <evtl/evtl_eventloop.h>

#include "sanpass.h"
#include "pulllink.h"


class sanfilepassdrv
{
public:
	sanfilepassdrv(): m_id(0)
	{}

	void set_linkconnector(pulllink::intr_connector ccb)
	{
		m_sanpass.set_linkconnector(std::move(ccb));
	}

	void init(int id)
	{
		m_id = id;
		m_sanpass.set_loop(m_loop.ref());
		m_sanpass.init(id);
		m_sanpass.start();
	}

	void run_bg()
	{
		m_loop.run_loop(evtl::simpeventloop<evtl::dynamic_loop>::background_thread, "filepassdrv");
	}

	int64_t get_session_count() const
	{
		return m_sanpass.get_session_count();
	}

	void async_recvconn(std::vector<evtl::connection> &connections)
	{
		m_sanpass.async_get_connection(connections);
	}

private:
	int  m_id;
	evtl::simpeventloop<evtl::dynamic_loop>  m_loop;
	sanpass  m_sanpass;
};


#endif


