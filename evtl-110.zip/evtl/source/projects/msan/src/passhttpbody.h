

#ifndef __PASSHTTPBODY_H__
#define __PASSHTTPBODY_H__

#include <memory>

#include "passession_baseinfo.h"
#include "pulllink.h"


class passhttpbody
{
public:
	passhttpbody()
		: m_sessbase(nullptr),
		m_result(sendresult::unknown)
	{}

	enum class sendresult
	{
		unknown,
		needsend,
		over,
		error
	};

	void set_sessbase(passess_baseinfo *info)
	{
		m_sessbase = info;
	}

	void set_linkptr(const std::shared_ptr<pulllink> &ptr)
	{
		m_linkptr = ptr;
	}

	void init()
	{
		if (!m_linkptr->m_got_header)
			assert(false && "header invalid");

		m_inited = true;
	}

	bool inited() const
	{
		return m_inited;
	}

	void send()
	{
		m_result = sendresult::unknown;

		if (m_linkptr->m_send_len >= m_linkptr->m_content_length)
		{
			set_result(sendresult::over);
			return;
		}

		bool fin = m_linkptr->m_remote_fin;

		evtl::linearbuf<char> *buf = m_linkptr->m_buffer.get_consume();
		if (buf == nullptr)
		{
			if (!fin)
				set_result(sendresult::needsend);
			else
				set_result(sendresult::error);
			return;
		}

		ssize_t sz = buf->size();
		if (sz > 0)
		{
			ssize_t rt = m_sessbase->m_itf->pas_write(buf->dataptr(), sz);
			if (rt > 0)
			{
				if (rt > sz)
					assert(false);
				if (!buf->shit_whole(rt))
					assert(false);
				m_linkptr->m_send_len += rt;
			}
		}

		if (m_linkptr->m_send_len >= m_linkptr->m_content_length)
		{
			if (m_linkptr->m_send_len > m_linkptr->m_content_length)
				assert(false);

			set_result(sendresult::over);
		}
		else
		{
			if (buf->empty())
				m_linkptr->m_buffer.consume_complete(buf);
			set_result(sendresult::needsend);
		}
	}

	sendresult get_result() const
	{
		return m_result;
	}

	void reset()
	{
		m_linkptr.reset();
		m_inited.reset();
		m_result = sendresult::unknown;
	}

private:
	void set_result(sendresult result)
	{
		m_result = result;
	}

private:
	passess_baseinfo  *m_sessbase;
	std::shared_ptr<pulllink>  m_linkptr;
	evtl::boolflag<false>  m_inited;

	sendresult  m_result;
};


#endif


