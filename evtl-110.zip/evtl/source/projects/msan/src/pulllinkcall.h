

#ifndef __PULLLINKCALL_H__
#define __PULLLINKCALL_H__

#include <memory>

#include <evtl/evtl_uuid.h>

#include "pasrequest_info.h"
#include "pulllink.h"
#include "passession_baseinfo.h"


class pulllinkcall
{
public:
	pulllinkcall(): m_sessbase(nullptr)
	{}

	void set_sessbase(passess_baseinfo *info)
	{
		m_sessbase = info;
	}

	void set_request(const pasrequest_info &info)
	{
		m_request.set_assign(info);
	}

	bool call()
	{
		if (m_sessbase == nullptr)
			assert(false);
		if (!m_request.isset())
			assert(false);
		if (m_called)
			assert(false);

		pasrequest_info &info = m_request.refer();
		m_link = std::make_shared<pulllink>();

		m_link->m_filepath = info.m_filepath;
		m_link->m_rangestart = info.m_rangebyte_start;
		m_link->m_rangeend = info.m_rangebyte_end;
		m_link->init_buffer(3, 1024*1024);

		m_link->m_intconnector = m_sessbase->m_connector;
		m_link->m_id = evtl::uuid::generate_random();

		m_link->m_syn = true;
		m_link->m_local_port = 0;
		m_link->m_remote_port = 0;
		m_link->m_local_key = m_sessbase->m_sessptr;
		m_link->m_local_interrupt = m_sessbase->m_local_interrupt_cb;

		bool br = m_link->m_intconnector(m_link);
		m_called = true;
		return br;
	}

	bool called() const
	{
		return m_called;
	}

	std::shared_ptr<pulllink>& get_linkptr()
	{
		return m_link;
	}

	void reset()
	{
		m_request.reset();
		m_link.reset();
		m_called.reset();
	}

private:
	passess_baseinfo  *m_sessbase;
	evtl::st_var<pasrequest_info>  m_request;
	std::shared_ptr<pulllink>  m_link;

	evtl::boolflag<false>  m_called;
};


#endif


