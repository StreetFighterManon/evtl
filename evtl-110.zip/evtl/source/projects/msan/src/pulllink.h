

#ifndef __PULLLINK_H__
#define __PULLLINK_H__

#include <memory>

#include <evtl/evtl_itc.h>
#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_boundedbuf.h>
#include <evtl/evtl_linearbuf.h>


struct pulllink : public evtl::itc::baseprotocol<pulllink>
{
	pulllink()
	{
		m_heartbeat = false;
		m_code = 0;

		m_resp_rangestart = 0;
		m_resp_rangeend = 0;
		m_resp_totalsize = 0;

		m_received_len = 0;
		m_send_len = 0;
	}

	void init_buffer(int bufcount, ssize_t bufsize)
	{
		m_buffer.resize(bufcount);
		for (int i = 0; i < bufcount; i++)
		{
			m_buffer[i].elem().reset_capacity(bufsize);
		}
	}

	void response_prepare(int code, int64_t content_length, int64_t rangestart, int64_t rangeend, int64_t rangetotal)
	{
		m_code = code;
		m_resp_rangestart = rangestart;
		m_resp_rangeend = rangeend;
		m_resp_totalsize = rangetotal;
		m_content_length = content_length;
		m_got_header = true;

		m_received_len = 0;
	}

	bool  m_heartbeat;

	std::string  m_filepath;
	evtl::st_var<int64_t>  m_rangestart;
	evtl::st_var<int64_t>  m_rangeend;

	evtl::boolflag<false, true>  m_got_header;
	int      m_code;
	int64_t  m_resp_rangestart;
	int64_t  m_resp_rangeend;
	int64_t  m_resp_totalsize;
	int64_t  m_content_length;

	evtl::boundedbuf<evtl::linearbuf<char>>  m_buffer;
	std::atomic<int64_t>  m_received_len;
	std::atomic<int64_t>  m_send_len;
};


struct pulllink_ranid
{
	pulllink_ranid() = default;

	std::string  m_sanid;
	std::shared_ptr<pulllink>  m_pulllink;
};


struct pulllink_active
{
	pulllink_active() = default;

	void recovery()
	{
		m_httprequest.set_assign(m_httprequest_backup);
	}

	pulllink_ranid   m_link;
	evtl::dn_var<evtl::linearbuf<char>>  m_httprequest;
	evtl::linearbuf<char>  m_httprequest_backup;
};


#endif


