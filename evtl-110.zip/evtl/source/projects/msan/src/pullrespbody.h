

#ifndef __PULLRESPBODY_H__
#define __PULLRESPBODY_H__

#include <list>

#include "pulllink.h"
#include "pulliointerface.h"


class pullrespbody
{
public:
	pullrespbody(): m_ioinf(nullptr),m_recvbuf(nullptr), m_wrlink(nullptr),
		m_tempbuf(1024*1024*5),
		m_result(pullresult::unknown),
		m_code(0), m_content_length(0), m_received(0)
	{}

	enum class pullresult
	{
		unknown,
		wait_receive,
		only_continue,
		one_complete,
		error
	};

	void set_ioinf(pulliointerface *pinf)
	{
		m_ioinf = pinf;
	}

	void set_rlink(std::list<pulllink_active> *link)
	{
		m_wrlink = link;
	}

	void set_recvbuf(evtl::linearbuf<char> *buf)
	{
		m_recvbuf = buf;
	}

	void set_respinfo(int code, const std::string &sanid, int64_t content_length, int64_t rangestart, int64_t rangeend, int64_t rangetotal)
	{
		m_code = code;
		m_sanid = sanid;
		m_content_length = content_length;
		m_rangestart = rangestart;
		m_rangeend = rangeend;
		m_rangetotal = rangetotal;
	}

	void link_locate()
	{
		for (std::list<pulllink_active>::iterator iter = m_wrlink->begin(); iter != m_wrlink->end(); ++iter)
		{
			const std::string &ranid = iter->m_link.m_sanid;
			if (ranid == m_sanid)
			{
				m_current_link.valid_assign(iter->m_link);
				m_wrlink->erase(iter);

				m_ioinf->update_link_count();
				return;
			}
		}

		m_current_link.set_invalid();
		m_ioinf->update_link_count();
	}

	bool link_located() const
	{
		return !m_current_link.isunset();
	}

	void init_recv()
	{
		m_received = 0;
		if (m_current_link.isvalid())
		{
			std::shared_ptr<pulllink> &p = m_current_link.refer().m_pulllink;
			p->response_prepare(m_code, m_content_length, m_rangestart, m_rangeend, m_rangetotal);
		}
	}

	void handle()
	{
		set_result(pullresult::unknown);

		if (m_current_link.isunset())
			assert(false);

		if (m_current_link.isvalid())
			handle_atlink();
		else
			handle_pass();
	}

	pullresult get_handleresult() const
	{
		return m_result;
	}

	void handle_one_complete()
	{
		if (m_current_link.isvalid())
		{
			std::shared_ptr<pulllink> plink = m_current_link.refer().m_pulllink;
			if (plink->m_received_len < plink->m_content_length)
				assert(false);

			if (!plink->m_remote_fin)
			{
				plink->m_remote_fin = true;
				if (!plink->m_local_fin)
					plink->interrupt_local(plink, 0);
			}
		}

		m_current_link.reset();
		m_ioinf->update_link_count();

		m_tempbuf.clear();

		m_result = pullresult::unknown;

		m_code = 0;
		m_content_length = 0;
		m_sanid.clear();
		m_received = 0;
	}

	void handle_error()
	{
		if (m_current_link.isvalid())
		{
			std::shared_ptr<pulllink> plink = m_current_link.refer().m_pulllink;
			if (!plink->m_remote_fin)
			{
				plink->m_remote_fin = true;
				if (!plink->m_local_fin)
					plink->interrupt_local(plink, 0);
			}
		}

		m_current_link.reset();
		m_ioinf->update_link_count();

		m_tempbuf.clear();

		m_result = pullresult::unknown;

		m_code = 0;
		m_content_length = 0;
		m_sanid.clear();
		m_received = 0;
	}

private:
	void set_result(pullresult result)
	{
		m_result = result;
	}

	void handle_atlink()
	{
		std::shared_ptr<pulllink> &linkptr = m_current_link.refer().m_pulllink;
		if (linkptr->m_received_len > linkptr->m_content_length)
			assert(false);

		if (linkptr->m_received_len < linkptr->m_content_length)
		{
			if (linkptr->m_heartbeat)
			{
				receive_to_temp();
				return;
			}

			if (linkptr->m_local_fin)
			{
				receive_to_temp();
				return;
			}

			receive_to_link();
			return;
		}
		else
		{
			set_result(pullresult::one_complete);
		}
	}

	void handle_pass()
	{
		if (m_received > m_content_length)
			assert(false);

		if (m_received < m_content_length)
		{
			ssize_t sz = m_recvbuf->size();
			if (sz > m_content_length - m_received)
				sz = m_content_length - m_received;

			if (sz > 0)
			{
				if (!m_recvbuf->shit_whole(sz))
					assert(false);
				m_received += sz;
			}
		}

		if (m_received < m_content_length)
		{
			if (!m_recvbuf->empty())
				assert(false);
			if (!m_tempbuf.empty())
				assert(false);

			ssize_t left = m_content_length - m_received;
			ssize_t headsp = m_tempbuf.headspace();
			if (headsp != m_tempbuf.capacity())
				assert(false);
			ssize_t minsz = left > headsp ? headsp : left;

			ssize_t rt = m_ioinf->pul_read(m_tempbuf.headptr(), minsz);
			if (rt > 0)
			{
				if (rt > minsz)
					assert(false);
				m_received += rt;
				set_result(pullresult::only_continue);
			}
			else
			{
				set_result(pullresult::wait_receive);
			}
		}
		else
		{
			if (m_received > m_content_length)
				assert(false);
			set_result(pullresult::one_complete);
		}
	}

	void receive_to_link()
	{
		std::shared_ptr<pulllink> &linkptr = m_current_link.refer().m_pulllink;

		if (linkptr->m_received_len >= linkptr->m_content_length)
			assert(false);

		evtl::linearbuf<char> *buf = linkptr->m_buffer.get_produce();
		if (buf == nullptr)
		{
			set_result(pullresult::only_continue);
			return;
		}

		if (!buf->empty())
			assert(false);

		if (linkptr->m_received_len < linkptr->m_content_length)
		{
			ssize_t sz = m_recvbuf->size();
			if (sz > linkptr->m_content_length - linkptr->m_received_len)
				sz = linkptr->m_content_length - linkptr->m_received_len;

			if (sz > 0)
			{
				ssize_t rt = buf->eat(*m_recvbuf, sz, true);
				if (rt <= 0)
					assert(false);
				linkptr->m_received_len += rt;

				linkptr->m_buffer.produce_complete(buf);
				set_result(pullresult::only_continue);
				return;
			}
		}

		if (!m_recvbuf->empty())
			assert(false);

		if (linkptr->m_received_len < linkptr->m_content_length)
		{
			ssize_t sz = buf->headspace();
			if (sz > linkptr->m_content_length - linkptr->m_received_len)
				sz = linkptr->m_content_length - linkptr->m_received_len;
			if (sz <= 0)
				assert(false);

			ssize_t rt = m_ioinf->pul_read(buf->headptr(), sz);
			if (rt > 0)
			{
				if (rt > sz)
					assert(false);
				if (!buf->head_eaten_whole(rt))
					assert(false);

				linkptr->m_received_len += rt;
				linkptr->m_buffer.produce_complete(buf);
				set_result(pullresult::only_continue);
				return;
			}
			else
			{
				set_result(pullresult::wait_receive);
				return;
			}
		}
	}

	void receive_to_temp()
	{
		std::shared_ptr<pulllink> &linkptr = m_current_link.refer().m_pulllink;

		if (linkptr->m_received_len < linkptr->m_content_length)
		{
			ssize_t rsz = m_recvbuf->size();
			if (rsz > linkptr->m_content_length - linkptr->m_received_len)
				rsz = linkptr->m_content_length - linkptr->m_received_len;

			if (rsz > 0)
			{
				if (!m_recvbuf->shit_whole(rsz))
					assert(false);
				linkptr->m_received_len += rsz;
			}
		}

		if (linkptr->m_received_len < linkptr->m_content_length)
		{
			ssize_t sz = m_tempbuf.headspace();
			if (sz != m_tempbuf.capacity())
				assert(false);
			if (sz > linkptr->m_content_length - linkptr->m_received_len)
				sz = linkptr->m_content_length - linkptr->m_received_len;

			ssize_t rt = m_ioinf->pul_read(m_tempbuf.headptr(), sz);
			if (rt > 0)
			{
				if (rt > sz)
					assert(false);
				linkptr->m_received_len += rt;
			}
		}

		if (linkptr->m_received_len < linkptr->m_content_length)
			set_result(pullresult::wait_receive);
		else
			set_result(pullresult::one_complete);
	}

private:
	pulliointerface  *m_ioinf;
	evtl::linearbuf<char>  *m_recvbuf;
	std::list<pulllink_active>  *m_wrlink;

	evtl::statvar<pulllink_ranid>  m_current_link;
	evtl::linearbuf<char>   m_tempbuf;

	pullresult  m_result;

	int          m_code;
	std::string  m_sanid;

	int64_t      m_content_length;
	int64_t      m_rangestart;
	int64_t      m_rangeend;
	int64_t      m_rangetotal;

	int64_t      m_received;
};


#endif


