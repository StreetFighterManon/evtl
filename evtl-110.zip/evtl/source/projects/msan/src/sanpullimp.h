

#ifndef __SANPULLIMP_H__
#define __SANPULLIMP_H__

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_watcher_io.h>
#include <evtl/evtl_connector.h>
#include <evtl/evtl_watcher_timer.h>
#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_wasyncs.h>
#include <evtl/evtl_random.h>
#include <evtl/evtl_watcher_async.h>
#include <evtl/evtl_interface.h>
#include <evtl/evtl_threadpool.h>

#include "pullprocess.h"
#include "pulllink.h"
#include "pulliointerface.h"


class sanpullimp : public evtl::watcher_io<sanpullimp>,
	public evtl::itask,
	public pulliointerface
{
public:
	sanpullimp(): m_threadpool(nullptr), m_last_recvtime_s(0)
	{}

	void set_loop(evtl::looprefer loop)
	{
		m_loop = loop;
	}

	void start_pull()
	{
		if (!m_connector.is_idle())
			assert(false && "connector is not idle");

		m_reconnect_async.set(m_loop);
		m_reconnect_async.set_callback(std::bind(&sanpullimp::reconnect_async_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_reconnect_async.start();

		m_linkquerys.init();
		m_linkquerys.set(m_loop);
		m_linkquerys.set_callback(std::bind(&sanpullimp::knock_async_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_linkquerys.start();

		m_connector.set_loop(m_loop);
		m_connector.set_callback(std::bind(&sanpullimp::connect_callback, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3));
		bool br = m_connector.async_connect(evtl::makeipaddr("127.0.0.1", 2000));
		if (!br)
		{
			m_reconnect_timer.set(m_loop, 2 + m_loop.now_difference(), 0);
			m_reconnect_timer.set_callback(std::bind(&sanpullimp::reconnect_timer_callback, this, std::placeholders::_1, std::placeholders::_2));
			m_reconnect_timer.start();
		}
	}

	void set_threadpool(evtl::thread::ptpc_threadpool<> *pool)
	{
		m_threadpool = pool;
	}

	void init()
	{
		m_process.set_interface(this);
		m_process.set_links(&m_linkquerys);
		m_process.init();
	}

	ssize_t pul_read(void *buf, ssize_t nbytes) override
	{
		if (nbytes <= 0)
			assert(false);

		ssize_t sz = this->read(buf, nbytes);
		if (sz < 0)
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
			{
				m_rwstatus.orset(evtl::com::rwresult_read_error, errno);
			}
			return sz;
		}
		else if (sz == 0)
		{
			m_rwstatus.orset(evtl::com::rwresult_read_end, 0);
		}
		else
		{
			update_recvtime();

			if (sz > nbytes)
				assert(false);
		}

		return sz;
	}

	ssize_t pul_write(const void *buf, ssize_t nbytes) override
	{
		if (nbytes <= 0)
			assert(false);

		ssize_t sz = this->write(buf, nbytes);
		if (sz < 0)
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
			{
				m_rwstatus.orset(evtl::com::rwresult_write_error, errno);
			}
			return sz;
		}
		else if (sz == 0)
		{
			if (nbytes > 0)
				assert(false && "write 0");
		}
		else if (sz > nbytes)
		{
			assert(false && "write exception");
		}

		return sz;
	}

	void update_recvtime()
	{
		m_last_recvtime_s = evtl::timec::fast_sec();
	}

	int64_t get_last_recvtime_s() const
	{
		return m_last_recvtime_s;
	}

	void update_link_count() override
	{
		m_process.update_link_count();
	}

	int64_t get_task_count() const
	{
		int64_t n = m_linkquerys.atom_size() + m_process.get_linkcount();
		return n;
	}

	bool async_knock(std::shared_ptr<pulllink> datalink)
	{
		if (m_linkquerys.atom_size() >= 10)
			return false;

		datalink->m_remote_key = this;
		datalink->m_remote_interrupt = std::bind(&sanpullimp::pull_interrupt, this, std::placeholders::_1);
		datalink->m_syn_ack = true;

		pulllink_ranid pr;
		pr.m_sanid = evtl::rand::cclock::str_realtime();
		pr.m_pulllink = datalink;
		m_linkquerys.pushback(pr);
		m_linkquerys.send();

		return true;
	}

	bool pull_interrupt(const evtl::itc::interrupt_message<pulllink> &message)
	{
		return true;
	}

	void run(void *)
	{
		if (!m_thread_running)
			return;

		m_process.process();
		evtl::com::process_nextstep  nextstep = m_process.get_nextstep();

		if (recv_timeout())
		{
			cout<<"receive timeout, close and reconnect"<<endl;
			m_process.handle_error();
			m_thread_running = false;
			m_reconnect_async.send();
			return;
		}

		if (nextstep == evtl::com::nextstep_wait_to_receive)
		{
			if (m_rwstatus.readerror_raised())
			{
				m_process.handle_error();
				m_thread_running = false;
				m_reconnect_async.send();
			}
			return;
		}

		if (nextstep == evtl::com::nextstep_wait_to_send)
		{
			if (m_rwstatus.writeerror_raised())
			{
				m_process.handle_error();
				m_thread_running = false;
				m_reconnect_async.send();
			}
			return;
		}

		if (nextstep == evtl::com::nextstep_wait_to_receive_send)
		{
			if (m_rwstatus.error_raised())
			{
				m_process.handle_error();
				m_thread_running = false;
				m_reconnect_async.send();
			}
			return;
		}

		if (nextstep == evtl::com::nextstep_continue)
		{
			return;
		}

		if (nextstep == evtl::com::nextstep_error)
		{
			m_process.handle_error();
			m_thread_running = false;
			m_reconnect_async.send();
			return;
		}

		assert(false && "invalid result");
	}

private:
	void connect_callback(evtl::simpconnector &connector, int errcode, int errnocode)
	{
		if (connector.is_active())
			assert(false && "active connector");

		if (errcode != evtl::simpconnector::success)
		{
			cout << "connect 127.0.0.1:2000 failed, errnocode: " << errnocode <<endl;
			m_reconnect_timer.set(m_loop, 2 + m_loop.now_difference(), 0);
			m_reconnect_timer.set_callback(std::bind(&sanpullimp::reconnect_timer_callback, this, std::placeholders::_1, std::placeholders::_2));
			m_reconnect_timer.start();
		}
		else
		{
			cout << "connect 127.0.0.1:2000 success" << endl;

			int fd = connector.get_fd();
			if (fd < 0)
				assert(false && "invalid fd");
			connector.only_reset();

			this->set_fd(fd);
			if (m_inpool)
				assert(false && "is inpool");

			m_rwstatus.reset();
			m_last_recvtime_s = evtl::timec::fast_sec();

			const void *p = m_threadpool->add_task<>(this);
			if (!p)
				assert(false && "add failed");
			m_inpool = true;
			m_thread_running = true;
		}
	}

	void reconnect_timer_callback(evtl::simpwtimer &watcher, int revents)
	{
		if (&watcher != &m_reconnect_timer)
			assert(false && "unknown timer");

		watcher.stop();
		m_connector.set_loop(m_loop);
		m_connector.set_callback(std::bind(&sanpullimp::connect_callback, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3));
		bool br = m_connector.async_connect(evtl::makeipaddr("127.0.0.1", 2000));
		if (!br)
		{
			watcher.set(m_loop, 2 + m_loop.now_difference(), 0);
			watcher.start();
		}
	}

	void reconnect_async_callback(evtl::simpwasync &watcher, int revents)
	{
		const void *p = m_threadpool->remove_task(this);
		if (!p)
			assert(false);
		m_inpool = false;
		m_thread_running = false;

		m_rwstatus.reset();
		this->stop_close();
		if (!m_connector.is_idle())
			assert(false);

		m_reconnect_timer.set(m_loop, 2 + m_loop.now_difference(), 0);
		m_reconnect_timer.set_callback(std::bind(&sanpullimp::reconnect_timer_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_reconnect_timer.start();
	}

	void knock_async_callback(evtl::queue_simpwasync<pulllink_ranid> &watcher, int revents)
	{
		if (&watcher != &m_linkquerys)
			assert(false && "unknown watchers");
	}

	bool recv_timeout()
	{
		int64_t now_s = evtl::timec::fast_sec();
		if (now_s - m_last_recvtime_s >= 35 || now_s - m_last_recvtime_s <= -5)
			return true;
		return false;
	}

private:
	evtl::looprefer  m_loop;
	evtl::simpconnector  m_connector;
	evtl::simpwtimer  m_reconnect_timer;
	evtl::simpwasync  m_reconnect_async;

	evtl::queue_simpwasync<pulllink_ranid>   m_linkquerys;
	evtl::thread::ptpc_threadpool<>  *m_threadpool;
	evtl::boolflag<false>  m_inpool;
	evtl::boolflag<false, true>  m_thread_running;
	evtl::com::rwstatus    m_rwstatus;
	int64_t   m_last_recvtime_s;

	pullprocess   m_process;
};


#endif


