

#ifndef __SANFILEGET_H__
#define __SANFILEGET_H__

#include <evtl/evtl_eventloop.h>

#include "sanfilepass.h"
#include "sanpull.h"


class sanfileget
{
public:
	sanfileget()
	{}

	void init()
	{
		m_filepass.set_linkconnector(std::bind(&sanpull::pull_knockdoor, &m_pull, std::placeholders::_1));
		m_filepass.init();
		m_pull.init();
	}

	void run_bg()
	{
		m_filepass.run_bg();
		m_pull.run_bg();
	}

	void async_recvconn(std::vector<evtl::connection> &connections)
	{
		m_filepass.async_recvconn(connections);
	}

private:
	sanfilepass  m_filepass;
	sanpull      m_pull;
};


#endif


