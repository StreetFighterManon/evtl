

#ifndef __ACCEPTOR_H__
#define __ACCEPTOR_H__


namespace file
{

class acceptor
{
public:
	acceptor()
	{}
};

}

#endif


