

#include <unistd.h>

#include <iostream>
using namespace std;

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_acceptor.h>


void asc(evtl::tcp::simpacceptor &accptor, std::vector<evtl::connection> &connections)
{
	for (std::vector<evtl::connection>::iterator iter = connections.begin(); iter != connections.end(); ++iter)
	{
		evtl::connection conn = *iter;
		::close(conn.fd);
	}
}

int main()
{
	evtl::simpeventloop<>  loop;

	evtl::tcp::listener listener;
	listener.set_address("0.0.0.0", 1234);
	listener.listen(12);

	evtl::tcp::simpacceptor acceptor;
	acceptor.set_loop(loop.ref());
	acceptor.set_callback(std::bind(&asc, std::placeholders::_1, std::placeholders::_2));
	acceptor.set_listener(listener);
	acceptor.watch();

	loop.run_loop();

	return 0;
}


