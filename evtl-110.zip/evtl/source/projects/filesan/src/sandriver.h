

#ifndef __SANDIRVER_H__
#define __SANDIRVER_H__

#include <evtl/evtl_acceptor.h>
#include <evtl/evtl_eventloop.h>

#include "sanservice.h"


class sandriver
{
public:
	sandriver()
	{}

	void init()
	{
		m_service.set_loop(m_loop.ref());
		m_service.some_init();
	}

	void run_bg()
	{
		m_loop.run_loop(evtl::simpeventloop<evtl::dynamic_loop>::background_thread, "sandrv");
	}

	ssize_t get_session_count() const
	{
		return m_service.get_session_count();
	}

	void async_receive_connections(std::vector<evtl::connection> &conn)
	{
		m_service.async_receive_connections(conn);
	}

private:
	evtl::simpeventloop<evtl::dynamic_loop>  m_loop;

	sanservice  m_service;
};


#endif


