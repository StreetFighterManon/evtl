

#ifndef __REQUEST_H__
#define __REQUEST_H__

#include <string>
#include <sstream>

#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_pcre2.h>

#include "request_info.h"
#include "response_info.h"


class request
{
public:
	request()
	{}

	enum anares
	{
		success,
		failed,
	};

	bool received() const
	{
		if (m_request.empty())
			return false;
		return true;
	}

	anares search(evtl::linearbuf<char> &buf)
	{
		if (buf.empty())
			return failed;

		try
		{
			evtl::pcre2_8::regex  reg(R"(GET +(\S+) +HTTP/1..\r\n(.+?\r\n\r\n|\r\n))");
			evtl::pcre2_8::match_results<char>  matchs;
			bool br = evtl::pcre2_8::regex_search(buf.dataptr(), buf.dataptr() + buf.size(), matchs, reg, 10);
			if (br)
			{
				if (matchs.size() != 3)
					assert(false && "size unmatch");

				const evtl::pcre2_8::sub_match<char> &sub0 = matchs[0];
				const evtl::pcre2_8::sub_match<char> &sub1 = matchs[1];
				const evtl::pcre2_8::sub_match<char> &sub2 = matchs[2];

				if (!sub0.matched || !sub1.matched || !sub2.matched)
					assert(false && "sub unmatch");

				m_request.extens_store_whole(sub0.str());
				m_url = sub1.str();
				m_headers = sub2.str();

				ssize_t shits = sub0.second - buf.dataptr();
				if (shits < 0)
					assert(false && "negative search");

				if (!buf.shit_whole(shits))
					assert(false && "shit error");

				return success;
			}
		}
		catch (std::exception &e)
		{
			assert(false && "regex exception");
		}

		buf.shit_to(1024*8);
		return failed;
	}

	void parse()
	{
		if (m_parsed)
			assert(false && "parsed");

		try
		{
			evtl::pcre2_8::regex reg(R"(\A(/.*?)(?:\?(?:sanid=(\w+)|.+?&sanid=(\w+))?|\Z))");
			evtl::pcre2_8::match_results<char>  matches;
			bool br = evtl::pcre2_8::regex_search(m_url, matches, reg, 20);
			if (br)
			{
				if (matches.size() != 4)
					assert(false && "invalid size");

				const evtl::pcre2_8::sub_match<char> &sub1 = matches[1];
				const evtl::pcre2_8::sub_match<char> &sub2 = matches[2];
				const evtl::pcre2_8::sub_match<char> &sub3 = matches[3];

				if (!sub1.matched)
					assert(false && "sub1 unmatch");

				m_info.m_filepath.set_assign(sub1.str());
				if (sub2.matched)
					m_info.m_id = sub2.str();
				else if (sub3.matched)
					m_info.m_id = sub3.str();
			}

			evtl::pcre2_8::regex reg_range(R"(Range: *bytes=(\d+)-(\d*))");
			evtl::pcre2_8::match_results<char> range_matches;
			br = evtl::pcre2_8::regex_search(m_headers, range_matches, reg_range, 30);
			if (br)
			{
				if (range_matches.size() != 3)
					assert(false && "invalid matchs");

				const evtl::pcre2_8::sub_match<char>  &sub_start = range_matches[1];
				const evtl::pcre2_8::sub_match<char>  &sub_end = range_matches[2];
				if (!sub_start.matched || !sub_end.matched)
					assert(false && "not match");

				std::string strstart = sub_start.str();
				std::string strend = sub_end.str();

				if (strstart.empty())
					assert(false && "empty start");

				int64_t val = 0;
				std::stringstream ss;
				ss << strstart;
				ss >> val;

				m_info.m_start_bytes.set_assign(val);

				if (!strend.empty())
				{
					ss.str("");ss.clear();
					ss << strend;
					ss >> val;

					m_info.m_end_bytes.set_assign(val);
				}
			}
		}
		catch (std::exception &e)
		{
			assert(false && "regex exception");
		}

		m_parsed = true;
	}

	bool parsed() const
	{
		return m_parsed;
	}

	request_info get_request_info() const
	{
		return m_info;
	}

	void reset()
	{
		m_request.reset();
		m_url.clear();
		m_headers.clear();
		m_parsed.reset();
		m_info.reset();
	}

private:
	evtl::linearbuf<char>  m_request;
	std::string   m_url;
	std::string   m_headers;

	evtl::boolflag<false>  m_parsed;

	request_info  m_info;
};


class request_check
{
public:
	request_check()
	{}

	void set(request_info &&info)
	{
		m_info = info;
	}

	void check()
	{
		if (!m_info.m_filepath.isset() || m_info.m_filepath.refer().empty())
		{
			set_error(400, "no filepath");
			return;
		}

		if (m_info.m_start_bytes.isset())
		{
			if (m_info.m_start_bytes < 0)
			{
				set_error(400, "invalid range bytes");
				return;
			}

			if (m_info.m_end_bytes.isset())
			{
				if (m_info.m_end_bytes < m_info.m_start_bytes)
				{
					set_error(404, "range start is after end");
					return;
				}
			}
		}
	}

	bool is_ok() const
	{
		return m_ok;
	}

	const response_info& get_response_info() const
	{
		return m_response;
	}

	void reset()
	{
		m_info.reset();
		m_ok.reset();
		m_response.reset();
	}

private:
	void set_error(int code, const std::string &err)
	{
		m_ok = false;

		m_response.code = code;
		m_response.errmsg = err;
		m_response.id = m_info.m_id;
	}

private:
	request_info  m_info;

	evtl::boolflag<true>  m_ok;
	response_info  m_response;
};


#endif


