

#ifndef __FILEINFO_H__
#define __FILEINFO_H__

#include <sys/types.h>


struct fileinfo
{
	fileinfo(): fd(-1), totallen(0), readlen(0)
	{}

	void reset()
	{
		fd = -1;
		totallen = 0;
		readlen = 0;
	}

	int fd;
	ssize_t  totallen;
	ssize_t  readlen;
};


#endif


