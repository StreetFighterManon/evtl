

#ifndef __RESPONSE_INFO_H__
#define __RESPONSE_INFO_H__


struct response_info
{
	response_info()
		: code(0), range_start(0), range_end(0), total_length(0)
	{}

	void reset()
	{
		code = 0;
		errmsg.clear();
		range_start = 0;
		range_end = 0;
		total_length = 0;
		id.clear();
	}

	int code;
	std::string  errmsg;

	int64_t  range_start;
	int64_t  range_end;
	int64_t  total_length;

	std::string  id;
};


#endif


