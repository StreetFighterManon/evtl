

#include <iostream>
using namespace std;

#include <evtl/evtl_signal.h>
#include <evtl/evtl_time.h>

#include "sanservice_asm.h"


int main()
{
	evtl::signalc::sig_ignore(SIGPIPE);

	sanservice_asm *sam = new sanservice_asm;
	sam->init();
	sam->run();
	return 0;
}


