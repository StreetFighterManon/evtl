

#ifndef __FILESEND_H__
#define __FILESEND_H__

#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_boundedbuf.h>

#include "request_info.h"
#include "response_info.h"
#include "fileinfo.h"


class filesend
{
public:
	filesend()
	{}

	enum read_result
	{
		res_continue,
		res_finished,
		res_read_error
	};

	bool inited() const
	{
		return m_inited;
	}

	void set_sendbuf(evtl::boundedbuf<evtl::linearbuf<char>> &buf)
	{
		m_sendbuf = &buf;
	}

	void set_request(request_info &&info)
	{
		m_request = info;
	}

	void init_send()
	{
		m_inited = true;
		if (!m_request.m_filepath.isset())
		{
			set_error_response(400, "invalid filepath");
			return;
		}

		if (m_request.m_start_bytes.isset())
		{
			if (m_request.m_start_bytes < 0)
			{
				set_error_response(404, "invalid range");
				return;
			}

			if (m_request.m_end_bytes.isset())
			{
				if (m_request.m_start_bytes > m_request.m_end_bytes)
				{
					set_error_response(404, "invalid range");
					return;
				}
			}
		}

		std::stringstream ss;

		int fd = ::open(m_request.m_filepath.refer().c_str(), O_RDONLY);
		if (fd < 0)
		{
			ss << "open " << m_request.m_filepath.refer() << " failed";
			set_error_response(404, ss.str());
			return;
		}

		off_t filesize = ::lseek(fd, 0, SEEK_END);
		if (filesize < 0)
		{
			::close(fd);
			set_error_response(404, "seektoend failed");
			return;
		}

		off_t off = 0;
		if (m_request.m_start_bytes.isset())
		{
			if (m_request.m_start_bytes >= filesize)
			{
				::close(fd);
				set_error_response(404, "out of range");
				return;
			}

			off = ::lseek(fd, m_request.m_start_bytes, SEEK_SET);
			if (off != m_request.m_start_bytes)
			{
				::close(fd);
				ss << "seekto " << m_request.m_start_bytes << " failed";
				set_error_response(404, ss.str());
				return;
			}
		}
		else
		{
			off = ::lseek(fd, 0, SEEK_SET);
			if (off != 0)
			{
				::close(fd);
				ss << "seekto 0 failed";
				set_error_response(404, ss.str());
				return;
			}
		}

		m_fileinfo.fd = fd;
		m_fileinfo.readlen = 0;

		if (!m_request.m_end_bytes.isset())
		{
			m_fileinfo.totallen = filesize - off;
		}
		else
		{
			if (m_request.m_end_bytes < filesize)
				m_fileinfo.totallen = m_request.m_end_bytes - off + 1;
			else
				m_fileinfo.totallen = filesize - off;
		}

		if (m_request.m_start_bytes.isset())
		{
			if (m_request.m_start_bytes > 0 || m_request.m_end_bytes.isset())
			{
				set_succ_response(206, off, off + m_fileinfo.totallen - 1, filesize);
				m_init_succ = true;
				return;
			}
		}

		set_succ_response(200, off, off + m_fileinfo.totallen - 1, filesize);
		m_init_succ = true;
	}

	bool init_success() const
	{
		return m_init_succ;
	}

	response_info get_response_info() const
	{
		return m_response;
	}

	read_result readfile()
	{
		if (m_sendbuf == nullptr)
			assert(false && "null sendbuf");
		if (m_fileinfo.fd == -1)
			assert(false && "invalid fd");

		if (!_read())
		{
			return res_read_error;
		}

		if (_send_finished())
		{
			return res_finished;
		}

		return res_continue;
	}

	void deinit()
	{
		m_inited.reset();
		m_sendbuf = nullptr;
		m_request.reset();
		m_response.reset();
		m_init_succ.reset();
		if (m_fileinfo.fd != -1)
			::close(m_fileinfo.fd);
		m_fileinfo.reset();
	}

private:
	void set_error_response(int code, const std::string &err)
	{
		m_response.code = code;
		m_response.errmsg = err;
		m_response.id = m_request.m_id;
	}

	void set_succ_response(int code, ssize_t start, ssize_t end, ssize_t length)
	{
		m_response.code = code;
		m_response.range_start = start;
		m_response.range_end = end;
		m_response.total_length = length;
		m_response.id = m_request.m_id;
	}

	bool _read()
	{
		ssize_t rest = m_fileinfo.totallen - m_fileinfo.readlen;
		if (rest > 0)
		{
			evtl::linearbuf<char> *buf = m_sendbuf->get_produce();
			if (buf == nullptr)
				return true;
			buf->crowdac(32*1024, 12*1024);

			ssize_t space = buf->headspace();
			if (space <= 0)
			{
				m_sendbuf->produce_complete(buf);
				return true;
			}

			ssize_t readsz = rest > space ? space : rest;
			ssize_t rd = ::read(m_fileinfo.fd, buf->headptr(), readsz);
			if (rd < 0)
			{
				if (errno != EINTR)
				{
					if (!buf->empty())
						m_sendbuf->produce_complete(buf);
					return false;
				}
			}
			else if (rd == 0)
			{
				if (!buf->empty())
					m_sendbuf->produce_complete(buf);
				return false;
			}
			else
			{
				if (rd > readsz)
					assert(false && "read exception");
				if (!buf->head_eaten_whole(rd))
					assert(false && "head eaten failed");
				m_sendbuf->produce_complete(buf);
				m_fileinfo.readlen += rd;
			}
		}

		return true;
	}

	bool _send_finished()
	{
		if (m_fileinfo.readlen >= m_fileinfo.totallen && m_sendbuf->get_consume() == nullptr)
			return true;
		return false;
	}

private:
	evtl::boolflag<false>  m_inited;

	evtl::boundedbuf<evtl::linearbuf<char>>  *m_sendbuf;
	request_info   m_request;
	response_info  m_response;
	evtl::boolflag<false>  m_init_succ;

	fileinfo  m_fileinfo;
};


#endif


