

#ifndef __SANSERVICE_H__
#define __SANSERVICE_H__

#include <unordered_set>
#include <atomic>

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_watcher_timer.h>
#include <evtl/evtl_wasyncs.h>
#include <evtl/evtl_gcc.h>

#include "sansession.h"


class sanservice
{
public:
	sanservice(): m_loop(nullptr), m_sesscount(0)
	{}

	void set_loop(evtl::looprefer loop)
	{
		m_loop = loop;
	}

	void some_init()
	{
		m_timer.set(m_loop);
		m_timer.set_callback(std::bind(&sanservice::timer_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_timer.set_repeat(10);
		m_timer.again();

		m_connrecv_async.init();
		m_connrecv_async.set(m_loop);
		m_connrecv_async.set_callback(std::bind(&sanservice::connrecv_async_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_connrecv_async.start();
	}

	void async_receive_connections(std::vector<evtl::connection> &connections)
	{
		m_connrecv_async.pushback(connections);
		gcc_thread_fence;
		m_connrecv_async.send();
	}

	ssize_t get_session_count() const
	{
		return m_sesscount + m_connrecv_async.atom_size();
	}

private:
	void recycle_session(sansession *psess)
	{
		if (psess == nullptr)
			assert(false && "invalid sess");

		ssize_t n = m_sessions.erase(psess);
		if (n <= 0)
			assert(false && "erase failed");
		m_sesscount = m_sessions.size();

		psess->deinit();
		delete psess;
	}

private:
	void timer_callback(evtl::simpwtimer &watcher, int revents)
	{
		if (&watcher != &m_timer)
			assert(false);
	}

	void connrecv_async_callback(evtl::queue_simpwasync<evtl::connection> &watcher, int revents)
	{
		if (&watcher != &m_connrecv_async)
			assert(false);

		evtl::connection  conn;
		if (!m_connrecv_async.popfront(conn))
			return;

		sansession *sess = new sansession;

		sess->set(m_loop);
		sess->set_callback();
		sess->set_recycle_callback(std::bind(&sanservice::recycle_session, this, std::placeholders::_1));
		sess->set(conn.fd, ev::READ);
		sess->start();

		std::pair<std::unordered_set<sansession *>::const_iterator, bool> br = m_sessions.insert(sess);
		if (!br.second)
			assert(false && "insert failed");
		m_sesscount = m_sessions.size();

		watcher.send();
	}

private:
	evtl::looprefer  m_loop;

	std::unordered_set<sansession *>  m_sessions;
	std::atomic<ssize_t>  m_sesscount;

	evtl::simpwtimer  m_timer;
	evtl::queue_simpwasync<evtl::connection>  m_connrecv_async;
};


#endif


