

#ifndef __ACCEPTOR_H__
#define __ACCEPTOR_H__

#include <functional>

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_acceptor.h>


class acceptor
{
public:
	acceptor()
	{}

	typedef std::function<void (acceptor &acpt, std::vector<evtl::connection> &connections)>  accept_callback_t;

	void init()
	{
		m_listener.set_address(evtl::makeipaddr("0.0.0.0", 2000));
		m_listener.tcplisten(3);
	}

	void set_callback(accept_callback_t cb)
	{
		m_accept_cb = std::move(cb);
	}

	void start()
	{
		m_acceptor.set_loop(m_loop.ref());
		m_acceptor.set_listener(&m_listener);
		m_acceptor.set_callback(std::bind(&acceptor::_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_acceptor.watch();
	}

	void run()
	{
		m_loop.run_loop(evtl::simpeventloop<evtl::dynamic_loop>::current_thread);
	}

private:
	void _callback(evtl::simpacceptor &accpt, std::vector<evtl::connection> &connections)
	{
		if (&accpt != &m_acceptor)
			assert(false && "unexpected acceptor");

		m_accept_cb(*this, connections);
	}

private:
	evtl::simpeventloop<evtl::dynamic_loop>  m_loop;

	accept_callback_t   m_accept_cb;

	evtl::listener      m_listener;
	evtl::simpacceptor  m_acceptor;
};


#endif


