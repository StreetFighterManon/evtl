

#ifndef __HTTPRESPONSE_H__
#define __HTTPRESPONSE_H__

#include <string>
#include <sstream>

#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_wrapper.h>


class httpresponse
{
public:
	httpresponse()
		: m_sendbufs(nullptr),
		m_range_start(0), m_range_end(0), m_total_length(0)
	{}

	bool finished() const
	{
		return m_finished;
	}

	bool is_prepared() const
	{
		return m_code.isset();
	}

	void set_sendbuf(evtl::boundedbuf<evtl::linearbuf<char>> &buf)
	{
		m_sendbufs = &buf;
	}

	void set_response(int code, const std::string &errmsg)
	{
		m_code.set_assign(code);
		m_errmsg = errmsg;
	}

	void set_range(int64_t range_start, int64_t range_end, int64_t total_length)
	{
		m_range_start = range_start;
		m_range_end = range_end;
		m_total_length = total_length;
	}

	void set_sanid(const std::string &sanid)
	{
		m_sanid = sanid;
	}

	void push_response()
	{
		if (m_sendbufs == nullptr)
			assert(false && "null sendbuf");
		if (!m_code.isset())
			assert(false && "unprepared");

		if (!m_response.isset())
		{
			std::stringstream ss;

			if (m_code >= 200 && m_code < 300)
			{
				ss << "HTTP/1.1 " << m_code.refer() << " " << description(m_code) << "\r\n"
					<< "Server: fans\r\n"
					<< "Accept-Ranges: bytes\r\n"
					<< "Content-Range: bytes " << m_range_start << "-" << m_range_end << "/" << m_total_length << "\r\n"
					<< "sanid: " << m_sanid << "\r\n"
					<< "Content-Length: " << content_length() << "\r\n"
					<< "Connection: keep-alive\r\n"
					<< "\r\n";
			}
			else if (m_code >= 400 && m_code < 500)
			{
				ss << "HTTP/1.1 " << m_code.refer() << " " << description(m_code) << "\r\n"
					<< "Server: fans\r\n"
					<< "Content-Length: 0\r\n"
					<< "sanid: " << m_sanid << "\r\n"
					<< "message: " << m_errmsg << "\r\n"
					<< "Connection: keep-alive\r\n"
					<< "\r\n";
			}
			else
			{
				assert(false && "invalid httpcode");
			}

			std::string str = ss.str();
			m_response.refer().extens_store_whole(str);
			m_response.set();
		}

		evtl::linearbuf<char> &resp = m_response.refer();
		if (!resp.empty())
		{
			evtl::linearbuf<char> *sbuf = m_sendbufs->get_produce();
			if (sbuf != nullptr)
			{
				sbuf->eat(resp, 0, true);
				m_sendbufs->produce_complete(sbuf);
			}
		}

		if (m_sendbufs->get_consume() == nullptr)
		{
			if (!resp.empty())
				assert(false && "buf error");

			m_finished = true;
		}
	}

	void reset()
	{
		m_sendbufs = nullptr;
		m_code.reset();
		m_errmsg.clear();

		m_range_start = 0;
		m_range_end = 0;
		m_total_length = 0;
		m_response.reset();
		m_finished.reset();
	}

private:
	static std::string description(int code)
	{
		switch (code)
		{
		case 200:
			return "OK";
		case 206:
			return "Partial";
		case 400:
			return "Bad Request";
		case 404:
			return "Not Found";
		}

		return "Unknown";
	}

	int64_t content_length() const
	{
		int64_t len = m_range_end - m_range_start + 1;
		if (len > 0)
			return len;
		return 0;
	}

private:
	evtl::boundedbuf<evtl::linearbuf<char>>  *m_sendbufs;

	evtl::st_var<int>   m_code;
	std::string   m_errmsg;

	int64_t  m_range_start;
	int64_t  m_range_end;
	int64_t  m_total_length;
	std::string  m_sanid;
	evtl::dn_var<evtl::linearbuf<char>>  m_response;

	evtl::boolflag<false>  m_finished;
};


#endif


