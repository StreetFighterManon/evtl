

#ifndef __SANSERVICE_ASM_H__
#define __SANSERVICE_ASM_H__

#include <vector>

#include "sandriver.h"
#include "acceptor.h"


class sanservice_asm
{
public:
	sanservice_asm()
	{}

	void init()
	{
		for (int i = 0; i < 2; i++)
		{
			sandriver *pserv = new sandriver;
			pserv->init();
			m_services.push_back(pserv);
		}

		m_acceptor.init();
		m_acceptor.set_callback(std::bind(&sanservice_asm::accept_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_acceptor.start();
	}

	void run()
	{
		for (std::vector<sandriver *>::const_iterator iter = m_services.begin(); iter != m_services.end(); ++iter)
		{
			sandriver *p = *iter;
			p->run_bg();
		}

		m_acceptor.run();
	}

private:
	void accept_callback(acceptor &accpt, std::vector<evtl::connection> &connections)
	{
		if (&accpt != &m_acceptor)
			assert(false);

		ssize_t session_count = -1;
		sandriver  *psrv = nullptr;

		for (std::vector<sandriver *>::const_iterator iter = m_services.begin(); iter != m_services.end(); ++iter)
		{
			sandriver *p = *iter;
			if (p == nullptr)
				assert(false && "null driver");

			ssize_t count = p->get_session_count();

			if (psrv == nullptr)
			{
				session_count = count;
				psrv = p;
			}
			else
			{
				if (count < session_count)
				{
					session_count = count;
					psrv = p;
				}
			}
		}

		if (psrv == nullptr)
			assert(false && "found sandriver failed");

		psrv->async_receive_connections(connections);
	}

private:
	std::vector<sandriver *>  m_services;
	acceptor  m_acceptor;
};


#endif


