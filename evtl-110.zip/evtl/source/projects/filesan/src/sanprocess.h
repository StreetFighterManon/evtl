

#ifndef __SANPROCESS_H__
#define __SANPROCESS_H__

#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_com.h>
#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_boundedbuf.h>

#include "request.h"
#include "httpresponse.h"
#include "filesend.h"


class sanprocess
{
public:
	sanprocess()
		: m_recvbuf(1024*32),
		m_sendbufs(2),
		m_nextstep(evtl::com::nextstep_unknown)
	{
		for (ssize_t i = 0; i < m_sendbufs.size(); i++)
		{
			evtl::linearbuf<char> &buf = m_sendbufs[i].elem();
			buf.reset_capacity(1024*1024);
		}
	}

	evtl::linearbuf<char>& recvbuf()
	{
		return m_recvbuf;
	}

	evtl::boundedbuf<evtl::linearbuf<char>>& sendbuf()
	{
		return m_sendbufs;
	}

	void process()
	{
		if (!m_request.received())
		{
			request::anares rslt = m_request.search(m_recvbuf);
			if (rslt == request::failed)
			{
				set_nextstep(evtl::com::nextstep_wait_to_receive);
				return;
			}

			if (!m_request.received())
				assert(false && "not recieved");
		}

		if (!m_request.parsed())
		{
			m_request.parse();
			if (!m_request.parsed())
				assert(false && "unparsed");

			m_requestcheck.set(m_request.get_request_info());
			m_requestcheck.check();
		}

		if (!m_requestcheck.is_ok())
		{
			push_error_response(m_requestcheck.get_response_info());
			return;
		}

		handle_request();
	}

	evtl::com::process_nextstep get_nextstep() const
	{
		return m_nextstep;
	}

	void cycle_reset()
	{
		m_nextstep = evtl::com::nextstep_unknown;
		m_request.reset();
		m_requestcheck.reset();
		m_response.reset();
		m_filesend.deinit();
	}

	void reset()
	{
		m_recvbuf.reset();
		m_sendbufs.reset();
		m_nextstep = evtl::com::nextstep_unknown;
		m_request.reset();
		m_requestcheck.reset();
		m_response.reset();
		m_filesend.deinit();
	}

private:
	void handle_request()
	{
		if (!m_filesend.inited())
		{
			m_filesend.set_sendbuf(m_sendbufs);
			m_filesend.set_request(m_request.get_request_info());
			m_filesend.init_send();

			if (!m_filesend.inited())
				assert(false && "uninit");
		}

		if (!m_filesend.init_success())
		{
			push_error_response(m_filesend.get_response_info());
			return;
		}
		else
		{
			if (!m_response.finished())
			{
				push_success_response(m_filesend.get_response_info());
				if (!m_response.finished())
				{
					set_nextstep(evtl::com::nextstep_wait_to_send);
					return;
				}
			}

			filesend::read_result re = m_filesend.readfile();
			switch (re)
			{
			case filesend::res_continue:
				set_nextstep(evtl::com::nextstep_wait_to_send);
				break;
			case filesend::res_finished:
				set_nextstep(evtl::com::nextstep_cycledone);
				break;
			case filesend::res_read_error:
				set_nextstep(evtl::com::nextstep_error);
				break;
			default:
				assert(false && "invalid result");
				break;
			}
		}
	}

private:
	void set_nextstep(evtl::com::process_nextstep nextstep)
	{
		m_nextstep = nextstep;
	}

	void push_error_response(const response_info &info)
	{
		if (!m_response.finished())
		{
			if (!m_response.is_prepared())
			{
				m_response.set_sendbuf(m_sendbufs);
				m_response.set_response(info.code, info.errmsg);
				m_response.set_sanid(info.id);
			}
			m_response.push_response();
		}
		if (!m_response.finished())
			set_nextstep(evtl::com::nextstep_wait_to_send);
		else
			set_nextstep(evtl::com::nextstep_cycledone);
	}

	void push_success_response(const response_info &info)
	{
		if (!m_response.is_prepared())
		{
			m_response.set_sendbuf(m_sendbufs);
			m_response.set_response(info.code, info.errmsg);
			m_response.set_range(info.range_start, info.range_end, info.total_length);
			m_response.set_sanid(info.id);
		}
		m_response.push_response();
	}

private:
	evtl::linearbuf<char>  m_recvbuf;
	evtl::boundedbuf<evtl::linearbuf<char>>  m_sendbufs;

	evtl::com::process_nextstep  m_nextstep;

	request   m_request;
	request_check  m_requestcheck;

	httpresponse  m_response;
	filesend    m_filesend;
};


#endif


