

#ifndef __REQUEST_INFO_H__
#define __REQUEST_INFO_H__

#include <cstdint>
#include <string>
#include <evtl/evtl_wrapper.h>


struct request_info
{
	request_info()
	{}

	void reset()
	{
		m_filepath.reset();
		m_id.clear();
		m_start_bytes.reset();
		m_end_bytes.reset();
	}

	evtl::st_var<std::string>  m_filepath;
	std::string  m_id;
	evtl::st_var<int64_t>  m_start_bytes;
	evtl::st_var<int64_t>  m_end_bytes;
};


#endif


