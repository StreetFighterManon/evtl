

#ifndef __SANSESSION_H__
#define __SANSESSION_H__

#include <functional>
#include <utility>

#include <evtl/evtl_watcher_io.h>
#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_com.h>

#include "sanprocess.h"


class sansession : public evtl::watcher_io<sansession>
{
public:
	sansession()
	{}

	typedef std::function<void (sansession *sess)>  recycle_callback_t;

	void set_recycle_callback(recycle_callback_t cb)
	{
		m_recycle_cb = std::move(cb);
	}

	void io_callback(sansession &watcher, int revents)
	{
		if (&watcher != this)
			assert(false && "invalid watcher");

		evtl::linearbuf<char>  &recvbuf = m_process.recvbuf();
		evtl::boundedbuf<evtl::linearbuf<char>>  &sendbuf = m_process.sendbuf();

		if ((revents & ev::READ) != 0)
		{
			recvbuf.crowdct(1024*8, 1024*8);

			ssize_t headsize = recvbuf.headspace();
			if (headsize > 0)
			{
				ssize_t rn = this->read(recvbuf.headptr(), headsize);
				if (rn > 0)
				{
					if (rn > headsize)
						assert(false && "read except");
					if (!recvbuf.head_eaten_whole(rn))
						assert(false && "head eaten failed");
				}
				else if (rn < 0)
				{
					if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
					{
						m_rwstat.orset(evtl::com::rwresult_read_error, errno);
					}
				}
				else
				{
					m_rwstat.orset(evtl::com::rwresult_read_end, 0);
				}
			}
		}

		if ((revents & ev::WRITE) != 0)
		{
			evtl::linearbuf<char> *sbuf = sendbuf.get_consume();
			if (sbuf != nullptr)
			{
				ssize_t datasz = sbuf->size();
				if (datasz > 0)
				{
					ssize_t wn = this->write(sbuf->dataptr(), datasz);
					if (wn > 0)
					{
						if (wn > datasz)
							assert(false && "write exception");
						if (!sbuf->shit_whole(wn))
							assert(false && "shit error");
					}
					else if (wn < 0)
					{
						if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
						{
							m_rwstat.orset(evtl::com::rwresult_write_error, errno);
						}
					}
					else
					{
						assert(false && "write zero");
					}
				}

				if (sbuf->empty())
					sendbuf.consume_complete(sbuf);
			}
		}

		if (m_rwstat.error_raised())
		{
			watcher.stop();
			m_recycle_cb(this);
			return;
		}

		m_process.process();

		evtl::com::process_nextstep  nextstep = m_process.get_nextstep();
		switch (nextstep)
		{
		case evtl::com::nextstep_wait_to_receive:
			{
				if (watcher.get_events() != ev::READ)
				{
					watcher.stop();
					watcher.set_events(ev::READ);
					watcher.start();
				}
			}
			break;
		case evtl::com::nextstep_wait_to_send:
			{
				if (watcher.get_events() != ev::WRITE)
				{
					watcher.stop();
					watcher.set_events(ev::WRITE);
					watcher.start();
				}
			}
			break;
		case evtl::com::nextstep_cycledone:
			{
				m_process.cycle_reset();
				m_rwstat.reset();
				if (watcher.get_events() != ev::WRITE)
				{
					watcher.stop();
					watcher.set_events(ev::WRITE);
					watcher.start();
				}
			}
			break;
		case evtl::com::nextstep_error:
			{
				watcher.stop();
				m_recycle_cb(this);
			}
			break;
		default:
			assert(false && "invalid step");
			break;
		};
	}

	void deinit()
	{
		this->stop_close();
		m_process.reset();
		m_rwstat.reset();
	}

private:
	recycle_callback_t  m_recycle_cb;

	sanprocess   m_process;
	evtl::com::rwstatus  m_rwstat;
};


#endif


