

#ifndef __PROCESS2_H__
#define __PROCESS2_H__

#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_linearbuf.h>

#include "sessionbase.h"


class process2
{
public:
	process2()
	{
		m_sessbase = nullptr;
	}

	void set_sessbase(sessionbase *base)
	{
		m_sessbase = base;
	}

	bool is_active()
	{
		return m_buf.isset();
	}

	void set(const std::string &s)
	{
		m_buf.refer().extens_store_whole(s);
		m_buf.set();
	}

	void sendww()
	{
		if (!m_buf.isset())
			assert(false);

		evtl::linearbuf<char> &buf = m_buf.refer();
		ssize_t size = buf.size();
		if (size > 0)
		{
			ssize_t rt = m_sessbase->m_ioitf->io_write(buf.dataptr(), buf.size());
			if (rt > 0)
			{
				if (!buf.shit_whole(rt))
					assert(false);
			}
		}
	}

	bool finished()
	{
		if (!m_buf.isset())
			return true;
		if (m_buf.refer().empty())
			return true;
		return false;
	}

	void reset()
	{
		m_buf.reset();
	}

private:
	sessionbase  *m_sessbase;
	evtl::var<evtl::linearbuf<char>>  m_buf;
};


#endif


