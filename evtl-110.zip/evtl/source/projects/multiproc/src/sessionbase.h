

#ifndef __SESSIONBASE_H__
#define __SESSIONBASE_H__


struct iointerface
{
	virtual ~iointerface()
	{}

	virtual ssize_t io_read(void *buf, size_t n) = 0;

	virtual ssize_t io_write(const void *buf, size_t n) = 0;
};


struct sessionbase
{
	sessionbase()
	{
		m_ioitf = nullptr;
	}

	iointerface  *m_ioitf;
};


#endif


