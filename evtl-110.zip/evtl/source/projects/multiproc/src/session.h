

#ifndef __SESSION_H__
#define __SESSION_H__

#include <evtl/evtl_watcher_io.h>
#include <evtl/evtl_com.h>
#include <evtl/evtl_watcher_timer.h>

#include "request.h"
#include "response.h"
#include "process2.h"
#include "sessionbase.h"


class session : public evtl::watcher_io<session>, public iointerface
{
public:
	session(): m_recvbuf(1024*10)
	{
		m_step1 = evtl::com::nextstep_unknown;
		m_step2 = evtl::com::nextstep_unknown;
		m_finalstep = evtl::com::nextstep_unknown;
	}

	typedef std::function<void (session *psess)>  recycle_callback_t;

	void set_loop(evtl::looprefer loop)
	{
		m_loop = loop;
	}

	void set_recycle_callback(recycle_callback_t cb)
	{
		m_recycle_cb = std::move(cb);
	}

	void init()
	{
		m_base.m_ioitf = this;

		m_timer.set(m_loop, 0., 10.);
		m_timer.set_callback(std::bind(&session::timer_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_timer.again();
	}

	ssize_t io_read(void *buf, size_t n) override
	{
		if (buf == nullptr || n <= 0)
			assert(false);

		ssize_t rt = this->read(buf, n);
		if (rt < 0)
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
				m_iostatus.orset(evtl::com::rwresult_read_error, errno);
		}
		else if (rt == 0)
		{
			m_iostatus.orset(evtl::com::rwresult_read_end, 0);
		}

		return rt;
	}

	ssize_t io_write(const void *buf, size_t n)
	{
		if (buf == nullptr || n <= 0)
			assert(false);

		ssize_t rt = this->write(buf, n);
		if (rt < 0)
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
				m_iostatus.orset(evtl::com::rwresult_write_error, errno);
		}
		else if (rt == 0)
		{
			assert(false);
		}

		return rt;
	}

	void io_callback(session &watcher, int revents)
	{
		if (&watcher != this)
			assert(false);

		process();

		if (m_iostatus.error_raised())
		{
			stop();
			m_recycle_cb(this);
			return;
		}

		evtl::com::process_nextstep step = get_nextstep();
		switch (step)
		{
		case evtl::com::nextstep_wait_to_receive:
			{
				active_event(ev::READ);
			}
			break;
		case evtl::com::nextstep_wait_to_send:
			{
				active_event(ev::WRITE);
			}
			break;
		case evtl::com::nextstep_wait_to_receive_send:
			{
				active_event(ev::READ|ev::WRITE);
			}
			break;
		case evtl::com::nextstep_continue:
			{
				if ((get_events() & ev::WRITE) == 0)
				{
					stop();
					set_events(ev::WRITE);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
			}
			break;
		case evtl::com::nextstep_error:
			{
				stop();
				m_recycle_cb(this);
				return;
			}
			break;
		default:
			assert(false);
			break;
		}
	}

	void deinit()
	{
		stop_close();
		m_timer.stop();
	}

private:
	evtl::com::process_nextstep get_nextstep()
	{
		return m_finalstep;
	}

	void process()
	{
		m_step1 = evtl::com::nextstep_unknown;
		m_step2 = evtl::com::nextstep_unknown;
		m_finalstep = evtl::com::nextstep_unknown;

		process_one();
		process_two();

		if (m_step1 == evtl::com::nextstep_cycledone)
			cycle_reset1();
		if (m_step2 == evtl::com::nextstep_cycledone)
			cycle_reset2();

		final_nextstep();
	}

	void process_one()
	{
		if (!m_request.got())
		{
			m_request.set_sessbase(&m_base);
			m_request.set_recvbuf(&m_recvbuf);
			int ret = m_request.search();
			switch (ret)
			{
			case -1:
				{
					set_nextstep1(evtl::com::nextstep_error);
					return;
				}
				break;
			case 1:
				{
					set_nextstep1(evtl::com::nextstep_continue);
					return;
				}
				break;
			case 2:
				{
					set_nextstep1(evtl::com::nextstep_wait_to_receive);
					return;
				}
				break;
			default:
				break;
			}

			if (ret != 0)
				assert(false);
		}

		if (!m_response.finished())
		{
			m_response.set_sessbase(&m_base);
			if (!m_response.is_paramset())
			{
				const evtl::linearbuf<char> &req = m_request.get_request();
				std::string sr = req.tostring();
				m_response.set_param(std::string("[") + sr + "]");
			}

			m_response.sendresponse();
		}

		if (!m_response.finished())
			set_nextstep1(evtl::com::nextstep_wait_to_send);
		else
			set_nextstep1(evtl::com::nextstep_cycledone);
	}

	void process_two()
	{
		m_pc2.set_sessbase(&m_base);
		if (!m_pc2.is_active())
		{
			if (m_pc2_ready)
			{
				m_pc2.set("[this is timer]");
				m_pc2_ready = false;
			}

			if (!m_pc2.is_active())
			{
				set_nextstep2(evtl::com::nextstep_stop);
				return;
			}
		}

		if (!m_pc2.is_active())
			assert(false);

		m_pc2.sendww();
		if (m_pc2.finished())
		{
			set_nextstep2(evtl::com::nextstep_cycledone);
			return;
		}
		else
		{
			set_nextstep2(evtl::com::nextstep_wait_to_send);
			return;
		}
	}

	void timer_callback(evtl::simpwtimer &watcher, int revents)
	{
		if (&watcher != &m_timer)
			assert(false);

		m_pc2_ready = true;

		if ((get_events() & ev::WRITE) == 0)
		{
			stop();
			set_events(ev::WRITE);
			start();
		}
		else
		{
			if (!is_active())
				start();
		}

		m_timer.set_repeat(10. + m_loop.now_difference());
		m_timer.again();
	}

private:
	void set_nextstep1(evtl::com::process_nextstep step)
	{
		m_step1 = step;
	}

	void set_nextstep2(evtl::com::process_nextstep step)
	{
		m_step2 = step;
	}

	void cycle_reset1()
	{
		m_request.reset();
		m_response.reset();
	}

	void cycle_reset2()
	{
		m_pc2.reset();
	}

	void final_nextstep()
	{
		if (m_step1 == evtl::com::nextstep_error)
		{
			m_finalstep = evtl::com::nextstep_error;
			return;
		}
		else if (m_step1 == evtl::com::nextstep_continue)
		{
			m_finalstep = evtl::com::nextstep_continue;
			return;
		}
		else if (m_step1 == evtl::com::nextstep_wait_to_receive)
		{
			switch (m_step2)
			{
			case evtl::com::nextstep_stop:
				m_finalstep = evtl::com::nextstep_wait_to_receive;
				break;
			case evtl::com::nextstep_cycledone:
				m_finalstep = evtl::com::nextstep_wait_to_receive_send;
				break;
			case evtl::com::nextstep_wait_to_send:
				m_finalstep = evtl::com::nextstep_wait_to_receive_send;
				break;
			default:
				assert(false);
				break;
			}
		}
		else if (m_step1 == evtl::com::nextstep_wait_to_send)
		{
			m_finalstep = evtl::com::nextstep_wait_to_send;
		}
		else if (m_step1 == evtl::com::nextstep_cycledone)
		{
			m_finalstep = evtl::com::nextstep_wait_to_send;
		}
		else
		{
			assert(false);
		}
	}

	void active_event(int event)
	{
		if (get_events() != event)
		{
			stop();
			set_events(event);
			start();
		}
		else
		{
			if (!is_active())
				start();
		}
	}

private:
	sessionbase  m_base;
	recycle_callback_t  m_recycle_cb;

	evtl::looprefer  m_loop;

	evtl::simpwtimer  m_timer;
	evtl::com::rwstatus  m_iostatus;

	evtl::com::process_nextstep  m_step1;
	evtl::com::process_nextstep  m_step2;
	evtl::com::process_nextstep  m_finalstep;

	evtl::linearbuf<char>  m_recvbuf;
	request  m_request;
	response  m_response;

	evtl::boolflag<false>  m_pc2_ready;
	process2  m_pc2;
};


#endif


