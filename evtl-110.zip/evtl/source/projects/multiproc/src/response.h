

#ifndef __RESPONSE_H__
#define __RESPONSE_H__

#include "sessionbase.h"


class response
{
public:
	response()
	{}

	bool finished()
	{
		if (m_response.isset() && m_response.refer().empty())
			return true;
		return false;
	}

	void set_sessbase(sessionbase *base)
	{
		m_sessbase = base;
	}

	bool is_paramset()
	{
		return m_response.isset();
	}

	void set_param(const std::string &str)
	{
		m_response.refer().extens_store_whole(str);
		m_response.set();
	}

	void sendresponse()
	{
		if (!m_response.isset())
			assert(false);

		evtl::linearbuf<char> &buf = m_response.refer();
		ssize_t bufsz = buf.size();
		if (bufsz <= 0)
			return;

		ssize_t sz = m_sessbase->m_ioitf->io_write(buf.dataptr(), bufsz);
		if (sz > 0)
		{
			if (!buf.shit_whole(sz))
				assert(false);
		}
	}

	void reset()
	{
		m_response.reset();
	}

private:
	sessionbase  *m_sessbase;
	evtl::var<evtl::linearbuf<char>>  m_response;
};


#endif


