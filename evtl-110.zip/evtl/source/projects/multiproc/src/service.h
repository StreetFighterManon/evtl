

#ifndef __SERVICE_H__
#define __SERVICE_H__

#include <set>

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_acceptor.h>
#include <evtl/evtl_socket.h>

#include "session.h"


class service
{
public:
	service()
	{}

	void init()
	{
		m_listener.set_address("0.0.0.0", 2333);
		m_listener.listen(12, true, true);
		m_acceptor.set_loop(m_loop.ref());
		m_acceptor.set_listener(m_listener);
		m_acceptor.set_callback(std::bind(&service::accept_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_acceptor.watch();
	}

	void run()
	{
		m_loop.run_loop();
	}

private:
	void accept_callback(evtl::tcp::simpacceptor &accpt, std::vector<evtl::connection> &conns)
	{
		for (std::vector<evtl::connection>::const_iterator iter = conns.begin(); iter != conns.end(); ++iter)
		{
			const evtl::connection &conn = *iter;

			evtl::sockoption::set_tcp_nodelay(conn.fd, true);

			session *psess = new session;
			psess->set_loop(m_loop.ref());
			psess->set_recycle_callback(std::bind(&service::recycle_session, this, std::placeholders::_1));
			psess->init();
			psess->set(m_loop.ref());
			psess->set_callback();
			psess->set(conn.fd, ev::READ);
			psess->start();

			std::pair<std::set<session*>::const_iterator, bool> rt = m_sessions.insert(psess);
			if (!rt.second)
				assert(false);
		}
	}

	void recycle_session(session *psess)
	{
		if (psess == nullptr)
			assert(false);

		size_t n = m_sessions.erase(psess);
		if (n <= 0)
			assert(false);

		psess->deinit();
		delete psess;
	}

private:
	evtl::simpeventloop<evtl::default_loop>  m_loop;
	evtl::tcp::listener   m_listener;
	evtl::tcp::simpacceptor  m_acceptor;

	std::set<session*>  m_sessions;
};


#endif


