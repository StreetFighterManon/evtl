

#ifndef __REQUEST_H__
#define __REQUEST_H__

#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_pcre2.h>

#include "sessionbase.h"


class request
{
public:
	request()
	{
		m_sessbase = nullptr;
		m_recvbuf = nullptr;
	}

	bool got()
	{
		if (m_req.isset())
			return true;
		return false;
	}

	void set_sessbase(sessionbase *base)
	{
		m_sessbase = base;
	}

	void set_recvbuf(evtl::linearbuf<char> *buf)
	{
		m_recvbuf = buf;
	}

	int search()
	{
		if (m_req.isset())
			assert(false);

		evtl::pcre2_8::regex  reg(R"(\[\d+\])");
		evtl::pcre2_8::match_results<char>  matches;
		bool br = evtl::pcre2_8::regex_search(m_recvbuf->dataptr(), m_recvbuf->dataptr() + m_recvbuf->size(), matches, reg);
		if (br)
		{
			std::string req = matches[0].str();
			m_req.refer().extens_store_whole(req);
			m_req.set();

			if (!m_recvbuf->shit_whole(matches[0].second - m_recvbuf->dataptr()))
				assert(false);
			return 0;  //success
		}

		if (m_recvbuf->size() >= 1024)
			return -1;  //error

		m_recvbuf->crowdct(1024, 1024);

		ssize_t headspace = m_recvbuf->headspace();
		if (headspace <= 0)
			assert(false);

		ssize_t rs = m_sessbase->m_ioitf->io_read(m_recvbuf->headptr(), headspace);
		if (rs > 0)
		{
			if (!m_recvbuf->head_eaten_whole(rs))
				assert(false);
			return 1;  //continue
		}

		return 2;  //wait to recieve
	}

	const evtl::linearbuf<char> &get_request() const
	{
		return m_req.refer();
	}

	void reset()
	{
		m_req.reset();
	}

private:
	sessionbase  *m_sessbase;
	evtl::linearbuf<char>  *m_recvbuf;
	evtl::var<evtl::linearbuf<char>>  m_req;
};


#endif


