

#include <sys/types.h>
#include <sys/wait.h>

#include <evtl/evtl_daemon.h>
#include <evtl/evtl_signal.h>

#include <iostream>
using namespace std;

#include "service.h"


struct statusinfo
{
	statusinfo(): pid(-1), exited(false)
	{}

	pid_t pid;
	bool  exited;
};

statusinfo  g_info[2];
#define ARRAYLEN(a) ((ssize_t)(sizeof(a)/sizeof(a[0])))


void signalhandle(int sig)
{
	if (sig == SIGCHLD)
	{
		while (true)
		{
			int status = 0;
			pid_t pid = waitpid(-1, &status, WNOHANG);
			if (pid == 0)
			{
				return;
			}
			else if (pid == -1)
			{
				if (errno == EINTR)
					continue;
				return;
			}
			else
			{
				cout<<"exit: "<<pid<<endl;
				for (int i = 0; i < ARRAYLEN(g_info); i++)
				{
					if (g_info[i].pid == pid)
					{
						g_info[i].exited = true;
						break;
					}
				}
			}
		}
	}
}


class multiroute
{
public:
	multiroute()
	{}

	void tofork()
	{
		for (int i = 0; i < ARRAYLEN(g_info); i++)
		{
			pid_t pid = ::fork();
			if (pid == 0)
			{
				_run_child();
				::abort();
				exit(0);
			}
			else if (pid == -1)
			{
				exit(0);
			}
			else
			{
				g_info[i].pid = pid;
				g_info[i].exited = false;
			}
		}
	}

	void refork()
	{
		while (true)
		{
			evtl::signalc::suspend_all();

			for (int i = 0; i < ARRAYLEN(g_info); i++)
			{
				if (g_info[i].exited)
				{
					pid_t pid = ::fork();
					if (pid == 0)
					{
						_run_child();
						::abort();
						exit(0);
					}
					else if (pid == -1)
					{
						assert(false);
					}
					else
					{
						cout<<"fork: "<<pid<<endl;
						g_info[i].pid = pid;
						g_info[i].exited = false;
					}
				}
			}
		}
	}

	void debug()
	{
		_run_child();
	}

private:
	void _run_child()
	{
		evtl::signalc::typical_ignore();
		evtl::signalc::typical_unblock();

		evtl::proctitle::setproctitle("multiroute: child");

		m_service.init();
		m_service.run();
		assert(false && "exit");
	}

private:
	service  m_service;
};


int main(int argc,char *argv[])
{
	evtl::daemonize::daemon();

	ev_default_loop();

	evtl::signalc::typical_ignore();
	evtl::signalc::sigaction(SIGCHLD, signalhandle);
	//evtl::signalc::sig_default(SIGINT);
	evtl::signalc::typical_block();

	evtl::proctitle::init(argv);
	evtl::proctitle::setproctitle("multiroute: forker");

	multiroute  route;
	//route.debug();
	route.tofork();
	route.refork();

	return 0;
}


