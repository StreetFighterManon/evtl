


#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <assert.h>
#include <signal.h>

#include <iostream>
using namespace std;

#include <evtl/evtl_signal.h>
#include <evtl/evtl_daemon.h>

#include <eio/eio.h>


class procinfo
{
public:
	procinfo(): m_reap(false)
	{}

	static procinfo * instance()
	{
		static procinfo *info = new procinfo;
		return info;
	}

	struct statusinfo
	{
		statusinfo(): m_pid(-1), m_exited(false), m_status(0)
		{}

		pid_t  m_pid;
		bool   m_exited;
		int    m_status;
	};

	statusinfo  m_masterinfo;
	statusinfo  m_slaveinfo[10];
	bool        m_reap;
};


void signalhandle(int nsig)
{
	cout<<"signal: "<<nsig<<endl;

	if (nsig == SIGCHLD)
	{
		procinfo::instance()->m_reap = true;

		while (true)
		{
			int status = 0;

			pid_t pid = waitpid(-1, &status, WNOHANG);
			if (pid == 0)
			{
				return;
			}
			else if (pid == -1)
			{
				if (errno == EINTR)
					continue;
				return;
			}
			else
			{
				procinfo::statusinfo &masterinfo = procinfo::instance()->m_masterinfo;
				if (pid == procinfo::instance()->m_masterinfo.m_pid)
				{
					masterinfo.m_exited = true;
					masterinfo.m_status = status;
					continue;
				}

				procinfo::statusinfo *slaveinfo = procinfo::instance()->m_slaveinfo;
				for (int i = 0; i < 10; i++)
				{
					if (slaveinfo[i].m_pid == pid)
					{
						slaveinfo[i].m_exited = true;
						slaveinfo[i].m_status = status;
						break;
					}
				}
			}
		}
	}
}


class master
{
public:
	master()
	{}

	void run()
	{
		evtl::signalc::typical_ignore();
		evtl::proctitle::setproctitle("multi: master");
		cout<<"master: "<<getpid()<<" "<<getppid()<<endl;
		while (true)
			sleep(1);
	}
};

class slave
{
public:
	slave()
	{}

	void run()
	{
		evtl::signalc::typical_ignore();
		evtl::proctitle::setproctitle("multi: slave");
		cout<<"slave: "<<getpid()<<" "<<getppid()<<endl;
		while (true)
			sleep(1);
	}
};

class app
{
public:
	app()
	{}

	void init()
	{
		evtl::signalc::typical_ignore();
		evtl::signalc::sigaction(SIGCHLD, signalhandle);
		evtl::signalc::typical_block();
	}

	void tofork()
	{
		procinfo::statusinfo &masterinfo = procinfo::instance()->m_masterinfo;

		pid_t pid = fork();
		if (pid == 0)
		{
			m_master.run();
			assert(false);
		}
		else if (pid == -1)
		{
			return;
		}
		else
		{
			masterinfo.m_pid = pid;
			masterinfo.m_exited = false;
			masterinfo.m_status = 0;
		}

		procinfo::statusinfo *slaveinfo = procinfo::instance()->m_slaveinfo;
		for (int i = 0; i < 10; i++)
		{
			pid_t pid = fork();
			if (pid == 0)
			{
				m_slave.run();
				assert(false);
			}
			else if (pid == -1)
			{
				return;
			}
			else
			{
				slaveinfo[i].m_pid = pid;
				slaveinfo[i].m_exited = false;
				slaveinfo[i].m_status = 0;
			}
		}
	}

	void refork()
	{
		while (true)
		{
			evtl::signalc::suspend_all();

			if (!procinfo::instance()->m_reap)
				continue;

			procinfo::instance()->m_reap = false;

			procinfo::statusinfo &masterinfo = procinfo::instance()->m_masterinfo;
			if (masterinfo.m_exited)
			{
				pid_t pid = fork();
				if (pid == 0)
				{
					m_master.run();
					assert(false);
				}
				else if (pid == -1)
				{
					assert(false);
					return;
				}
				else
				{
					masterinfo.m_pid = pid;
					masterinfo.m_exited = false;
					masterinfo.m_status = 0;
				}
			}

			procinfo::statusinfo *slaveinfo = procinfo::instance()->m_slaveinfo;
			for (int i = 0; i < 10; i++)
			{
				if (slaveinfo[i].m_exited)
				{
					pid_t pid = fork();
					if (pid == 0)
					{
						m_slave.run();
						assert(false);
					}
					else if (pid == -1)
					{
						assert(false);
						return;
					}
					else
					{
						slaveinfo[i].m_pid = pid;
						slaveinfo[i].m_exited = false;
						slaveinfo[i].m_status = 0;
					}
				}
			}
		}
	}

private:
	master  m_master;
	slave   m_slave;
};

int main(int argc, char* argv[])
{
	evtl::daemonize::daemon();

	evtl::proctitle::init(argv);
	evtl::proctitle::setproctitle("multi: forker");

	procinfo::instance();

	app ss;

	ss.init();
	ss.tofork();
	ss.refork();
	return 0;
}




