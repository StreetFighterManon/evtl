

#ifndef __CALLGIVEPROCE_H__
#define __CALLGIVEPROCE_H__

#include <evtl/evtl_watcher_timer.h>

#include "callsessioninfo.h"
#include "callprep.h"
#include "callgiverequest.h"
#include "callgiveintr.h"
#include "callgiveresponse.h"


class callgiveproce
{
public:
	callgiveproce()
	{
		m_nextstep = evtl::com::nextstep_unknown;
	}

	void set_sessinfo(callsessioninfo *info)
	{
		m_proceinfo.m_sessinfo = info;
	}

	void set_prep(callprep *prep)
	{
		m_proceinfo.m_prep = prep;
	}

	void set_type(givereqtype type)
	{
		m_proceinfo.m_type = type;
	}

	void init()
	{
		m_proceinfo.m_giveproceptr = this;
	}

	void process()
	{
		m_nextstep = evtl::com::nextstep_unknown;
		_process();
		if (m_nextstep == evtl::com::nextstep_cycledone)
		{
			_cycle_reset();
		}
	}

	evtl::com::process_nextstep get_nextstep() const
	{
		return m_nextstep;
	}

	bool is_idlestatus() const
	{
		return m_idlestatus;
	}

	bool give_localintr(std::shared_ptr<givelink> link)
	{
		if (link->m_id != m_proceinfo.m_givelink->m_id)
			return false;

		m_proceinfo.m_sessinfo->m_base.m_iointf->activate();
		return true;
	}

	void deinit()
	{
		m_nextstep = evtl::com::nextstep_unknown;
		m_idlestatus.reset();
		m_request.reset();
		m_interrupt.reset();
		m_timeout_timer.stop();
		m_response.reset();
	}

private:
	void _process()
	{
		m_idlestatus = false;

		if (!m_request.ready())
		{
			m_request.set_proceinfo(&m_proceinfo);
		}

		if (!m_request.got())
		{
			if (!evtl::lock::routelock_acquire(m_proceinfo.m_prep->m_prelock, m_proceinfo.m_prelockowner))
			{
				m_idlestatus = true;
				set_nextstep(evtl::com::nextstep_none);
				return;
			}

			callgiverequest::searchresult result = m_request.search();
			switch (result)
			{
			case callgiverequest::searchresult::needrecv:
				{
					evtl::lock::routelock_release(m_proceinfo.m_prep->m_prelock, m_proceinfo.m_prelockowner, true);
					m_idlestatus = true;
					set_nextstep(evtl::com::nextstep_wait_to_receive);
					return;
				}
				break;
			case callgiverequest::searchresult::needcontinue:
				{
					evtl::lock::routelock_release(m_proceinfo.m_prep->m_prelock, m_proceinfo.m_prelockowner, true);
					m_idlestatus = true;
					set_nextstep(evtl::com::nextstep_continue);
					return;
				}
				break;
			case callgiverequest::searchresult::other_route:
				{
					evtl::lock::routelock_release(m_proceinfo.m_prep->m_prelock, m_proceinfo.m_prelockowner, true);
					m_idlestatus = true;
					set_nextstep(evtl::com::nextstep_none);
					return;
				}
				break;
			case callgiverequest::searchresult::error:
				{
					evtl::lock::routelock_release(m_proceinfo.m_prep->m_prelock, m_proceinfo.m_prelockowner, true);
					m_idlestatus = true;
					set_nextstep(evtl::com::nextstep_error_end);
					return;
				}
				break;
			default:
				break;
			}

			if (result != callgiverequest::searchresult::success)
				assert(false);
			if (!m_request.got())
				assert(false);

			evtl::lock::routelock_release(m_proceinfo.m_prep->m_prelock, m_proceinfo.m_prelockowner);
		}

		if (!m_interrupt.interrupted())
		{
			m_interrupt.set_proceinfo(&m_proceinfo);
			m_interrupt.set_request(m_request.get_requestinfo());
			m_interrupt.interrupt();

			if (!m_interrupt.interrupted())
				assert(false);

			evtl::looprefer loop = m_proceinfo.m_sessinfo->m_loop;
			m_timeout_timer.set(loop, 10. + loop.now_difference(), 0.);
			m_timeout_timer.set_callback(std::bind(&callgiveproce::timer_callback, this, std::placeholders::_1, std::placeholders::_2));
			m_timeout_timer.start();
		}

		if (!m_interrupt.got_result())
		{
			set_nextstep(evtl::com::nextstep_stop);
			return;
		}

		if (!m_response.ready())
		{
			m_response.set_proceinfo(&m_proceinfo);
		}

		if (!evtl::lock::routelock_acquire(m_proceinfo.m_prep->m_socksendlock, m_proceinfo.m_sendlockowner))
		{
			set_nextstep(evtl::com::nextstep_none);
			return;
		}

		if (!m_response.sendcomplete())
		{
			m_response.sendresponse();
			if (!m_response.sendcomplete())
			{
				set_nextstep(evtl::com::nextstep_wait_to_send);
				return;
			}
		}

		evtl::lock::routelock_release(m_proceinfo.m_prep->m_socksendlock, m_proceinfo.m_sendlockowner);
		set_nextstep(evtl::com::nextstep_cycledone);
	}

	void set_nextstep(evtl::com::process_nextstep step)
	{
		m_nextstep = step;
	}

	void _cycle_reset()
	{
		m_proceinfo.m_prelockowner.reset();
		m_proceinfo.m_sendlockowner.reset();
		m_proceinfo.m_givelink.reset();

		m_request.reset();
		m_interrupt.reset();
		m_timeout_timer.stop();
		m_response.reset();
	}

private:
	void timer_callback(evtl::simpwtimer &watcher, int revents)
	{
		if (&watcher != &m_timeout_timer)
			assert(false);

		watcher.stop();

		std::shared_ptr<givelink> ptr = m_proceinfo.m_givelink;
		if (ptr->m_got_response)
			return;

		remoteresponse &resp = ptr->m_response;
		resp.m_error = errortype::timeout;
		resp.m_errstr = "give interrupt timeout";
		ptr->m_got_response = true;

		m_proceinfo.m_sessinfo->m_base.m_iointf->activate();
	}

private:
	callgiveproceinfo  m_proceinfo;

	evtl::com::process_nextstep  m_nextstep;

	evtl::boolflag<false>  m_idlestatus;
	callgiverequest  m_request;
	callgiveintr   m_interrupt;
	evtl::simpwtimer  m_timeout_timer;

	callgiveresponse  m_response;
};


#endif


