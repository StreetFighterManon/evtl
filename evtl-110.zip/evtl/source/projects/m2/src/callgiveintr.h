

#ifndef __CALLGIVEINTR_H__
#define __CALLGIVEINTR_H__

#include "requestlink.h"


class callgiveintr
{
public:
	callgiveintr()
	{
		m_proceinfo = nullptr;
	}

	bool interrupted()
	{
		if (m_proceinfo->m_givelink)
			return true;
		return false;
	}

	void set_proceinfo(callgiveproceinfo *info)
	{
		m_proceinfo = info;
	}

	void set_request(givereqinfo info)
	{
		m_reqinfo = info;
	}

	void interrupt() const
	{
		m_proceinfo->m_givelink = std::make_shared<givelink>();

		m_proceinfo->m_givelink->m_id = evtl::rand::urandom::str_az09(8);
		m_proceinfo->m_givelink->m_group_id = m_proceinfo->m_sessinfo->m_groupid;

		m_proceinfo->m_givelink->m_intconnector = m_proceinfo->m_sessinfo->m_give_intrconnector;

		m_proceinfo->m_givelink->m_local_key = m_proceinfo->m_sessinfo->m_callsesstcptr;
		m_proceinfo->m_givelink->m_local_interrupt = m_proceinfo->m_sessinfo->m_give_localintr;
		m_proceinfo->m_givelink->m_syn = true;

		m_proceinfo->m_givelink->m_remote_key = m_proceinfo->m_sessinfo->m_comesessptr;

		m_proceinfo->m_givelink->m_giveproceptr = m_proceinfo->m_giveproceptr;
		m_proceinfo->m_givelink->m_reqinfo = m_reqinfo;

		m_proceinfo->m_givelink->interrupt_connect(m_proceinfo->m_givelink);
	}

	bool got_result() const
	{
		return m_proceinfo->m_givelink->m_got_response;
	}

	void reset()
	{
		m_reqinfo.reset();
	}

private:
	callgiveproceinfo  *m_proceinfo;
	givereqinfo  m_reqinfo;
};


#endif


