

#ifndef __CALLGIVERESPONSE_H__
#define __CALLGIVERESPONSE_H__


class callgiveresponse
{
public:
	callgiveresponse()
	{}

	bool ready()
	{
		if (m_giveporce == nullptr)
			return false;
		return true;
	}

	void set_proceinfo(callgiveproceinfo *info)
	{
		m_giveporce = info;
	}

	bool sendcomplete()
	{
		if (m_response.isset() && m_response.refer().empty())
			return true;
		return false;
	}

	void sendresponse()
	{
		if (!m_response.isset())
		{
			std::stringstream ss;

			remoteresponse &resp = m_giveporce->m_givelink->m_response;
			if (resp.m_error == errortype::success)
			{
				if (resp.m_responseinfo.m_type != recvdatatype::response)
					assert(false);

				ss << "[response]\r\n"
					<< "id: " << resp.m_responseinfo.m_id << "\r\n"
					<< "content: " << resp.m_responseinfo.m_content << "\r\n"
					<< "[end]\r\n";

					m_response.refer().extens_store_whole(ss.str());
			}
			m_response.set();
		}

		evtl::linearbuf<char> &buf = m_response.refer();
		ssize_t size = buf.size();
		if (size > 0)
		{
			ssize_t rt = m_giveporce->m_sessinfo->m_base.m_iointf->io_write(buf.dataptr(), size);
			if (rt > 0)
			{
				if (rt > size)
					assert(false);

				if (!buf.shit_whole(rt))
					assert(false);
			}
		}
	}

	void reset()
	{
		m_response.reset();
	}

private:
	callgiveproceinfo  *m_giveporce;
	evtl::var<evtl::linearbuf<char>>  m_response;
};


#endif


