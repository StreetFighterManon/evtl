

#ifndef __COMEPROCESS_H__
#define __COMEPROCESS_H__

#include <evtl/evtl_in.h>

#include "comeprep.h"
#include "requestprocess.h"
#include "giveprocess.h"
#include "comesessioninfo.h"
#include "comeinvalidprocess.h"


class comeprocess
{
public:
	comeprocess()
	{
		m_sessinfo = nullptr;
		m_nextstep = evtl::com::nextstep_unknown;
	}

	void set_sessinfo(comesessioninfo *info)
	{
		m_sessinfo = info;
	}

	void init()
	{
		m_prep.m_proce.set_sessinfo(m_sessinfo);
		m_prep.m_proce.init();

		m_single.set_sessinfo(m_sessinfo);
		m_single.set_prep(&m_prep);
		m_single.set_reqtype(requesttype::single);
		m_single.init();

		for (int i = 0; i < 2; i++)
		{
			m_multi[i].set_sessinfo(m_sessinfo);
			m_multi[i].set_prep(&m_prep);
			m_multi[i].set_reqtype(requesttype::multi);
			m_multi[i].init();
		}

		m_give.set_sessinfo(m_sessinfo);
		m_give.set_prep(&m_prep);
		m_give.set_givetype(givereqtype::single);
		m_give.init();

		for (int i = 0; i < 2; i++)
		{
			m_multigive[i].set_sessinfo(m_sessinfo);
			m_multigive[i].set_prep(&m_prep);
			m_multigive[i].set_givetype(givereqtype::multi);
			m_multigive[i].init();
		}

		m_invaid.set_sessinfo(m_sessinfo);
		m_invaid.set_prep(&m_prep);
		m_invaid.init();
	}

	void process()
	{
		m_prep.m_proce.process();

		push_on();
		determine();
	}

	evtl::com::process_nextstep get_nextstep() const
	{
		return m_nextstep;
	}

	void clean()
	{
		for (int i = 0; i < 2; i++)
		{
			m_multi[i].clean();
		}

		for (int i = 0; i < 2; i++)
		{
			m_multigive[i].clean();
		}
	}

	bool needrecycle() const
	{
		if (m_single.needrecycle())
			return true;

		for (int i = 0; i < 2; i++)
		{
			if (m_multi[i].needrecycle())
				return true;
		}

		if (m_give.needrecycle())
			return true;

		for (int i = 0; i < 2; i++)
		{
			if (m_multigive[i].needrecycle())
				return true;
		}

		return false;
	}

	bool request_localintr(std::shared_ptr<requestlink> link)
	{
		requestprocess *subpptr = (requestprocess *)link->m_subprocessptr;
		if (subpptr == nullptr)
			assert(false);

		if (subpptr == &m_single)
			return m_single.request_localintr(link);

		for (int i = 0; i < 2; i++)
		{
			if (subpptr == m_multi + i)
				return m_multi[i].request_localintr(link);
		}
		return false;
	}

	void deinit()
	{
		m_single.deinit();

		for (int i = 0; i < 2; i++)
		{
			m_multi[i].deinit();
		}

		m_give.deinit();

		for (int i = 0; i < 2; i++)
		{
			m_multigive[i].deinit();
		}
	}

private:
	void push_on()
	{
		m_stepstream.clear();

		m_single.process();
		m_stepstream << m_single.get_nextstep();

		for (int i = 0; i < 2; i++)
		{
			m_multi[i].process();
			m_stepstream << m_multi[i].get_nextstep();
		}

		m_give.process();
		m_stepstream << m_give.get_nextstep();

		for (int i = 0; i < 2; i++)
		{
			m_multigive[i].process();
			m_stepstream << m_multigive[i].get_nextstep();
		}

		if (prepblocked_all())
			m_invaid.process(true);
		else
			m_invaid.process(false);
		m_stepstream << m_invaid.get_nextstep();
	}

	void determine()
	{
		evtl::com::nextstepstream  stream;
		stream << evtl::com::nextstep_unknown << evtl::com::nextstep_none;

		if (m_stepstream <= stream)
			assert(false);

		if (m_stepstream.have(evtl::com::nextstep_error) || m_stepstream.have(evtl::com::nextstep_error_end))
		{
			set_nextstep(evtl::com::nextstep_error_end);
			return;
		}

		set_nextstep(m_stepstream.elect());
	}

	bool prepblocked_all()
	{
		if (!m_single.prepblocked())
			return false;

		for (int i = 0; i < 2; i++)
		{
			if (!m_multi[i].prepblocked())
				return false;
		}

		if (!m_give.prepblocked())
			return false;

		for (int i = 0; i < 2; i++)
		{
			if (!m_multigive[i].prepblocked())
				return false;
		}

		return true;
	}

	void set_nextstep(evtl::com::process_nextstep step)
	{
		m_nextstep = step;
	}

private:
	comesessioninfo   *m_sessinfo;

	comeprep   m_prep;

	requestprocess  m_single;
	requestprocess  m_multi[2];
	giveprocess  m_give;
	giveprocess  m_multigive[2];
	comeinvalidprocess  m_invaid;

	evtl::com::nextstepstream  m_stepstream;
	evtl::com::process_nextstep  m_nextstep;
};


#endif


