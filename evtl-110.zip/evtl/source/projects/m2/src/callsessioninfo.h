

#ifndef __CALLSESSIONINFO_H__
#define __CALLSESSIONINFO_H__

#include "interface.h"
#include "callorder.h"


struct callsessionbase
{
	callsessionbase()
	{
		m_iointf = nullptr;
	}

	iointerface  *m_iointf;
};


struct callsessioninfo
{
	callsessioninfo()
	{
		m_singlereqlist = nullptr;
		m_multireqlist = nullptr;
		m_comesessptr = nullptr;
		m_callsesstcptr = nullptr;
	}

	callsessionbase  m_base;
	evtl::looprefer  m_loop;
	std::list<std::shared_ptr<requestlink>>  *m_singlereqlist;
	std::list<std::shared_ptr<requestlink>>  *m_multireqlist;

	std::string  m_groupid;
	void *  m_comesessptr;
	void *  m_callsesstcptr;
	givelink::intr_connector  m_give_intrconnector;
	givelink::intr_entrance   m_give_localintr;
};


#endif


