

#ifndef __GIVEREPLY_H__
#define __GIVEREPLY_H__


class givereply
{
public:
	givereply()
	{}

	bool replied() const
	{
		if (!m_givelink)
			return false;
		return true;
	}

	void set_link(std::shared_ptr<givelink> ptr)
	{
		m_givelink = ptr;
	}

	void set_content(const std::string &content)
	{
		m_content = content;
	}

	void reply()
	{
		if (!m_givelink)
			assert(false);

		responseinfo &respinfo = m_givelink->m_response.m_responseinfo;
		respinfo.m_id = m_givelink->m_reqinfo.m_id;
		respinfo.m_content = m_content;

		m_givelink->m_got_response = true;
		m_givelink->interrupt_local(m_givelink, 0);
	}

	void reset()
	{
		m_givelink.reset();
		m_content.clear();
	}

private:
	std::shared_ptr<givelink>  m_givelink;
	std::string  m_content;
};


#endif


