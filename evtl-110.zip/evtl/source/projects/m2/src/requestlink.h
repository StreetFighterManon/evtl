

#ifndef __REQUESTLINK_H__
#define __REQUESTLINK_H__

#include <evtl/evtl_itc.h>
#include <evtl/evtl_wrapper.h>


#include "recvdata.h"
#include "requestinfo.h"


enum class errortype
{
	unknown,
	success,
	timeout,
	connect_failed,
	fatalerror
};

struct remoteresponse
{
	remoteresponse()
	{
		m_error = errortype::success;
	}

	void reset()
	{
		m_error = errortype::unknown;
		m_errstr.clear();
		m_responseinfo.reset();
	}

	errortype     m_error;
	std::string   m_errstr;
	responseinfo  m_responseinfo;
};

struct requestlink : public evtl::itc::baseprotocol<requestlink>
{
	requestlink()
	{
		m_subprocessptr = nullptr;
	}

	void *  m_subprocessptr;
	requestinfo  m_requestinfo;

	evtl::boolflag<false>  m_got_response;
	remoteresponse   m_response;
};


struct givelink : public evtl::itc::baseprotocol<givelink>
{
	givelink()
	{
		m_giveproceptr = nullptr;
	}

	void * m_giveproceptr;
	givereqinfo  m_reqinfo;

	evtl::boolflag<false>  m_got_response;
	remoteresponse  m_response;
};


struct closelink : public evtl::itc::baseprotocol<closelink>
{
	closelink()
	{}
};


#endif


