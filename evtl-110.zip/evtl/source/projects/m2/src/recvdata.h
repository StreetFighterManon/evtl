

#ifndef __RECVDATA_H__
#define __RECVDATA_H__


enum class recvdatatype
{
	unknown,
	singlereq,
	multireq,
	singlegive,
	multigive,
	qsingleheartbeat,
	qmultiheartbeat,
	response,
	invalid
};

struct recvdatainfo
{
	recvdatainfo()
	{
		m_type = recvdatatype::unknown;
	}

	void reset()
	{
		m_type = recvdatatype::unknown;
		m_id.clear();
	}

	recvdatatype  m_type;
	std::string   m_id;
};

struct responseinfo
{
	responseinfo()
	{
		m_type = recvdatatype::unknown;
	}

	void reset()
	{
		m_type = recvdatatype::unknown;
	}

	recvdatatype  m_type;
	std::string   m_id;
	std::string   m_content;
};


#endif


