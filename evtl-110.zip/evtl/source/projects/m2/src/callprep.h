

#ifndef __CALLPREP_H__
#define __CALLPREP_H__

#include <evtl/evtl_lock.h>

#include "callpreproce.h"


struct callprep
{
	callprep()
	{}

	callpreproce  m_proce;

	evtl::lock::routelock  m_prelock;
	evtl::lock::routelock  m_socksendlock;
	evtl::lock::routeorderlock<>  m_multireqsendlock;
};


#endif



