

#ifndef __COMEPREPROCESS_H__
#define __COMEPREPROCESS_H__

#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_pcre2.h>

#include "recvdata.h"
#include "comesessioninfo.h"


class comepreprocess
{
public:
	comepreprocess(): m_recvbuf(1024*12)
	{
		m_sessinfo = nullptr;
	}

	void set_sessinfo(comesessioninfo *info)
	{
		m_sessinfo = info;
	}

	void init()
	{
	}

	void process()
	{
		if (m_datainfo.m_type == recvdatatype::unknown)
		{
			search_data();
		}
	}

	evtl::linearbuf<char>& get_recvbuf()
	{
		return m_recvbuf;
	}

	const recvdatainfo& get_recvdatainfo() const
	{
		return m_datainfo;
	}

	bool needrecv() const
	{
		return m_needrecv;
	}

	void reset_recvdata()
	{
		m_datainfo.reset();
	}

private:
	void search_data()
	{
		m_needrecv = false;

		evtl::pcre2_8::regex  reg(R"(\A\[(\w+)\]\r\nid: *(\d+)\r\ncontent: (.*?)\[end\]\r\n)");
		evtl::pcre2_8::match_results<char>  matches;
		bool br = evtl::pcre2_8::regex_search(m_recvbuf.dataptr(), m_recvbuf.dataptr() + m_recvbuf.size(), matches, reg);
		if (br)
		{
			if (matches.size() != 4)
				assert(false && "matches size");

			const evtl::pcre2_8::sub_match<char> &sub1 = matches[1];
			const evtl::pcre2_8::sub_match<char> &sub2 = matches[2];

			std::string  head = sub1.str();
			std::string  id = sub2.str();

			if (head == "singlerequest")
				m_datainfo.m_type = recvdatatype::singlereq;
			else if (head == "multirequest")
				m_datainfo.m_type = recvdatatype::multireq;
			else if (head == "response")
				m_datainfo.m_type = recvdatatype::response;
			else
				m_datainfo.m_type = recvdatatype::invalid;

			m_datainfo.m_id = id;
			return;
		}

		if (m_recvbuf.size() >= 1024*6)
		{
			m_datainfo.m_type = recvdatatype::invalid;
			return;
		}

		m_recvbuf.crowdct(1024*6, 1024*6);
		ssize_t headsp = m_recvbuf.headspace();
		if (headsp <= 0)
			assert(false);

		ssize_t ret = m_sessinfo->m_base.m_iointf->io_read(m_recvbuf.headptr(), headsp);
		if (ret > 0)
		{
			if (ret > headsp)
				assert(false);
			if (!m_recvbuf.head_eaten_whole(ret))
				assert(false);

			m_needrecv = false;
		}
		else
		{
			m_needrecv = true;
		}
	}

private:
	comesessioninfo *m_sessinfo;

	evtl::linearbuf<char>  m_recvbuf;
	recvdatainfo   m_datainfo;
	evtl::boolflag<false>  m_needrecv;
};


#endif


