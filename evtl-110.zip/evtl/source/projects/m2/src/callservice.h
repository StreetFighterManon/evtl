

#ifndef __CALLSERVICE_H__
#define __CALLSERVICE_H__

#include <functional>
#include <set>

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_watcher_timer.h>

#include "callsessiontc.h"
#include "sessionstore.h"


class callservice
{
public:
	callservice()
	{}

	void set_loop(evtl::looprefer loop)
	{
		m_loop = loop;
	}

	void set_give_intrconnector(givelink::intr_connector connector)
	{
		m_give_intrconnector = std::move(connector);
	}

	void init()
	{
		m_wakeuptimer.set(m_loop, 0, 60.);
		m_wakeuptimer.set_callback(std::bind(&callservice::wakeuptimer_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_wakeuptimer.again();

		m_timer.set(m_loop, 0, 30);
		m_timer.set_callback(std::bind(&callservice::timer_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_timer.again();
	}

	bool request_intrconnector(std::shared_ptr<requestlink> linkptr)
	{
		if (!linkptr)
			assert(false);

		if (linkptr->m_group_id.empty())
			assert(false);

		callsessiontc *psess = m_sessstore.find_session_from_groupid(linkptr->m_group_id);
		if (psess == nullptr)
		{
			psess = new callsessiontc;
			psess->set_loop(m_loop);
			psess->set_groupid(linkptr->m_group_id);
			psess->set_comesessptr(linkptr->m_local_key);
			psess->set_give_intrconnector(m_give_intrconnector);
			psess->set_give_localintr(std::bind(&callservice::give_localintr, this, std::placeholders::_1));
			psess->set_recycle_callback(std::bind(&callservice::recycle_session, this, std::placeholders::_1));
			psess->init();
			if (!psess->request_intrconnector(linkptr))
			{
				psess->deinit();
				delete psess;
				return false;
			}

			std::pair<std::set<callsessiontc*>::const_iterator, bool> br = m_sessions.insert(psess);
			if (!br.second)
				assert(false);

			if (!m_sessstore.insert_groupid(psess, linkptr->m_group_id))
				assert(false);
		}
		else
		{
			if (m_sessions.find(psess) == m_sessions.end())
				assert(false);

			if (!psess->request_intrconnector(linkptr))
				return false;
		}

		linkptr->m_remote_key = psess;
		linkptr->m_remote_interrupt = std::bind(&callservice::request_remoteintr, this, std::placeholders::_1);
		linkptr->m_syn_ack = true;
		return true;
	}

	bool close_intrconnector(std::shared_ptr<closelink> link)
	{
		if (!link)
			assert(false);

		std::string gid = link->m_group_id;
		if (gid.empty())
			assert(false);

		for (std::set<callsessiontc*>::iterator iter = m_sessions.begin(); iter != m_sessions.end(); ++iter)
		{
			callsessiontc *psess = *iter;
			if (psess == nullptr)
				assert(false);

			if (gid == psess->get_groupid())
			{
				m_sessions.erase(iter);
				if (!m_sessstore.remove_groupid(gid))
					assert(false);

				psess->deinit();
				delete psess;
				break;
			}
		}

		return true;
	}

private:
	bool request_remoteintr(const requestlink::intr_message &msg)
	{
		return true;
	}

	bool give_localintr(const givelink::intr_message &msg)
	{
		callsessiontc *psess = (callsessiontc *)msg.key;
		if (psess == nullptr)
			assert(false);

		if (m_sessions.find(psess) == m_sessions.end())
			return false;

		return psess->give_localintr(msg);
	}

	void recycle_session(callsessiontc *psess)
	{
		if (psess == nullptr)
			assert(false);

		size_t n = m_sessions.erase(psess);
		if (n <= 0)
			assert(false);

		if (!m_sessstore.remove_groupid(psess->get_groupid()))
			assert(false);

		psess->deinit();
		delete psess;
	}

	void wakeuptimer_callback(evtl::simpwtimer &watcher, int revents)
	{
		if (&watcher != &m_wakeuptimer)
			assert(false);

		return;

		for (std::set<callsessiontc*>::const_iterator iter = m_sessions.begin(); iter != m_sessions.end(); ++iter)
		{
			callsessiontc *psess = *iter;
			psess->wakeup();
		}

		m_wakeuptimer.set_repeat(m_loop.fast_now_difference() + 60.);
		m_wakeuptimer.again();
	}

	void timer_callback(evtl::simpwtimer &watcher, int revents)
	{
		if (&watcher != &m_timer)
			assert(false);

		return;

		for (std::set<callsessiontc*>::iterator iter = m_sessions.begin(); iter != m_sessions.end(); )
		{
			callsessiontc *psess = *iter;
			if (psess->need_recycle())
			{
				cout<<"[callservice::timer_callback] erase callsessiontc, ptr = " << psess << ", groupid = " << psess->get_groupid() << endl;

				if (!m_sessstore.remove_groupid(psess->get_groupid()))
					assert(false);

				m_sessions.erase(iter++);
				psess->deinit();
				delete psess;
			}
			else
			{
				++iter;
			}
		}
	}

private:
	evtl::looprefer  m_loop;
	givelink::intr_connector  m_give_intrconnector;
	std::set<callsessiontc*>  m_sessions;
	callsessionstore  m_sessstore;

	evtl::simpwtimer  m_wakeuptimer;
	evtl::simpwtimer  m_timer;
};


#endif


