

#ifndef __REQUEST_INTERRUPT_H__
#define __REQUEST_INTERRUPT_H__

#include <memory>

#include <evtl/evtl_random.h>

#include "requestlink.h"


class request_interrupt
{
public:
	request_interrupt()
	{
		m_reqproceinfo = nullptr;
	}

	void set_requestproceinfo(requestprocessinfo *info)
	{
		m_reqproceinfo = info;
	}

	bool interrupted() const
	{
		if (m_reqlink)
			return true;
		return false;
	}

	void set_reqinfo(const requestinfo &info)
	{
		m_reqinfo = info;
	}

	void intrconnect()
	{
		if (m_reqlink)
			assert(false);

		m_reqlink = std::make_shared<requestlink>();

		m_reqlink->m_id = evtl::rand::urandom::str_az09(8);
		m_reqlink->m_group_id = m_reqproceinfo->m_sessinfo->m_base.m_groupid;

		m_reqlink->m_intconnector = m_reqproceinfo->m_sessinfo->m_base.m_connector;
		m_reqlink->m_local_key = m_reqproceinfo->m_sessinfo->m_base.m_sessionptr;
		m_reqlink->m_local_interrupt = m_reqproceinfo->m_sessinfo->m_base.m_localintr;
		m_reqlink->m_subprocessptr = m_reqproceinfo->m_procebase.m_requestprocessptr;
		m_reqlink->m_requestinfo = m_reqinfo;

		m_reqlink->m_syn = true;

		m_reqlink->m_intconnector(m_reqlink);
	}

	void fin_interrupt()
	{
		if (!m_reqlink)
			return;

		m_reqlink->m_local_fin = true;
		if (!m_reqlink->m_syn_ack || m_reqlink->m_remote_fin)
			return;

		m_reqlink->interrupt_remote(m_reqlink, 0);
	}

	bool got_response() const
	{
		if (!m_reqlink)
			return false;

		if (m_reqlink->m_got_response)
			return true;
		return false;
	}

	remoteresponse get_remoteresp() const
	{
		if (!m_reqlink)
			assert(false);

		return m_reqlink->m_response;
	}

	std::shared_ptr<requestlink> get_reqlink() const
	{
		return m_reqlink;
	}

	void reset()
	{
		m_reqproceinfo = nullptr;
		m_reqinfo.reset();
		m_reqlink.reset();
	}

private:
	requestprocessinfo  *m_reqproceinfo;
	requestinfo  m_reqinfo;

	std::shared_ptr<requestlink>  m_reqlink;
};


#endif


