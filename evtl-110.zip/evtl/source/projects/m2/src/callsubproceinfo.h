

#ifndef __CALLSUBPROCEINFO_H__
#define __CALLSUBPROCEINFO_H__

#include "requestlink.h"


struct callrequestproceinfo
{
	callrequestproceinfo()
	{
		m_sessinfo = nullptr;
		m_prep = nullptr;
		m_type = requesttype::unknown;
	}

	callsessioninfo  *m_sessinfo;
	callprep  *m_prep;
	requesttype   m_type;

	std::shared_ptr<requestlink>  m_reqlink;

	evtl::lock::routelockowner  m_searchlockowner;
};


struct callgiveproceinfo
{
	callgiveproceinfo()
	{
		m_sessinfo = nullptr;
		m_prep = nullptr;
		m_type = givereqtype::unknown;
		m_giveproceptr = nullptr;
	}

	callsessioninfo  *m_sessinfo;
	callprep  *m_prep;
	givereqtype  m_type;

	void * m_giveproceptr;

	evtl::lock::routelockowner  m_prelockowner;
	evtl::lock::routelockowner  m_sendlockowner;

	std::shared_ptr<givelink>  m_givelink;
};


struct callinvalidproceinfo
{
	callinvalidproceinfo()
	{
		m_sessinfo = nullptr;
		m_prep = nullptr;
	}

	callsessioninfo  *m_sessinfo;
	callprep  *m_prep;

	evtl::lock::routelockowner  m_prelockowner;
};


#endif


