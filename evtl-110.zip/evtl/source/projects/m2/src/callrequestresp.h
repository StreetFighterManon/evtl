

#ifndef __CALLREQUESTRESP_H__
#define __CALLREQUESTRESP_H__

#include <evtl/evtl_pcre2.h>


class callrequestresp
{
public:
	callrequestresp()
	{
		m_proceinfo = nullptr;
	}

	enum class searchresult
	{
		success,
		needrecv,
		needcontinue,
		otherroute,
		error,
	};

	bool ready()
	{
		if (m_proceinfo == nullptr)
			return false;
		return true;
	}

	void set_proceinfo(callrequestproceinfo *info)
	{
		m_proceinfo = info;
	}

	bool got() const
	{
		if (m_response.m_type == recvdatatype::unknown)
			return false;
		return true;
	}

	searchresult searchresp()
	{
		if (m_proceinfo == nullptr)
			assert(false);
		if (m_response.m_type != recvdatatype::unknown)
			assert(false);

		callpreproce &preproce = m_proceinfo->m_prep->m_proce;
		const recvdatainfo &datainfo = preproce.get_recvdatainfo();
		if (datainfo.m_type == recvdatatype::unknown)
		{
			if (preproce.needrecv())
				return searchresult::needrecv;
			else
				return searchresult::needcontinue;
		}

		if (datainfo.m_type != recvdatatype::response)
		{
			return searchresult::otherroute;
		}

		const requestinfo &reqinfo = m_proceinfo->m_reqlink->m_requestinfo;
		if (datainfo.m_id != reqinfo.m_id)
		{
			return searchresult::otherroute;
		}

		evtl::linearbuf<char> &recvbuf = preproce.get_recvbuf();
		ssize_t size = recvbuf.size();
		if (size <= 0)
			assert(false);

		evtl::pcre2_8::regex  reg(R"(\[response\]\r\nid: (\w+)\r\ncontent: (.*?)\r\n\[end\]\r\n)");
		evtl::pcre2_8::match_results<char> matches;
		bool br = evtl::pcre2_8::regex_search(recvbuf.dataptr(), recvbuf.dataptr() + size, matches, reg);
		if (br)
		{
			if (matches.size() != 3)
				assert(false);

			const evtl::pcre2_8::sub_match<char> &total = matches[0];
			const evtl::pcre2_8::sub_match<char> &subid = matches[1];
			const evtl::pcre2_8::sub_match<char> &subcontent = matches[2];
			if (!total.matched || !subid.matched || !subcontent.matched)
				assert(false);

			std::string id = subid.str();
			std::string content = subcontent.str();

			if (reqinfo.m_id != id)
				assert(false);

			m_response.m_type = recvdatatype::response;
			m_response.m_id = id;
			m_response.m_content = content;

			if (!recvbuf.shit_whole(total.second - recvbuf.dataptr()))
				assert(false);

			preproce.reset_datainfo();
			preproce.set_recvflag(false);
			return searchresult::success;
		}
		else
		{
			assert(false);
		}

		return searchresult::error;
	}

	responseinfo get_response() const
	{
		return m_response;
	}

	void reset()
	{
		m_response.reset();
	}

private:
	callrequestproceinfo  *m_proceinfo;
	responseinfo   m_response;
};


#endif


