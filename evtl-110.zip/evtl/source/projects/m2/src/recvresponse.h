

#ifndef __RECVRESPONSE_H__
#define __RECVRESPONSE_H__


class recvresponse
{
public:
	recvresponse()
	{
		m_giveproceinfo = nullptr;
		m_prep = nullptr;
		m_meetresp = false;
	}

	enum searchresult
	{
		success,
		needrecv,
		needcontinue,
		other_route
	};

	void set_giveproceinfo(giveproceinfo *info)
	{
		m_giveproceinfo = info;
	}

	void set_prep(comeprep *prep)
	{
		m_prep = prep;
	}

	bool ready() const
	{
		return m_id.isset();
	}

	void set_respid(const std::string &id)
	{
		m_id.set_assign(id);
	}

	bool got_response() const
	{
		return m_content.isset();
	}

	searchresult search_response()
	{
		if (!evtl::lock::routelock_acquire(m_prep->m_prelock, m_prelockowner))
		{
			m_giveproceinfo->m_preinfo_blocked = true;
			return searchresult::other_route;
		}

		if (!m_meetresp)
		{
			const recvdatainfo &datainfo = m_prep->m_proce.get_recvdatainfo();
			if (datainfo.m_type == recvdatatype::unknown)
			{
				evtl::lock::routelock_release(m_prep->m_prelock, m_prelockowner, true);

				if (m_prep->m_proce.needrecv())
					return searchresult::needrecv;
				else
					return searchresult::needcontinue;
			}
			else
			{
				if (datainfo.m_type != recvdatatype::response)
				{
					m_giveproceinfo->m_preinfo_blocked = true;
					evtl::lock::routelock_release(m_prep->m_prelock, m_prelockowner, true);
					return searchresult::other_route;
				}
				else
				{
					if (datainfo.m_id != m_id.refer())
					{
						m_giveproceinfo->m_preinfo_blocked = true;
						evtl::lock::routelock_release(m_prep->m_prelock, m_prelockowner, true);
						return searchresult::other_route;
					}

					m_meetresp = true;
				}
			}
		}

		if (!m_content.isset())
		{
			evtl::linearbuf<char> &buf = m_prep->m_proce.get_recvbuf();
			if (buf.empty())
				assert(false);

			evtl::pcre2_8::regex  reg(R"(\[response\]\r\nid: (\w+)\r\ncontent: (.*?)\r\n\[end\]\r\n)");
			evtl::pcre2_8::match_results<char>  matches;
			bool br = evtl::pcre2_8::regex_search(buf.dataptr(), buf.dataptr() + buf.size(), matches, reg);
			if (br)
			{
				if (matches.size() != 3)
					assert(false);

				const evtl::pcre2_8::sub_match<char> &all = matches[0];
				const evtl::pcre2_8::sub_match<char> &id = matches[1];
				const evtl::pcre2_8::sub_match<char> &cont = matches[2];
				if (!all.matched || !id.matched || !cont.matched)
					assert(false);

				std::string idstr = id.str();
				if (idstr != m_id.refer())
					assert(false);

				m_content.set_assign(cont.str());
				if (buf.shit_whole(all.second - buf.dataptr()))
					assert(false);

				m_prep->m_proce.reset_recvdata();
			}
			else
			{
				assert(false);
			}
		}

		evtl::lock::routelock_release(m_prep->m_prelock, m_prelockowner);
		return searchresult::success;
	}

	std::string get_content() const
	{
		return m_content;
	}

	void reset()
	{
		m_giveproceinfo = nullptr;
		m_prep = nullptr;
		m_prelockowner.reset();
		m_id.reset();
		m_meetresp = false;
		m_content.reset();
	}

private:
	giveproceinfo  *m_giveproceinfo;
	comeprep  *m_prep;
	evtl::lock::routelockowner  m_prelockowner;

	evtl::var<std::string>  m_id;
	bool  m_meetresp;
	evtl::var<std::string>  m_content;
};


#endif


