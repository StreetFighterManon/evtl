

#ifndef __ACCEPTOR_H__
#define __ACCEPTOR_H__

#include <evtl/evtl_acceptor.h>
#include <evtl/evtl_listener.h>


class acceptor : public evtl::acceptor<acceptor>
{
public:
	acceptor()
	{}

	bool set_addr(const evtl::address &addr)
	{
		return m_listener.set_address(addr);
	}

	bool start()
	{
		if (!m_listener.tcplisten(32))
			return false;
		set_listener(&m_listener);
		if (!watch())
			return false;
		return true;
	}

private:
	evtl::listener  m_listener;
};


#endif


