

#ifndef __REQUESTPROCESS_H__
#define __REQUESTPROCESS_H__

#include <evtl/evtl_com.h>

#include "request.h"
#include "request_interrupt.h"
#include "subprocessinfo.h"
#include "response.h"


class requestprocess
{
public:
	requestprocess()
	{
		m_prep = nullptr;
		m_nextstep = evtl::com::nextstep_unknown;
		m_reqtype = requesttype::unknown;
	}

	void set_prep(comeprep *prep)
	{
		m_prep = prep;
	}

	void set_sessinfo(comesessioninfo *info)
	{
		m_requestproceinfo.m_sessinfo = info;
	}

	void set_reqtype(requesttype type)
	{
		m_reqtype = type;
	}

	void init()
	{
		m_requestproceinfo.m_procebase.m_requestprocessptr = this;
		m_requestproceinfo.m_starttime_s = 0;
	}

	void process()
	{
		m_nextstep = evtl::com::nextstep_unknown;
		_process();
		if (m_nextstep == evtl::com::nextstep_cycledone)
		{
			_cycle_reset();
		}
	}

	evtl::com::process_nextstep get_nextstep() const
	{
		return m_nextstep;
	}

	bool prepblocked() const
	{
		return m_requestproceinfo.m_preinfo_blocked;
	}

	void clean()
	{
		if (m_requestproceinfo.m_starttime_s == 0)
			return;

		int64_t now_s = evtl::timec::fast_sec();
		if (now_s < m_requestproceinfo.m_starttime_s)
			m_requestproceinfo.m_starttime_s = now_s;

		if (m_reqtype == requesttype::multi)
		{
			if (now_s - m_requestproceinfo.m_starttime_s > 10)
			{
				if (m_sendlockown.is_lockown())
					return;

				m_interrupt.fin_interrupt();
				_cycle_reset();
			}
		}
	}

	bool needrecycle() const
	{
		if (m_requestproceinfo.m_starttime_s == 0)
			return false;

		if (m_reqtype == requesttype::single)
		{
			if (evtl::timec::fast_sec() - m_requestproceinfo.m_starttime_s > 10)
				return true;
		}

		return false;
	}

	bool request_localintr(std::shared_ptr<requestlink> link)
	{
		std::shared_ptr<requestlink> reqlink = m_interrupt.get_reqlink();
		if (!reqlink)
			return false;
		if (reqlink->m_id != link->m_id)
			return false;

		m_requestproceinfo.m_sessinfo->m_base.m_iointf->activate();
		return true;
	}

	void deinit()
	{
		m_request.reset();
		m_interrupt.fin_interrupt();
		m_interrupt.reset();

		m_sendlockown.reset();
		m_response.reset();
	}

private:
	void _process()
	{
		m_requestproceinfo.m_preinfo_blocked = false;

		if (!m_request.got())
		{
			m_request.set_requestproceinfo(&m_requestproceinfo);
			m_request.set_reqtype(m_reqtype);
			m_request.set_prep(m_prep);
			request::searchresult res = m_request.search();
			switch (res)
			{
			case request::searchresult::other_route:
				{
					set_nextstep(evtl::com::nextstep_none);
					return;
				}
				break;
			case request::searchresult::needrecv:
				{
					set_nextstep(evtl::com::nextstep_wait_to_receive);
					return;
				}
				break;
			case request::searchresult::needcontinue:
				{
					set_nextstep(evtl::com::nextstep_continue);
					return;
				}
				break;
			case request::searchresult::error:
				{
					set_nextstep(evtl::com::nextstep_error_end);
					return;
				}
				break;
			default:
				break;
			}

			if (res != request::searchresult::success)
				assert(false);
		}

		if (!m_request.got())
			assert(false && "ungot");

		if (!m_interrupt.interrupted())
		{
			m_interrupt.set_requestproceinfo(&m_requestproceinfo);
			m_interrupt.set_reqinfo(m_request.get_requestinfo());
			m_interrupt.intrconnect();
		}

		if (!m_interrupt.got_response())
		{
			set_nextstep(evtl::com::nextstep_stop);
			return;
		}

		if (!m_response.prepared())
		{
			m_response.set_sessinfo(m_requestproceinfo.m_sessinfo);
			m_response.set_remoteresponse(m_interrupt.get_remoteresp());
		}

		if (!evtl::lock::routelock_acquire(m_prep->m_sendlock, m_sendlockown))
		{
			set_nextstep(evtl::com::nextstep_none);
			return;
		}

		if (!m_response.finished())
			m_response.sendresponse();

		if (!m_response.finished())
		{
			set_nextstep(evtl::com::nextstep_wait_to_send);
			return;
		}

		evtl::lock::routelock_release(m_prep->m_sendlock, m_sendlockown);
		set_nextstep(evtl::com::nextstep_cycledone);
	}

	void set_nextstep(evtl::com::process_nextstep  step)
	{
		m_nextstep = step;
	}

	void _cycle_reset()
	{
		m_requestproceinfo.m_preinfo_blocked = false;
		m_requestproceinfo.m_starttime_s = 0;

		m_request.reset();
		m_interrupt.reset();
		if (m_sendlockown.is_lockown())
			assert(false);
		m_sendlockown.reset();
		m_response.reset();
	}

private:
	requestprocessinfo  m_requestproceinfo;

	comeprep  *m_prep;
	requesttype  m_reqtype;

	request    m_request;
	request_interrupt  m_interrupt;

	evtl::lock::routelockowner  m_sendlockown;
	response    m_response;

	evtl::com::process_nextstep  m_nextstep;
};


#endif


