

#ifndef __CALLPROCESS_H__
#define __CALLPROCESS_H__

#include <list>

#include <evtl/evtl_com.h>

#include "callprep.h"
#include "callrequestproce.h"
#include "callgiveproce.h"
#include "callinvalidproce.h"


class callprocess
{
public:
	callprocess()
	{
		m_sessinfo = nullptr;
		m_nextstep = evtl::com::nextstep_unknown;
	}

	void setsessinfo(callsessioninfo *sessinfo)
	{
		m_sessinfo = sessinfo;
	}

	void init()
	{
		m_prep.m_proce.set_sessinfo(m_sessinfo);

		m_singlerequest.set_sessinfo(m_sessinfo);
		m_singlerequest.set_prep(&m_prep);
		m_singlerequest.set_type(requesttype::single);

		m_singlegive.set_sessinfo(m_sessinfo);
		m_singlegive.set_prep(&m_prep);
		m_singlegive.set_type(givereqtype::single);
		m_singlegive.init();

		m_invalidproce.set_sessinfo(m_sessinfo);
		m_invalidproce.set_prep(&m_prep);
	}

	void process()
	{
		m_prep.m_proce.process();

		push_on();
		monitor();
		determine();
	}

	bool give_localintr(std::shared_ptr<givelink> link)
	{
		callgiveproce *proce = (callgiveproce *)link->m_giveproceptr;
		if (proce == nullptr)
			assert(false);

		if (proce == &m_singlegive)
			return m_singlegive.give_localintr(link);

		for (std::list<callgiveproce*>::const_iterator iter = m_multigive.begin(); iter != m_multigive.end(); ++iter)
		{
			callgiveproce *p = *iter;
			if (proce == p)
				return p->give_localintr(link);
		}
		return false;
	}

	evtl::com::process_nextstep get_nextstep() const
	{
		return m_nextstep;
	}

	void deinit()
	{
		m_singlerequest.deinit();
		for (std::list<callrequestproce*>::const_iterator iter = m_multirequest.begin(); iter != m_multirequest.end(); ++iter)
		{
			callrequestproce *proce = *iter;
			proce->deinit();
			delete proce;
		}
		m_multirequest.clear();

		m_singlegive.deinit();
		for (std::list<callgiveproce*>::const_iterator iter = m_multigive.begin(); iter != m_multigive.end(); ++iter)
		{
			callgiveproce *proce = *iter;
			proce->deinit();
			delete proce;
		}
		m_multigive.clear();

		m_invalidproce.deinit();
	}

private:
	void push_on()
	{
		m_stepstream.clear();

		m_nextstep = evtl::com::nextstep_unknown;

		m_singlerequest.process();
		m_stepstream << m_singlerequest.get_nextstep();

		for (std::list<callrequestproce*>::const_iterator iter = m_multirequest.begin(); iter != m_multirequest.end(); ++iter)
		{
			callrequestproce *proce = *iter;
			proce->process();
			m_stepstream << proce->get_nextstep();
		}

		m_singlegive.process();
		m_stepstream << m_singlegive.get_nextstep();

		for (std::list<callgiveproce*>::const_iterator iter = m_multigive.begin(); iter != m_multigive.end(); ++iter)
		{
			callgiveproce *proce = *iter;
			proce->process();
			m_stepstream << proce->get_nextstep();
		}

		if (received_invaliddata())
			m_invalidproce.process(true);
		else
			m_invalidproce.process(false);
		m_stepstream << m_invalidproce.get_nextstep();
	}

	void monitor()
	{
		bool multireq_idle = false;
		for (std::list<callrequestproce*>::iterator iter = m_multirequest.begin(); iter != m_multirequest.end(); )
		{
			callrequestproce *proce = *iter;

			if (proce->is_idlestatus())
				multireq_idle = true;

			if (proce->get_nextstep() == evtl::com::nextstep_cycledone)
			{
				m_multirequest.erase(iter++);
				proce->deinit();
				delete proce;
			}
			else
			{
				++iter;
			}
		}

		if (!multireq_idle)
		{
			if (m_multirequest.size() < 5)
			{
				callrequestproce *proce = new callrequestproce;
				proce->set_sessinfo(m_sessinfo);
				proce->set_prep(&m_prep);
				proce->set_type(requesttype::multi);
				m_multirequest.push_back(proce);

				m_stepstream << evtl::com::nextstep_continue;
			}
		}

		bool multigive_idle = false;
		for (std::list<callgiveproce*>::iterator iter = m_multigive.begin(); iter != m_multigive.end(); )
		{
			callgiveproce *proce = *iter;

			if (proce->is_idlestatus())
				multigive_idle = true;

			if (proce->get_nextstep() == evtl::com::nextstep_cycledone)
			{
				m_multigive.erase(iter++);
				proce->deinit();
				delete proce;
			}
			else
			{
				++iter;
			}
		}

		if (!multigive_idle)
		{
			if (m_multigive.size() < 5)
			{
				callgiveproce *proce = new callgiveproce;
				proce->set_sessinfo(m_sessinfo);
				proce->set_prep(&m_prep);
				proce->set_type(givereqtype::multi);
				proce->init();
				m_multigive.push_back(proce);

				m_stepstream << evtl::com::nextstep_continue;
			}
		}
	}

	void determine()
	{
		evtl::com::nextstepstream  stream;
		stream << evtl::com::nextstep_unknown << evtl::com::nextstep_none;
		if (m_stepstream <= stream)
			assert(false);

		stream.clear();
		stream << evtl::com::nextstep_error << evtl::com::nextstep_error_end;
		if (m_stepstream.have_one(stream))
		{
			set_nextstep(evtl::com::nextstep_error_end);
			return;
		}

		evtl::com::process_nextstep step = m_stepstream.elect();
		set_nextstep(step);
	}

	void set_nextstep(evtl::com::process_nextstep step)
	{
		m_nextstep = step;
	}

private:
	bool received_invaliddata() const
	{
		const recvdatainfo& datainfo = m_prep.m_proce.get_recvdatainfo();
		if (datainfo.m_type == recvdatatype::unknown)
			return false;
		if (datainfo.m_type == recvdatatype::invalid)
			return true;

		if (datainfo.m_type == recvdatatype::response)
		{
			if (m_singlerequest.is_mydata(datainfo))
				return false;
			for (std::list<callrequestproce*>::const_iterator iter = m_multirequest.begin(); iter != m_multirequest.end(); ++iter)
			{
				callrequestproce *proce = *iter;
				if (proce->is_mydata(datainfo))
					return false;
			}
			return true;
		}

		if (datainfo.m_type == recvdatatype::singlegive)
		{
			return false;
		}

		if (datainfo.m_type == recvdatatype::multigive)
		{
			return false;
		}

		return true;
	}

private:
	callsessioninfo  *m_sessinfo;
	callprep  m_prep;

	callrequestproce  m_singlerequest;
	std::list<callrequestproce*>  m_multirequest;

	callgiveproce  m_singlegive;
	std::list<callgiveproce*>  m_multigive;

	callinvalidproce  m_invalidproce;

	evtl::com::nextstepstream  m_stepstream;
	evtl::com::process_nextstep  m_nextstep;
};


#endif


