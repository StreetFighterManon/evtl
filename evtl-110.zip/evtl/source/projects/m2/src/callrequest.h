

#ifndef __CALLREQUEST_H__
#define __CALLREQUEST_H__

#include "requestlink.h"
#include "callsessioninfo.h"
#include "callsubproceinfo.h"


class callrequest
{
public:
	callrequest()
	{
		m_proceinfo = nullptr;
	}

	bool ready() const
	{
		if (m_proceinfo == nullptr)
			return false;
		return true;
	}

	void set_proceinfo(callrequestproceinfo *proceinfo)
	{
		m_proceinfo = proceinfo;
	}

	bool sendcomplete() const
	{
		if (m_buffer.isset() && m_buffer.refer().empty())
			return true;
		return false;
	}

	void sendrequest()
	{
		const requestinfo &reqinfo = m_proceinfo->m_reqlink->m_requestinfo;
		evtl::linearbuf<char> &buf = m_buffer.refer();
		if (!m_buffer.isset())
		{
			std::stringstream ss;

			if (reqinfo.m_type == requesttype::single)
			{
				ss << "[singlerequest]\r\n"
					<< "id: " << reqinfo.m_id << "\r\n"
					<< "content: " << reqinfo.m_content.tostring()
					<< "[end]\r\n";
			}
			else if (reqinfo.m_type == requesttype::multi)
			{
				ss << "[multirequest]\r\n"
					<< "id: " << reqinfo.m_id << "\r\n"
					<< "content: " << reqinfo.m_content.tostring()
					<< "[end]\r\n";
			}
			else
			{
				assert(false);
			}

			buf.extens_store_whole(ss.str());
			m_buffer.set();
		}

		ssize_t size = buf.size();
		if (size > 0)
		{
			ssize_t rt = m_proceinfo->m_sessinfo->m_base.m_iointf->io_write(buf.dataptr(), size);
			if (rt > 0)
			{
				if (rt > size)
					assert(false);

				if (!buf.shit_whole(rt))
					assert(false);
			}
		}
	}

	void reset()
	{
		m_proceinfo = nullptr;
		m_buffer.reset();
	}

private:
	callrequestproceinfo  *m_proceinfo;
	evtl::dn_var<evtl::linearbuf<char>>  m_buffer;
};


#endif


