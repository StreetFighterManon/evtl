

#ifndef __CALLGIVEREQUEST_H__
#define __CALLGIVEREQUEST_H__

#include "requestinfo.h"


class callgiverequest
{
public:
	callgiverequest()
	{
		m_proceinfo = nullptr;
	}

	enum class searchresult
	{
		success,
		needrecv,
		needcontinue,
		other_route,
		error
	};

	bool ready() const
	{
		if (m_proceinfo == nullptr)
			return false;
		return true;
	}

	void set_proceinfo(callgiveproceinfo *info)
	{
		m_proceinfo = info;
	}

	bool got()
	{
		if (m_requestinfo.m_type == givereqtype::unknown)
			return false;
		return true;
	}

	searchresult search()
	{
		if (m_requestinfo.m_type != givereqtype::unknown)
			assert(false);

		callpreproce &preproce = m_proceinfo->m_prep->m_proce;
		const recvdatainfo &datainfo = preproce.get_recvdatainfo();
		if (datainfo.m_type == recvdatatype::unknown)
		{
			if (preproce.needrecv())
				return searchresult::needrecv;
			else
				return searchresult::needcontinue;
		}

		if (m_proceinfo->m_type == givereqtype::single)
		{
			if (datainfo.m_type != recvdatatype::singlegive)
				return searchresult::other_route;
		}
		else if (m_proceinfo->m_type == givereqtype::multi)
		{
			if (datainfo.m_type != recvdatatype::multigive)
				return searchresult::other_route;
		}
		else
		{
			assert(false);
		}

		evtl::linearbuf<char> &buf = preproce.get_recvbuf();

		evtl::pcre2_8::regex  reg(R"(\[(\w+)\]\r\nid: (\w+)\r\ncontent: (.*?)\r\n\[end\]\r\n)");
		evtl::pcre2_8::match_results<char>  matches;
		bool br = evtl::pcre2_8::regex_search(buf.dataptr(), buf.dataptr() + buf.size(), matches, reg);
		if (br)
		{
			if (matches.size() != 4)
				assert(false);

			const evtl::pcre2_8::sub_match<char> &whole = matches[0];
			const evtl::pcre2_8::sub_match<char> &header = matches[1];
			const evtl::pcre2_8::sub_match<char> &id = matches[2];
			const evtl::pcre2_8::sub_match<char> &content = matches[3];
			if (!whole.matched || !header.matched || !id.matched || !content.matched)
				assert(false);

			std::string headers = header.str();
			std::string ids = id.str();
			std::string contents = content.str();

			if (m_proceinfo->m_type == givereqtype::single)
			{
				if (headers != "singlegive")
					assert(false);
			}
			else if (m_proceinfo->m_type == givereqtype::multi)
			{
				if (headers != "multigive")
					assert(false);
			}

			if (ids.empty())
				assert(false);

			m_requestinfo.m_type = m_proceinfo->m_type;
			m_requestinfo.m_id = ids;
			m_requestinfo.m_content.extens_store_whole(contents);

			if (!buf.shit_whole(whole.second - buf.dataptr()))
				assert(false);

			preproce.reset_datainfo();
			preproce.set_recvflag(false);
			return searchresult::success;
		}

		assert(false);
		return searchresult::error;
	}

	givereqinfo get_requestinfo() const
	{
		return m_requestinfo;
	}

	void reset()
	{
		m_requestinfo.reset();
	}

private:
	callgiveproceinfo  *m_proceinfo;

	givereqinfo  m_requestinfo;
};


#endif


