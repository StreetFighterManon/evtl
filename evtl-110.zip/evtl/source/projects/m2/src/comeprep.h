

#ifndef __COMEPREP_H__
#define __COMEPREP_H__

#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_lock.h>

#include "comepreprocess.h"


struct comeprep
{
	comeprep()
	{}

	comepreprocess  m_proce;
	evtl::lock::routelock  m_prelock;
	evtl::lock::routelock  m_sendlock;
};


#endif


