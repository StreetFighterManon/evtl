

#ifndef __CALLPREPPROCE_H__
#define __CALLPREPPROCE_H__

#include <evtl/evtl_pcre2.h>

#include "callsessioninfo.h"
#include "recvdata.h"


class callpreproce
{
public:
	callpreproce(): m_recvbuf(12*1024)
	{
		m_sessinfo = nullptr;
	}

	void set_sessinfo(callsessioninfo *info)
	{
		m_sessinfo = info;
	}

	void process()
	{
		m_needrecv = false;

		if (m_datainfo.m_type != recvdatatype::unknown)
			return;

		ssize_t size = m_recvbuf.size();
		if (size > 0)
		{
			evtl::pcre2_8::regex  reg(R"(\[(\w+)\]\r\nid: (\d+)\r\ncontent: .*?\r\n\[end\]\r\n)");
			evtl::pcre2_8::match_results<char>  matches;
			bool br = evtl::pcre2_8::regex_search(m_recvbuf.dataptr(), m_recvbuf.dataptr() + m_recvbuf.size(), matches, reg);
			if (br)
			{
				if (matches.size() != 3)
					assert(false);

				const evtl::pcre2_8::sub_match<char> &header = matches[1];
				const evtl::pcre2_8::sub_match<char> &id = matches[2];
				if (!header.matched || !id.matched)
					assert(false);

				std::string  headerstr = header.str();
				std::string  idstr = id.str();

				if (idstr.empty())
				{
					m_datainfo.m_type = recvdatatype::invalid;
					return;
				}

				m_datainfo.m_id = idstr;

				if (headerstr == "response")
				{
					m_datainfo.m_type = recvdatatype::response;
				}
				else if (headerstr == "singlegive")
				{
					m_datainfo.m_type = recvdatatype::singlegive;
				}
				else if (headerstr == "multigive")
				{
					m_datainfo.m_type = recvdatatype::multigive;
				}
				else if (headerstr == "qsingleheartbeat")
				{
					m_datainfo.m_type = recvdatatype::qsingleheartbeat;
				}
				else if (headerstr == "qmultiheartbeat")
				{
					m_datainfo.m_type = recvdatatype::qmultiheartbeat;
				}
				else
				{
					m_datainfo.m_type = recvdatatype::invalid;
				}
				return;
			}
		}

		m_recvbuf.crowdct(8*1024, 8*1024);
		ssize_t headsp = m_recvbuf.headspace();
		if (headsp <= 0)
		{
			m_datainfo.m_type = recvdatatype::invalid;
			return;
		}

		ssize_t rt = m_sessinfo->m_base.m_iointf->io_read(m_recvbuf.headptr(), headsp);
		if (rt > 0)
		{
			if (rt > headsp)
				assert(false);

			if (!m_recvbuf.head_eaten_whole(rt))
				assert(false);
			m_needrecv = false;
		}
		else
		{
			m_needrecv = true;
		}
	}

	const recvdatainfo& get_recvdatainfo() const
	{
		return m_datainfo;
	}

	evtl::linearbuf<char> &get_recvbuf()
	{
		return m_recvbuf;
	}

	bool needrecv() const
	{
		return m_needrecv;
	}

	void set_recvflag(bool flag)
	{
		m_needrecv = flag;
	}

	void reset_datainfo()
	{
		m_datainfo.reset();
	}

private:
	callsessioninfo  *m_sessinfo;

	evtl::linearbuf<char>  m_recvbuf;

	recvdatainfo   m_datainfo;
	evtl::boolflag<false>  m_needrecv;
};


#endif


