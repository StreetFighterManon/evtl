

#ifndef __GIVEREQUEST_H__
#define __GIVEREQUEST_H__

#include <string>
#include <sstream>

#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_com.h>


class giverequest
{
public:
	giverequest()
	{
		m_sessbase = nullptr;
	}

	void set_sessbase(comesessionbase *base)
	{
		m_sessbase = base;
	}

	bool is_linkset() const
	{
		if (m_givelink)
			return true;
		return false;
	}

	void set_link(std::shared_ptr<givelink> ptr)
	{
		m_givelink = ptr;
	}

	bool sendcomplete() const
	{
		if (m_sendbuf.isset() && m_sendbuf.refer().empty())
			return true;
		return false;
	}

	void send()
	{
		if (!m_givelink)
			assert(false);

		if (!m_sendbuf.isset())
		{
			std::stringstream ss;
			if (m_givelink->m_reqinfo.m_type == givereqtype::single)
			{
				ss << "[singlegive]\r\n"
					<< "id: " << m_givelink->m_reqinfo.m_id << "\r\n"
					<< "content: " << m_givelink->m_reqinfo.m_content.tostring() << "\r\n"
					<< "[end]\r\n";
			}
			else if (m_givelink->m_reqinfo.m_type == givereqtype::multi)
			{
				ss << "[multigive]\r\n"
					<< "id: " << m_givelink->m_reqinfo.m_id << "\r\n"
					<< "content: " << m_givelink->m_reqinfo.m_content.tostring() << "\r\n"
					<< "[end]\r\n";
			}
			else
			{
				assert(false);
			}

			m_sendbuf.refer().extens_store_whole(ss.str());
			m_sendbuf.set();
		}

		evtl::linearbuf<char> &buf = m_sendbuf.refer();
		ssize_t sz = buf.size();
		if (sz > 0)
		{
			ssize_t rt = m_sessbase->m_iointf->io_write(buf.dataptr(), sz);
			if (rt > 0)
			{
				if (rt > sz)
					assert(false);
				if (!buf.shit_whole(rt))
					assert(false);
			}
		}
	}

	std::string get_id() const
	{
		return m_givelink->m_reqinfo.m_id;
	}

	std::shared_ptr<givelink> get_givelink() const
	{
		return m_givelink;
	}

	void reset()
	{
		m_sessbase = nullptr;
		m_givelink.reset();
		m_sendbuf.reset();
	}

private:
	comesessionbase  *m_sessbase;
	std::shared_ptr<givelink>  m_givelink;
	evtl::st_var<evtl::linearbuf<char>>  m_sendbuf;
};


#endif


