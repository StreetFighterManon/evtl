

#ifndef __REQUESTINFO_H__
#define __REQUESTINFO_H__

#include <string>

#include <evtl/evtl_linearbuf.h>


enum class requesttype
{
	unknown,
	single,
	multi
};

struct requestinfo
{
	requestinfo()
	{
		m_type = requesttype::unknown;
	}

	void reset()
	{
		m_type = requesttype::unknown;
		m_id.clear();
		m_content.clear();
	}

	requesttype  m_type;
	std::string  m_id;
	evtl::linearbuf<char>  m_content;
};


enum class givereqtype
{
	unknown,
	single,
	multi
};

struct givereqinfo
{
	givereqinfo()
	{
		m_type = givereqtype::unknown;
	}

	void reset()
	{
		m_type = givereqtype::unknown;
		m_id.clear();
		m_content.clear();
	}

	givereqtype  m_type;
	std::string  m_id;
	evtl::linearbuf<char>  m_content;
};


#endif


