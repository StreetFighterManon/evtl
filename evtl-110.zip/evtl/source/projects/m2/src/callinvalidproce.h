

#ifndef __CALLINVALIDPROCE_H__
#define __CALLINVALIDPROCE_H__


class callinvalidproce
{
public:
	callinvalidproce()
	{}

	void set_sessinfo(callsessioninfo *info)
	{
		m_proceinfo.m_sessinfo = info;
	}

	void set_prep(callprep *prep)
	{
		m_proceinfo.m_prep = prep;
	}

	void process(bool invaliddata)
	{
		m_nextstep = evtl::com::nextstep_unknown;
		_process(invaliddata);
		if (m_nextstep == evtl::com::nextstep_cycledone)
			_cycle_reset();
	}

	evtl::com::process_nextstep get_nextstep() const
	{
		return m_nextstep;
	}

	void deinit()
	{
		m_nextstep = evtl::com::nextstep_unknown;
	}

private:
	void _process(bool invaliddata)
	{
		if (!evtl::lock::routelock_acquire(m_proceinfo.m_prep->m_prelock, m_proceinfo.m_prelockowner))
		{
			set_nextstep(evtl::com::nextstep_none);
			return;
		}

		const recvdatainfo &info = m_proceinfo.m_prep->m_proce.get_recvdatainfo();
		if (info.m_type == recvdatatype::unknown)
		{
			evtl::lock::routelock_release(m_proceinfo.m_prep->m_prelock, m_proceinfo.m_prelockowner, true);
			if (m_proceinfo.m_prep->m_proce.needrecv())
				set_nextstep(evtl::com::nextstep_wait_to_receive);
			else
				set_nextstep(evtl::com::nextstep_continue);
			return;
		}

		if (!invaliddata)
		{
			evtl::lock::routelock_release(m_proceinfo.m_prep->m_prelock, m_proceinfo.m_prelockowner, true);
			set_nextstep(evtl::com::nextstep_none);
			return;
		}

		if (info.m_type == recvdatatype::invalid)
		{
			evtl::lock::routelock_release(m_proceinfo.m_prep->m_prelock, m_proceinfo.m_prelockowner, true);
			set_nextstep(evtl::com::nextstep_error_end);
			return;
		}

		callpreproce &proce = m_proceinfo.m_prep->m_proce;
		evtl::linearbuf<char> &buf = proce.get_recvbuf();
		ssize_t sz = buf.size();
		if (sz <= 0)
			assert(false);

		evtl::pcre2_8::regex reg(R"(\[\w+\]\r\nid: \w+\r\ncontent: .*?\r\n\[end\]\r\n)");
		evtl::pcre2_8::match_results<char> matches;
		bool br = evtl::pcre2_8::regex_search(buf.dataptr(), buf.dataptr() + buf.size(), matches, reg);
		if (br)
		{
			if (matches.size() != 1)
				assert(false);

			const evtl::pcre2_8::sub_match<char> &sub = matches[0];
			if (!sub.matched)
				assert(false);

			if (!buf.shit_whole(sub.second - buf.dataptr()))
				assert(false);
			proce.reset_datainfo();
			proce.set_recvflag(false);
		}
		else
		{
			assert(false);
		}

		evtl::lock::routelock_release(m_proceinfo.m_prep->m_prelock, m_proceinfo.m_prelockowner, true);
		set_nextstep(evtl::com::nextstep_cycledone);
		return;
	}

	void _cycle_reset()
	{
		m_proceinfo.m_prelockowner.reset();
	}

private:
	void set_nextstep(evtl::com::process_nextstep step)
	{
		m_nextstep = step;
	}

private:
	callinvalidproceinfo  m_proceinfo;

	evtl::com::process_nextstep  m_nextstep;
};


#endif


