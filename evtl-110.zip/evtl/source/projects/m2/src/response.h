

#ifndef __RESPONSE_H__
#define __RESPONSE_H__

#include <evtl/evtl_linearbuf.h>

#include "comesessioninfo.h"


class response
{
public:
	response()
	{
		m_sessinfo = nullptr;
	}

	bool finished() const
	{
		if (m_respbuf.isset() && m_respbuf.refer().empty())
			return true;
		return false;
	}

	bool prepared() const
	{
		if (m_sessinfo == nullptr)
			return false;
		return true;
	}

	void set_sessinfo(comesessioninfo *info)
	{
		m_sessinfo = info;
	}

	void set_remoteresponse(const remoteresponse &resp)
	{
		m_respinfo = resp;
	}

	void sendresponse()
	{
		if (m_sessinfo == nullptr)
			assert(false);

		if (!m_respbuf.isset())
		{
			if (m_respinfo.m_error != errortype::success)
			{
				m_respbuf.refer().clear();
			}
			else
			{
				std::stringstream ss;
				ss << "[response]\r\n"
					<< "id: " << m_respinfo.m_responseinfo.m_id << "\r\n"
					<< "content: " << m_respinfo.m_responseinfo.m_content << "\r\n"
					<< "[end]\r\n";

				m_respbuf.refer().extens_store_whole(ss.str());
			}
			m_respbuf.set();
		}

		evtl::linearbuf<char> &buf = m_respbuf.refer();
		ssize_t sz = buf.size();
		if (sz > 0)
		{
			ssize_t rt = m_sessinfo->m_base.m_iointf->io_write(buf.dataptr(), sz);
			if (rt > 0)
			{
				if (rt > sz)
					assert(false);
				if (!buf.shit_whole(rt))
					assert(false);
			}
		}
	}

	void reset()
	{
		m_sessinfo = nullptr;
		m_respinfo.reset();
		m_respbuf.reset();
	}

private:
	comesessioninfo  *m_sessinfo;
	remoteresponse  m_respinfo;

	evtl::dn_var<evtl::linearbuf<char>>  m_respbuf;
};


#endif


