

#ifndef __COMEINVALIDPROCESS_H__
#define __COMEINVALIDPROCESS_H__

#include "invalidrequest.h"


class comeinvalidprocess
{
public:
	comeinvalidprocess()
	{
		m_sessinfo = nullptr;
		m_prep = nullptr;
	}

	void set_sessinfo(comesessioninfo *info)
	{
		m_sessinfo = info;
	}

	void set_prep(comeprep *prep)
	{
		m_prep = prep;
	}

	void init()
	{
	}

	void process(bool prepblocked_all)
	{
		m_nextstep = evtl::com::nextstep_unknown;
		_process(prepblocked_all);
		if (m_nextstep == evtl::com::nextstep_cycledone)
		{
			_cycle_reset();
		}
	}

	evtl::com::process_nextstep  get_nextstep() const
	{
		return m_nextstep;
	}

private:
	void _process(bool prepblocked_all)
	{
		if (!m_request.got())
		{
			m_request.set_prep(m_prep);
			invalidrequest::searchresult result = m_request.search(prepblocked_all);
			switch (result)
			{
			case invalidrequest::searchresult::needrecv:
				{
					set_nextstep(evtl::com::nextstep_wait_to_receive);
					return;
				}
				break;
			case invalidrequest::searchresult::needcontinue:
				{
					set_nextstep(evtl::com::nextstep_continue);
					return;
				}
				break;
			case invalidrequest::searchresult::other_route:
				{
					set_nextstep(evtl::com::nextstep_none);
					return;
				}
				break;
			case invalidrequest::searchresult::invalid_request:
				{
					set_nextstep(evtl::com::nextstep_error_end);
					return;
				}
				break;
			default:
				break;
			}

			if (result != invalidrequest::searchresult::success)
				assert(false);
		}

		set_nextstep(evtl::com::nextstep_cycledone);
	}

	void set_nextstep(evtl::com::process_nextstep step)
	{
		m_nextstep = step;
	}

	void _cycle_reset()
	{
		m_request.reset();
	}

private:
	comesessioninfo *m_sessinfo;
	comeprep  *m_prep;

	invalidrequest  m_request;

	evtl::com::process_nextstep  m_nextstep;
};


#endif


