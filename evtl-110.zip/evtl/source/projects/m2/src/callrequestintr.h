

#ifndef __CALLREQUESTINTR_H__
#define __CALLREQUESTINTR_H__


class callrequestintr
{
public:
	callrequestintr()
	{}

	bool interrupted() const
	{
		if (m_link)
			return true;
		return false;
	}

	void set_link(std::shared_ptr<requestlink> link)
	{
		m_link = link;
	}

	void set_response(responseinfo resp)
	{
		m_response = resp;
	}

	void response_interrupt()
	{
		remoteresponse &resp = m_link->m_response;
		resp.m_error = errortype::success;
		resp.m_errstr.clear();
		resp.m_responseinfo = m_response;
		m_link->m_got_response = true;
		m_link->interrupt_local(m_link, 0);
	}

	void reset()
	{
		m_link.reset();
		m_response.reset();
	}

private:
	std::shared_ptr<requestlink>  m_link;
	responseinfo  m_response;
};


#endif


