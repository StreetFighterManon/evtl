

#ifndef __COMESESSION_H__
#define __COMESESSION_H__

#include <list>
#include <functional>
#include <utility>

#include <evtl/evtl_watcher_io.h>
#include <evtl/evtl_in.h>
#include <evtl/evtl_random.h>

#include "comeprocess.h"
#include "interface.h"
#include "comesessioninfo.h"
#include "requestinfo.h"


class comesession : public evtl::watcher_io<comesession>,
	public iointerface
{
public:
	comesession()
	{}

	typedef std::function<void (comesession *psess)>  recycle_callback_t;

	void set_loop(evtl::looprefer loop)
	{
		m_loop = loop;
		set(loop);
	}

	void set_reqintrconnector(requestlink::intr_connector connector)
	{
		m_sessinfo.m_base.m_connector = std::move(connector);
	}

	void set_reqlocalintr(requestlink::intr_entrance localintr)
	{
		m_sessinfo.m_base.m_localintr = std::move(localintr);
	}

	void set_closeintrconnector(closelink::intr_connector connector)
	{
		m_sessinfo.m_base.m_closeconnector = std::move(connector);
	}

	void set_recycle_callback(recycle_callback_t cb)
	{
		m_recycle_cb = std::move(cb);
	}

	void someinit()
	{
		m_sessinfo.m_base.m_groupid = evtl::rand::urandom::str_az09(8);
		m_sessinfo.m_base.m_iointf = this;
		m_sessinfo.m_base.m_sessionptr = this;
		update_recvtime();

		m_process.set_sessinfo(&m_sessinfo);
		m_process.init();
	}

	ssize_t io_read(void *buf, ssize_t n)
	{
		if (buf == nullptr || n <= 0)
			assert(false && "invalid param");

		ssize_t r = this->read(buf, n);
		if (r > 0)
		{
			if (r > n)
				assert(false && "read except");

			update_recvtime();
		}
		else if (r < 0)
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
				m_iostatus.orset(evtl::com::rwresult_read_error, errno);
		}
		else
		{
			m_iostatus.orset(evtl::com::rwresult_read_end, 0);
		}

		return r;
	}

	ssize_t io_write(const void *buf, ssize_t n)
	{
		if (buf == nullptr || n <= 0)
			assert(false && "invalid param");

		ssize_t r = this->write(buf, n);
		if (r > 0)
		{
			if (r > n)
				assert(false && "read except");
		}
		else if (r < 0)
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
				m_iostatus.orset(evtl::com::rwresult_write_error, errno);
		}
		else
		{
			assert(false && "write 0");
		}

		return r;
	}

	void activate()
	{
		int events = get_events();
		if ((events & ev::WRITE) == 0)
		{
			stop();
			set_events(events | ev::WRITE);
			start();
		}
		else
		{
			if (!is_active())
				start();
		}
	}

	std::string get_groupid() const
	{
		return m_sessinfo.m_base.m_groupid;
	}

	void io_callback(comesession &watcher, int revents)
	{
		if (&watcher != this)
			assert(false && "watcher unmathed");

		m_process.process();

		if (m_iostatus.error_raised())
		{
			stop();
			m_recycle_cb(this);
			return;
		}

		evtl::com::process_nextstep  step = m_process.get_nextstep();
		switch (step)
		{
		case evtl::com::nextstep_wait_to_receive:
			{
				if (get_events() != ev::READ)
				{
					stop();
					set_events(ev::READ);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
				return;
			}
			break;
		case evtl::com::nextstep_wait_to_send:
			{
				if (get_events() != ev::WRITE)
				{
					stop();
					set_events(ev::WRITE);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
				return;
			}
			break;
		case evtl::com::nextstep_wait_to_receive_send:
			{
				if (get_events() != (ev::WRITE | ev::READ))
				{
					stop();
					set_events(ev::WRITE | ev::READ);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
				return;
			}
			break;
		case evtl::com::nextstep_continue:
			{
				if (get_events() != ev::WRITE)
				{
					stop();
					set_events(ev::WRITE);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
				return;
			}
			break;
		case evtl::com::nextstep_stop:
			{
				stop();
				return;
			}
			break;
		case evtl::com::nextstep_cycledone:
			{
				if (get_events() != ev::WRITE)
				{
					stop();
					set_events(ev::WRITE);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
				return;
			}
			break;
		case evtl::com::nextstep_error:
		case evtl::com::nextstep_error_end:
			{
				stop();
				m_recycle_cb(this);
				return;
			}
			break;
		default:
			assert(false && "invalid step");
			break;
		};
	}

	void receive_givelink(std::shared_ptr<givelink> linkptr)
	{
		if (linkptr->m_reqinfo.m_type == givereqtype::single)
			m_sessinfo.m_singlegivelinks.push_back(linkptr);
		else if (linkptr->m_reqinfo.m_type == givereqtype::multi)
			m_sessinfo.m_multigivelinks.push_back(linkptr);
		else
			assert(false && "invalid givereqtype");

		activate();
	}

	void clean()
	{
		m_process.clean();
	}

	bool needrecycle() const
	{
		int64_t now_s = evtl::timec::fast_sec();
		if (now_s - m_sessinfo.m_last_recvtime_s > 20)
			return true;

		return m_process.needrecycle();
	}

	bool request_localintr(const requestlink::intr_message &message)
	{
		std::shared_ptr<requestlink> ptr = message.datalink;
		if (get_groupid() != ptr->m_group_id)
			return false;

		return m_process.request_localintr(ptr);
	}

	void close_interrupt()
	{
		std::shared_ptr<closelink> link = std::make_shared<closelink>();

		link->m_group_id = get_groupid();
		link->m_intconnector = m_sessinfo.m_base.m_closeconnector;
		link->interrupt_connect(link);
	}

	void deinit()
	{
		m_process.deinit();
		stop_close();
	}

	void update_recvtime()
	{
		m_sessinfo.m_last_recvtime_s = evtl::timec::fast_sec();
	}

private:
	evtl::looprefer  m_loop;
	comesessioninfo  m_sessinfo;
	recycle_callback_t  m_recycle_cb;
	evtl::com::rwstatus  m_iostatus;

	comeprocess  m_process;
};


#endif


