

#include <iostream>
using namespace std;

#include <cassert>
#include <evtl/evtl_random.h>
#include <evtl/evtl_signal.h>

#include "m2driver.h"


int main()
{
	evtl::timec::background_update(100);
	evtl::rand::urandom::init();
	evtl::signalc::sig_ignore(SIGPIPE);

	m2driver  *driver = new m2driver;
	driver->init();
	driver->run();
	assert(false);
	return 0;
}


