

#ifndef __CALLSESSION_H__
#define __CALLSESSION_H__

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_watcher_io.h>
#include <evtl/evtl_com.h>

#include "interface.h"
#include "callprocess.h"
#include "callsessioninfo.h"


class callsession : public evtl::watcher_io<callsession>,
	public iointerface
{
public:
	callsession()
	{
		m_last_active_time_s = 0;
	}

	void set_loop(evtl::looprefer loop)
	{
		m_sessinfo.m_loop = loop;
		set(loop);
	}

	void set_groupid(const std::string &id)
	{
		m_sessinfo.m_groupid = id;
	}

	void setcomesessptr(void *ptr)
	{
		m_sessinfo.m_comesessptr = ptr;
	}

	void set_giveintrconnector(givelink::intr_connector connector)
	{
		m_sessinfo.m_give_intrconnector = connector;
	}

	void set_give_localintr(givelink::intr_entrance localintr)
	{
		m_sessinfo.m_give_localintr = localintr;
	}

	void set_callsesstcptr(void *ptr)
	{
		m_sessinfo.m_callsesstcptr = ptr;
	}

	void set_singlereqlist(std::list<std::shared_ptr<requestlink>> *links)
	{
		m_sessinfo.m_singlereqlist = links;
	}

	void set_multireqlist(std::list<std::shared_ptr<requestlink>> *links)
	{
		m_sessinfo.m_multireqlist = links;
	}

	void set_recycle_callback(std::function<void ()> cb)
	{
		m_recycle_cb = std::move(cb);
	}

	void init()
	{
		m_sessinfo.m_base.m_iointf = this;
		m_last_active_time_s = evtl::timec::fast_sec();
		m_process.setsessinfo(&m_sessinfo);
		m_process.init();
	}

	std::string get_groupid() const
	{
		return m_sessinfo.m_groupid;
	}

	void activate()
	{
		if ((get_events() & ev::WRITE) == 0)
		{
			stop();
			set_events(ev::WRITE);
			start();
		}
		else
		{
			if (!is_active())
				start();
		}
	}

	ssize_t io_read(void *buf, ssize_t n)
	{
		if (buf == nullptr || n <= 0)
			assert(false);

		ssize_t r = this->read(buf, n);
		if (r > 0)
		{
			if (r > n)
				assert(false);

			m_last_active_time_s = evtl::timec::fast_sec();
		}
		else if (r < 0)
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
				m_iostatus.orset(evtl::com::rwresult_read_error, errno);
		}
		else
		{
			m_iostatus.orset(evtl::com::rwresult_read_end, 0);
		}

		return r;
	}

	ssize_t io_write(const void *buf, ssize_t n)
	{
		if (buf == nullptr || n <= 0)
			assert(false);

		ssize_t r = this->write(buf, n);
		if (r > 0)
		{
			if (r > n)
				assert(false);

			m_last_active_time_s = evtl::timec::fast_sec();
		}
		else if (r < 0)
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
				m_iostatus.orset(evtl::com::rwresult_write_error, errno);
		}
		else
		{
			assert(false);
		}

		return r;
	}

	void io_callback(callsession &watcher, int revents)
	{
		if (&watcher != this)
			assert(false);

		m_process.process();

		if (m_iostatus.error_raised())
		{
			stop();
			m_recycle_cb();
			return;
		}

		evtl::com::process_nextstep step = m_process.get_nextstep();
		switch (step)
		{
		case evtl::com::nextstep_wait_to_receive:
			{
				if (get_events() != ev::READ)
				{
					stop();
					set_events(ev::READ);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
			}
			break;
		case evtl::com::nextstep_wait_to_send:
			{
				if (get_events() != ev::WRITE)
				{
					stop();
					set_events(ev::WRITE);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
			}
			break;
		case evtl::com::nextstep_wait_to_receive_send:
			{
				if (get_events() != (ev::READ | ev::WRITE))
				{
					stop();
					set_events(ev::READ | ev::WRITE);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
			}
			break;
		case evtl::com::nextstep_continue:
			{
				if ((get_events() & ev::WRITE) == 0)
				{
					stop();
					set_events(ev::WRITE);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
			}
			break;
		case evtl::com::nextstep_stop:
			{
				stop();
			}
			break;
		case evtl::com::nextstep_cycledone:
			{
				if ((get_events() & ev::WRITE) == 0)
				{
					stop();
					set_events(ev::WRITE);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
			}
			break;
		case evtl::com::nextstep_done:
			{
				assert(false);
			}
			break;
		case evtl::com::nextstep_done_end:
			{
				assert(false);
			}
			break;
		case evtl::com::nextstep_error:
		case evtl::com::nextstep_error_end:
			{
				stop();
				m_recycle_cb();
			}
			break;
		case evtl::com::nextstep_other:
			{
				assert(false);
			}
			break;
		default:
			assert(false && "unknown step");
			break;
		}
	}

	bool give_localintr(std::shared_ptr<givelink> link)
	{
		if (link->m_group_id != m_sessinfo.m_groupid)
			return false;

		return m_process.give_localintr(link);
	}

	bool need_recycle() const
	{
		int64_t now_s = evtl::timec::fast_sec();
		if (now_s - m_last_active_time_s > 60)
			return true;

		return false;
	}

	void deinit()
	{
		m_process.deinit();
		stop_close();
	}

private:
	callsessioninfo  m_sessinfo;

	std::function<void ()>  m_recycle_cb;
	evtl::com::rwstatus  m_iostatus;
	int64_t  m_last_active_time_s;

	callprocess  m_process;
};


#endif


