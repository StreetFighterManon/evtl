

#ifndef __SERVICE_H__
#define __SERVICE_H__

#include <vector>

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_in.h>

#include "comeservice.h"
#include "callservice.h"


class service
{
public:
	service()
	{}

	void set_loop(evtl::looprefer loop)
	{
		m_loop = loop;
	}

	bool init()
	{
		m_come.set_loop(m_loop);
		m_come.set_request_intrconnector(std::bind(&callservice::request_intrconnector, &m_call, std::placeholders::_1));
		m_come.set_close_intrconnector(std::bind(&callservice::close_intrconnector, &m_call, std::placeholders::_1));
		if (!m_come.init())
			return false;

		m_call.set_loop(m_loop);
		m_call.set_give_intrconnector(std::bind(&comeservice::give_intrconnect, &m_come, std::placeholders::_1));
		m_call.init();

		return true;
	}

	void receive_connection(std::vector<evtl::connection> &conns)
	{
		m_come.receive_connection(conns);
	}

private:
	evtl::looprefer  m_loop;
	comeservice  m_come;
	callservice  m_call;
};


#endif


