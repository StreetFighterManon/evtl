

#ifndef __REQUEST_H__
#define __REQUEST_H__

#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_linearbuf.h>

#include "requestinfo.h"
#include "subprocessinfo.h"


class request
{
public:
	request()
	{
		m_requestproceinfo = nullptr;
		m_reqtype = requesttype::unknown;
		m_prep = nullptr;
	}

	enum class searchresult
	{
		success,
		other_route,
		needrecv,
		needcontinue,
		error
	};

	void set_requestproceinfo(requestprocessinfo *info)
	{
		m_requestproceinfo = info;
	}

	void set_reqtype(requesttype type)
	{
		m_reqtype = type;
	}

	void set_prep(comeprep *prep)
	{
		m_prep = prep;
	}

	bool got() const
	{
		return m_requestinfo.isset();
	}

	searchresult search()
	{
		if (m_requestinfo.isset())
			assert(false);

		if (m_prep->m_prelock.is_locked())
		{
			m_requestproceinfo->m_preinfo_blocked = true;
			return searchresult::other_route;
		}

		evtl::lock::lockguard<evtl::lock::routelock>  lg(m_prep->m_prelock);

		const recvdatainfo &datainfo = m_prep->m_proce.get_recvdatainfo();
		switch (datainfo.m_type)
		{
		case recvdatatype::unknown:
			{
				if (m_prep->m_proce.needrecv())
					return searchresult::needrecv;
				else
					return searchresult::needcontinue;
			}
			break;
		case recvdatatype::singlereq:
			{
				if (m_reqtype != requesttype::single)
				{
					m_requestproceinfo->m_preinfo_blocked = true;
					return searchresult::other_route;
				}
			}
			break;
		case recvdatatype::multireq:
			{
				if (m_reqtype != requesttype::multi)
				{
					m_requestproceinfo->m_preinfo_blocked = true;
					return searchresult::other_route;
				}
			}
			break;
		default:
			{
				m_requestproceinfo->m_preinfo_blocked = true;
				return searchresult::other_route;
			}
			break;
		}

		evtl::linearbuf<char> &recvbuf = m_prep->m_proce.get_recvbuf();
		ssize_t size = recvbuf.size();
		if (size <= 0)
			assert(false);

		evtl::pcre2_8::regex  reg(R"(\A\[(\w+)\]\r\nid: *(\d+)\r\ncontent: (.*?)\[end\]\r\n)");
		evtl::pcre2_8::match_results<char>  matches;
		bool br = evtl::pcre2_8::regex_search(recvbuf.dataptr(), recvbuf.dataptr() + recvbuf.size(), matches, reg);
		if (br)
		{
			if (matches.size() != 4)
				assert(false);

			const evtl::pcre2_8::sub_match<char> &whole = matches[0];
			const evtl::pcre2_8::sub_match<char> &header = matches[1];
			const evtl::pcre2_8::sub_match<char> &id = matches[2];
			const evtl::pcre2_8::sub_match<char> &content = matches[3];
			if (!header.matched || !id.matched || !content.matched)
				assert(false && "unmatch");

			std::string headerstr = header.str();
			if (m_reqtype == requesttype::single)
			{
				if (headerstr != "singlerequest")
					assert(false);
			}
			else if (m_reqtype == requesttype::multi)
			{
				if (headerstr != "multirequest")
					assert(false);
			}
			else
			{
				assert(false);
			}

			requestinfo &info = m_requestinfo.refer();
			info.m_type = m_reqtype;
			info.m_id = id.str();
			info.m_content.extens_store_whole(content.first, content.second - content.first);
			m_requestinfo.set();

			if (!recvbuf.shit_whole(whole.second - recvbuf.dataptr()))
				assert(false && "shit error");

			m_prep->m_proce.reset_recvdata();
			m_requestproceinfo->m_starttime_s = evtl::timec::fast_sec();
			return searchresult::success;
		}

		assert(false);
		return searchresult::error;
	}

	const requestinfo& get_requestinfo() const
	{
		return m_requestinfo.refer();
	}

	void reset()
	{
		m_requestproceinfo = nullptr;
		m_reqtype = requesttype::unknown;
		m_prep = nullptr;
		m_requestinfo.reset();
	}

private:
	requestprocessinfo  *m_requestproceinfo;
	requesttype  m_reqtype;
	comeprep   *m_prep;

	evtl::st_var<requestinfo>  m_requestinfo;
};


#endif


