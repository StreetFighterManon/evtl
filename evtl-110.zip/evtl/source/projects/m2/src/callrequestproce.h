

#ifndef __CALLREQUESTPROCE_H__
#define __CALLREQUESTPROCE_H__

#include <list>
#include <memory>

#include <evtl/evtl_com.h>
#include <evtl/evtl_time.h>

#include "callrequest.h"
#include "callrequestresp.h"
#include "callsubproceinfo.h"
#include "callrequestintr.h"


class callrequestproce
{
public:
	callrequestproce()
	{
		m_nextstep = evtl::com::nextstep_unknown;
		m_isidle = false;
		m_sendfinish_time_s = 0;
	}

	void set_sessinfo(callsessioninfo *info)
	{
		m_proceinfo.m_sessinfo = info;
	}

	void set_prep(callprep *prep)
	{
		m_proceinfo.m_prep = prep;
	}

	void set_type(requesttype type)
	{
		m_proceinfo.m_type = type;
	}

	void process()
	{
		m_nextstep = evtl::com::nextstep_unknown;
		_process();
		if (m_nextstep == evtl::com::nextstep_cycledone)
		{
			_cycle_reset();
		}
	}

	evtl::com::process_nextstep get_nextstep() const
	{
		return m_nextstep;
	}

	bool is_idlestatus() const
	{
		return m_isidle;
	}

	bool is_mydata(const recvdatainfo &info) const
	{
		if (info.m_type != recvdatatype::response)
			return false;

		if (m_request.sendcomplete() && !m_response.got())
		{
			std::shared_ptr<requestlink> link = m_proceinfo.m_reqlink;
			if (!link)
				assert(false && "null link");
			if (link->m_requestinfo.m_id == info.m_id)
				return true;
		}

		return false;
	}

	void deinit()
	{
		m_nextstep = evtl::com::nextstep_unknown;
		m_isidle = false;
		m_request.reset();
		m_sendlockowner.reset();
		m_multiorderowner.reset();

		m_response.reset();
		m_requestintr.reset();
	}

private:
	void _process()
	{
		m_isidle = false;
		if (!m_request.ready())
		{
			std::list<std::shared_ptr<requestlink>> *plink = nullptr;
			if (m_proceinfo.m_type == requesttype::single)
				plink = m_proceinfo.m_sessinfo->m_singlereqlist;
			else if (m_proceinfo.m_type == requesttype::multi)
				plink = m_proceinfo.m_sessinfo->m_multireqlist;
			else
				assert(false);

			std::list<std::shared_ptr<requestlink>>::iterator iter = plink->begin();
			if (iter == plink->end())
			{
				m_isidle = true;
				set_nextstep(evtl::com::nextstep_stop);
				return;
			}

			m_proceinfo.m_reqlink = *iter;

			m_request.set_proceinfo(&m_proceinfo);
			plink->erase(iter);
		}

		if (m_proceinfo.m_type == requesttype::multi)
		{
			std::pair<bool, bool> br = m_proceinfo.m_prep->m_multireqsendlock.regist_acquire(this, m_multiorderowner);
			if (!br.first)
				assert(false);
			if (!br.second)
			{
				set_nextstep(evtl::com::nextstep_none);
				return;
			}
		}

		if (!evtl::lock::routelock_acquire(m_proceinfo.m_prep->m_socksendlock, m_sendlockowner))
		{
			set_nextstep(evtl::com::nextstep_none);
			return;
		}

		if (!m_request.sendcomplete())
		{
			m_request.sendrequest();
			if (!m_request.sendcomplete())
			{
				set_nextstep(evtl::com::nextstep_wait_to_send);
				return;
			}
			m_sendfinish_time_s = evtl::timec::fast_sec();
		}

		evtl::lock::routelock_release(m_proceinfo.m_prep->m_socksendlock, m_sendlockowner);

		if (m_proceinfo.m_type == requesttype::multi)
		{
			m_proceinfo.m_prep->m_multireqsendlock.release_unregist(this, m_multiorderowner);
		}

		if (m_routesched.yield())
		{
			set_nextstep(evtl::com::nextstep_continue);
			return;
		}

		if (!m_response.ready())
		{
			m_response.set_proceinfo(&m_proceinfo);
		}

		if (!m_response.got())
		{
			if (!evtl::lock::routelock_acquire(m_proceinfo.m_prep->m_prelock, m_proceinfo.m_searchlockowner))
			{
				set_nextstep(evtl::com::nextstep_none);
				return;
			}

			if (m_sendfinish_time_s == 0)
				assert(false);

			callrequestresp::searchresult result = m_response.searchresp();
			switch (result)
			{
			case callrequestresp::searchresult::needrecv:
				{
					evtl::lock::routelock_release(m_proceinfo.m_prep->m_prelock, m_proceinfo.m_searchlockowner, true);

					if (m_proceinfo.m_type == requesttype::multi && evtl::timec::fast_sec() - m_sendfinish_time_s > 10)
						set_nextstep(evtl::com::nextstep_cycledone);
					else
						set_nextstep(evtl::com::nextstep_wait_to_receive);
					return;
				}
				break;
			case callrequestresp::searchresult::needcontinue:
				{
					evtl::lock::routelock_release(m_proceinfo.m_prep->m_prelock, m_proceinfo.m_searchlockowner, true);

					if (m_proceinfo.m_type == requesttype::multi && evtl::timec::fast_sec() - m_sendfinish_time_s > 10)
						set_nextstep(evtl::com::nextstep_cycledone);
					else
						set_nextstep(evtl::com::nextstep_continue);
					return;
				}
				break;
			case callrequestresp::searchresult::otherroute:
				{
					evtl::lock::routelock_release(m_proceinfo.m_prep->m_prelock, m_proceinfo.m_searchlockowner, true);
					if (m_proceinfo.m_type == requesttype::multi && evtl::timec::fast_sec() - m_sendfinish_time_s > 10)
						set_nextstep(evtl::com::nextstep_cycledone);
					else
						set_nextstep(evtl::com::nextstep_none);
					return;
				}
				break;
			case callrequestresp::searchresult::error:
				{
					evtl::lock::routelock_release(m_proceinfo.m_prep->m_prelock, m_proceinfo.m_searchlockowner, true);
					set_nextstep(evtl::com::nextstep_error_end);
					return;
				}
				break;
			default:
				break;
			}

			if (result != callrequestresp::searchresult::success)
				assert(false);
			if (!m_response.got())
				assert(false);

			evtl::lock::routelock_release(m_proceinfo.m_prep->m_prelock, m_proceinfo.m_searchlockowner);
		}

		if (!m_requestintr.interrupted())
		{
			m_requestintr.set_link(m_proceinfo.m_reqlink);
			m_requestintr.set_response(m_response.get_response());
			m_requestintr.response_interrupt();
		}

		set_nextstep(evtl::com::nextstep_cycledone);
	}

	void set_nextstep(evtl::com::process_nextstep step)
	{
		m_nextstep = step;
	}

	void _cycle_reset()
	{
		m_proceinfo.m_reqlink.reset();
		m_proceinfo.m_searchlockowner.reset();
		m_request.reset();
		m_sendlockowner.reset();
		m_multiorderowner.reset();
		m_routesched.reset();
		m_sendfinish_time_s = 0;
		m_response.reset();
		m_requestintr.reset();
	}

private:
	callrequestproceinfo  m_proceinfo;

	evtl::com::process_nextstep  m_nextstep;

	bool  m_isidle;
	callrequest  m_request;
	evtl::lock::routelockowner  m_sendlockowner;
	evtl::lock::routeorderowner  m_multiorderowner;
	evtl::lock::routescheduler   m_routesched;
	int64_t  m_sendfinish_time_s;

	callrequestresp  m_response;
	callrequestintr  m_requestintr;
};


#endif


