

#ifndef __CALLSESSIONTC_H__
#define __CALLSESSIONTC_H__

#include <list>
#include <utility>
#include <functional>

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_connector.h>

#include "callsession.h"


class callsessiontc
{
public:
	callsessiontc()
	{}

	typedef std::function<void (callsessiontc *psess)>  recycle_callback_t;

	void set_loop(evtl::looprefer loop)
	{
		m_loop = loop;
		m_session.set_loop(loop);
	}

	void set_groupid(const std::string &id)
	{
		m_session.set_groupid(id);
	}

	void set_comesessptr(void *ptr)
	{
		m_session.setcomesessptr(ptr);
	}

	void set_give_intrconnector(givelink::intr_connector connector)
	{
		m_session.set_giveintrconnector(connector);
	}

	void set_give_localintr(givelink::intr_entrance intr)
	{
		m_session.set_give_localintr(intr);
	}

	void set_recycle_callback(recycle_callback_t cb)
	{
		m_recycle_cb = std::move(cb);
	}

	void init()
	{
		m_session.set_callsesstcptr(this);
	}

	bool request_intrconnector(std::shared_ptr<requestlink> linkptr)
	{
		if (linkptr->m_requestinfo.m_type == requesttype::single)
		{
			if (m_singlereqlist.size() > 20)
				return false;
			m_singlereqlist.push_back(std::move(linkptr));
		}
		else if (linkptr->m_requestinfo.m_type == requesttype::multi)
		{
			if (m_multireqlist.size() > 20)
				return false;
			m_multireqlist.push_back(std::move(linkptr));
		}
		return activate();
	}

	std::string get_groupid() const
	{
		return m_session.get_groupid();
	}

	void wakeup()
	{
		if (m_session.get_fd() == -1)
			return;

		m_session.activate();
	}

	bool need_recycle() const
	{
		if (m_session.get_fd() == -1)
			return false;

		return m_session.need_recycle();
	}

	bool give_localintr(const givelink::intr_message &msg)
	{
		return m_session.give_localintr(msg.datalink);
	}

	void deinit()
	{
		m_session.deinit();
		m_connector.stop_close();
		m_timer.stop();
		m_singlereqlist.clear();
		m_multireqlist.clear();
	}

private:
	bool activate()
	{
		if (m_session.get_fd() == -1)
		{
			if (m_connector.is_active())
			{
				return true;
			}
			else
			{
				if (!m_connector.is_idle())
					assert(false);

				m_connector.set_loop(m_loop);
				m_connector.set_callback(std::bind(&callsessiontc::connect_callback, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3));
				bool br = m_connector.async_connect(evtl::makeipaddr("127.0.0.1", 3333), true);
				if (!br)
				{
					for (std::list<std::shared_ptr<requestlink>>::const_iterator iter = m_singlereqlist.begin(); iter != m_singlereqlist.end(); ++iter)
					{
						std::shared_ptr<requestlink> ptr = *iter;
						if (!ptr->m_got_response)
						{
							ptr->m_response.m_error = errortype::fatalerror;
							ptr->m_response.m_errstr = "async_connect failed";
							ptr->m_got_response = true;
							ptr->m_remote_fin = true;
						}
					}
					for (std::list<std::shared_ptr<requestlink>>::const_iterator iter = m_multireqlist.begin(); iter != m_multireqlist.end(); ++iter)
					{
						std::shared_ptr<requestlink> ptr = *iter;
						if (!ptr->m_got_response)
						{
							ptr->m_response.m_error = errortype::fatalerror;
							ptr->m_response.m_errstr = "async_connect failed";
							ptr->m_got_response = true;
							ptr->m_remote_fin = true;
						}
					}

					m_singlereqlist.clear();
					m_multireqlist.clear();
					return false;
				}

				m_timer.set(m_loop, 3. + m_loop.now_difference(), 0);
				m_timer.set_callback(std::bind(&callsessiontc::timer_callback, this, std::placeholders::_1, std::placeholders::_2));
				m_timer.start();
			}
		}
		else
		{
			m_session.activate();
		}

		return true;
	}

	void connect_callback(evtl::simpconnector &connector, int errcode, int errnocode)
	{
		if (&connector != &m_connector)
			assert(false);

		m_timer.stop();
		if (errcode == evtl::simpconnector::success)
		{
			int fd = m_connector.get_fd();
			m_connector.only_reset();

			if (m_session.is_active() || m_session.get_fd() != -1)
				assert(false);

			m_session.set_loop(m_loop);
			m_session.set_singlereqlist(&m_singlereqlist);
			m_session.set_multireqlist(&m_multireqlist);
			m_session.set_recycle_callback(std::bind(&callsessiontc::recycle_session, this));
			m_session.init();
			m_session.set_callback();
			m_session.set(fd, ev::WRITE);
			m_session.start();
		}
		else
		{
			for (std::list<std::shared_ptr<requestlink>>::const_iterator iter = m_singlereqlist.begin(); iter != m_singlereqlist.end(); ++iter)
			{
				std::shared_ptr<requestlink> ptr = *iter;
				if (!ptr->m_got_response)
				{
					ptr->m_response.m_error = errortype::connect_failed;
					ptr->m_response.m_errstr = "async_connect callback failed";
					ptr->m_got_response = true;
					ptr->m_remote_fin = true;
					ptr->interrupt_local(ptr, 0);
				}
			}
			for (std::list<std::shared_ptr<requestlink>>::const_iterator iter = m_multireqlist.begin(); iter != m_multireqlist.end(); ++iter)
			{
				std::shared_ptr<requestlink> ptr = *iter;
				if (!ptr->m_got_response)
				{
					ptr->m_response.m_error = errortype::connect_failed;
					ptr->m_response.m_errstr = "async_connect callback failed";
					ptr->m_got_response = true;
					ptr->m_remote_fin = true;
					ptr->interrupt_local(ptr, 0);
				}
			}

			m_singlereqlist.clear();
			m_multireqlist.clear();
			m_recycle_cb(this);
		}
	}

	void timer_callback(evtl::simpwtimer &timer, int revents)
	{
		if (&timer != &m_timer)
			assert(false);

		timer.stop();
		m_connector.stop_close();

		for (std::list<std::shared_ptr<requestlink>>::const_iterator iter = m_singlereqlist.begin(); iter != m_singlereqlist.end(); ++iter)
		{
			std::shared_ptr<requestlink> ptr = *iter;
			if (!ptr->m_got_response)
			{
				ptr->m_response.m_error = errortype::timeout;
				ptr->m_response.m_errstr = "async_connect timer timeout";
				ptr->m_got_response = true;
				ptr->m_remote_fin = true;
				ptr->interrupt_local(ptr, 0);
			}
		}
		for (std::list<std::shared_ptr<requestlink>>::const_iterator iter = m_multireqlist.begin(); iter != m_multireqlist.end(); ++iter)
		{
			std::shared_ptr<requestlink> ptr = *iter;
			if (!ptr->m_got_response)
			{
				ptr->m_response.m_error = errortype::timeout;
				ptr->m_response.m_errstr = "async_connect timer timeout";
				ptr->m_got_response = true;
				ptr->m_remote_fin = true;
				ptr->interrupt_local(ptr, 0);
			}
		}

		m_singlereqlist.clear();
		m_multireqlist.clear();
		m_recycle_cb(this);
	}

	void recycle_session()
	{
		m_recycle_cb(this);
	}

private:
	evtl::looprefer  m_loop;
	recycle_callback_t  m_recycle_cb;

	callsession  m_session;
	std::list<std::shared_ptr<requestlink>>  m_singlereqlist;
	std::list<std::shared_ptr<requestlink>>  m_multireqlist;
	evtl::simpconnector  m_connector;
	evtl::simpwtimer  m_timer;
};


#endif


