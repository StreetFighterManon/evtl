

#ifndef __GIVEPROCESS_H__
#define __GIVEPROCESS_H__

#include <evtl/evtl_com.h>

#include "comesessioninfo.h"
#include "subprocessinfo.h"
#include "giverequest.h"
#include "recvresponse.h"
#include "givereply.h"


class giveprocess
{
public:
	giveprocess()
	{
		m_givetype = givereqtype::unknown;
		m_nextstep = evtl::com::nextstep_unknown;
	}

	void set_sessinfo(comesessioninfo *info)
	{
		m_giveproceinfo.m_sessinfo = info;
	}

	void set_prep(comeprep *prep)
	{
		m_prep = prep;
	}

	void set_givetype(givereqtype type)
	{
		m_givetype = type;
	}

	void init()
	{
		m_giveproceinfo.m_procebase.m_giveprocessptr = this;
		m_giveproceinfo.m_starttime_s = 0;
	}

	void process()
	{
		m_nextstep = evtl::com::nextstep_unknown;
		_process();
		if (m_nextstep == evtl::com::nextstep_cycledone)
		{
			_cycle_reset();
		}
	}

	evtl::com::process_nextstep  get_nextstep() const
	{
		return m_nextstep;
	}

	bool prepblocked() const
	{
		return m_giveproceinfo.m_preinfo_blocked;
	}

	void clean()
	{
		if (m_giveproceinfo.m_starttime_s == 0)
			return;

		int64_t now_s = evtl::timec::fast_sec();
		if (now_s < m_giveproceinfo.m_starttime_s)
			m_giveproceinfo.m_starttime_s = now_s;

		if (m_givetype == givereqtype::multi)
		{
			if (now_s - m_giveproceinfo.m_starttime_s > 10)
			{
				if (m_sendlockowner.is_lockown())
					return;

				std::shared_ptr<givelink> link = m_givereq.get_givelink();
				if (link)
				{
					link->m_remote_fin = true;
					link->interrupt_local(link, 0);
				}

				_cycle_reset();
			}
		}
	}

	bool needrecycle() const
	{
		if (m_giveproceinfo.m_starttime_s == 0)
			return false;

		if (m_givetype == givereqtype::single)
		{
			if (evtl::timec::fast_sec() - m_giveproceinfo.m_starttime_s > 10)
				return true;
		}

		return false;
	}

	void deinit()
	{
		std::shared_ptr<givelink> ptr = m_givereq.get_givelink();
		if (ptr)
		{
			ptr->m_remote_fin = true;
			ptr->interrupt_local(ptr, 0);
		}

		m_givereq.reset();
		m_sendlockowner.reset();
		m_recvresponse.reset();
		m_reply.reset();
	}

private:
	void _process()
	{
		m_giveproceinfo.m_preinfo_blocked = false;

		if (!m_givereq.is_linkset())
		{
			m_givereq.set_sessbase(&m_giveproceinfo.m_sessinfo->m_base);

			std::list<std::shared_ptr<givelink>> *givelinks = nullptr;
			if (m_givetype == givereqtype::single)
				givelinks = &m_giveproceinfo.m_sessinfo->m_singlegivelinks;
			else if (m_givetype == givereqtype::multi)
				givelinks = &m_giveproceinfo.m_sessinfo->m_multigivelinks;
			else
				assert(false);

			std::list<std::shared_ptr<givelink>>::iterator iter = givelinks->begin();
			if (iter == givelinks->end())
			{
				set_nextstep(evtl::com::nextstep_stop);
				return;
			}

			std::shared_ptr<givelink> ptr = *iter;
			givelinks->erase(iter);

			m_givereq.set_link(ptr);
			if (!m_givereq.is_linkset())
				assert(false);

			m_giveproceinfo.m_starttime_s = evtl::timec::fast_sec();
		}

		if (!evtl::lock::routelock_acquire(m_prep->m_sendlock, m_sendlockowner))
		{
			set_nextstep(evtl::com::nextstep_none);
			return;
		}

		if (!m_givereq.sendcomplete())
		{
			m_givereq.send();
			if (!m_givereq.sendcomplete())
			{
				set_nextstep(evtl::com::nextstep_wait_to_send);
				return;
			}
		}

		evtl::lock::routelock_release(m_prep->m_sendlock, m_sendlockowner);
		if (m_sched.yield())
		{
			set_nextstep(evtl::com::nextstep_continue);
			return;
		}

		if (!m_recvresponse.ready())
		{
			m_recvresponse.set_giveproceinfo(&m_giveproceinfo);
			m_recvresponse.set_prep(m_prep);
			m_recvresponse.set_respid(m_givereq.get_id());
			if (!m_recvresponse.ready())
				assert(false);
		}

		if (!m_recvresponse.got_response())
		{
			recvresponse::searchresult res = m_recvresponse.search_response();
			switch (res)
			{
			case recvresponse::searchresult::needrecv:
				{
					set_nextstep(evtl::com::nextstep_wait_to_receive);
					return;
				}
				break;
			case recvresponse::searchresult::needcontinue:
				{
					set_nextstep(evtl::com::nextstep_continue);
					return;
				}
				break;
			case recvresponse::searchresult::other_route:
				{
					set_nextstep(evtl::com::nextstep_none);
					return;
				}
				break;
			default:
				break;
			}

			if (res != recvresponse::searchresult::success)
				assert(false);
		}

		if (!m_reply.replied())
		{
			m_reply.set_link(m_givereq.get_givelink());
			m_reply.set_content(m_recvresponse.get_content());
			m_reply.reply();
		}

		set_nextstep(evtl::com::nextstep_cycledone);
	}

	void set_nextstep(evtl::com::process_nextstep step)
	{
		m_nextstep = step;
	}

private:
	void _cycle_reset()
	{
		m_giveproceinfo.m_starttime_s = 0;

		m_givereq.reset();
		if (m_sendlockowner.is_lockown())
			assert(false);
		m_sendlockowner.reset();
		m_sched.reset();

		m_recvresponse.reset();
		m_reply.reset();
	}

private:
	giveproceinfo  m_giveproceinfo;
	comeprep  *m_prep;
	givereqtype   m_givetype;

	evtl::com::process_nextstep  m_nextstep;

	giverequest  m_givereq;
	evtl::lock::routelockowner  m_sendlockowner;
	evtl::lock::routescheduler  m_sched;

	recvresponse  m_recvresponse;
	givereply   m_reply;
};


#endif


