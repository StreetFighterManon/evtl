

#ifndef __M2DRIVER_H__
#define __M2DRIVER_H__

#include <evtl/evtl_eventloop.h>

#include "acceptor.h"
#include "service.h"


class m2driver
{
public:
	m2driver()
	{}

	void init()
	{
		m_acceptor.set_loop(m_loop.ref());
		m_acceptor.set_callback(std::bind(&m2driver::accept_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_acceptor.set_addr(evtl::makeipaddr("0.0.0.0", 2222));
		m_acceptor.start();

		m_servive.set_loop(m_loop.ref());
		m_servive.init();
	}

	void run()
	{
		m_loop.run_loop(evtl::simpeventloop<evtl::default_loop>::current_thread);
	}

private:
	void accept_callback(acceptor &acpt, std::vector<evtl::connection> &connections)
	{
		m_servive.receive_connection(connections);
	}

private:
	evtl::simpeventloop<evtl::default_loop>  m_loop;

	acceptor  m_acceptor;
	service   m_servive;
};


#endif


