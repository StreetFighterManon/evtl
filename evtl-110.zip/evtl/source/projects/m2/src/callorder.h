

#ifndef __CALLORDER_H__
#define __CALLORDER_H__

#include <list>
#include <set>


class callrequestorder
{
public:
	callrequestorder()
	{}
};


#endif


