

#ifndef __INVALIDREQUEST_H__
#define __INVALIDREQUEST_H__


class invalidrequest
{
public:
	invalidrequest()
	{
		m_prep = nullptr;
	}

	enum class searchresult
	{
		success,
		other_route,
		needrecv,
		needcontinue,
		invalid_request
	};

	bool got() const
	{
		return m_got_request;
	}

	void set_prep(comeprep *prep)
	{
		m_prep = prep;
	}

	searchresult search(bool prepblocked)
	{
		if (m_got_request)
			assert(false);

		if (!evtl::lock::routelock_acquire(m_prep->m_prelock, m_prelockowner))
		{
			return searchresult::other_route;
		}

		const recvdatainfo &info = m_prep->m_proce.get_recvdatainfo();
		if (info.m_type == recvdatatype::unknown)
		{
			evtl::lock::routelock_release(m_prep->m_prelock, m_prelockowner, true);

			if (m_prep->m_proce.needrecv())
				return searchresult::needrecv;
			else
				return searchresult::needcontinue;
		}
		else
		{
			if (info.m_type == recvdatatype::singlereq || info.m_type == recvdatatype::multireq)
			{
				evtl::lock::routelock_release(m_prep->m_prelock, m_prelockowner, true);

				if (prepblocked)
					assert(false);
				return searchresult::other_route;
			}
			else if (info.m_type == recvdatatype::response)
			{
				if (prepblocked)
				{
					_search_response();
					evtl::lock::routelock_release(m_prep->m_prelock, m_prelockowner);
					return searchresult::success;
				}
				else
				{
					evtl::lock::routelock_release(m_prep->m_prelock, m_prelockowner, true);
					return searchresult::other_route;
				}
			}
			else if (info.m_type == recvdatatype::invalid)
			{
				evtl::lock::routelock_release(m_prep->m_prelock, m_prelockowner);
				return searchresult::invalid_request;
			}
			else
			{
				assert(false);
				evtl::lock::routelock_release(m_prep->m_prelock, m_prelockowner);
				return searchresult::invalid_request;
			}
		}
	}

	void _search_response()
	{
		evtl::linearbuf<char> &buf = m_prep->m_proce.get_recvbuf();
		if (buf.empty())
			assert(false);

		evtl::pcre2_8::regex  reg(R"(\[response\]\r\nid: \w+\r\ncontent: .*?\r\n\[end\]\r\n)");
		evtl::pcre2_8::match_results<char>  matches;
		bool br = evtl::pcre2_8::regex_search(buf.dataptr(), buf.dataptr() + buf.size(), matches, reg);
		if (br)
		{
			if (matches.size() != 1)
				assert(false);

			const evtl::pcre2_8::sub_match<char> &sub = matches[0];
			if (!sub.matched)
				assert(false);

			if (!buf.shit_whole(sub.second - buf.dataptr()))
				assert(false);

			m_got_request = true;
			m_prep->m_proce.reset_recvdata();
		}
		else
		{
			assert(false);
		}
	}

	void reset()
	{
		m_prep = nullptr;
		m_got_request.reset();
		m_prelockowner.reset();
	}

private:
	comeprep  *m_prep;

	evtl::boolflag<false>  m_got_request;
	evtl::lock::routelockowner  m_prelockowner;
};


#endif


