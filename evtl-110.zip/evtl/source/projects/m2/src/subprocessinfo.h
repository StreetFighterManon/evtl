

#ifndef __SUBPROCESSINFO_H__
#define __SUBPROCESSINFO_H__

#include "comesessioninfo.h"


struct requestprocessbase
{
	requestprocessbase()
	{
		m_requestprocessptr = nullptr;
	}

	void *  m_requestprocessptr;
};

struct requestprocessinfo
{
	requestprocessinfo()
	{
		m_sessinfo = nullptr;
		m_preinfo_blocked = false;
		m_starttime_s = 0;
	}

	requestprocessbase   m_procebase;
	comesessioninfo  *m_sessinfo;

	bool  m_preinfo_blocked;
	int64_t  m_starttime_s;
};


struct giveprocebase
{
	giveprocebase()
	{
		m_giveprocessptr = nullptr;
	}

	void * m_giveprocessptr;
};

struct giveproceinfo
{
	giveproceinfo()
	{
		m_sessinfo = nullptr;
		m_preinfo_blocked = false;
		m_starttime_s = 0;
	}

	giveprocebase  m_procebase;
	comesessioninfo  *m_sessinfo;

	bool m_preinfo_blocked;
	int64_t  m_starttime_s;
};


#endif


