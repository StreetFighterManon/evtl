

#ifndef __INTERFACE_H__
#define __INTERFACE_H__


struct iointerface
{
	virtual ~iointerface()
	{}

	virtual ssize_t io_read(void *buf, ssize_t n) = 0;

	virtual ssize_t io_write(const void *buf, ssize_t n) = 0;

	virtual void activate() = 0;
};


#endif


