

#ifndef __SESSIONSTORE_H__
#define __SESSIONSTORE_H__

#include <string>
#include <map>

#include "callsessiontc.h"


class callsessionstore
{
public:
	callsessionstore()
	{}

	bool insert_groupid(callsessiontc *psess, const std::string &groupid)
	{
		if (psess == nullptr || groupid.empty())
			assert(false);

		std::pair<std::map<std::string, callsessiontc*>::const_iterator, bool>  br = m_groupid.insert(std::make_pair(groupid, psess));
		return br.second;
	}

	bool remove_groupid(const std::string &groupid)
	{
		if (groupid.empty())
			assert(false);

		ssize_t n = m_groupid.erase(groupid);
		if (n > 0)
			return true;
		return false;
	}

	callsessiontc * find_session_from_groupid(const std::string &id) const
	{
		std::map<std::string, callsessiontc*>::const_iterator iter = m_groupid.find(id);
		if (iter != m_groupid.end())
			return iter->second;
		return nullptr;
	}

private:
	std::map<std::string, callsessiontc*>  m_groupid;
};


#endif


