

#ifndef __COMESESSIONINFO_H__
#define __COMESESSIONINFO_H__

#include <list>
#include <memory>

#include "interface.h"
#include "requestlink.h"


struct comesessionbase
{
	comesessionbase()
	{
		m_iointf = nullptr;
		m_sessionptr = nullptr;
	}

	std::string  m_groupid;

	iointerface  *m_iointf;
	requestlink::intr_connector  m_connector;
	requestlink::intr_entrance   m_localintr;
	closelink::intr_connector    m_closeconnector;

	void *m_sessionptr;
};

struct comesessioninfo
{
	comesessioninfo()
	{
		m_last_recvtime_s = 0;
	}

	comesessionbase  m_base;

	int64_t  m_last_recvtime_s;
	std::list<std::shared_ptr<givelink>>  m_singlegivelinks;
	std::list<std::shared_ptr<givelink>>  m_multigivelinks;
};


#endif


