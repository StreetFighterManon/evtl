

#ifndef __COMESERVICE_H__
#define __COMESERVICE_H__

#include <vector>
#include <set>
#include <evtl/evtl_in.h>
#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_watcher_timer.h>

#include "requestlink.h"
#include "comesession.h"


class comeservice
{
public:
	comeservice()
	{}

	void set_loop(evtl::looprefer loop)
	{
		m_loop = loop;
	}

	void set_request_intrconnector(requestlink::intr_connector cb)
	{
		m_reqintrconnector = std::move(cb);
	}

	void set_close_intrconnector(closelink::intr_connector cb)
	{
		m_closeintrconnector = std::move(cb);
	}

	bool init()
	{
		m_timer.set(m_loop, 0, 10);
		m_timer.set_callback(std::bind(&comeservice::timer_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_timer.again();
		return true;
	}

	void receive_connection(std::vector<evtl::connection> &conns)
	{
		for (std::vector<evtl::connection>::const_iterator iter = conns.begin(); iter != conns.end(); ++iter)
		{
			evtl::connection  conn = *iter;

			comesession *psess = new comesession;
			psess->set_loop(m_loop);
			psess->set_reqintrconnector(m_reqintrconnector);
			psess->set_reqlocalintr(std::bind(&comeservice::request_localintr, this, std::placeholders::_1));
			psess->set_closeintrconnector(m_closeintrconnector);
			psess->set_recycle_callback(std::bind(&comeservice::recycle_session, this, std::placeholders::_1));
			psess->someinit();
			psess->set_callback();
			psess->set(conn.fd, ev::WRITE);
			psess->start();

			std::pair<std::set<comesession*>::const_iterator, bool> br = m_sessions.insert(psess);
			if (!br.second)
				assert(false && "insert session failed");
		}
	}

	bool request_localintr(const requestlink::intr_message &message)
	{
		comesession *psess = (comesession *)message.key;
		if (psess == nullptr)
			assert(false);

		if (m_sessions.find(psess) == m_sessions.end())
			return false;

		return psess->request_localintr(message);
	}

	bool give_intrconnect(std::shared_ptr<givelink> link)
	{
		link->m_remote_interrupt = std::bind(&comeservice::give_remoteintr, this, std::placeholders::_1);
		link->m_syn_ack = true;

		comesession *psess = static_cast<comesession*>(link->m_remote_key);
		if (psess == nullptr)
			assert(false);

		std::set<comesession*>::const_iterator iter = m_sessions.find(psess);
		if (iter == m_sessions.end())
		{
			link->m_remote_fin = true;
			return true;
		}

		if (psess->get_groupid() != link->m_group_id)
		{
			link->m_remote_fin = true;
			return true;
		}

		psess->receive_givelink(link);
		return true;
	}

	bool give_remoteintr(const givelink::intr_message &message)
	{
		return true;
	}

private:
	void timer_callback(evtl::simpwtimer &timer, int revents)
	{
		if (&timer != &m_timer)
			assert(false);

		return;

		for (std::set<comesession*>::const_iterator iter = m_sessions.begin(); iter != m_sessions.end(); )
		{
			comesession *psess = *iter;
			psess->clean();
			if (psess->needrecycle())
			{
				cout << "[comeservice::timer_callback] timer erase comesession, ptr = " << psess << endl;

				m_sessions.erase(iter++);

				psess->close_interrupt();
				psess->deinit();
				delete psess;
			}
			else
			{
				++iter;
			}
		}
	}

	void recycle_session(comesession *psess)
	{
		if (psess == nullptr)
			assert(false);

		size_t n = m_sessions.erase(psess);
		if (n <= 0)
			assert(false && "null session");

		psess->close_interrupt();
		psess->deinit();
		delete psess;
	}

private:
	evtl::looprefer  m_loop;
	requestlink::intr_connector  m_reqintrconnector;
	closelink::intr_connector  m_closeintrconnector;
	std::set<comesession*>  m_sessions;

	evtl::simpwtimer  m_timer;
};


#endif


