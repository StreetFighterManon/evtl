
#include <iostream>
using namespace std;

#include <evtl/evtl_listener.h>
#include <evtl/evtl_acceptor.h>
#include <evpl/selector/selector.h>
#include <evtl/evtl_linearbuf.h>


enum requesttype
{
	http,
	ftp
};

class asc
{
public:
	asc()
	{}

	void init()
	{
		m_listener.set_address(evtl::makeipaddr("0.0.0.0", 2333));
		m_listener.tcplisten(10);
		m_acceptor.set_loop(m_loop.ref());
		m_acceptor.set_listener(&m_listener);
		m_acceptor.set_callback(std::bind(&asc::accept_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_acceptor.watch();

		m_selector.set_detectfunc(std::bind(&asc::detect, this, std::placeholders::_1, std::placeholders::_2));
		m_selector.set_deliverfunc(std::bind(&asc::deliver, this, std::placeholders::_1));
		m_selector.init(m_loop.ref());
	}

	void run()
	{
		m_loop.run_loop();
	}

private:
	void accept_callback(evtl::simpacceptor &accptor, std::vector<evtl::connection> &connections)
	{
		for (std::vector<evtl::connection>::const_iterator iter = connections.begin(); iter != connections.end(); ++iter)
		{
			m_selector.receive(*iter);
		}
	}

	evpl::selector::detectresult detect(const evtl::linearbuf<char> &reqbuf, requesttype &reqtype)
	{
		if (reqbuf.size() < 10)
			return evpl::selector::detectresult::needmore;
		if (reqbuf.finds("http", 4) == 0)
		{
			reqtype = http;
			return evpl::selector::detectresult::succeed;
		}
		else if (reqbuf.finds("ftp", 3) == 0)
		{
			reqtype = ftp;
			return evpl::selector::detectresult::succeed;
		}

		return evpl::selector::detectresult::badrequest;
	}

	void deliver(evpl::selector::detectdetail<requesttype> &detail)
	{
		cout<<"fd:"<<detail.fd<<", bufsize:"<<detail.recvdata.size()<<", reqtype:"<<detail.reqtype
			<<", detail:"<<(int)detail.exceptcode<<", addr.isset:"<<detail.addr.isset()<<endl;
		if (detail.addr.isset())
		{
			cout<<"address:"<<endl;
			evtl::address peeraddr = evtl::inetc::inaddr_ntop(detail.addr.refer().peeraddr);
			evtl::address localaddr = evtl::inetc::inaddr_ntop(detail.addr.refer().localaddr);
			cout<<peeraddr.host.str()<<", port:"<<peeraddr.port<<endl;
			cout<<localaddr.host.str()<<", port:"<<localaddr.port<<endl;
		}
		cout<<detail.recvdata.tostring()<<endl;
	}

private:
	evtl::listener      m_listener;
	evtl::simpacceptor  m_acceptor;
	evtl::simpeventloop<>  m_loop;

	evpl::selector::selservice<requesttype>  m_selector;
};


int main()
{
	evtl::default_loop::preinit();
	asc server;
	server.init();
	server.run();
	return 0;
}


