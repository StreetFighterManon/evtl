

#ifndef __QSINGLEHEARTBEAT_QSINGLEHB_PROCESS_H__
#define __QSINGLEHEARTBEAT_QSINGLEHB_PROCESS_H__

#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_random.h>
#include <evtl/evtl_watcher_timer.h>

#include "../sessionbase.h"
#include "../preprocess.h"


class qsinglehb_process
{
public:
	qsinglehb_process()
	{
		m_sessbase = nullptr;
		m_preproce = nullptr;
		m_nextstep = evtl::com::nextstep_unknown;
	}

	void set_sessbase(sessionbase *base)
	{
		m_sessbase = base;
	}

	void set_preprocess(preprocess *pre)
	{
		m_preproce = pre;
	}

	void init()
	{
	}

	void process()
	{
		set_nextstep(evtl::com::nextstep_unknown);

		if (!m_senddata.isset())
		{
			std::string id = evtl::rand::urandom::str_dec(12);
			std::stringstream ss;
			ss << "[qsingleheartbeat]\r\n"
				<< "id: " << id << "\r\n"
				<< "content: kjasnd" << id << "\r\n"
				<< "[end]\r\n";
			m_id = id;
			m_senddata.refer().extens_store_whole(ss.str());
			m_senddata.set();
		}

		evtl::linearbuf<char> &buf = m_senddata.refer();
		ssize_t sz = buf.size();
		if (sz > 0)
		{
			ssize_t rt = m_sessbase->m_ssitf->sockwrite(buf.dataptr(), sz);
			if (rt > 0)
			{
				if (!buf.shit_whole(rt))
					assert(false && "shit error");
			}

			if (!buf.empty())
			{
				set_nextstep(evtl::com::nextstep_wait_to_send);
				return;
			}
		}

		if (!m_getresp)
		{
			if (!m_foundresp)
			{
				if (m_preproce->haserror())
				{
					set_nextstep(evtl::com::nextstep_error);
					return;
				}

				if (m_preproce->is_busy())
				{
					set_nextstep(evtl::com::nextstep_none);
					return;
				}

				const cliseginfo &info = m_preproce->get_seginfo();
				if (info.m_type == clisegtype::unknown)
				{
					if (m_preproce->is_needrecv())
						set_nextstep(evtl::com::nextstep_wait_to_receive);
					else
						set_nextstep(evtl::com::nextstep_continue);
					return;
				}

				if (info.m_type != clisegtype::response || info.m_id != m_id)
				{
					set_nextstep(evtl::com::nextstep_none);
					return;
				}

				m_preproce->set_busy(true);
				m_foundresp = true;
			}

			evtl::linearbuf<char> *buf = m_preproce->get_recvbuf();
			ssize_t pos = buf->finds("[end]\r\n", 7);
			if (pos < 0)
			{
				buf->shit_to(7);
				buf->crowd();
				ssize_t rt = m_sessbase->m_ssitf->sockread(buf->headptr(), buf->headspace());
				if (rt > 0)
				{
					if (!buf->head_eaten_whole(rt))
						assert(false && "headeaten failed");
					set_nextstep(evtl::com::nextstep_continue);
					return;
				}

				set_nextstep(evtl::com::nextstep_wait_to_receive);
				return;
			}

			if (buf->shit_whole(pos + 7))
				assert(false && "shit error");

			m_preproce->set_busy(false);
			m_preproce->set_needrecv(false);
			m_preproce->reset_seginfo();
			m_getresp = true;

			m_timer.set(m_sessbase->m_loop, 10. + m_sessbase->m_loop.now_difference(), 0);
			m_timer.set_callback(std::bind(&qsinglehb_process::timer_callback, this, std::placeholders::_1, std::placeholders::_2));
			m_timer.start();
		}

		set_nextstep(evtl::com::nextstep_stop);
	}

	evtl::com::process_nextstep get_nextstep() const
	{
		return m_nextstep;
	}

	bool may_handle(const cliseginfo &info) const
	{
		if (!m_senddata.isset())
			return false;
		if (!m_getresp)
		{
			if (info.m_type == clisegtype::response && info.m_id == m_id)
				return true;
			else
				return false;
		}
		return false;
	}

	void reset()
	{
		m_senddata.reset();
		m_id.clear();
		m_getresp.reset();
		m_foundresp.reset();
		m_timer.stop();
	}

private:
	void set_nextstep(evtl::com::process_nextstep step)
	{
		m_nextstep = step;
	}

	void timer_callback(evtl::simpwtimer &watcher, int revents)
	{
		if (&watcher != &m_timer)
			assert(false && "unexpected watcher");

		watcher.stop();
		_cycle_reset();
		m_sessbase->m_ssitf->activate();
	}

	void _cycle_reset()
	{
		m_senddata.reset();
		m_id.clear();
		m_getresp.reset();
		m_foundresp.reset();
		m_timer.stop();
	}

private:
	sessionbase  *m_sessbase;
	preprocess   *m_preproce;

	evtl::com::process_nextstep  m_nextstep;

	evtl::var<evtl::linearbuf<char>>  m_senddata;
	std::string  m_id;
	evtl::boolflag<false>  m_getresp;
	evtl::boolflag<false>  m_foundresp;
	evtl::simpwtimer  m_timer;
};


#endif


