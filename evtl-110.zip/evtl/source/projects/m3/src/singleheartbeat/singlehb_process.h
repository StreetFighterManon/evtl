

#ifndef __SINGLEHEARTBEAT_SINGLEHB_PROCESS_H__
#define __SINGLEHEARTBEAT_SINGLEHB_PROCESS_H__


class singlehb_process
{
public:
	singlehb_process()
	{}
};


#endif



