

#ifndef __SINGLEGIVE_SINGLEGIVE_PROCESS_H__
#define __SINGLEGIVE_SINGLEGIVE_PROCESS_H__


class singlegive_process
{
public:
	singlegive_process()
	{}
};


#endif


