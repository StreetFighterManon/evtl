

#ifndef __SINGLEREQUEST_SINGLEREQ_PROCESS_H__
#define __SINGLEREQUEST_SINGLEREQ_PROCESS_H__

#include <evtl/evtl_com.h>
#include <evtl/evtl_wrapper.h>

#include "../sessionbase.h"
#include "../preprocess.h"
#include "clientrequest.h"
#include "response.h"


class singlereq_process
{
public:
	singlereq_process()
	{
		m_sessbase = nullptr;
		m_preproce = nullptr;
		m_nextstep = evtl::com::nextstep_unknown;
	}

	void set_sessbase(sessionbase *base)
	{
		m_sessbase = base;
	}

	void set_preprocess(preprocess *pre)
	{
		m_preproce = pre;
	}

	void init()
	{
	}

	void process()
	{
		set_nextstep(evtl::com::nextstep_unknown);
		_process();
		if (m_nextstep == evtl::com::nextstep_cycledone)
		{
			_cycle_reset();
		}
	}

	evtl::com::process_nextstep get_nextstep() const
	{
		return m_nextstep;
	}

	void reset()
	{
		m_error.reset();
		m_request.reset();
		m_response.reset();
	}

private:
	void set_nextstep(evtl::com::process_nextstep  step)
	{
		m_nextstep = step;
	}

	void _process()
	{
		if (m_error)
		{
			set_nextstep(evtl::com::nextstep_error_end);
			return;
		}

		if (!m_request.got())
		{
			m_request.set_sessbase(m_sessbase);
			m_request.set_preprocess(m_preproce);

			singlereq_clientrequest::searchresult result = m_request.search();
			switch (result)
			{
			case singlereq_clientrequest::searchresult::other_route:
				{
					set_nextstep(evtl::com::nextstep_none);
					return;
				}
				break;
			case singlereq_clientrequest::searchresult::wait_receive:
				{
					set_nextstep(evtl::com::nextstep_wait_to_receive);
					return;
				}
				break;
			case singlereq_clientrequest::searchresult::wait_continue:
				{
					set_nextstep(evtl::com::nextstep_continue);
					return;
				}
				break;
			case singlereq_clientrequest::searchresult::error:
				{
					m_error = true;
					set_nextstep(evtl::com::nextstep_error);
					return;
				}
				break;
			default:
				break;
			}

			if (result != singlereq_clientrequest::searchresult::success)
				assert(false && "invalid result");
		}

		if (!m_response.is_paramset())
		{
			m_response.set_sessbase(m_sessbase);
			m_response.set_id(m_request.get_id());
		}

		if (m_response.have_error())
		{
			m_error = true;
			set_nextstep(evtl::com::nextstep_error);
			return;
		}

		if (!m_response.finished())
			m_response.sendresponse();
		if (!m_response.finished())
		{
			set_nextstep(evtl::com::nextstep_wait_to_send);
			return;
		}
		else
		{
			set_nextstep(evtl::com::nextstep_cycledone);
			return;
		}
	}

	void _cycle_reset()
	{
		m_request.reset();
		m_response.reset();
	}

private:
	sessionbase  *m_sessbase;
	preprocess  *m_preproce;

	evtl::com::process_nextstep  m_nextstep;
	evtl::boolflag<false>  m_error;

	singlereq_clientrequest  m_request;
	singlereq_response  m_response;
};


#endif


