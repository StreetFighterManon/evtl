

#ifndef __SINGLEREQUEST_CLIENTREQUEST_H__
#define __SINGLEREQUEST_CLIENTREQUEST_H__

#include "../sessionbase.h"
#include "../preprocess.h"
#include "../types.h"


class singlereq_clientrequest
{
public:
	singlereq_clientrequest()
	{
		m_sessbase = nullptr;
		m_preproce = nullptr;

		m_type = clisegtype::unknown;
		m_reach_end = false;
	}

	enum class searchresult
	{
		success,
		other_route,
		wait_receive,
		wait_continue,
		error
	};

	void set_sessbase(sessionbase *base)
	{
		m_sessbase = base;
	}

	void set_preprocess(preprocess *pre)
	{
		m_preproce = pre;
	}

	bool got() const
	{
		return m_reach_end;
	}

	searchresult search()
	{
		if (m_type == clisegtype::unknown)
		{
			if (m_preproce->haserror())
				return searchresult::error;

			if (m_preproce->is_busy())
				return searchresult::other_route;

			const cliseginfo &info = m_preproce->get_seginfo();
			if (info.m_type == clisegtype::unknown)
			{
				if (m_preproce->is_needrecv())
					return searchresult::wait_receive;
				else
					return searchresult::wait_continue;
			}

			if (info.m_type != clisegtype::singlerequest)
				return searchresult::other_route;

			m_type = info.m_type;
			m_id = info.m_id;

			m_preproce->set_busy(true);
		}

		evtl::linearbuf<char> *buf = m_preproce->get_recvbuf();
		ssize_t pos = buf->finds("[end]\r\n", 7);
		if (pos < 0)
		{
			buf->shit_to(7);
			buf->crowd();
			ssize_t headsp = buf->headspace();
			if (headsp <= 0)
				assert(false && "bad buffer");
			ssize_t size = m_sessbase->m_ssitf->sockread(buf->headptr(), headsp);
			if (size > 0)
			{
				if (!buf->head_eaten_whole(size))
					assert(false && "head eaten failed");
				return searchresult::wait_continue;
			}
			else
			{
				return searchresult::wait_receive;
			}
		}
		else
		{
			if (!buf->shit_whole(pos + 7))
				assert(false && "shit error");

			m_reach_end = true;
			m_preproce->reset_seginfo();
			m_preproce->set_needrecv(false);
			m_preproce->set_busy(false);
			return searchresult::success;
		}
	}

	std::string get_id() const
	{
		return m_id;
	}

	void reset()
	{
		m_type = clisegtype::unknown;
		m_id.clear();
		m_content.clear();
		m_reach_end = false;
	}

private:
	sessionbase  *m_sessbase;
	preprocess   *m_preproce;

	clisegtype   m_type;
	std::string  m_id;
	std::string  m_content;
	bool         m_reach_end;
};


#endif


