

#ifndef __INTERFACE_H__
#define __INTERFACE_H__


struct sessinterface
{
	virtual ~sessinterface()
	{}

	virtual ssize_t sockread(void *buf, ssize_t len) = 0;

	virtual ssize_t sockwrite(const void *buf, ssize_t len) = 0;

	virtual void activate() = 0;
};


#endif


