

#ifndef __SESSIONBASE_H__
#define __SESSIONBASE_H__

#include <evtl/evtl_eventloop.h>

#include "interface.h"


struct sessionbase
{
	sessionbase()
	{
		m_ssitf = nullptr;
	}

	evtl::looprefer  m_loop;
	sessinterface   *m_ssitf;
};


#endif


