

#ifndef __DEFAULT_DEFAULT_PROCESS_H__
#define __DEFAULT_DEFAULT_PROCESS_H__

#include <evtl/evtl_com.h>

#include "../sessionbase.h"


class default_process
{
public:
	default_process()
	{
		m_sessbase = nullptr;
		m_preproce = nullptr;
		m_nextstep = evtl::com::nextstep_unknown;
	}

	void set_sessbase(sessionbase *base)
	{
		m_sessbase = base;
	}

	void set_preprocess(preprocess *pre)
	{
		m_preproce = pre;
	}

	void init()
	{
	}

	void process(bool is_invalid)
	{
		set_nextstep(evtl::com::nextstep_unknown);

		_process(is_invalid);
		if (m_nextstep == evtl::com::nextstep_cycledone)
		{
			_cycle_reset();
		}
	}

	void _process(bool is_invalid)
	{
		if (m_preproce->haserror())
		{
			set_nextstep(evtl::com::nextstep_error);
			return;
		}

		if (!m_recvlock)
		{
			if (m_preproce->is_busy())
			{
				set_nextstep(evtl::com::nextstep_none);
				return;
			}

			const cliseginfo &info = m_preproce->get_seginfo();
			if (info.m_type == clisegtype::unknown)
			{
				if (m_preproce->is_needrecv())
					set_nextstep(evtl::com::nextstep_wait_to_receive);
				else
					set_nextstep(evtl::com::nextstep_continue);
				return;
			}

			if (info.m_type != clisegtype::response)
			{
				set_nextstep(evtl::com::nextstep_none);
				return;
			}

			if (!is_invalid)
			{
				set_nextstep(evtl::com::nextstep_none);
				return;
			}

			m_preproce->set_busy(true);
			m_recvlock = true;
		}

		if (!m_received_msg)
		{
			evtl::linearbuf<char> *buf = m_preproce->get_recvbuf();
			ssize_t pos = buf->finds("[end]\r\n", 7);
			if (pos < 0)
			{
				buf->shit_to(7);
				buf->crowd();
				ssize_t ret = m_sessbase->m_ssitf->sockread(buf->headptr(), buf->headspace());
				if (ret > 0)
				{
					if (!buf->head_eaten_whole(ret))
						assert(false && "eaten failed");
					set_nextstep(evtl::com::nextstep_continue);
				}
				else
				{
					set_nextstep(evtl::com::nextstep_wait_to_receive);
				}
				return;
			}

			if (!buf->shit_whole(pos + 7))
				assert(false && "shit error");
			m_received_msg = true;
			m_preproce->set_busy(false);
		}

		set_nextstep(evtl::com::nextstep_cycledone);
	}

	evtl::com::process_nextstep get_nextstep() const
	{
		return m_nextstep;
	}

	void reset()
	{
		m_recvlock.reset();
		m_received_msg.reset();
	}

private:
	void set_nextstep(evtl::com::process_nextstep  step)
	{
		m_nextstep = step;
	}

	void _cycle_reset()
	{
		m_recvlock.reset();
		m_received_msg.reset();
	}

private:
	sessionbase  *m_sessbase;
	preprocess   *m_preproce;

	evtl::com::process_nextstep  m_nextstep;

	evtl::boolflag<false>  m_recvlock;
	evtl::boolflag<false>  m_received_msg;
};


#endif


