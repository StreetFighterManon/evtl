

#ifndef __SERVICE_H__
#define __SERVICE_H__

#include <set>

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_wasyncs.h>
#include <evtl/evtl_in.h>

#include "session.h"


class service
{
public:
	service()
	{}

	void set_loop(evtl::looprefer loop)
	{
		m_loop = loop;
	}

	bool init()
	{
		if (!m_conn_async.init())
			return false;
		m_conn_async.set(m_loop);
		m_conn_async.set_callback(std::bind(&service::connasync_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_conn_async.start();
		return true;
	}

	void receive_conn(std::vector<evtl::connection> &connections)
	{
		m_conn_async.pushback(std::move(connections));
		m_conn_async.send();
	}

private:
	void connasync_callback(evtl::queue_simpwasync<evtl::connection> &watcher, int revents)
	{
		std::vector<evtl::connection>  conns;
		if (watcher.popfront(conns, 10) <= 0)
			return;

		if (conns.empty())
			assert(false && "popfront error");

		watcher.send();

		for (std::vector<evtl::connection>::const_iterator iter = conns.begin(); iter != conns.end(); ++iter)
		{
			const evtl::connection &conn = *iter;

			session *sess = new session;
			sess->set_loop(m_loop);
			sess->set_fd(conn.fd);
			sess->set_recycle_callback(std::bind(&service::recycle_callback, this, std::placeholders::_1));
			sess->init();

			std::pair<std::set<session*>::const_iterator, bool> rt = m_sessions.insert(sess);
			if (!rt.second)
				assert(false && "insert failed");
		}
	}

	void recycle_callback(session *psess)
	{
		if (psess == nullptr)
			assert(false && "nullptr");

		size_t n = m_sessions.erase(psess);
		if (n <= 0)
			assert(false && "invalid session");

		psess->deinit();
		delete psess;
	}

private:
	evtl::looprefer  m_loop;

	evtl::queue_simpwasync<evtl::connection>  m_conn_async;
	std::set<session*>  m_sessions;
};


#endif


