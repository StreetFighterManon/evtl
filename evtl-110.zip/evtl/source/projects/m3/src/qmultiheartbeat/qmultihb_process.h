

#ifndef __QMULTIHEARTBEAT_QMULTIHB_PROCESS_H__
#define __QMULTIHEARTBEAT_QMULTIHB_PROCESS_H__

#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_random.h>

#include "../sessionbase.h"
#include "../preprocess.h"


class qmultihb_process
{
public:
	qmultihb_process()
	{}

	void set_sessbase(sessionbase *base)
	{
		m_sessbase = base;
	}

	void set_preprocess(preprocess *pre)
	{
		m_preproce = pre;
	}

	void init()
	{
	}

	void process()
	{
		set_nextstep(evtl::com::nextstep_unknown);
		_process();
	}

	evtl::com::process_nextstep get_nextstep() const
	{
		return m_nextstep;
	}

	bool may_handle(const cliseginfo &info) const
	{
		if (!m_sendreq.isset())
			return false;
		if (!m_gotresp)
		{
			if (info.m_type == clisegtype::response && info.m_id == m_id)
				return true;
			else
				return false;
		}
		return false;
	}

	void deinit()
	{
		m_id.clear();
		m_sendreq.reset();
		m_locked.reset();
		m_gotresp.reset();
	}

private:
	void set_nextstep(evtl::com::process_nextstep step)
	{
		m_nextstep = step;
	}

	void _process()
	{
		if (m_error)
		{
			set_nextstep(evtl::com::nextstep_error_end);
			return;
		}

		if (!m_sendreq.isset())
		{
			m_id = evtl::rand::urandom::str_dec(12);

			std::stringstream ss;
			ss << "[qmultiheartbeat]\r\n"
				<< "id: " << m_id << "\r\n"
				<< "content: " << m_id << "iklqjnwejknj\r\n"
				<< "[end]\r\n";

			std::string s = ss.str();
			m_sendreq.refer().extens_store_whole(s);
			m_sendreq.set();
		}

		evtl::linearbuf<char> &buf = m_sendreq.refer();
		ssize_t size = buf.size();
		if (size > 0)
		{
			ssize_t rt = m_sessbase->m_ssitf->sockwrite(buf.dataptr(), size);
			if (rt > 0)
			{
				if (!buf.shit_whole(rt))
					assert(false && "shit error");
			}
		}

		if (!buf.empty())
		{
			set_nextstep(evtl::com::nextstep_wait_to_send);
			return;
		}

		if (m_preproce->haserror())
		{
			m_error = true;
			set_nextstep(evtl::com::nextstep_error);
			return;
		}

		if (!m_locked)
		{
			if (m_preproce->is_busy())
			{
				set_nextstep(evtl::com::nextstep_none);
				return;
			}

			const cliseginfo &info = m_preproce->get_seginfo();
			if (info.m_type == clisegtype::unknown)
			{
				if (m_preproce->is_needrecv())
					set_nextstep(evtl::com::nextstep_wait_to_receive);
				else
					set_nextstep(evtl::com::nextstep_continue);
				return;
			}

			if (info.m_type != clisegtype::response || info.m_id != m_id)
			{
				set_nextstep(evtl::com::nextstep_none);
				return;
			}

			m_preproce->set_busy(true);
			m_locked = true;
		}

		if (!m_gotresp)
		{
			if(!m_preproce->is_busy())
				assert(false && "not busy");

			evtl::linearbuf<char> *buf = m_preproce->get_recvbuf();
			ssize_t pos = buf->finds("[end]\r\n", 7);
			if (pos < 0)
			{
				buf->shit_to(7);
				buf->crowd();
				ssize_t sz = m_sessbase->m_ssitf->sockread(buf->headptr(), buf->headspace());
				if (sz > 0)
				{
					if (!buf->head_eaten_whole(sz))
						assert(false && "head eaten failed");
					set_nextstep(evtl::com::nextstep_continue);
				}
				else
				{
					set_nextstep(evtl::com::nextstep_wait_to_receive);
				}
				return;
			}

			if (!buf->shit_whole(pos + 7))
				assert(false && "shit error");

			m_gotresp = true;
			m_preproce->set_needrecv(false);
			m_preproce->set_busy(false);
			m_preproce->reset_seginfo();

			set_nextstep(evtl::com::nextstep_done);
			return;
		}

		set_nextstep(evtl::com::nextstep_done_end);
		return;
	}

private:
	sessionbase  *m_sessbase;
	preprocess   *m_preproce;

	evtl::com::process_nextstep  m_nextstep;

	evtl::boolflag<false>  m_error;
	std::string  m_id;
	evtl::var<evtl::linearbuf<char>>  m_sendreq;
	evtl::boolflag<false>  m_locked;
	evtl::boolflag<false>  m_gotresp;
};


#endif


