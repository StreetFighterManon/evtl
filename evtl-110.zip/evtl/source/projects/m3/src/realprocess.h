

#ifndef __REALPROCESS_H__
#define __REALPROCESS_H__

#include <list>

#include <evtl/evtl_linearbuf.h>

#include "singlerequest/singlereq_process.h"
#include "multirequest/multireq_process.h"

#include "qsingleheartbeat/qsinglehb_process.h"
#include "qmultiheartbeat/qmultihb_process.h"

#include "default/default_process.h"


class realprocess
{
public:
	realprocess()
	{
		m_sessbase = nullptr;
		m_preproce = nullptr;
		m_nextstep = evtl::com::nextstep_unknown;
		m_qcount = 0;
	}

	void set_sessbase(sessionbase *base)
	{
		m_sessbase = base;
	}

	void set_preprocess(preprocess *pre)
	{
		m_preproce = pre;
	}

	void init()
	{
		m_singlereqproce.set_sessbase(m_sessbase);
		m_singlereqproce.set_preprocess(m_preproce);
		m_singlereqproce.init();

		m_qsinglehbproce.set_sessbase(m_sessbase);
		m_qsinglehbproce.set_preprocess(m_preproce);
		m_qsinglehbproce.init();
		m_qcount = 0;

		m_defaultproce.set_sessbase(m_sessbase);
		m_defaultproce.set_preprocess(m_preproce);
		m_defaultproce.init();
	}

	void doprocess()
	{
		push_on();
		monitor();
		determine();
	}

	evtl::com::process_nextstep get_nextstep() const
	{
		return m_nextstep;
	}

	void mulsethb()
	{
		if (m_qcount <= 0)
			m_qcount = 2;
	}

	void deinit()
	{
		m_singlereqproce.reset();
		for (std::list<multireq_process*>::iterator iter = m_multireqproce.begin(); iter != m_multireqproce.end(); ++iter)
		{
			multireq_process *p = *iter;
			p->deinit();
			delete p;
		}
		m_multireqproce.clear();

		m_qsinglehbproce.reset();
		for (std::list<qmultihb_process*>::iterator iter = m_qmultihbproce.begin(); iter != m_qmultihbproce.end(); ++iter)
		{
			qmultihb_process *p = *iter;
			p->deinit();
			delete p;
		}
		m_qmultihbproce.clear();

		m_defaultproce.reset();
	}

private:
	void push_on()
	{
		m_stepstream.clear();

		m_singlereqproce.process();
		m_stepstream << m_singlereqproce.get_nextstep();

		evtl::com::process_nextstep nstep = evtl::com::nextstep_unknown;
		for (std::list<multireq_process*>::iterator iter = m_multireqproce.begin(); iter != m_multireqproce.end(); )
		{
			multireq_process *pro = *iter;
			if (pro == nullptr)
				assert(false && "null proce");

			pro->process();
			nstep = pro->get_nextstep();
			m_stepstream << nstep;
			if (nstep == evtl::com::nextstep_done_end || nstep == evtl::com::nextstep_error_end)
			{
				pro->deinit();
				m_multireqproce.erase(iter++);
				delete pro;
			}
			else
				++iter;
		}

		m_qsinglehbproce.process();
		m_stepstream << m_qsinglehbproce.get_nextstep();

		for (std::list<qmultihb_process*>::iterator iter = m_qmultihbproce.begin(); iter != m_qmultihbproce.end(); )
		{
			qmultihb_process *pro = *iter;
			if (pro == nullptr)
				assert(false && "null proce");

			pro->process();
			nstep = pro->get_nextstep();
			m_stepstream << nstep;
			if (nstep == evtl::com::nextstep_done_end || nstep == evtl::com::nextstep_error_end)
			{
				pro->deinit();
				m_qmultihbproce.erase(iter++);
				delete pro;
			}
			else
				++iter;
		}

		if (received_invalid_message())
			m_defaultproce.process(true);
		else
			m_defaultproce.process(false);
		m_stepstream << m_defaultproce.get_nextstep();
	}

	void monitor()
	{
		if (m_preproce->haserror())
		{
			m_stepstream << evtl::com::nextstep_error;
			return;
		}

		evtl::com::nextstepstream  nonestream;
		nonestream << evtl::com::nextstep_unknown << evtl::com::nextstep_none;

		if (m_preproce->is_busy())
		{
			if (m_stepstream <= nonestream)
				assert(false && "nonestream");

			m_stepstream << evtl::com::nextstep_none;
			return;
		}

		while (m_qcount-- > 0)
		{
			if (m_qmultihbproce.size() < 2)
			{
				_add_qmultihb();
				m_stepstream << evtl::com::nextstep_continue;
			}
			else
				break;
		}

		const cliseginfo &seginfo = m_preproce->get_seginfo();
		switch (seginfo.m_type)
		{
		case clisegtype::unknown:
			{
				if (m_multireqproce.size() < 2 || m_qmultihbproce.size() < 2)
				{
					if (m_preproce->is_needrecv())
						m_stepstream << evtl::com::nextstep_wait_to_receive;
					else
						m_stepstream << evtl::com::nextstep_continue;
				}
				else
				{
					if (m_stepstream <= nonestream)
						assert(false && "nonestream");

					m_stepstream << evtl::com::nextstep_stop;
				}
			}
			break;
		case clisegtype::multirequest:
			{
				if (m_multireqproce.size() < 2)
				{
					_add_one_multireq();
					m_stepstream << evtl::com::nextstep_continue;
				}
				else
				{
					if (m_stepstream <= nonestream)
						assert(false && "nonestream");

					m_stepstream << evtl::com::nextstep_stop;
				}
			}
			break;
		case clisegtype::response:
			{
				if (m_stepstream <= nonestream)
					assert(false && "nonestream");

				m_stepstream << evtl::com::nextstep_none;
			}
			break;
		case clisegtype::invalid:
			{
				m_stepstream.set(evtl::com::nextstep_error);
			}
			break;
		default:
			assert(false && "invalid type");
			break;
		}
	}

	void determine()
	{
		if (m_stepstream.empty())
			assert(false && "empty step");
		if (m_stepstream.have(evtl::com::nextstep_unknown))
			assert(false && "unknown step");

		evtl::com::nextstepstream illstep;
		illstep << evtl::com::nextstep_none << evtl::com::nextstep_done_end << evtl::com::nextstep_error_end;
		if (m_stepstream.have(evtl::com::nextstep_none) && m_stepstream <= illstep)
			assert(false && "illstep");

		if (m_stepstream.have(evtl::com::nextstep_error) || m_stepstream.have(evtl::com::nextstep_error_end))
		{
			set_nextstep(evtl::com::nextstep_error);
			return;
		}

		set_nextstep(m_stepstream.elect());
	}

	void set_nextstep(evtl::com::process_nextstep  nstep)
	{
		m_nextstep = nstep;
	}

	void _add_one_multireq()
	{
		multireq_process *p = new multireq_process;
		if (p == nullptr)
			assert(false && "nullptr");

		p->set_sessbase(m_sessbase);
		p->set_preprocess(m_preproce);
		p->init();
		m_multireqproce.push_back(p);
	}

	void _add_qmultihb()
	{
		qmultihb_process *p = new qmultihb_process;
		if (p == nullptr)
			assert(false && "nullptr");

		p->set_sessbase(m_sessbase);
		p->set_preprocess(m_preproce);
		p->init();
		m_qmultihbproce.push_back(p);
	}

	bool received_invalid_message() const
	{
		if (m_preproce->haserror())
			return false;
		if (m_preproce->is_busy())
			return false;
		const cliseginfo &info = m_preproce->get_seginfo();
		if (info.m_type != clisegtype::response)
			return false;

		if (m_qsinglehbproce.may_handle(info))
			return false;

		for (std::list<qmultihb_process*>::const_iterator iter = m_qmultihbproce.begin(); iter != m_qmultihbproce.end(); ++iter)
		{
			qmultihb_process *p = *iter;
			if (p->may_handle(info))
				return false;
		}
		return true;
	}

private:
	sessionbase  *m_sessbase;
	preprocess   *m_preproce;

	evtl::com::process_nextstep  m_nextstep;

	singlereq_process  m_singlereqproce;
	std::list<multireq_process*>  m_multireqproce;

	qsinglehb_process  m_qsinglehbproce;
	std::list<qmultihb_process*>  m_qmultihbproce;
	int  m_qcount;

	default_process   m_defaultproce;

	evtl::com::nextstepstream  m_stepstream;
};


#endif


