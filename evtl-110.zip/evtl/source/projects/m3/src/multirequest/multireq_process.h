

#ifndef __MULTIREQUEST_MULTIREQ_PROCESS_H__
#define __MULTIREQUEST_MULTIREQ_PROCESS_H__

#include "mulreq_request.h"
#include "multireq_response.h"


class multireq_process
{
public:
	multireq_process()
	{
		m_sessbase = nullptr;
		m_preproce = nullptr;

		m_nextstep = evtl::com::nextstep_unknown;
	}

	void set_sessbase(sessionbase *base)
	{
		m_sessbase = base;
	}

	void set_preprocess(preprocess *pre)
	{
		m_preproce = pre;
	}

	void init()
	{
	}

	void process()
	{
		set_nextstep(evtl::com::nextstep_unknown);
		_process();
	}

	evtl::com::process_nextstep  get_nextstep() const
	{
		return m_nextstep;
	}

	void deinit()
	{
		m_error.reset();
		m_request.reset();
		m_response.reset();
	}

private:
	void set_nextstep(evtl::com::process_nextstep step)
	{
		m_nextstep = step;
	}

	void _process()
	{
		if (m_error)
		{
			set_nextstep(evtl::com::nextstep_error_end);
			return;
		}

		if (!m_request.got())
		{
			m_request.set_sessbase(m_sessbase);
			m_request.set_preproce(m_preproce);

			mulreq_reqeust::searchresult result = m_request.search();
			switch (result)
			{
			case mulreq_reqeust::searchresult::error:
				{
					m_error = true;
					set_nextstep(evtl::com::nextstep_error);
					return;
				}
				break;
			case mulreq_reqeust::searchresult::other_route:
				{
					set_nextstep(evtl::com::nextstep_none);
					return;
				}
				break;
			case mulreq_reqeust::searchresult::wait_recv:
				{
					set_nextstep(evtl::com::nextstep_wait_to_receive);
					return;
				}
				break;
			case mulreq_reqeust::searchresult::wait_continue:
				{
					set_nextstep(evtl::com::nextstep_continue);
					return;
				}
				break;
			default:
				break;
			}

			if (result != mulreq_reqeust::searchresult::success)
				assert(false && "unknown result");
		}

		if (!m_response.is_paramset())
		{
			m_response.set_sessbase(m_sessbase);
			m_response.set_id(m_request.get_id());
		}

		if (!m_response.finished())
			m_response.sendresponse();

		if (!m_response.finished())
			set_nextstep(evtl::com::nextstep_wait_to_send);
		else
			set_nextstep(evtl::com::nextstep_done_end);
	}

	void _cycle_reset()
	{
		m_request.reset();
		m_response.reset();
	}

private:
	sessionbase  *m_sessbase;
	preprocess  *m_preproce;

	evtl::com::process_nextstep  m_nextstep;

	evtl::boolflag<false>  m_error;
	mulreq_reqeust  m_request;
	mulreq_response  m_response;
};


#endif


