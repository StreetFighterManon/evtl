

#ifndef __MULTIREQ_RESPONSE_H__
#define __MULTIREQ_RESPONSE_H__

#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_wrapper.h>

#include "../sessionbase.h"


class mulreq_response
{
public:
	mulreq_response()
	{
		m_sessbase = nullptr;
	}

	void set_sessbase(sessionbase *base)
	{
		m_sessbase = base;
	}

	bool is_paramset() const
	{
		return m_id.isset();
	}

	void set_id(const std::string &id)
	{
		m_id.set_assign(id);
	}

	bool finished()
	{
		if (m_response.isset() && m_response.refer().empty())
			return true;
		return false;
	}

	void sendresponse()
	{
		if (!m_id.isset())
			return;

		if (!m_response.isset())
		{
			std::stringstream ss;
			ss << "[response]\r\n"
				<< "id: " << m_id.refer() << "\r\n"
				<< "content: " << m_id.refer() << " multirequest\r\n"
				<< "[end]\r\n";

			m_response.refer().extens_store_whole(ss.str());
			m_response.set();
		}

		evtl::linearbuf<char> &buf = m_response.refer();
		ssize_t size = buf.size();
		if (size > 0)
		{
			ssize_t sz = m_sessbase->m_ssitf->sockwrite(buf.dataptr(), size);
			if (sz > 0)
			{
				if (!buf.shit_whole(sz))
					assert(false && "shit error");
			}
		}
	}

	void reset()
	{
		m_id.reset();
		m_response.reset();
	}

private:
	sessionbase  *m_sessbase;

	evtl::var<std::string>  m_id;
	evtl::dn_var<evtl::linearbuf<char>>  m_response;
};


#endif


