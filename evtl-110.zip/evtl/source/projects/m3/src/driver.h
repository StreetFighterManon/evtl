

#ifndef __DRIVER_H__
#define __DRIVER_H__

#include <evtl/evtl_eventloop.h>

#include "service.h"
#include "acceptor.h"


class driver
{
public:
	driver()
	{}

	bool init()
	{
		m_acceptor.set_loop(m_loop.ref());
		if (!m_acceptor.set_address(evtl::makeipaddr("0.0.0.0", 3333)))
			return false;
		m_acceptor.set_callback(std::bind(&driver::accept_callback, this, std::placeholders::_1, std::placeholders::_2));
		if (!m_acceptor.start())
			return false;

		m_service.set_loop(m_loop.ref());
		if (!m_service.init())
			return false;

		return true;
	}

	void run()
	{
		m_loop.run_loop(evtl::simpeventloop<evtl::default_loop>::current_thread);
	}

private:
	void accept_callback(evtl::simpacceptor &accpt, std::vector<evtl::connection> &connections)
	{
		m_service.receive_conn(connections);
	}

private:
	evtl::simpeventloop<evtl::default_loop>  m_loop;
	acceptor  m_acceptor;
	service  m_service;
};


#endif


