

#ifndef __MULTIHEARTBEAT_MULTIHB_PROCESS_H__
#define __MULTIHEARTBEAT_MULTIHB_PROCESS_H__


class multihb_process
{
public:
	multihb_process()
	{}
};


#endif


