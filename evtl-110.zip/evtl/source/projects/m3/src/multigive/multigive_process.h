

#ifndef __MULTIGIVE_MULTIGIVE_PROCESS_H__	
#define __MULTIGIVE_MULTIGIVE_PROCESS_H__


class multigive_process
{
public:
	multigive_process()
	{}
};


#endif



