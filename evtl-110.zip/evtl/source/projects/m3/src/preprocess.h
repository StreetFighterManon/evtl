

#ifndef __PREPROCESS_H__
#define __PREPROCESS_H__

#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_com.h>
#include <evtl/evtl_pcre2.h>

#include "types.h"
#include "sessionbase.h"


class preprocess
{
public:
	preprocess()
	{
		m_sessbase = nullptr;
		m_recvbuf = nullptr;
		m_error = false;
		m_needrecv = true;
		m_occupyed = false;
	}

	void set_recvbuf(evtl::linearbuf<char> *buf)
	{
		m_recvbuf = buf;
	}

	void set_sessbase(sessionbase *base)
	{
		m_sessbase = base;
	}

	void preproc()
	{
		if (m_error)
			return;

		if (m_cliseginfo.m_type == clisegtype::unknown)
			search();
	}

	evtl::linearbuf<char> * get_recvbuf()
	{
		return m_recvbuf;
	}

	const cliseginfo& get_seginfo() const
	{
		return m_cliseginfo;
	}

	void reset_seginfo()
	{
		m_cliseginfo.reset();
	}

	bool is_needrecv() const
	{
		return m_needrecv;
	}

	void set_needrecv(bool need)
	{
		m_needrecv = need;
	}

	bool is_busy() const
	{
		return m_occupyed;
	}

	void set_busy(bool busy)
	{
		m_occupyed = busy;
	}

	bool haserror() const
	{
		return m_error;
	}

	void deinit()
	{
		m_cliseginfo.reset();
	}

private:
	void search()
	{
		m_needrecv = false;
		ssize_t size = m_recvbuf->size();
		if (size > 0)
		{
			evtl::pcre2_8::regex reg(R"(\A\[(\w+)\]\r\nid: *(\d+)\r\n)");
			evtl::pcre2_8::match_results<char> matches;
			bool br = evtl::pcre2_8::regex_search(m_recvbuf->dataptr(), m_recvbuf->dataptr() + size, matches, reg);
			if (br)
			{
				if (matches.size() != 3)
					assert(false && "invalid matches");

				const evtl::pcre2_8::sub_match<char> &sub1 = matches[1];
				const evtl::pcre2_8::sub_match<char> &sub2 = matches[2];
				if (!sub1.matched || !sub2.matched)
					assert(false && "unmatch");

				std::string s2 = sub2.str();
				if (s2.size() > 128)
				{
					m_error = true;
					return;
				}

				cliseginfo  seginfo;

				std::string s1 = sub1.str();
				if (s1 == "singlerequest")
				{
					seginfo.m_type = clisegtype::singlerequest;
					seginfo.m_id   = s2;
					m_cliseginfo = seginfo;
				}
				else if (s1 == "multirequest")
				{
					seginfo.m_type = clisegtype::multirequest;
					seginfo.m_id   = s2;
					m_cliseginfo = seginfo;
				}
				else if (s1 == "response")
				{
					seginfo.m_type = clisegtype::response;
					seginfo.m_id   = s2;
					m_cliseginfo = seginfo;
				}
				else
				{
					m_error = true;
				}
				return;
			}
		}

		if (m_recvbuf->size() >= 1024)
		{
			m_error = true;
			return;
		}

		m_recvbuf->crowdct(1024, 1024);
		ssize_t headsp = m_recvbuf->headspace();
		if (headsp <= 0)
			assert(false && "buf error");

		ssize_t readsz = m_sessbase->m_ssitf->sockread(m_recvbuf->headptr(), headsp);
		if (readsz > 0)
		{
			if (readsz > headsp)
				assert(false && "read exception");
			if (!m_recvbuf->head_eaten_whole(readsz))
				assert(false && "head eaten whole");
			m_needrecv = false;
		}
		else
		{
			m_needrecv = true;
		}
	}

private:
	sessionbase  *m_sessbase;
	evtl::linearbuf<char> *m_recvbuf;
	cliseginfo  m_cliseginfo;

	bool  m_needrecv;
	bool  m_occupyed;
	bool  m_error;
};


#endif


