

#ifndef __PROCESS_H__
#define __PROCESS_H__

#include <evtl/evtl_linearbuf.h>

#include "preprocess.h"
#include "realprocess.h"
#include "singlerequest/singlereq_process.h"
#include "sessionbase.h"


class process
{
public:
	process(): m_recvbuf(1024*64)
	{
		m_sessbase = nullptr;
	}

	void set_sessbase(sessionbase *base)
	{
		m_sessbase = base;
	}

	void init()
	{
		m_preproce.set_recvbuf(&m_recvbuf);
		m_preproce.set_sessbase(m_sessbase);

		m_realproce.set_sessbase(m_sessbase);
		m_realproce.set_preprocess(&m_preproce);
		m_realproce.init();
	}

	void doprocess()
	{
		m_preproce.preproc();
		m_realproce.doprocess();
	}

	evtl::com::process_nextstep get_nextstep() const
	{
		return m_realproce.get_nextstep();
	}

	void mulsethb()
	{
		m_realproce.mulsethb();
	}

	void deinit()
	{
		m_recvbuf.clear();
		m_preproce.deinit();
		m_realproce.deinit();
	}

private:
	sessionbase  *m_sessbase;

	evtl::linearbuf<char>  m_recvbuf;
	preprocess  m_preproce;
	realprocess  m_realproce;
};


#endif


