

#include <iostream>
using namespace std;

#include <evtl/evtl_signal.h>

#include "driver.h"


int main()
{
	evtl::rand::urandom::init();
	evtl::signalc::sig_ignore(SIGPIPE);

	driver drv;
	if (!drv.init())
	{
		cout<<"driver init failed"<<endl;
		return 0;
	}

	drv.run();
	assert(false);
	return 0;
}


