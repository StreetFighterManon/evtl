

#ifndef __ACCEPTOR_H__
#define __ACCEPTOR_H__

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_acceptor.h>
#include <evtl/evtl_listener.h>


class acceptor
{
public:
	acceptor()
	{}

	void set_loop(evtl::looprefer loop)
	{
		m_loop = loop;
	}

	bool set_address(const evtl::address &addr)
	{
		return m_listener.set_address(addr);
	}

	void set_callback(evtl::simpacceptor::accept_callback_t cb)
	{
		m_acceptor.set_callback(cb);
	}

	bool start()
	{
		if (!m_listener.tcplisten(32))
			return false;

		m_acceptor.set_loop(m_loop);
		m_acceptor.set_listener(&m_listener);
		if (!m_acceptor.watch())
			return false;

		return true;
	}

private:
	evtl::looprefer  m_loop;

	evtl::listener  m_listener;
	evtl::simpacceptor  m_acceptor;
};


#endif


