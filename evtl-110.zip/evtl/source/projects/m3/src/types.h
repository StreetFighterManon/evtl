

#ifndef __TYPES_901784692_H__
#define __TYPES_901784692_H__


enum class clisegtype
{
	unknown,
	singlerequest,
	multirequest,
	singleheartbeat,
	multiheartbeat,
	response,
	invalid
};

struct cliseginfo
{
	cliseginfo(): m_type(clisegtype::unknown)
	{}

	void reset()
	{
		m_type = clisegtype::unknown;
		m_id.clear();
	}

	clisegtype  m_type;
	std::string  m_id;
};


#endif


