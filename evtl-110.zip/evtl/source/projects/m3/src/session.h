

#ifndef __SESSION_H__
#define __SESSION_H__

#include <utility>

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_watcher_io.h>
#include <evtl/evtl_com.h>
#include <evtl/evtl_watcher_timer.h>

#include "process.h"
#include "interface.h"
#include "sessionbase.h"


class session : public evtl::watcher_io<session>,
	public sessinterface
{
public:
	session()
	{}

	typedef std::function<void (session *psess)>  recycle_callback_t;

	void set_loop(evtl::looprefer loop)
	{
		m_loop = loop;
	}

	void set_recycle_callback(recycle_callback_t cb)
	{
		m_recycle_cb = std::move(cb);
	}

	void init()
	{
		m_sessbase.m_ssitf = this;
		m_sessbase.m_loop = m_loop;
		m_process.set_sessbase(&m_sessbase);
		m_process.init();

		start_watcher();

		set(m_loop);
		set_callback();
		set_events(ev::READ);
		start();
	}

	ssize_t sockread(void *buf, ssize_t nbytes) override
	{
		if (buf == nullptr || nbytes <= 0)
			assert(false && "error");

		ssize_t rt = this->read(buf, nbytes);
		if (rt > 0)
		{
			if (rt >nbytes)
				assert(false && "read excption");
		}
		else if (rt < 0)
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
				m_iostatus.orset(evtl::com::rwresult_read_error, errno);
		}
		else
		{
			m_iostatus.orset(evtl::com::rwresult_read_end, 0);
		}

		return rt;
	}

	ssize_t sockwrite(const void *buf, ssize_t nbytes) override
	{
		if (buf == nullptr || nbytes <= 0)
			assert(false && "error");

		ssize_t rt = this->write(buf, nbytes);
		if (rt > 0)
		{
			if (rt > nbytes)
				assert(false && "read excption");
		}
		else if (rt < 0)
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
				m_iostatus.orset(evtl::com::rwresult_read_error, errno);
		}
		else
		{
			m_iostatus.orset(evtl::com::rwresult_read_end, 0);
		}

		return rt;
	}

	void io_callback(session &watcher, int revents)
	{
		if (&watcher != this)
			assert(false && "unexpected watcher");

		m_process.doprocess();
		evtl::com::process_nextstep  step = m_process.get_nextstep();

		if (m_iostatus.error_raised())
		{
			m_recycle_cb(this);
			return;
		}

		switch (step)
		{
		case evtl::com::nextstep_wait_to_receive:
			{
				if (get_events() != ev::READ)
				{
					stop();
					set_events(ev::READ);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
				return;
			}
			break;
		case evtl::com::nextstep_wait_to_send:
			{
				if (get_events() != ev::WRITE)
				{
					stop();
					set_events(ev::WRITE);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
				return;
			}
			break;
		case evtl::com::nextstep_wait_to_receive_send:
			{
				if (get_events() != (ev::READ|ev::WRITE))
				{
					stop();
					set_events(ev::READ|ev::WRITE);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
				return;
			}
			break;
		case evtl::com::nextstep_continue:
			{
				if ((get_events() & ev::WRITE) == 0)
				{
					stop();
					set_events(ev::WRITE);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
				return;
			}
			break;
		case evtl::com::nextstep_stop:
			{
				stop();
				return;
			}
			break;
		case evtl::com::nextstep_none:
			{
				assert(false && "none");
				return;
			}
			break;
		case evtl::com::nextstep_cycledone:
			{
				if ((get_events() & ev::WRITE) == 0)
				{
					stop();
					set_events(ev::WRITE);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
				return;
			}
			break;
		case evtl::com::nextstep_done:
			{
				assert(false && "done");
				return;
			}
			break;
		case evtl::com::nextstep_done_end:
			{
				assert(false && "done end");
				return;
			}
			break;
		case evtl::com::nextstep_error:
			{
				stop();
				m_recycle_cb(this);
				return;
			}
			break;
		case evtl::com::nextstep_error_end:
			{
				stop();
				m_recycle_cb(this);
				return;
			}
			break;
		case evtl::com::nextstep_other:
			{
				assert(false && "other");
				return;
			}
			break;
		default:
			assert(false && "invalid step");
			break;
		};
	}

	void activate() override
	{
		if ((get_events() & ev::WRITE) == 0)
		{
			stop();
			set_events(ev::WRITE);
			start();
		}
		else
		{
			if (!is_active())
				start();
		}
	}

	void deinit()
	{
		stop_close();
		m_process.deinit();
		m_qhbtimer.stop();
	}

private:
	void start_watcher()
	{
		m_qhbtimer.set(m_loop, 0, 10.);
		m_qhbtimer.set_callback(std::bind(&session::hbtimer_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_qhbtimer.start();
	}

	void hbtimer_callback(evtl::simpwtimer &watcher, int revents)
	{
		if (&watcher != &m_qhbtimer)
			assert(false && "unexpected watcher");

		m_process.mulsethb();
		activate();
	}

private:
	evtl::looprefer  m_loop;
	sessionbase  m_sessbase;
	process  m_process;

	recycle_callback_t  m_recycle_cb;

	evtl::com::rwstatus  m_iostatus;
	evtl::simpwtimer  m_qhbtimer;
};


#endif


