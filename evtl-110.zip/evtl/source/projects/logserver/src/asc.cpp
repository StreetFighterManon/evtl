

#include <iostream>
using namespace std;

#include <string>

#include <evtl/evtl_eventloop.h>
#include <evpl/logger/logserver.h>

int64_t n = 0;

void asc(evpl::logger::logtypeinfo &typeinfo, const char *logstr, ssize_t len)
{
	std::string s(logstr, len);
	//cout<<"type: "<<typeinfo.id<<"|"<<s<<endl;
	n++;
	if (n%10000 == 0)
		cout<< evtl::timec::sec()<< " type:" << typeinfo.id << " n: "<<n<< " " <<s<<endl;
}

int main(int argc,char *argv[])
{
	if (evtl::timec::is_updating())
		assert(false);
	evtl::timec::background_update();
	if (!evtl::timec::is_updating())
		assert(false);

	evtl::simpeventloop<evtl::default_loop>  m_loop;

	evpl::logger::logserver server;
	server.set_loop(m_loop.ref());
	server.set_logcallback(std::bind(&asc, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3));
	server.set_address("127.0.0.1", 2333);
	server.start();

	m_loop.run_loop();
	return 0;
}


