

#ifndef __HEARTBRESPONSE_H__
#define __HEARTBRESPONSE_H__

#include "sessinfo.h"


class heartbresponse
{
public:
	heartbresponse()
	{
		m_base = nullptr;
	}

	enum searchresult
	{
		success,
		notmydata,
		badrequest,
		needcontinue,
		needrecv
	};

	void setbase(sessbase *base)
	{
		m_base = base;
	}

	bool got_response() const
	{
		return m_response.isset();
	}

	searchresult searchresponse()
	{
		evtl::linearbuf<char> &buf = m_base->recvbuf;
		if (!buf.empty())
		{
			evtl::pcre2_8::regex reg(R"(^HTTP/1.1 \d+.*?\r\n\r\n)");
			evtl::pcre2_8::match_results<char> matches;
			bool br = evtl::pcre2_8::regex_search(buf.dataptr(), buf.dataptr() + buf.size(), matches, reg);
			if (br)
			{
				const evtl::pcre2_8::sub_match<char> &sub = matches[0];
				m_response.refer().extens_store_whole(sub.first, sub.size());
				m_response.set();
				if (!buf.shit_whole(sub.second - buf.dataptr()))
					assert(false);

				return success;
			}
		}

		if (is_not_mydata())
		    return notmydata;

		if (buf.size() >= 1024*8)
		    return badrequest;

		buf.crowdct(1024*8, 1024*8);
		ssize_t headsize = buf.headspace();
		assert(headsize > 0);

		ssize_t n = m_base->m_iio->io_read(buf.headptr(), buf.headspace());
		if (n > 0)
		{
			if (!buf.head_eaten_whole(n))
				assert(false);
			return needcontinue;
		}

		return needrecv;
	}

	const evtl::linearbuf<char>& get_response() const
	{
		return m_response.refer();
	}

	void reset()
	{
		m_response.reset();
	}

private:
	bool is_not_mydata() const
	{
		const evtl::linearbuf<char> &buf = m_base->recvbuf;
		if (buf.size() > 10)
		{
			if (!evtl::util::isprefixwith(buf.dataptr(), buf.size(), "HTTP/1."))
				return true;
		}
		return false;
	}

private:
	sessbase  *m_base;
	evtl::st_var<evtl::linearbuf<char>>  m_response;
};


#endif

