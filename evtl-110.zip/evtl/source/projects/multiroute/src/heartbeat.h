
#ifndef __HEARTBEAT_H__
#define __HEARTBEAT_H__

#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_wrapper.h>

#include "sessinfo.h"


class heartbeat
{
public:
	heartbeat()
	{
		m_base = nullptr;
	}

	void setbase(sessbase *base)
	{
		m_base = base;
	}

	bool is_data_prepared() const
	{
		return m_buffer.isset();
	}

	void prepare_data()
	{
		std::string s;
		s.append("GET /heartbeat?aaa=111 HTTP/1.1\r\n");
		s.append("Content-Length: 0\r\n");
		s.append("\r\n");

		m_buffer.refer().extens_store_whole(s);
		m_buffer.set();
	}

	void sendheartbeat()
	{
		if (!m_buffer.isset())
			assert(false);

		evtl::linearbuf<char> &buf = m_buffer.refer();
		ssize_t size = buf.size();
		if (size > 0)
		{
			ssize_t n = m_base->m_iio->io_write(buf.dataptr(), size);
			if (n > 0)
			{
				if (!buf.shit_whole(n))
					assert(false);
			}
		}
	}

	bool sendfinished() const
	{
		if (m_buffer.refer().empty())
			return true;
		return false;
	}

	void reset()
	{
		m_buffer.reset();
	}

private:
	sessbase  *m_base;
	evtl::dn_var<evtl::linearbuf<char>>  m_buffer;
};


#endif

