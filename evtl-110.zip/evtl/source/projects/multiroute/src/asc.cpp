

#include <assert.h>
#include <evtl/evtl_listener.h>
#include <evtl/evtl_acceptor.h>

#include "server.h"

/*

client request:
	GET /asc HTTP/1.1
	Content-Length: 0
	Msg: go

server response:
	HTTP/1.1 200 OK
	Content-Length: 0


server request:
	GET /heartbeat?aaa=111 HTTP/1.1
	Content-Length: 0

client response:
	HTTP/1.1 200 OK
	Content-Length: 0
	Msg: go

*/


class multiroute
{
public:
	multiroute()
	{}

	void init()
	{
		m_listener.set_address(evtl::makeipaddr("0.0.0.0", 2333));
		m_listener.tcplisten(10);
		m_acceptor.set_loop(m_loop.ref());
		m_acceptor.set_listener(&m_listener);
		m_acceptor.set_callback(std::bind(&multiroute::accept_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_acceptor.watch();

		m_servser.set_loop(m_loop.ref());
		m_servser.init();
	}

	void run()
	{
		m_loop.run_loop();
	}

private:
	void accept_callback(evtl::simpacceptor &accptor, std::vector<evtl::connection> &connections)
	{
		for (std::vector<evtl::connection>::const_iterator iter = connections.begin(); iter != connections.end(); ++iter)
		{
			m_servser.recv_connection(iter->fd);
		}
	}

private:
	evtl::simpeventloop<>  m_loop;

	evtl::listener      m_listener;
	evtl::simpacceptor  m_acceptor;
	server  m_servser;
};


int main()
{
	evtl::default_loop::preinit();
	evtl::signalc::sig_ignore(SIGPIPE);

	multiroute  route;
	route.init();
	route.run();
	assert(false);
	return 0;
}


