

#ifndef __HTTPS_H__
#define __HTTPS_H__

#include <vector>

#include "httpsacceptor.h"
#include "httpsservice_asm.h"


class https
{
public:
	https()
	{}

	void init()
	{
		m_https.init();
		m_acceptor.set_callback(std::bind(&httpsservice_asm::accept_callback, &m_https, std::placeholders::_1, std::placeholders::_2));
		m_acceptor.init();
	}

	void run()
	{
		m_https.run_bg();
		m_acceptor.run();
	}

private:
	acceptor  m_acceptor;
	httpsservice_asm  m_https;
};


#endif


