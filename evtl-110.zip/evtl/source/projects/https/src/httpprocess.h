

#ifndef __HTTPPROCESS_H__
#define __HTTPPROCESS_H__

#include <evtl/evtl_com.h>

#include "sessionbase.h"
#include "rcvsegment.h"
#include "httprequest.h"
#include "sendfile.h"
#include "httpresponse.h"


class httpprocess
{
public:
	httpprocess(): m_base(nullptr)
	{
		m_nextstep = evtl::com::nextstep_unknown;
	}

	void set_sessbase(sessionbase *base)
	{
		m_base = base;
	}

	void init()
	{
	}

	void process()
	{
		m_nextstep = evtl::com::nextstep_unknown;

		if (!m_base->m_sslm.handshake_finished())
		{
			m_base->m_sslm.handshake();
			const evpl::openssl::ioresult &result = m_base->m_sslm.get_handshake_result().refer();
			switch (result.resultcode)
			{
			case SSL_ERROR_NONE:
				break;
			case SSL_ERROR_WANT_READ:
				{
					set_nextstep(evtl::com::nextstep_wait_to_receive);
					return;
				}
				break;
			case SSL_ERROR_WANT_WRITE:
				{
					set_nextstep(evtl::com::nextstep_wait_to_receive_send);
					return;
				}
				break;
			default:
				{
					set_nextstep(evtl::com::nextstep_error_end);
					return;
				}
				break;
			}

			if (!m_base->m_sslm.handshake_finished())
				assert(false && "accept not finished");
		}

		if (!m_rcvseg.ready())
		{
			m_rcvseg.set_sessbase(m_base);
		}

		if (!m_rcvseg.got())
		{
			rcvsegment::searchresult result = m_rcvseg.search_segment();
			switch (result)
			{
			case rcvsegment::searchresult::regex_exception:
			case rcvsegment::searchresult::invalid_data:
			case rcvsegment::searchresult::read_failed:
				{
					set_nextstep(evtl::com::nextstep_error_end);
					return;
				}
				break;
			case rcvsegment::searchresult::need_continue:
				{
					set_nextstep(evtl::com::nextstep_continue);
					return;
				}
				break;
			case rcvsegment::searchresult::need_receive:
				{
					set_nextstep(evtl::com::nextstep_wait_to_receive);
					return;
				}
				break;
			case rcvsegment::searchresult::need_send:
				{
					set_nextstep(evtl::com::nextstep_wait_to_send);
					return;
				}
				break;
			default:
				break;
			}

			if (result != rcvsegment::searchresult::success)
				assert(false);
		}

		if (!m_request.parsed())
		{
			m_request.set_reqbuf(m_rcvseg.get_segment());
			m_request.parse();

			if (!m_request.parsed())
				assert(false);
		}

		send_data();
	}

	void read()
	{
		m_sendfile.read();
	}

	void async_read()
	{
		m_sendfile.async_read();
	}

	evtl::com::process_nextstep get_nextstep() const
	{
		return m_nextstep;
	}

	void set_needexit()
	{
		m_sendfile.set_needexit();
	}

	bool can_exit() const
	{
		return m_sendfile.can_exit();
	}

	void cycle_reset()
	{
		m_rcvseg.reset();
		m_request.reset();
		m_sendfile.deinit();
		m_response.reset();
	}

	void deinit()
	{
		cycle_reset();
	}

private:
	void set_nextstep(evtl::com::process_nextstep step)
	{
		m_nextstep = step;
	}

	void send_data()
	{
		if (!m_sendfile.ready())
		{
			m_sendfile.set_sessbase(m_base);
			m_sendfile.set_request(&m_request);
			m_sendfile.init();
		}

		if (!m_sendfile.init_success())
		{
			fail_response(404);
			if (m_response.response_finished())
				set_nextstep(evtl::com::nextstep_cycledone);
			return;
		}

		if (!m_response.response_finished())
		{
			success_response(m_sendfile.get_fileinfo(), m_sendfile.is_partial());
			if (!m_response.response_finished())
				return;
		}

		if (!m_base->m_in_theadpool)
		{
			set_nextstep(evtl::com::nextstep_other);
			return;
		}

		send_filedata();
	}

	void send_filedata()
	{
		sendfile::sendresult result = m_sendfile.send();
		switch (result)
		{
		case sendfile::sendresult::sendcomplete:
			set_nextstep(evtl::com::nextstep_cycledone);
			break;
		case sendfile::sendresult::readcontinue:
			set_nextstep(evtl::com::nextstep_wait_to_receive);
			break;
		case sendfile::sendresult::sendcontinue:
			set_nextstep(evtl::com::nextstep_wait_to_send);
			break;
		case sendfile::sendresult::senderror:
			set_nextstep(evtl::com::nextstep_error_end);
			break;
		default:
			assert(false);
			break;
		}
	}

	void fail_response(int code)
	{
		if (!m_response.is_set())
		{
			m_response.set_sessbase(m_base);
			m_response.set_code(code);
		}

		if (!m_response.response_finished())
			m_response.sendresponse();
		if (!m_response.response_finished())
		{
			evtl::com::process_nextstep step = m_response.get_step();
			if (step == evtl::com::nextstep_unknown)
				assert(false);
			set_nextstep(step);
		}
	}

	void success_response(const fileinfo &info, bool partial)
	{
		if (!m_response.is_set())
		{
			m_response.set_sessbase(m_base);
			m_response.set_code(partial ? 206 : 200);
			m_response.set_range(info.m_start_offset, info.m_start_offset + info.m_total_length - 1, info.m_filesize);
		}

		m_response.sendresponse();
		if (!m_response.response_finished())
		{
			evtl::com::process_nextstep step = m_response.get_step();
			if (step == evtl::com::nextstep_unknown)
				assert(false);
			set_nextstep(step);
		}
	}

private:
	sessionbase  *m_base;

	evtl::com::process_nextstep  m_nextstep;

	rcvsegment  m_rcvseg;
	httpreqeust  m_request;
	sendfile  m_sendfile;
	httpresponse  m_response;
};


#endif


