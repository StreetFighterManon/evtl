

#ifndef __HTTPREQINFO_H__
#define __HTTPREQINFO_H__

#include <evtl/evtl_wrapper.h>


struct requestinfo
{
	requestinfo()
	{}

	void reset()
	{
		m_filename.clear();
		m_rangestart.reset();
		m_rangeend.reset();
	}

	std::string m_filename;
	evtl::st_var<int64_t>  m_rangestart;
	evtl::st_var<int64_t>  m_rangeend;
};


#endif


