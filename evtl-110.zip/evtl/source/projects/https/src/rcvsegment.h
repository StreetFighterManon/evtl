

#ifndef __RCVSEGMENT_H__
#define __RCVSEGMENT_H__

#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_pcre2.h>
#include <evtl/evtl_wrapper.h>


#include "sessionbase.h"


class rcvsegment
{
public:
	rcvsegment(): m_base(nullptr)
	{}

	enum class searchresult
	{
		success,
		regex_exception,
		invalid_data,
		need_continue,
		need_receive,
		need_send,
		read_failed
	};

	bool ready() const
	{
		return m_base != nullptr;
	}

	void set_sessbase(sessionbase *base)
	{
		m_base = base;
	}

	bool got() const
	{
		return m_rseg.isset();
	}

	searchresult search_segment()
	{
		if (m_rseg.isset())
			assert(false);

		try
		{
			evtl::pcre2_8::regex  reg(R"(GET .*?HTTP/1.1.*?\r\n\r\n)");
			evtl::pcre2_8::match_results<char>  matches;
			bool br = evtl::pcre2_8::regex_search(m_base->m_recvbuf.dataptr(), m_base->m_recvbuf.dataptr() + m_base->m_recvbuf.size(), matches, reg);
			if (br)
			{
				if (matches.size() != 1)
					assert(false);

				const evtl::pcre2_8::sub_match<char>  sub = matches[0];
				if (!sub.matched)
					assert(false);

				if (sub.empty())
					assert(false);

				evtl::linearbuf<char> &buf = m_rseg.refer();
				buf.extens_store_whole(sub.first, sub.second - sub.first);
				m_rseg.set();

				if (!m_base->m_recvbuf.shit_whole(sub.second - m_base->m_recvbuf.dataptr()))
					assert(false);
				return searchresult::success;
			}
		}
		catch (std::exception &e)
		{
			return searchresult::regex_exception;
		}

		if (m_base->m_recvbuf.size() > 8*1024)
			return searchresult::invalid_data;

		m_base->m_recvbuf.crowdct(8*1024, 8*1024);
		ssize_t headspace = m_base->m_recvbuf.headspace();
		if (headspace <= 0)
			assert(false);

		int rt = m_base->m_ioif->ssl_read(m_base->m_recvbuf.headptr(), headspace);
		if (rt > 0)
		{
			if (rt > headspace)
				assert(false);
			if (!m_base->m_recvbuf.head_eaten_whole(rt))
				assert(false);
			return searchresult::need_continue;
		}

		const evpl::openssl::ioresult &result = m_base->m_sslm.get_result();
		switch (result.resultcode)
		{
		case SSL_ERROR_NONE:
			assert(false);
			break;
		case SSL_ERROR_WANT_READ:
			return searchresult::need_receive;
		case SSL_ERROR_WANT_WRITE:
			return searchresult::need_send;
		default:
			break;
		}

		return searchresult::read_failed;
	}

	const evtl::linearbuf<char> * get_segment() const
	{
		return &m_rseg.refer();
	}

	void reset()
	{
		m_base = nullptr;
		m_rseg.reset();
	}

private:
	sessionbase *m_base;

	evtl::st_var<evtl::linearbuf<char>>  m_rseg;
};


#endif


