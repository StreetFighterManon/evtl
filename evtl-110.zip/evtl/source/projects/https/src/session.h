

#ifndef __SESSION_H__
#define __SESSION_H__

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_watcher_io.h>
#include <evtl/evtl_watcher_async.h>

#include "httpprocess.h"
#include "sessionbase.h"
#include "threadpoolcom.h"
#include "interface.h"


class session : public evtl::watcher_io<session>,
	public ifc_httpstask, public iointerface
{
public:
	session()
	{
		m_pool_a = nullptr;
		m_pool_b = nullptr;
	}

	typedef std::function<void (session *psess)>  recycle_callback_t;

	void set_recycle_callback(recycle_callback_t cb)
	{
		m_recycle_cb = cb;
	}

	void set_threadpool(threadpool_at *a, threadpool_bt *b)
	{
		m_pool_a = a;
		m_pool_b = b;
	}

	void set_loop(evtl::looprefer loop)
	{
		m_sessbase.m_loop = loop;
	}

	void set_ssl(SSL *ssl)
	{
		m_sessbase.m_sslm.set_ssl(ssl);
	}

	void set_connection(const evtl::connection &conn)
	{
		m_sessbase.m_connection = conn;
		m_sessbase.m_sslm.set_fd(conn.fd);
	}

	void init()
	{
		m_sessbase.m_ioif = this;
		m_sessbase.m_sslm.set_accept_state();

		m_switchnotify_async.set(m_sessbase.m_loop);
		m_switchnotify_async.set_callback(std::bind(&session::switch_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_switchnotify_async.start();

		m_process.set_sessbase(&m_sessbase);
		m_process.init();
		update_last_active_time();
	}

	int ssl_read(void *buf, int nbytes) override
	{
		int ret = m_sessbase.m_sslm.read(buf, nbytes);
		if (ret > 0)
			update_last_active_time();

		return ret;
	}

	int ssl_write(const void *buf, int nbytes) override
	{
		int ret = m_sessbase.m_sslm.write(buf, nbytes);
		if (ret > 0)
			update_last_active_time();

		return ret;
	}

	int ssl_readv(void *buf, int nbytes, int retry, int *trytimes) override
	{
		int ret = m_sessbase.m_sslm.readv(buf, nbytes, retry, trytimes);
		if (ret > 0)
			update_last_active_time();

		return ret;
	}

	int ssl_writev(const void *buf, int nbytes, int retry, int *trytimes) override
	{
		int ret = m_sessbase.m_sslm.writev(buf, nbytes, retry, trytimes);
		if (ret > 0)
			update_last_active_time();

		return ret;
	}

	void io_callback(session &watcher, int revent)
	{
		if (&watcher != this)
			assert(false);

		m_process.process();

		evtl::com::process_nextstep step = m_process.get_nextstep();
		switch (step)
		{
		case evtl::com::nextstep_wait_to_receive:
			{
				if (get_events() != ev::READ)
				{
					stop();
					set_events(ev::READ);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
			}
			break;
		case evtl::com::nextstep_wait_to_send:
			{
				if (get_events() != ev::WRITE)
				{
					stop();
					set_events(ev::WRITE);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
			}
			break;
		case evtl::com::nextstep_continue:
			{
				if ((get_events() & ev::WRITE) == 0)
				{
					stop();
					set_events(ev::WRITE);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
			}
			break;
		case evtl::com::nextstep_cycledone:
			{
				_cycle_reset();
				if ((get_events() & ev::WRITE) == 0)
				{
					stop();
					set_events(ev::WRITE);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
			}
			break;
		case evtl::com::nextstep_done_end:
			{
				stop();
				m_recycle_cb(this);
			}
			break;
		case evtl::com::nextstep_error_end:
			{
				stop();
				m_recycle_cb(this);
			}
			break;
		case evtl::com::nextstep_other:
			{
				if (!m_sessbase.m_in_theadpool)
				{
					m_sessbase.m_in_theadpool = true;

					const void *p1 = m_pool_a->add_task<>(this);
					const void *p2 = m_pool_b->add_task<>(this);
					if (p1 == nullptr || p2 == nullptr)
						assert(false && "add to threadpool failed");

					stop();
				}
				else
				{
					assert(false);
				}
			}
			break;
		default:
			assert(false && "unknown step");
			break;
		};
	}

	void run_a(void *arg) override
	{
		if (m_sessbase.m_switch_notified)
			return;

		m_process.process();

		evtl::com::process_nextstep step = m_process.get_nextstep();
		switch (step)
		{
		case evtl::com::nextstep_wait_to_receive:
		case evtl::com::nextstep_wait_to_send:
			{
				if (m_process.can_exit())
				{
					if (!m_sessbase.m_switch_notified)
					{
						m_sessbase.m_switch_recycle = true;
						m_switchnotify_async.send();
					}
					m_sessbase.m_switch_notified = true;
				}
			}
			break;
		case evtl::com::nextstep_cycledone:
			{
				if (m_process.can_exit())
				{
					if (!m_sessbase.m_switch_notified)
						m_switchnotify_async.send();
					m_sessbase.m_switch_notified = true;
				}
			}
			break;
		case evtl::com::nextstep_done_end:
		case evtl::com::nextstep_error_end:
			{
				if (m_process.can_exit())
				{
					if (!m_sessbase.m_switch_notified)
					{
						m_sessbase.m_switch_recycle = true;
						m_switchnotify_async.send();
					}
					m_sessbase.m_switch_notified = true;
				}
			}
			break;
		default:
			assert(false && "unknown step");
			break;
		};
	}

	void run_b(void *arg) override
	{
		m_process.async_read();
	}

	int64_t active_timeout()
	{
		int64_t now_s = evtl::timec::fast_sec();
		if (now_s < m_sessbase.m_last_active_s)
			m_sessbase.m_last_active_s = now_s;
		else if (now_s > m_sessbase.m_last_active_s + 60)
			return true;
		return false;
	}

	bool is_inthreadpool() const
	{
		return m_sessbase.m_in_theadpool;
	}

	void set_needexit()
	{
		m_process.set_needexit();
	}

	void remove_from_threadpool()
	{
		if (m_sessbase.m_in_theadpool)
		{
			const void *p1 = m_pool_a->remove_task(this);
			const void *p2 = m_pool_b->remove_task(this);
			if (p1 == nullptr || p2 == nullptr)
				assert(false);

			m_sessbase.m_in_theadpool = false;
		}
	}

	void deinit()
	{
		m_sessbase.m_sslm.shutdown();
		m_sessbase.m_sslm.free();

		m_switchnotify_async.stop();

		stop_close();
		m_process.deinit();
	}

private:
	void switch_callback(evtl::simpwasync &watcher, int revents)
	{
		if (&watcher != &m_switchnotify_async)
			assert(false);

		if (m_sessbase.m_in_theadpool)
		{
			const void *p1 = m_pool_a->remove_task(this);
			const void *p2 = m_pool_b->remove_task(this);
			if (p1 == nullptr || p2 == nullptr)
				assert(false);

			m_sessbase.m_in_theadpool = false;
			m_sessbase.m_switch_notified = false;

			if (is_active())
				assert(false);

			if (m_sessbase.m_switch_recycle)
			{
				stop();
				m_recycle_cb(this);
			}
			else
			{
				_cycle_reset();
				set_events(ev::WRITE);
				start();
			}
		}
		else
		{
			assert(false);
		}
	}

	void update_last_active_time()
	{
		m_sessbase.m_last_active_s = evtl::timec::fast_sec();
	}

	void _cycle_reset()
	{
		m_process.cycle_reset();
	}

private:
	sessionbase  m_sessbase;

	threadpool_at  *m_pool_a;
	threadpool_bt  *m_pool_b;

	recycle_callback_t  m_recycle_cb;
	httpprocess  m_process;

	evtl::simpwasync  m_switchnotify_async;
};


#endif


