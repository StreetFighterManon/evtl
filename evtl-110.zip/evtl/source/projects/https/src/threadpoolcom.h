

#ifndef __THREADPOOLCOM_H__
#define __THREADPOOLCOM_H__

#include <evtl/evtl_threadifc.h>


struct ifc_httpstask
{
	virtual ~ifc_httpstask()
	{}

	virtual void run_a(void *arg) = 0;

	virtual void run_b(void *arg) = 0;
};


struct threadctrl : public evtl::thread::ifc_ctrl<ifc_httpstask*>
{
	threadctrl()
	{}

	void circle_begin(void *arg, int64_t id)
	{
	}

	void circle_accompany(void *arg, int64_t id, ifc_httpstask* const &ptask)
	{
	}

	void circle_end(void *arg, int64_t id, int64_t taskcount, int64_t consumed_us)
	{
		usleep(3000);
	}
};

typedef evtl::thread::ptpc_threadpool<ifc_httpstask, &ifc_httpstask::run_a>  threadpool_at;
typedef evtl::thread::ptpc_threadpool<ifc_httpstask, &ifc_httpstask::run_b>  threadpool_bt;


#endif


