

#ifndef __HTTPSSERVICE_H__
#define __HTTPSSERVICE_H__

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_wasyncs.h>
#include <evtl/evtl_in.h>
#include <evtl/evtl_watcher_timer.h>

#include "session.h"
#include "sslcontext.h"


class httpsservice
{
public:
	httpsservice(): m_session_count(0)
	{
		m_threadpool_a = nullptr;
		m_threadpool_b = nullptr;
	}

	void set_loop(evtl::looprefer loop)
	{
		m_loop = loop;
	}

	void set_threadpool(threadpool_at *a, threadpool_bt *b)
	{
		m_threadpool_a = a;
		m_threadpool_b = b;
	}

	void init()
	{
		m_sslcontext.init();
		m_connection_async.init();
		start_watcher();
	}

	void async_receive_connections(std::vector<evtl::connection> &conns)
	{
		m_connection_async.pushback(conns);
		m_connection_async.send();
	}

	ssize_t get_session_count() const
	{
		return m_connection_async.atom_size() + m_session_count;
	}

private:
	void start_watcher()
	{
		m_connection_async.set(m_loop);
		m_connection_async.set_callback(std::bind(&httpsservice::connection_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_connection_async.start();

		m_timer.set(m_loop, 0, 10.);
		m_timer.set_callback(std::bind(&httpsservice::timer_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_timer.start();
	}

	void connection_callback(evtl::queue_simpwasync<evtl::connection> &watcher, int revents)
	{
		if (&watcher != &m_connection_async)
			assert(false);

		std::vector<evtl::connection>  conns;
		ssize_t n = m_connection_async.popfront(conns, 5);
		if (n <= 0)
			return;

		std::vector<evtl::connection>::iterator iter = conns.begin();
		if (iter == conns.end())
			assert(false);

		for ( ; iter != conns.end(); ++iter)
		{
			evtl::connection &conn = *iter;

			session *psess = new session;
			psess->set_recycle_callback(std::bind(&httpsservice::recycle_session, this, std::placeholders::_1));
			psess->set_threadpool(m_threadpool_a, m_threadpool_b);
			psess->set_loop(m_loop);

			SSL *ssl = m_sslcontext.new_ssl();
			if (ssl == nullptr)
			{
				close(conn.fd);
				conn.fd = -1;
				continue;
			}

			psess->set_ssl(ssl);
			psess->set_connection(conn);
			psess->init();

			psess->set(m_loop);
			psess->set(conn.fd, ev::READ);
			psess->set_callback();
			psess->start();

			std::pair<std::set<session*>::const_iterator, bool> rt = m_sessions.insert(psess);
			if (!rt.second)
				assert(false);
		}

		m_session_count = (ssize_t)m_sessions.size();
		watcher.send();
	}

	void timer_callback(evtl::simpwtimer &watcher, int revents)
	{
		if (&watcher != &m_timer)
			assert(false && "unexpected watcher");

		for (std::set<session*>::const_iterator iter = m_sessions.begin(); iter != m_sessions.end(); )
		{
			session *psess = *iter;
			if (psess->active_timeout())
			{
				if (psess->is_inthreadpool())
				{
					psess->set_needexit();
					++iter;
				}
				else
				{
					m_sessions.erase(iter++);
					psess->deinit();
					delete psess;

					m_session_count = (ssize_t)m_sessions.size();
				}
			}
			else
			{
				++iter;
			}
		}
	}

private:
	void recycle_session(session *psess)
	{
		if (psess == nullptr)
			assert(false);

		size_t n = m_sessions.erase(psess);
		if (n <= 0)
			assert(false);

		m_session_count = (ssize_t)m_sessions.size();
		psess->deinit();
		delete psess;
	}

private:
	evtl::looprefer  m_loop;
	ssl_context  m_sslcontext;

	threadpool_at  *m_threadpool_a;
	threadpool_bt  *m_threadpool_b;

	evtl::queue_simpwasync<evtl::connection>  m_connection_async;
	std::set<session*>  m_sessions;
	std::atomic<ssize_t>  m_session_count;

	evtl::simpwtimer  m_timer;
};


#endif


