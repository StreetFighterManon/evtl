

#ifndef __SENDFILE_H__
#define __SENDFILE_H__

#include <unistd.h>

#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_boundedbuf.h>
#include <evtl/evtl_eio.h>

#include "httprequest.h"
#include "fileinfo.h"


struct httpseio : public evtl::eio<httpseio>
{
	httpseio(): m_buf(nullptr), m_read_len(0), m_read_result(0), m_errno(0)
	{}

	void reset()
	{
		m_buf = nullptr;
		m_read_len = 0;
		m_read_result = 0;
		m_errno = 0;
		m_readfin.reset();
		m_destroyed.reset();
	}

	evtl::linearbuf<char> *m_buf;
	ssize_t  m_read_len;
	ssize_t  m_read_result;
	int      m_errno;
	evtl::boolflag<false, true>  m_readfin;
	evtl::boolflag<false, true>  m_destroyed;
};


class sendfile
{
public:
	sendfile(): m_sessbase(nullptr), m_request(nullptr), m_buffer(2)
	{
		m_fd = -1;
		m_partial = false;

		for (ssize_t i = 0; i < m_buffer.size(); i++)
		{
			evtl::linearbuf<char> &buf = m_buffer[i].elem();
			buf.reset_capacity(1024*1024);
		}

		m_init_success = false;
	}

	enum class sendresult
	{
		sendcomplete,
		readcontinue,
		sendcontinue,
		senderror
	};

	enum class eiostatus
	{
		unknown,
		wait_submit,
		wait_reading,
		deal_error,
		wait_exit
	};

	bool ready() const
	{
		if (m_request == nullptr)
			return false;
		return true;
	}

	void set_sessbase(sessionbase *base)
	{
		m_sessbase = base;
	}

	void set_request(const httpreqeust *request)
	{
		m_request = request;
	}

	void init()
	{
		if (m_request == nullptr)
			assert(false);

		m_init_success = false;

		if (!m_request->parse_success())
		{
			m_errstr = "parse failed";
			return;
		}

		const requestinfo &info = m_request->get_requestinfo();
		m_fd = ::open(info.m_filename.c_str(), O_RDONLY);
		if (m_fd == -1)
		{
			m_errstr = "open file failed";
			return;
		}

		m_fileinfo.m_filesize = get_filesize(m_fd);
		if (m_fileinfo.m_filesize <= 0)
		{
			m_errstr = "invalid file";
			::close(m_fd);
			m_fd = -1;
			return;
		}

		m_partial = false;

		if (info.m_rangestart.isset())
		{
			if (info.m_rangestart < 0 || info.m_rangestart >= m_fileinfo.m_filesize)
			{
				m_errstr = "invalid range";
				::close(m_fd);
				m_fd = -1;
				return;
			}

			if (info.m_rangestart > 0)
				m_partial = true;

			m_fileinfo.m_start_offset = info.m_rangestart;

			if (info.m_rangeend.isset())
			{
				if (info.m_rangeend < info.m_rangestart)
				{
					m_errstr = "invalid range";
					::close(m_fd);
					m_fd = -1;
					return;
				}
				else
				{
					if (info.m_rangeend < m_fileinfo.m_filesize)
						m_fileinfo.m_total_length = info.m_rangeend - m_fileinfo.m_start_offset + 1;
					else
						m_fileinfo.m_total_length = m_fileinfo.m_filesize - m_fileinfo.m_start_offset;

					if (info.m_rangeend < m_fileinfo.m_filesize - 1)
						m_partial = true;
				}
			}
			else
			{
				m_fileinfo.m_total_length = m_fileinfo.m_filesize - m_fileinfo.m_start_offset;
			}
		}
		else
		{
			m_fileinfo.m_start_offset = 0;
			m_fileinfo.m_total_length = m_fileinfo.m_filesize;
		}

		m_fileinfo.m_current_read = 0;
		m_fileinfo.m_current_send = 0;

		if (::lseek(m_fd, m_fileinfo.m_start_offset, SEEK_SET) != m_fileinfo.m_start_offset)
		{
			m_errstr = "seek failed";
			::close(m_fd);
			m_fd = -1;
			return;
		}

		m_buffer.zeroed_production();
		for (ssize_t i = 0; i < m_buffer.size(); i++)
		{
			evtl::boundedbuf<evtl::linearbuf<char>>::blockunit &bu = m_buffer[i];
			bu.elem().clear();
		}

		m_eio.set_readcallback(std::bind(&sendfile::read_callback, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3, std::placeholders::_4));
		m_eio.set_destroycallback(std::bind(&sendfile::destroy_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_eiostat = eiostatus::wait_submit;
		m_init_success = true;
	}

	bool init_success()
	{
		return m_init_success;
	}

	const fileinfo& get_fileinfo() const
	{
		return m_fileinfo;
	}

	bool is_partial() const
	{
		return m_partial;
	}

	std::string get_errstr() const
	{
		return m_errstr;
	}

	sendresult send()
	{
		ssize_t left = m_fileinfo.m_total_length - m_fileinfo.m_current_send;
		if (left <= 0)
		{
			m_need_exit = true;
			return sendresult::sendcomplete;
		}

		evtl::linearbuf<char> *buf = m_buffer.get_consume();
		if (buf == nullptr)
			return sendresult::sendcontinue;

		ssize_t datasize = buf->size();
		if (datasize <= 0)
		{
			buf->clear();
			m_buffer.consume_complete(buf);
			return sendresult::sendcontinue;
		}

		if (left > datasize)
			left = datasize;

		ssize_t rt = m_sessbase->m_ioif->ssl_writev(buf->dataptr(), left, 10);
		if (rt > 0)
		{
			if (rt > left)
				assert(false);
			if (!buf->shit_whole(rt))
				assert(false);

			if (buf->empty())
				m_buffer.consume_complete(buf);

			m_fileinfo.m_current_send += rt;
			if (m_fileinfo.m_current_send < m_fileinfo.m_total_length)
				return sendresult::sendcontinue;
			else
			{
				m_need_exit = true;
				return sendresult::sendcomplete;
			}
		}

		const evpl::openssl::ioresult &result = m_sessbase->m_sslm.get_result();
		switch (result.resultcode)
		{
		case SSL_ERROR_NONE:
			assert(false);
			break;
		case SSL_ERROR_WANT_READ:
			return sendresult::readcontinue;
			break;
		case SSL_ERROR_WANT_WRITE:
			return sendresult::sendcontinue;
			break;
		default:
			break;
		}

		m_need_exit = true;
		return sendresult::senderror;
	}

	void read()
	{
		ssize_t left = m_fileinfo.m_total_length - m_fileinfo.m_current_read;
		if (left <= 0)
			return;

		evtl::linearbuf<char> *buf = m_buffer.get_produce();
		if (buf == nullptr)
			return;

		if (!buf->empty())
			assert(false);

		buf->crowd();
		ssize_t headspace = buf->headspace();
		if (headspace <= 0)
			assert(false);
		if (left > headspace)
			left = headspace;

		ssize_t rt = ::read(m_fd, buf->headptr(), left);
		if (rt > 0)
		{
			if (rt > left)
				assert(false);
			if (!buf->head_eaten_whole(rt))
				assert(false);

			m_buffer.produce_complete(buf);
			m_fileinfo.m_current_read += rt;
		}
	}

	void async_read()
	{
		if (m_eiostat == eiostatus::wait_submit)
		{
			if (m_need_exit)
			{
				m_eiostat = eiostatus::wait_exit;
				return;
			}

			ssize_t left = m_fileinfo.m_total_length - m_fileinfo.m_current_read;
			if (left <= 0)
			{
				m_eiostat = eiostatus::wait_exit;
				return;
			}

			evtl::linearbuf<char> *buf = m_buffer.get_produce();
			if (buf == nullptr)
				return;

			if (!buf->empty())
				assert(false);

			buf->crowd();
			ssize_t headspace = buf->headspace();
			if (headspace <= 0)
				assert(false);
			if (left > headspace)
				left = headspace;

			m_eio.m_buf = buf;
			m_eio.m_read_len = left;
			m_eio.m_read_result = 0;
			m_eio.m_errno = 0;
			m_eio.m_readfin = false;
			m_eio.m_destroyed = false;

			eio_req *req = m_eio.submit_read(m_fd, m_eio.m_buf->headptr(), left, m_fileinfo.m_start_offset + m_fileinfo.m_current_read, true);
			if (req == nullptr)
				assert(false);

			m_eiostat = eiostatus::wait_reading;
		}
		else if (m_eiostat == eiostatus::wait_reading)
		{
			if (!m_eio.m_destroyed)
				return;

			if (!m_eio.m_readfin)
			{
				m_eiostat = eiostatus::wait_exit;
				return;
			}

			if (m_eio.m_read_result > 0)
			{
				if (m_eio.m_read_result > m_eio.m_read_len)
					assert(false && "eio read exception");
				if (!m_eio.m_buf->head_eaten_whole(m_eio.m_read_result))
					assert(false);

				m_buffer.produce_complete(m_eio.m_buf);
				m_fileinfo.m_current_read += m_eio.m_read_result;
				m_eiostat = eiostatus::wait_submit;
			}
			else if (m_eio.m_read_result == 0)
			{
				cout<<"eioread reach end of file"<<endl;
				m_eiostat = eiostatus::deal_error;
			}
			else
			{
				if (m_eio.m_errno == EAGAIN || m_eio.m_errno == EWOULDBLOCK || m_eio.m_errno == EINTR)
					m_eiostat = eiostatus::wait_submit;
				else
				{
					cout<<"eioread error, errno = "<<m_eio.m_errno<<endl;
					m_eiostat = eiostatus::deal_error;
				}
			}
		}
		else if (m_eiostat == eiostatus::deal_error || m_eiostat == eiostatus::wait_exit)
		{
		}
		else
		{
			assert(false);
		}
	}

	void set_needexit()
	{
		m_need_exit = true;
	}

	bool can_exit() const
	{
		if (m_need_exit && (m_eiostat == eiostatus::wait_exit || m_eiostat == eiostatus::deal_error))
			return true;
		return false;
	}

	void deinit()
	{
		m_sessbase = nullptr;
		m_request = nullptr;
		if (m_fd != -1)
			::close(m_fd);
		m_fd = -1;

		m_fileinfo.reset();
		m_partial = false;

		m_buffer.zeroed_production();
		for (ssize_t i = 0; i < m_buffer.size(); i++)
		{
			evtl::boundedbuf<evtl::linearbuf<char>>::blockunit &bu = m_buffer[i];
			bu.elem().clear();
		}

		m_eio.reset();
		m_eiostat.reset();
		m_need_exit.reset();

		m_init_success = false;
		m_errstr.clear();
	}

private:
	ssize_t get_filesize(int fd)
	{
		struct stat filestat;
		memset(&filestat, 0, sizeof(filestat));

		if (::fstat(fd, &filestat) != 0)
			return 0;

		return (ssize_t)filestat.st_size;
	}

	int read_callback(httpseio &eios, eio_req *req, ssize_t result, char *buf)
	{
		if (&eios != &m_eio)
			assert(false);

		m_eio.m_read_result = result;
		m_eio.m_errno = req->errorno;
		m_eio.m_readfin = true;
		return 0;
	}

	void destroy_callback(httpseio &eios, eio_req *req)
	{
		if (&eios != &m_eio)
			assert(false);

		m_eio.m_destroyed = true;
	}

private:
	sessionbase  *m_sessbase;
	const httpreqeust *m_request;

	int  m_fd;
	fileinfo  m_fileinfo;
	bool  m_partial;

	evtl::boundedbuf<evtl::linearbuf<char>>  m_buffer;
	httpseio   m_eio;
	evtl::enumflag<eiostatus, eiostatus::unknown, true>  m_eiostat;

	evtl::boolflag<false, true>  m_need_exit;

	bool  m_init_success;
	std::string  m_errstr;
};


#endif


