

#ifndef __SESSIONBASE_H__
#define __SESSIONBASE_H__

#include <atomic>

#include <evtl/evtl_in.h>
#include <evtl/evtl_linearbuf.h>

#include <evpl/openssl/ssl.h>

#include "interface.h"


struct sessionbase
{
	sessionbase(): m_recvbuf(1024*10)
	{
		m_ioif = nullptr;
		m_last_active_s = 0;
	}

	iointerface  *m_ioif;

	evtl::looprefer  m_loop;
	evtl::connection  m_connection;
	evpl::openssl::simpssl  m_sslm;

	evtl::linearbuf<char>  m_recvbuf;
	evtl::boolflag<false, true>  m_in_theadpool;
	evtl::boolflag<false, true>  m_switch_notified;
	evtl::boolflag<false, true>  m_switch_recycle;

	std::atomic<int64_t>  m_last_active_s;
};


#endif


