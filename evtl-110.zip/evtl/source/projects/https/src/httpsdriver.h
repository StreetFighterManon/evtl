

#ifndef __HTTPSDRIVER_H__
#define __HTTPSDRIVER_H__

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_threadpool.h>

#include "httpsservice.h"
#include "threadpoolcom.h"


class httpsdriver
{
public:
	httpsdriver()
	{}

	void init()
	{
		m_service.set_loop(m_loop.ref());
		m_service.set_threadpool(&m_threadpool_a, &m_threadpool_b);
		m_service.init();

		m_threadpool_a.set_poolname("pool_a");
		m_threadpool_a.make_thread(&m_ctrl, 0, 1);

		m_threadpool_b.set_poolname("pool_b");
		m_threadpool_b.make_thread(&m_ctrl, 0, 1);
	}

	void run_bg()
	{
		m_loop.run_loop(evtl::simpeventloop<evtl::dynamic_loop>::background_thread, "httpsdriver");
	}

	void async_receive_connections(std::vector<evtl::connection> &conns)
	{
		m_service.async_receive_connections(conns);
	}

	ssize_t get_session_count() const
	{
		return m_service.get_session_count();
	}

private:
	evtl::simpeventloop<evtl::dynamic_loop>  m_loop;

	threadpool_at  m_threadpool_a;
	threadpool_bt  m_threadpool_b;
	threadctrl  m_ctrl;

	httpsservice  m_service;
};


#endif


