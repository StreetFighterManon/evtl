

#ifndef __INTERFACE_H__
#define __INTERFACE_H__


struct iointerface
{
	virtual ~iointerface()
	{}

	virtual int ssl_read(void *buf, int len) = 0;

	virtual int ssl_write(const void *buf, int len) = 0;

	virtual int ssl_readv(void *buf, int len, int retry, int *trytimes = nullptr) = 0;

	virtual int ssl_writev(const void *buf, int len, int retry, int *trytimes = nullptr) = 0;
};


#endif


