

#ifndef __HTTPREQUEST_H__
#define __HTTPREQUEST_H__

#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_pcre2.h>

#include "httpreqinfo.h"


class httpreqeust
{
public:
	httpreqeust(): m_reqbuf(nullptr), m_result(parseresult::unparsed)
	{}

	enum class parseresult
	{
		unparsed,
		success,
		failed
	};

	bool parsed() const
	{
		if (m_result == parseresult::unparsed)
			return false;
		return true;
	}

	void set_reqbuf(const evtl::linearbuf<char> *buf)
	{
		m_reqbuf = buf;
	}

	void parse()
	{
		if (m_reqbuf == nullptr)
			assert(false);
		if (m_result != parseresult::unparsed)
			assert(false);

		try
		{
			evtl::pcre2_8::regex  reg(R"(GET (\S+) HTTP/1..\r\n)");
			evtl::pcre2_8::match_results<char>  matches;
			bool br = evtl::pcre2_8::regex_search(m_reqbuf->dataptr(), m_reqbuf->dataptr() + m_reqbuf->size(), matches, reg);
			if (br)
			{
				if (matches.size() != 2)
					assert(false);

				const evtl::pcre2_8::sub_match<char> &sub = matches[1];
				if (!sub.matched)
					assert(false);

				m_reqinfo.m_filename = sub.str();
			}
			else
			{
				m_result = parseresult::failed;
				return;
			}

			reg.assign(R"(\r\nRange: bytes=(\d+)-(\d*)\r\n)");
			br = evtl::pcre2_8::regex_search(m_reqbuf->dataptr(), m_reqbuf->dataptr() + m_reqbuf->size(), matches, reg);
			if (br)
			{
				if (matches.size() != 3)
					assert(false);
				if (!matches[1].matched || !matches[2].matched)
					assert(false);

				std::string start = matches[1].str();
				std::string end = matches[2].str();
				if (start.empty())
					assert(false);

				int64_t var = 0;
				std::stringstream ss;
				ss << start;
				ss >> var;

				m_reqinfo.m_rangestart.set_assign(var);
				if (!end.empty())
				{
					ss.str(""); ss.clear();
					ss << end;
					ss >> var;
					m_reqinfo.m_rangeend.set_assign(var);
				}
			}
		}
		catch (std::exception &e)
		{
			m_result = parseresult::failed;
			return;
		}

		m_result = parseresult::success;
	}

	bool parse_success() const
	{
		if (m_result == parseresult::success)
			return true;
		return false;
	}

	const requestinfo& get_requestinfo() const
	{
		return m_reqinfo;
	}

	void reset()
	{
		m_reqbuf = nullptr;
		m_reqinfo.reset();
		m_result = parseresult::unparsed;
	}

private:
	const evtl::linearbuf<char>  *m_reqbuf;
	requestinfo  m_reqinfo;
	parseresult  m_result;
};


#endif


