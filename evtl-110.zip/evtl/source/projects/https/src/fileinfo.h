

#ifndef __FILEINFO_H__
#define __FILEINFO_H__

#include <sys/types.h>


struct fileinfo
{
	fileinfo()
	{
		m_filesize = 0;
		m_start_offset = 0;
		m_total_length = 0;

		m_current_read = 0;
		m_current_send = 0;
	}

	void reset()
	{
		m_filesize = 0;
		m_start_offset = 0;
		m_total_length = 0;

		m_current_read = 0;
		m_current_send = 0;
	}

	ssize_t  m_filesize;
	ssize_t  m_start_offset;
	ssize_t  m_total_length;

	ssize_t  m_current_read;
	ssize_t  m_current_send;
};


#endif


