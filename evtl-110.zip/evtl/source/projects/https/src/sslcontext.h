

#ifndef __SSL_CONTEXT_H__
#define __SSL_CONTEXT_H__

#include <openssl/ssl.h>
#include <evpl/openssl/sslerr.h>


class ssl_context
{
public:
	ssl_context(): m_ctx(nullptr)
	{}

	bool init()
	{
		const SSL_METHOD *meth = TLS_method();
		if (meth == nullptr)
			return false;

		m_ctx = SSL_CTX_new(meth);
		if (m_ctx == nullptr)
			return false;

		SSL_CTX_set_max_proto_version(m_ctx, TLS1_2_VERSION);

		SSL_CTX_set_mode(m_ctx, SSL_MODE_AUTO_RETRY | SSL_MODE_ENABLE_PARTIAL_WRITE);
		SSL_CTX_set_read_ahead(m_ctx, 1);

		SSL_CTX_set_session_cache_mode(m_ctx, SSL_SESS_CACHE_OFF);

		//use RSA to debug with wireshark
		int ret = SSL_CTX_set_cipher_list(m_ctx, "RSA");
		if (ret != 1)
		{
			cout<<"SSL_CTX_set_cipher_list failed"<<endl;
			return false;
		}

		ret = SSL_CTX_use_certificate_chain_file(m_ctx, "../bin/chain/server_ca1.crt");
		if (ret != 1)
		{
			cout<<"SSL_CTX_use_certificate_chain_file failed, errstr = "<<evpl::openssl::sslerr::get_errstr()<<endl;
			return false;
		}

		ret = SSL_CTX_use_PrivateKey_file(m_ctx, "../bin/chain/server.key", SSL_FILETYPE_PEM);
		if (ret != 1)
		{
			cout<<"SSL_CTX_use_PrivateKey_file failed, errstr = "<<evpl::openssl::sslerr::get_errstr()<<endl;
			return false;
		}

		ret = SSL_CTX_check_private_key(m_ctx);
		if (ret != 1)
		{
			cout<<"SSL_CTX_check_private_key failed, errstr = "<<evpl::openssl::sslerr::get_errstr()<<endl;
			return false;
		}

		return true;
	}

	SSL * new_ssl() const
	{
		return SSL_new(m_ctx);
	}

private:
	SSL_CTX  *m_ctx;
};


#endif


