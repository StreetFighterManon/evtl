

#ifndef __HTTPSSERVICE_ASM_H__
#define __HTTPSSERVICE_ASM_H__

#include <vector>

#include <evtl/evtl_acceptor.h>
#include <evtl/evtl_in.h>

#include "httpsdriver.h"



class httpsservice_asm
{
public:
	httpsservice_asm()
	{}

	void init()
	{
		for (int i = 0; i < 2; i++)
		{
			httpsdriver *p = new httpsdriver;
			p->init();
			m_drivers.push_back(p);
		}
	}

	void run_bg()
	{
		for (std::vector<httpsdriver*>::const_iterator iter = m_drivers.begin(); iter != m_drivers.end(); ++iter)
		{
			httpsdriver *drv = *iter;
			drv->run_bg();
		}
	}

	void accept_callback(evtl::simpacceptor &acpt, std::vector<evtl::connection> &conns)
	{
		httpsdriver *drv = nullptr;
		ssize_t sesscount = -1;

		for (std::vector<httpsdriver*>::const_iterator iter = m_drivers.begin(); iter != m_drivers.end(); ++iter)
		{
			httpsdriver *p = *iter;
			ssize_t size = p->get_session_count();
			if (size < 0)
				assert(false);
			if (sesscount < 0 || size < sesscount)
			{
				drv = p;
				sesscount = size;
			}
		}

		if (drv == nullptr)
			assert(false);

		drv->async_receive_connections(conns);
	}

private:
	std::vector<httpsdriver*>  m_drivers;
};


#endif


