

#include <iostream>
using namespace std;

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_signal.h>
#include <evtl/evtl_random.h>
#include <evtl/evtl_daemon.h>
#include <evtl/evtl_eio.h>

#include "https.h"


int main()
{
	//evtl::daemonize::daemon();

	evtl::default_loop::preinit();
	evtl::signalc::sig_ignore(SIGPIPE);

	evtl::timec::background_update(100);
	evtl::rand::urandom::init();
	evtl::geio::init();
	evtl::geio::make_pollthread();

	OPENSSL_init_ssl(0, nullptr);

	https service;
	service.init();
	service.run();

	assert(false);
	return 0;
}


