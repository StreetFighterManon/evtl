

#ifndef __HTTPSACCEPTOR_H__
#define __HTTPSACCEPTOR_H__

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_acceptor.h>


class acceptor
{
public:
	acceptor()
	{}

	void set_callback(evtl::simpacceptor::accept_callback_t cb)
	{
		m_acceptor.set_callback(cb);
	}

	void init()
	{
		m_listener.set_address(evtl::makeipaddr("0.0.0.0", 4433));
		m_listener.tcplisten(32);

		m_acceptor.set_loop(m_loop.ref());
		m_acceptor.set_listener(&m_listener);
		m_acceptor.watch();
	}

	void run()
	{
		m_loop.run_loop(evtl::simpeventloop<evtl::default_loop>::current_thread);
	}

private:
	evtl::simpeventloop<evtl::default_loop>  m_loop;

	evtl::listener   m_listener;
	evtl::simpacceptor  m_acceptor;
};


#endif


