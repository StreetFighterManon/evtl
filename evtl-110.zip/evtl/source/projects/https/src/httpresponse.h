

#ifndef __HTTPRESPONSE_H__
#define __HTTPRESPONSE_H__

#include <string>
#include <sstream>

#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_wrapper.h>

#include "sessionbase.h"


class httpresponse
{
public:
	httpresponse()
	{
		m_sessbase = nullptr;
		m_code = 0;
		m_rangestart = 0;
		m_rangeend = 0;
		m_rangetotal = 0;
		m_step = evtl::com::nextstep_unknown;
	}

	bool is_set() const
	{
		if (m_sessbase == nullptr)
			return false;
		return true;
	}

	void set_sessbase(sessionbase *base)
	{
		m_sessbase = base;
	}

	void set_code(int code)
	{
		m_code = code;
	}

	void set_range(int64_t start, int64_t end, int64_t total)
	{
		m_rangestart = start;
		m_rangeend = end;
		m_rangetotal = total;
	}

	void sendresponse()
	{
		m_step = evtl::com::nextstep_unknown;
		if (!m_respbuf.isset())
		{
			std::stringstream ss;
			if (m_code == 200 || m_code == 206)
			{
				ss << "HTTP/1.1 " << m_code << " " << get_desc(m_code) << "\r\n"
					<< "Server: https\r\n"
					<< "Content-Type: application/octet-stream\r\n"
					<< "Content-Range: bytes " << m_rangestart << "-" << m_rangeend << "/" << m_rangetotal << "\r\n"
					<< "Content-Length: " << m_rangeend - m_rangestart + 1 << "\r\n"
					<< "Connection: keep-alive\r\n"
					<< "\r\n";
			}
			else if (m_code == 404)
			{
				ss << "HTTP/1.1 " << m_code << " " << get_desc(m_code) << "\r\n"
					<< "Server: https\r\n"
					<< "Content-Length: 0\r\n"
					<< "Connection: keep-alive\r\n"
					<< "\r\n";
			}
			else
			{
				assert(false);
			}

			evtl::linearbuf<char> &buf = m_respbuf.refer();
			buf.extens_store_whole(ss.str());
			m_respbuf.set();
		}

		evtl::linearbuf<char> &buf = m_respbuf.refer();
		ssize_t size = buf.size();
		if (size > 0)
		{
			int rt = m_sessbase->m_ioif->ssl_write(buf.dataptr(), size);
			if (rt > 0)
			{
				if (rt > size)
					assert(false);
				if (!buf.shit_whole(rt))
					assert(false);

				m_step = evtl::com::nextstep_wait_to_send;
			}
			else
			{
				const evpl::openssl::ioresult &result = m_sessbase->m_sslm.get_result();
				switch (result.resultcode)
				{
				case SSL_ERROR_NONE:
					assert(false);
					break;
				case SSL_ERROR_WANT_READ:
					m_step = evtl::com::nextstep_wait_to_receive;
					break;
				case SSL_ERROR_WANT_WRITE:
					m_step = evtl::com::nextstep_wait_to_send;
					break;
				default:
					m_step = evtl::com::nextstep_error_end;
					break;
				}
			}
		}
	}

	bool response_finished() const
	{
		if (m_respbuf.isset() && m_respbuf.refer().empty())
			return true;
		return false;
	}

	evtl::com::process_nextstep get_step() const
	{
		return m_step;
	}

	void reset()
	{
		m_sessbase = nullptr;
		m_code = 0;
		m_rangestart = 0;
		m_rangeend = 0;
		m_rangetotal = 0;

		m_respbuf.reset();
		m_step = evtl::com::nextstep_unknown;
	}

private:
	static std::string get_desc(int code)
	{
		switch (code)
		{
		case 200:
			return "OK";
		case 206:
			return "Partial";
		case 404:
			return "Not Found";
		default:
			break;
		}
		return "Unknown";
	}

private:
	sessionbase  *m_sessbase;
	int      m_code;
	int64_t  m_rangestart;
	int64_t  m_rangeend;
	int64_t  m_rangetotal;
	evtl::dn_var<evtl::linearbuf<char>>  m_respbuf;

	evtl::com::process_nextstep  m_step;
};


#endif



