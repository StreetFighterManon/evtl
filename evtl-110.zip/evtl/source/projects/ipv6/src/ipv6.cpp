

#include <evtl/evtl_inet.h>
#include <evtl/evtl_connector.h>
#include <evtl/evtl_watcher_io.h>


int main()
{
	int fd = socket(AF_INET, SOCK_DGRAM | SOCK_NONBLOCK, 0);
	int fd2 = socket(AF_INET, SOCK_DGRAM | SOCK_NONBLOCK, 0);

	std::pair<bool, sockaddr_storage> addr = evtl::inetc::inaddr_pton(evtl::makeipaddr("224.2.3.4", 1234));
	int rt = ::bind(fd, (const sockaddr *)&addr.second, sizeof(sockaddr_storage));
	int rt2 = ::bind(fd2, (const sockaddr *)&addr.second, sizeof(sockaddr_storage));

	return 0;
}


