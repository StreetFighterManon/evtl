

#include <iostream>
using namespace std;

#include <string>
#include <sstream>

#include <evtl/evtl_eventloop.h>
#include <evpl/logger/logclient.h>


class logclientdrv
{
public:
	logclientdrv()
	{}

	void init()
	{
		m_client.set_loop(m_loop.ref());
		m_client.logstart("127.0.0.1", 2333);

		m_loop.run_loop(evtl::simpeventloop<evtl::dynamic_loop>::background_thread);
	}

	evpl::logger::logclient& get_client()
	{
		return m_client;
	}

private:
	evtl::simpeventloop<evtl::dynamic_loop>  m_loop;
	evpl::logger::logclient  m_client;
};

logclientdrv *logcli;

#define logout(a) \
	do \
	{ \
		std::stringstream ss; \
		ss << a; \
		evpl::logger::logtypeinfo type; \
		type.id = 91; \
		logcli->get_client().pushlog(type, ss.str()); \
	} \
	while (0)


void *xxx(void *)
{
	unsigned int a = 0;
	while (true)
	{
		logout("this is a sample, klansdlvna  lamkvlkmadlsvmla adksmvlamsdvlkads   sdlvkmaldvmkslmadsvl ladmksvlmkadsv, logoutput: " << a++);
		//usleep(1000);
	}
}

void *sss(void *)
{
	unsigned int a = 0;
	while (true)
	{
		logout("iioopp, klansdlvna  lamkvlkmadlsvmla adksmvlamsdvlkads   sdlvkmaldvmkslmadsvl ladmksvlmkadsv, logoutput: " << a++);
		//usleep(1000);
	}
}


int main(int argc,char *argv[])
{
	logcli = new logclientdrv;
	logcli->init();

	evtl::thread::make_detached(xxx);
	evtl::thread::make_detached(sss);

	while (true)
		sleep(1);
	return 0;
}


