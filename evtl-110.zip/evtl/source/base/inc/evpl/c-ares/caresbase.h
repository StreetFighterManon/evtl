

#ifndef __EVPL_C_ARES_CARESBASE_H__
#define __EVPL_C_ARES_CARESBASE_H__

#include <stdlib.h>
#include <assert.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <arpa/nameser.h>
#include <netdb.h>

#include <string>
#include <cstring>
#include <vector>
#include <utility>

#include <c-ares/ares.h>
#include <c-ares/ares_dns.h>

#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_inet.h>


namespace evpl { namespace cares {


enum resolve_except
{
	except_none,
	except_null_timeout
};

struct optionset
{
	optionset(): sendbuf_size(0), recvbuf_size(0), ednspsz(0)
	{}

	void reset()
	{
		flags.reset();
		timeout_ms.reset();
		tries.reset();
		ndots.reset();
		sendbuf_size = 0;
		recvbuf_size = 0;
		domains.reset();
		lookups.clear();
		resolvconf_path.clear();
		ednspsz = 0;
	}

	void build_option(ares_options &option, int *optmask) const
	{
		if (optmask == nullptr)
			assert(false && "null param");

		memset(&option, 0, sizeof(option));
		*optmask = 0;

		if (flags.isset())
		{
			option.flags = flags.refer();
			*optmask |= ARES_OPT_FLAGS;
		}

		if (timeout_ms.isset())
		{
			option.timeout = timeout_ms.refer();
			*optmask |= ARES_OPT_TIMEOUTMS;
		}

		if (tries.isset())
		{
			option.tries = tries.refer();
			*optmask |= ARES_OPT_TRIES;
		}

		if (ndots.isset())
		{
			option.ndots = ndots.refer();
			*optmask |= ARES_OPT_NDOTS;
		}

		if (sendbuf_size > 0)
		{
			option.socket_send_buffer_size = sendbuf_size;
			*optmask |= ARES_OPT_SOCK_SNDBUF;
		}

		if (recvbuf_size > 0)
		{
			option.socket_receive_buffer_size = recvbuf_size;
			*optmask |= ARES_OPT_SOCK_RCVBUF;
		}

		if (domains.isset())
		{
			const std::vector<std::string> &doms = domains.refer();
			if (doms.empty())
			{
				option.domains = nullptr;
				option.ndomains = 0;
			}
			else
			{
				option.domains = new char*[doms.size() + 1];
				if (option.domains == nullptr)
					assert(false && "malloc failed");
				for (size_t i = 0; i < doms.size(); i++)
				{
					option.domains[i] = ::strdup(doms[i].c_str());
					if (option.domains[i] == nullptr)
						assert(false && "strdup failed");
				}
				option.domains[doms.size()] = nullptr;
				option.ndomains = doms.size();
			}

			*optmask |= ARES_OPT_DOMAINS;
		}
		else
		{
			option.domains = nullptr;
			option.ndomains = 0;
		}

		if (!lookups.empty())
		{
			option.lookups = ::strdup(lookups.c_str());
			if (option.lookups == nullptr)
				assert(false && "strdup failed");

			*optmask |= ARES_OPT_LOOKUPS;
		}
		else
		{
			option.lookups = nullptr;
		}

		if (!resolvconf_path.empty())
		{
			option.resolvconf_path = ::strdup(resolvconf_path.c_str());
			if (option.resolvconf_path == nullptr)
				assert(false && "strdup failed");

			*optmask |= ARES_OPT_RESOLVCONF;
		}
		else
		{
			option.resolvconf_path = nullptr;
		}

		if (ednspsz > 0)
		{
			option.ednspsz = ednspsz;
			*optmask |= ARES_OPT_EDNSPSZ;
		}
	}

	static void free_option(ares_options &option)
	{
		if (option.lookups != nullptr)
			::free(option.lookups);
		option.lookups = nullptr;

		if (option.resolvconf_path != nullptr)
			::free(option.resolvconf_path);
		option.resolvconf_path = nullptr;

		if (option.domains != nullptr)
		{
			for (char **p = option.domains; *p != nullptr; ++p)
				::free(*p);
			delete []option.domains;
			option.domains = nullptr;
		}
	}

	evtl::var<int>  flags;
	evtl::var<int>  timeout_ms;
	evtl::var<int>  tries;
	evtl::var<int>  ndots;
	int             sendbuf_size;
	int             recvbuf_size;
	evtl::var<std::vector<std::string>>  domains;
	std::string     lookups;
	std::string     resolvconf_path;
	int             ednspsz;
};

struct nameserver
{
	nameserver(): family(0), addr4(), addr6(), udp_port(0), tcp_port(0)
	{}

	int family;
	struct in_addr  addr4;
	struct in6_addr addr6;
	int udp_port;
	int tcp_port;
};

struct hostentc
{
	hostentc(): addrtype(0)
	{}

	void set(const struct hostent &host)
	{
		host_name = host.h_name;

		for (const char * const *p = host.h_aliases; *p != nullptr; ++p)
		{
			if (*p != nullptr)
				host_aliases.push_back(std::string(*p));
		}

		addrtype = host.h_addrtype;

		for (const char * const *p = host.h_addr_list; *p != nullptr; ++p)
		{
			if (*p != nullptr)
			{
				if (addrtype == AF_INET && host.h_length == 4)
				{
					struct in_addr addr4 = *(struct in_addr *)*p;
					std::string addr4str = evtl::inetc::inet_ntop4(addr4);
					if (!addr4str.empty())
						host_addrs.push_back(addr4str);
				}
				else if (addrtype == AF_INET6 && host.h_length == 16)
				{
					struct in6_addr addr6 = *(struct in6_addr *)*p;
					std::string addr6str = evtl::inetc::inet_ntop6(addr6);
					if (!addr6str.empty())
						host_addrs.push_back(addr6str);
				}
			}
		}
	}

	void reset()
	{
		host_name.clear();
		host_aliases.clear();
		addrtype = 0;
		host_addrs.clear();
	}

	std::string               host_name;
	std::vector<std::string>  host_aliases;
	int                       addrtype;
	std::vector<std::string>  host_addrs;
};

struct hostent_result
{
	hostent_result(): status(-1), timeout_times(0)
	{}

	void reset()
	{
		status = -1;
		status_str.clear();
		timeout_times = 0;
		hostinfo.reset();
	}

	const std::vector<std::string>& get_hostaddrs() const
	{
		return hostinfo.host_addrs;
	}

	int          status;
	std::string  status_str;
	int          timeout_times;
	hostentc     hostinfo;
};


struct question
{
	question(): type(0), dnsclass(0)
	{}

	std::string name;
	int         type;
	int         dnsclass;
};

struct answer_type_cname
{
	answer_type_cname(): dnsclass(0), ttl(0)
	{}

	std::string name;
	int         dnsclass;
	int         ttl;
	std::string cname;
};

struct answer_type_a
{
	answer_type_a(): dnsclass(0), ttl(0)
	{}

	std::string name;
	int         dnsclass;
	int         ttl;
	std::string address;
};

struct answer_type_aaaa
{
	answer_type_aaaa(): dnsclass(0), ttl(0)
	{}

	std::string name;
	int         dnsclass;
	int         ttl;
	std::string address;
};

struct answer_type_ptr
{
	answer_type_ptr(): dnsclass(0), ttl(0)
	{}

	std::string name;
	int         dnsclass;
	int         ttl;
	std::string domain_name;
};

struct dighost
{
	dighost()
		: id(0), qr(0), opcode(0), aa(0), tc(0), rd(0), ra(0), rcode(0),
		  qdcount(0), ancount(0), nscount(0), arcount(0)
	{}

	void reset()
	{
		id = 0;
		qr = 0;
		opcode = 0;
		aa = 0;
		tc = 0;
		rd = 0;
		ra = 0;
		rcode = 0;

		qdcount = 0;
		ancount = 0;
		nscount = 0;
		arcount = 0;

		questions.clear();
		answers_cname.clear();
		answers_a.clear();
		answers_aaaa.clear();
		answers_ptr.clear();
	}

	int id;      //transaction id
	int qr;      //0: query  1: response
	int opcode;  //Opcode 0: standard query  1: inverse query  2: server status query
	int aa;      //authoritative answer
	int tc;      //truncated
	int rd;      //recursion desired
	int ra;      //recursion available
	int rcode;   //reply code

	int qdcount; //questions
	int ancount; //answer resources
	int nscount; //authority resources
	int arcount; //additional resources

	std::vector<question>  questions;

	std::vector<answer_type_cname>  answers_cname;
	std::vector<answer_type_a>      answers_a;
	std::vector<answer_type_aaaa>   answers_aaaa;
	std::vector<answer_type_ptr>    answers_ptr;
};


struct dighost_result
{
	dighost_result(): status(-1), timeout_times(0)
	{}

	void reset()
	{
		status = -1;
		status_str.clear();
		timeout_times = 0;
		hostinfo.reset();
	}

	const dighost& get_dighost() const
	{
		return hostinfo;
	}

	int          status;
	std::string  status_str;
	int          timeout_times;
	dighost      hostinfo;
};


class dighost_parser
{
public:
	dighost_parser(dighost &hostinfo, const unsigned char *abuf, int alen)
		: m_hostinfo(hostinfo), m_buf(abuf), m_len(alen)
	{}

	void parse()
	{
		m_hostinfo.reset();

		if (m_buf == nullptr || m_len <= 0)
			return;

		/* Won't happen, but check anyway, for safety. */
		if (m_len < HFIXEDSZ)
		  return;

		/* Parse the answer header. */
		m_hostinfo.id = DNS_HEADER_QID(m_buf);
		m_hostinfo.qr = DNS_HEADER_QR(m_buf);
		m_hostinfo.opcode = DNS_HEADER_OPCODE(m_buf);
		m_hostinfo.aa = DNS_HEADER_AA(m_buf);
		m_hostinfo.tc = DNS_HEADER_TC(m_buf);
		m_hostinfo.rd = DNS_HEADER_RD(m_buf);
		m_hostinfo.ra = DNS_HEADER_RA(m_buf);
		m_hostinfo.rcode = DNS_HEADER_RCODE(m_buf);

		m_hostinfo.qdcount = DNS_HEADER_QDCOUNT(m_buf);
		m_hostinfo.ancount = DNS_HEADER_ANCOUNT(m_buf);
		m_hostinfo.nscount = DNS_HEADER_NSCOUNT(m_buf);
		m_hostinfo.arcount = DNS_HEADER_ARCOUNT(m_buf);

		const unsigned char *aptr = m_buf + HFIXEDSZ;

		if (m_hostinfo.qdcount < 0)
			return;

		/* Parse the questions. */
		for (int i = 0; i < m_hostinfo.qdcount; i++)
		{
			aptr = parse_question(aptr, m_buf, m_len);
			if (aptr == nullptr)
			  return;
		}

		if (m_hostinfo.ancount < 0)
			return;

		/* Parse the answers. */
		for (int i = 0; i < m_hostinfo.ancount; i++)
		{
			aptr = parse_answer_rr(aptr, m_buf, m_len);
			if (aptr == nullptr)
				return;
		}
	}

	const unsigned char * parse_question(const unsigned char *aptr, const unsigned char *abuf, int alen)
	{
		char *name = nullptr;
		long len = 0;

		/* Parse the question name. */
		int status = ::ares_expand_name(aptr, abuf, alen, &name, &len);
		if (status != ARES_SUCCESS)
			return nullptr;
		aptr += len;

		/* Make sure there's enough data after the name for the fixed part
		 * of the question.
		 */
		if (aptr + QFIXEDSZ > abuf + alen)
		{
			::ares_free_string(name);
			return nullptr;
		}

		/* Parse the question type and class. */
		int type = DNS_QUESTION_TYPE(aptr);
		int dnsclass = DNS_QUESTION_CLASS(aptr);
		aptr += QFIXEDSZ;

		question qst;
		qst.name = name;
		qst.type = type;
		qst.dnsclass = dnsclass;
		m_hostinfo.questions.push_back(std::move(qst));

		::ares_free_string(name);
		return aptr;
	}

	const unsigned char * parse_answer_rr(const unsigned char *aptr, const unsigned char *abuf, int alen)
	{
		char *name = nullptr;
		long len = 0;

		/* Parse the RR name. */
		int status = ::ares_expand_name(aptr, abuf, alen, &name, &len);
		if (status != ARES_SUCCESS)
			return nullptr;
		aptr += len;

		/* Make sure there is enough data after the RR name for the fixed
		 * part of the RR.
		 */
		if (aptr + RRFIXEDSZ > abuf + alen)
		{
			::ares_free_string(name);
			return nullptr;
		}

		/* Parse the fixed part of the RR, and advance to the RR data
		 * field.
		 */
		int type = DNS_RR_TYPE(aptr);
		int dnsclass = DNS_RR_CLASS(aptr);
		int ttl = DNS_RR_TTL(aptr);
		int dlen = DNS_RR_LEN(aptr);
		aptr += RRFIXEDSZ;
		if (aptr + dlen > abuf + alen)
		{
			::ares_free_string(name);
			return nullptr;
		}

		std::string namestr = name;
		::ares_free_string(name);
		name = nullptr;

		if (type == T_CNAME)
		{
			char *cname = nullptr;
			long enclen = 0;
			/* For these types, the RR data is just a domain name. */
			status = ::ares_expand_name(aptr, abuf, alen, &cname, &enclen);
			if (status != ARES_SUCCESS)
			  return nullptr;

			answer_type_cname answer;
			answer.name = std::move(namestr);
			answer.dnsclass = dnsclass;
			answer.ttl = ttl;
			answer.cname = cname;
			m_hostinfo.answers_cname.push_back(std::move(answer));

			::ares_free_string(cname);
		}
		else if (type == T_A)
		{
			/* The RR data is a four-byte Internet address. */
			if (dlen != 4)
				return nullptr;

			answer_type_a answer;
			answer.name = std::move(namestr);
			answer.dnsclass = dnsclass;
			answer.ttl = ttl;
			answer.address = evtl::inetc::inet_ntop4(*(const struct in_addr *)aptr);
			m_hostinfo.answers_a.push_back(std::move(answer));
		}
		else if (type == T_AAAA)
		{
			/* The RR data is a 16-byte IPv6 address. */
			if (dlen != 16)
				return nullptr;

			answer_type_aaaa answer;
			answer.name = std::move(namestr);
			answer.dnsclass = dnsclass;
			answer.ttl = ttl;
			answer.address = evtl::inetc::inet_ntop6(*(const struct in6_addr *)aptr);
			m_hostinfo.answers_aaaa.push_back(std::move(answer));
		}
		else if (type == T_PTR)
		{
			char *domain_name = nullptr;
			long enclen = 0;
			/* For these types, the RR data is just a domain name. */
			status = ::ares_expand_name(aptr, abuf, alen, &domain_name, &enclen);
			if (status != ARES_SUCCESS)
			  return nullptr;

			answer_type_ptr answer;
			answer.name = std::move(namestr);
			answer.dnsclass = dnsclass;
			answer.ttl = ttl;
			answer.domain_name = domain_name;
			m_hostinfo.answers_ptr.push_back(std::move(answer));

			::ares_free_string(domain_name);
		}

		return aptr + dlen;
	}

private:
	dighost&             m_hostinfo;
	const unsigned char *m_buf;
	int                  m_len;
};


} }


#endif


