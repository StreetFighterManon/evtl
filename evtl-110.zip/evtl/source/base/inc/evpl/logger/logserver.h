

#ifndef __EVPL_LOGGER_LOGSERVER_H__
#define __EVPL_LOGGER_LOGSERVER_H__

#include <sys/types.h>
#include <unistd.h>

#include <string>
#include <set>
#include <functional>
#include <utility>

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_in.h>
#include <evtl/evtl_listener.h>
#include <evtl/evtl_acceptor.h>
#include <evtl/evtl_thread.h>
#include <evtl/evtl_boundedbuf.h>
#include <evtl/evtl_watcher_timer.h>
#include <evtl/evtl_error.h>

#include "loginfo.h"
#include "logsession.h"


namespace evpl { namespace logger {


class logserver : public evtl::evtl_error
{
public:
	enum errorcode
	{
		success,
		invalid_address,
		listen_failed,
		accept_failed,
		makethread_failed
	};

	typedef  std::function<void (logtypeinfo &typeinfo, const char *logstr, ssize_t len)>  log_callback_t;

	logserver(): m_logbuf(50000)
	{
		ssize_t size = m_logbuf.size();
		for (ssize_t i = 0; i < size; i++)
		{
			logitem &item = m_logbuf[i].elem();
			item.m_log.reset_capacity(2*1024);
		}
	}

	void set_loop(evtl::looprefer loop)
	{
		m_loop = loop;
	}

	void set_logcallback(log_callback_t cb)
	{
		m_logcb = std::move(cb);
	}

	bool set_address(const evtl::address &addr)
	{
		bool br = m_listener.set_address(addr);
		if (!br)
		{
			set_error(invalid_address, m_listener.get_error_combine());
			return false;
		}
		return true;
	}

	bool start()
	{
		bool br = m_listener.tcplisten(128);
		if (!br)
		{
			set_error(listen_failed, m_listener.get_error_combine());
			return false;
		}

		m_acceptor.set_loop(m_loop);
		m_acceptor.set_listener(&m_listener);
		m_acceptor.set_callback(std::bind(&logserver::accept_callback, this, std::placeholders::_1, std::placeholders::_2));
		br = m_acceptor.watch();
		if (!br)
		{
			set_error(accept_failed, m_listener.get_error_combine());
			return false;
		}

		m_timer.set(m_loop.ref(), 0, 60.);
		m_timer.set_callback(std::bind(&logserver::timer_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_timer.again();

		m_thread.set_callback<logserver, &logserver::writelogproc>(this);
		br = m_thread.make_thread(nullptr, "writelog", 2*1024*1024);
		if (!br)
		{
			set_error(makethread_failed);
			return false;
		}
		return true;
	}

private:
	void accept_callback(evtl::simpacceptor &acpt, std::vector<evtl::connection> &connections)
	{
		if (&acpt != &m_acceptor)
			assert(false && "unexpected acceptor");

		for (std::vector<evtl::connection>::const_iterator iter = connections.begin(); iter != connections.end(); ++iter)
		{
			const evtl::connection &conn = *iter;

			logsession *psess = new logsession;
			assert(psess != nullptr);

			psess->set_logbuf(&m_logbuf);
			psess->set_recycle_callback(std::bind(&logserver::session_recycle, this, std::placeholders::_1));
			psess->init();
			psess->set(m_loop);
			psess->set_callback();
			psess->set(conn.fd, ev::READ);
			psess->start();

			std::pair<std::set<logsession*>::const_iterator, bool> rt = m_sessions.insert(psess);
			if (!rt.second)
				assert(false && "insert failed");
		}
	}

	void timer_callback(evtl::simpwtimer &watcher, int revents)
	{
		if (&watcher != &m_timer)
			assert(false && "unexpected timer");

		for (std::set<logsession*>::const_iterator iter = m_sessions.begin(); iter != m_sessions.end(); )
		{
			logsession *sess = *iter;
			if (sess->need_recycle())
			{
				m_sessions.erase(iter++);
				sess->deinit();
				delete sess;
			}
			else
			{
				++iter;
			}
		}

		watcher.set_repeat(60. + m_loop.now_difference());
		watcher.again();
	}

	void session_recycle(logsession *psess)
	{
		if (psess == nullptr)
			assert(false);

		size_t n = m_sessions.erase(psess);
		if (n <= 0)
			assert(false);

		psess->deinit();
		delete psess;
	}

	void * writelogproc(void *)
	{
		while (true)
		{
			logitem *item = m_logbuf.get_consume();
			if (item == nullptr)
			{
				::usleep(1000);
				continue;
			}

			m_logcb(item->m_info, item->m_log.dataptr(), item->m_log.size());

			item->m_info.reset();
			if (item->m_log.capacity() > 2*1024)
				item->m_log.reset_capacity(2*1024);
			item->m_log.clear();

			m_logbuf.consume_complete(item);
		}

		return nullptr;
	}

private:
	evtl::looprefer  m_loop;

	evtl::listener      m_listener;
	evtl::simpacceptor  m_acceptor;

	std::set<logsession*>  m_sessions;
	evtl::simpwtimer  m_timer;

	evtl::boundedbuf<logitem>    m_logbuf;
	evtl::thread::methodthreadc  m_thread;
	log_callback_t   m_logcb;
};


} }


#endif


