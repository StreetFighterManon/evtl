

#ifndef __EVPL_LOGGER_LOGINFO_H__
#define __EVPL_LOGGER_LOGINFO_H__

#include <cstdint>


namespace evpl { namespace logger {


struct logtypeinfo
{
	logtypeinfo(): id(0)
	{}

	void reset()
	{
		id = 0;
	}

	uint64_t id;
};


} }


#endif


