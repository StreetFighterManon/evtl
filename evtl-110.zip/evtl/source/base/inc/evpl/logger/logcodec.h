

#ifndef __EVPL_LOGGER_LOGCODEC_H__
#define __EVPL_LOGGER_LOGCODEC_H__

#include <sys/types.h>
#include <assert.h>

#include <cstdlib>
#include <cstdint>
#include <string>
#include <sstream>

#include "loginfo.h"


namespace evpl { namespace logger {


class loginfodecoder
{
public:
	loginfodecoder(): m_str(nullptr), m_len(0)
	{}

	void setlog(const char *str, ssize_t len)
	{
		m_str = str;
		m_len = len;
	}

	bool decode()
	{
		// <(88172)>.*
		if (m_str == nullptr || m_len < 5)
			return false;

		if (m_str[0] != '<' || m_str[1] != '(')
			return false;

		ssize_t digitend = 2;
		for (; digitend < m_len && digitend < 2 + 20 /* strlen("18446744073709551615") */; digitend++)
		{
			if (m_str[digitend] < '0' || m_str[digitend] > '9')
				break;
		}

		if (digitend <= 2 || digitend > m_len - 2)
			return false;
		if (m_str[digitend] != ')' || m_str[digitend + 1] != '>')
			return false;

		uint64_t val = _strtou64(m_str + 2, m_str + digitend);
		m_info.id = val;

		m_logstartpos = digitend + 2;
		return true;
	}

	ssize_t get_logstartpos() const
	{
		return m_logstartpos;
	}

	logtypeinfo get_loginfo() const
	{
		return m_info;
	}

private:
	static uint64_t _strtou64(const char *str, const char *end)
	{
		if (str >= end)
			assert(false);

		uint64_t val = 0;
		while (str < end)
		{
			unsigned char c = *str;
			if (c >= '0' && c <= '9')
			{
				val *= 10;
				val += c - '0';
			}
			else
			{
				assert(false);
			}

			++str;
		}

		return val;
	}

private:
	const char  *m_str;
	ssize_t      m_len;

	logtypeinfo  m_info;
	ssize_t      m_logstartpos;
};


class loginfoencoder
{
public:
	loginfoencoder() = default;

	std::string encode(const logtypeinfo &logtype, const std::string &log)
	{
		std::stringstream ss;
		if (log.size() <= 512*1024)
			ss << "<(" << logtype.id << ")>" << log << "\r\n";
		else
		{
			std::string logcut = log.substr(0, 512*1024);
			ss << "<(" << logtype.id << ")>" << logcut << "\r\n";
		}
		return ss.str();
	}
};


} }


#endif


