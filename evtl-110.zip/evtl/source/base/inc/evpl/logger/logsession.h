

#ifndef __EVPL_LOGGER_LOGSESSION_H__
#define __EVPL_LOGGER_LOGSESSION_H__

#include <sys/types.h>
#include <assert.h>
#include <errno.h>

#include <functional>
#include <utility>

#include <evtl/evtl_watcher_io.h>
#include <evtl/evtl_boundedbuf.h>
#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_com.h>
#include <evtl/evtl_time.h>

#include "loginfo.h"
#include "logcodec.h"


namespace evpl { namespace logger {


struct logitem
{
	logitem() = default;

	logtypeinfo  m_info;
	evtl::linearbuf<char>  m_log;
};

class logsession : public evtl::watcher_io<logsession>
{
public:
	logsession(): m_last_active_time_s(0),
		m_recvbuf(1024*1024*10),
		m_nextstep(evtl::com::nextstep_unknown),
		m_logbuf(nullptr)
	{}

	typedef std::function<void (logsession *psess)>  recycle_callback_t;

	void set_logbuf(evtl::boundedbuf<logitem> *logbuf)
	{
		m_logbuf = logbuf;
	}

	void set_recycle_callback(recycle_callback_t cb)
	{
		m_recycle_cb = std::move(cb);
	}

	void init()
	{
		_update_active_time();
	}

	void io_callback(logsession &watcher, int revents)
	{
		if (&watcher != this)
			assert(false && "unknown watcher");

		_update_active_time();
		process();

		evtl::com::process_nextstep step = get_nextstep();
		switch (step)
		{
		case evtl::com::nextstep_wait_to_receive:
			{
				if (m_iostatus.error_raised())
				{
					hanrest_logitem();
					stop();
					m_recycle_cb(this);
					return;
				}

				if (get_events() != ev::READ)
				{
					stop();
					set_events(ev::READ);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
				return;
			}
			break;
		case evtl::com::nextstep_continue:
			{
				if ((get_events() & ev::WRITE) == 0)
				{
					stop();
					set_events(ev::WRITE);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
				return;
			}
			break;
		default:
			assert(false && "unknown step");
			break;
		}
	}

	bool need_recycle()
	{
		int64_t now_s = evtl::timec::fast_sec();
		if (now_s - m_last_active_time_s > 3600*12)
			return true;
		else if (now_s < m_last_active_time_s)
			m_last_active_time_s = now_s;

		return false;
	}

	void deinit()
	{
		stop_close();
		m_nextstep = evtl::com::nextstep_unknown;
	}

private:
	void process()
	{
		set_nextstep(evtl::com::nextstep_unknown);
		search_logitem();

		if (m_recvbuf.size() >= 512*1024)
			assert(false);
		m_recvbuf.crowdct(512*1024, 512*1024);

		ssize_t headspace = m_recvbuf.headspace();
		if (headspace<= 0)
			assert(false);

		ssize_t rt = this->read(m_recvbuf.headptr(), headspace);
		if (rt > 0)
		{
			if (rt > headspace)
				assert(false);
			if (!m_recvbuf.head_eaten_whole(rt))
				assert(false);

			set_nextstep(evtl::com::nextstep_continue);
		}
		else
		{
			if (rt < 0)
			{
				if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
					m_iostatus.orset(evtl::com::rwresult_read_error, errno);
			}
			else
			{
				m_iostatus.orset(evtl::com::rwresult_read_end, 0);
			}

			set_nextstep(evtl::com::nextstep_wait_to_receive);
		}
	}

	void _update_active_time()
	{
		m_last_active_time_s = evtl::timec::fast_sec();
	}

	void search_logitem()
	{
		while (true)
		{
			ssize_t size = m_recvbuf.size();

			ssize_t pos = m_recvbuf.find('\n', 0, 512*1024);
			if (pos < 0)
			{
				if (size < 512*1024)
					return;
				else
				{
					_output(m_recvbuf.dataptr(), 512*1024);
					if (!m_recvbuf.shit_whole(512*1024))
						assert(false);
				}
			}
			else
			{
				if (pos == 0)
					_output(m_recvbuf.dataptr(), 0);
				else
				{
					if (m_recvbuf[pos - 1] == '\r')
						_output(m_recvbuf.dataptr(), pos - 1);
					else
						_output(m_recvbuf.dataptr(), pos);
				}

				if (!m_recvbuf.shit_whole(pos + 1))
					assert(false);
			}
		}
	}

	void hanrest_logitem()
	{
		ssize_t size = m_recvbuf.size();
		if (size > 0)
			_output(m_recvbuf.dataptr(), size);
		m_recvbuf.clear();
	}

	void set_nextstep(evtl::com::process_nextstep step)
	{
		m_nextstep = step;
	}

	evtl::com::process_nextstep get_nextstep() const
	{
		return m_nextstep;
	}

	void _output(const char *logstr, ssize_t len)
	{
		if (logstr == nullptr || len < 0)
			assert(false);

		logitem *item = m_logbuf->get_produce();
		if (item == nullptr)
			return;

		loginfodecoder decoder;
		decoder.setlog(logstr, len);
		if (decoder.decode())
		{
			ssize_t startpos = decoder.get_logstartpos();
			if (startpos < 0 || startpos > len)
				assert(false);

			item->m_info = decoder.get_loginfo();
			item->m_log.extens_store_whole(logstr + startpos, len - startpos);
		}
		else
		{
			item->m_info.reset();
			item->m_log.extens_store_whole(logstr, len);
		}

		m_logbuf->produce_complete(item);
	}

private:
	recycle_callback_t  m_recycle_cb;

	int64_t  m_last_active_time_s;
	evtl::linearbuf<char>  m_recvbuf;
	evtl::com::process_nextstep  m_nextstep;
	evtl::com::rwstatus  m_iostatus;
	evtl::boundedbuf<logitem>  *m_logbuf;
};


} }


#endif


