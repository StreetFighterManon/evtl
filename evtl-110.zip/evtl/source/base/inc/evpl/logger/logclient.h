

#ifndef __EVPL_LOGGER_LOGCLIENT_H__
#define __EVPL_LOGGER_LOGCLIENT_H__

#include <sys/types.h>
#include <assert.h>
#include <errno.h>

#include <string>
#include <functional>

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_watcher_io.h>
#include <evtl/evtl_watcher_timer.h>
#include <evtl/evtl_connector.h>
#include <evtl/evtl_in.h>
#include <evtl/evtl_boundedbuf.h>
#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_ringbuf.h>
#include <evtl/evtl_lock.h>
#include <evtl/evtl_com.h>
#include <evtl/evtl_error.h>

#include "loginfo.h"
#include "logcodec.h"


namespace evpl { namespace logger {


class logclient : public evtl::watcher_io<logclient>, public evtl::evtl_error
{
public:
	enum errorcode
	{
		success,
		mutex_error,
		connect_error
	};

	logclient(): m_check_selfconn(false),
		m_logbuf(20000),
		m_logsendbuf(1024*1024*4)
	{
		ssize_t size = m_logbuf.size();
		for (ssize_t i = 0; i < size; i++)
		{
			evtl::linearbuf<char> &buf = m_logbuf[i].elem();
			buf.reset_capacity(1024*2);
		}
	}

	void set_loop(evtl::looprefer loop)
	{
		m_loop = loop;
	}

	bool logstart(const evtl::address &addr, bool check_selfconn = true)
	{
		if (!m_logmutex.init())
		{
			set_error(mutex_error);
			return false;
		}

		m_servaddr = addr;
		m_check_selfconn = check_selfconn;

		m_connector.set_loop(m_loop);
		m_connector.set_callback(std::bind(&logclient::connect_callback, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3));
		bool br = m_connector.async_connect(addr, check_selfconn);
		if (!br)
		{
			set_error(connect_error, m_connector.get_error_combine());
			return false;
		}

		m_contimer.set(m_loop, 3. + m_loop.now_difference(), 0);
		m_contimer.set_callback(std::bind(&logclient::contimer_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_contimer.start();
		return true;
	}

	bool pushlog(const logtypeinfo &logtype, const std::string &log)
	{
		loginfoencoder  encoder;
		std::string encstr = encoder.encode(logtype, log);
		if (encstr.size() > 1024*1024)
			assert(false && "log too long");

		evtl::lock::lockguard<evtl::lock::mutex_lock> lg(m_logmutex);

		evtl::linearbuf<char> *buf = m_logbuf.get_produce();
		if (buf == nullptr)
			return false;

		buf->extens_store_whole(encstr);
		m_logbuf.produce_complete(buf);
		return true;
	}

	void io_callback(logclient &watcher, int revents)
	{
		if (&watcher != this)
			assert(false && "invalid watcher");

		evtl::com::process_nextstep step = process();
		switch (step)
		{
		case evtl::com::nextstep_wait_to_send:
			{
				if (m_iostat.error_raised())
				{
					stop_close();
					m_logtimer.stop();
					m_contimer.set(0.5 + m_loop.now_difference(), 0);
					m_contimer.start();
					return;
				}

				if (get_events() != ev::WRITE)
				{
					stop();
					set_events(ev::WRITE);
					start();
				}
				else
				{
					if (!is_active())
						start();
				}
				return;
			}
			break;
		case evtl::com::nextstep_stop:
			{
				stop();
				return;
			}
			break;
		default:
			assert(false && "invalid step");
			break;
		}
	}

	void deinit()
	{
		stop_close();
		m_connector.stop_close();
		m_contimer.stop();
		m_logtimer.stop();
		m_logmutex.deinit();
	}

private:
	void connect_callback(evtl::simpconnector &connector, int errcode, int errnocode)
	{
		if (&connector != &m_connector)
			assert(false && "unexpected connector");
		if (is_active())
			assert(false && "active client");

		m_contimer.stop();
		if (errcode == evtl::simpconnector::success)
		{
			int fd = connector.get_fd();
			if (fd == -1)
				assert(false && "invalid fd");
			connector.only_reset();

			_newconn_clean();
			set(m_loop);
			set_callback();
			set(fd, ev::WRITE);
			start();

			m_logtimer.set(m_loop, 0., 0.05);
			m_logtimer.set_callback(std::bind(&logclient::logtimer_callback, this, std::placeholders::_1, std::placeholders::_2));
			m_logtimer.start();
		}
		else
		{
			m_contimer.set(3. + m_loop.now_difference(), 0);
			m_contimer.start();
		}
	}

	void contimer_callback(evtl::simpwtimer &timer, int revents)
	{
		if (&timer != &m_contimer)
			assert(false && "unexpected timer");

		m_connector.stop_close();

		m_connector.set_loop(m_loop);
		m_connector.set_callback(std::bind(&logclient::connect_callback, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3));
		m_connector.async_connect(m_servaddr, m_check_selfconn);

		timer.stop();
		timer.set(3. + m_loop.now_difference(), 0);
		timer.start();
	}

	void logtimer_callback(evtl::simpwtimer &timer, int revents)
	{
		if (&timer != &m_logtimer)
			assert(false && "unexpected timer");

		evtl::linearbuf<char> *buf = m_logbuf.get_consume();
		if (buf == nullptr && m_logsendbuf.empty())
			return;
		else
		{
			if (get_events() != ev::WRITE)
			{
				stop();
				set_events(ev::WRITE);
				start();
			}
			else
			{
				if (!is_active())
					start();
			}
		}
	}

	evtl::com::process_nextstep process()
	{
		evtl::linearbuf<char> *buf = nullptr;
		while (true)
		{
			buf = m_logbuf.get_consume();
			if (buf == nullptr)
				break;

			bool br = m_logsendbuf.append_whole(*buf);
			if (!br)
				break;

			if (buf->capacity() > 1024*2)
				buf->reset_capacity(1024*2);
			buf->clear();
			m_logbuf.consume_complete(buf);
		}

		ssize_t headsize = m_logsendbuf.headsize();
		if (headsize > 0)
		{
			ssize_t ws = this->write(m_logsendbuf.dataptr(), headsize);
			if (ws > 0)
			{
				if (ws > headsize)
					assert(false && "write exception");
				if (!m_logsendbuf.shit_whole(ws))
					assert(false && "shit failed");
			}
			else if (ws < 0)
			{
				if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
					m_iostat.orset(evtl::com::rwresult_write_error, errno);
			}
			else
			{
				assert(false && "write zero");
			}
		}

		if (buf == nullptr && headsize <= 0)
			return evtl::com::nextstep_stop;
		else
			return evtl::com::nextstep_wait_to_send;
	}

	void _newconn_clean()
	{
		m_iostat.reset();
	}

private:
	evtl::looprefer  m_loop;

	evtl::address    m_servaddr;
	bool             m_check_selfconn;

	evtl::simpconnector  m_connector;
	evtl::simpwtimer  m_contimer;
	evtl::simpwtimer  m_logtimer;

	evtl::lock::mutex_lock  m_logmutex;
	evtl::boundedbuf<evtl::linearbuf<char>>  m_logbuf;
	evtl::ringbuf<char>  m_logsendbuf;

	evtl::com::rwstatus  m_iostat;
};


} }


#endif


