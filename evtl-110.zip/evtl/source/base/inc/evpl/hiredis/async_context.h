

#ifndef __EVPL_HIREDIS_ASYNC_CONTEXT_H__
#define __EVPL_HIREDIS_ASYNC_CONTEXT_H__

#include <assert.h>
#include <stdarg.h>

#include <string>
#include <cstring>

#include <hiredis/async.h>
#include <hiredis/adapters/libev.h>

#include <evtl/evtl_error.h>
#include <evtl/evtl_eventloop.h>


namespace evpl { namespace hiredis {


template <class thunkT>
struct thunk
{
	thunk(): arg(nullptr), addr(nullptr)
	{}

	thunk(void *_arg, thunkT *_addr): arg(_arg), addr(_addr)
	{}

	void set(void *_arg, thunkT *_addr)
	{
		arg  = _arg;
		addr = _addr;
	}

	void     *arg;
	thunkT   *addr;
};

class async_context : public evtl::evtl_error
{
public:
	async_context(): m_context(nullptr), m_loop(nullptr)
	{}

	enum error_code
	{
		success,
		invalid_ip            = 1,
		context_exist         = 2,
		null_loop             = 3,
		null_connect_context  = 4,
		connect_error         = 5,
		attach_failed         = 6,
		negative_timeout      = 7,
		null_context          = 8,
		invalid_context       = 9,
		command_failed        = 10
	};

	enum context_status
	{
		ctxstatus_null,
		ctxstatus_invalid,
		ctxstatus_normal
	};

	const redisAsyncContext * raw_context() const
	{
		return m_context;
	}

	void set_loop(evtl::looprefer loop)
	{
		m_loop = loop;
	}

	template <class T, void (T::*method)(const async_context &ctx, int status, const std::string &errstr)>
	void set_connect_callback(T *object)
	{
		if (object == nullptr)
			assert(false && "null object");

		m_connect_thunk.set(object, connect_method_thunk<T, method>);
	}

	template <class T, void (T::*method)(const async_context &ctx, int status)>
	void set_disconnect_callback(T *object)
	{
		if (object == nullptr)
			assert(false && "null object");

		m_disconnect_thunk.set(object, disconnect_method_thunk<T, method>);
	}

	bool async_connect(const std::string &ip, int port)
	{
		if (ip.empty())
		{
			set_error(invalid_ip);
			return false;
		}

		if (m_context != nullptr)
		{
			set_error(context_exist);
			return false;
		}

		if (m_loop.is_null())
		{
			set_error(null_loop);
			return false;
		}

		redisAsyncContext *ctx = ::redisAsyncConnect(ip.c_str(), port);
		if (ctx == nullptr)
		{
			set_error(null_connect_context);
			return false;
		}

		if (ctx->err != 0)
		{
			std::string errstr = (ctx->errstr == nullptr ? std::string() : ctx->errstr);
			set_error(connect_error, ctx->err, errstr);
			::redisAsyncFree(ctx);
			return false;
		}

		if (REDIS_OK != ::redisLibevAttach(m_loop.ref(), ctx))
		{
			set_error(attach_failed);
			::redisAsyncDisconnect(ctx);
			return false;
		}

		::redisAsyncSetConnectCallback(ctx, &async_context::__connect_callback);
		::redisAsyncSetDisconnectCallback(ctx, &async_context::__disconnect_callback);

		ctx->data = this;
		ctx->dataCleanup = nullptr;

		m_context = ctx;
		return true;
	}

	void async_free()
	{
		if (m_context != nullptr)
			::redisAsyncFree(m_context);
		m_context = nullptr;
	}

	bool set_timeout(long us)
	{
		if (us < 0)
		{
			assert(false && "negative timeout");
			set_error(negative_timeout, us);
			return false;
		}

		if (m_context == nullptr)
		{
			set_error(null_context);
			return false;
		}

		struct timeval tv;
		memset(&tv, 0, sizeof(tv));
		tv.tv_sec  = us/1000000L;
		tv.tv_usec = us%1000000L;

		::redisAsyncSetTimeout(m_context, tv);

		return true;
	}

	context_status check_context_status() const
	{
		if (m_context == nullptr)
			return ctxstatus_null;
		else
		{
			if (m_context->err != 0)
				return ctxstatus_invalid;
		}

		return ctxstatus_normal;
	}

	bool vcommand(redisCallbackFn *fn, void *privdata, const char *format, va_list ap)
	{
		if (m_context == nullptr)
		{
			set_error(null_context);
			return false;
		}

		if (m_context->err != 0)
		{
			std::string errstr = (m_context->errstr == nullptr ? std::string() : m_context->errstr);
			set_error(invalid_context, m_context->err, errstr);
			return false;
		}

		int status = ::redisvAsyncCommand(m_context, fn, privdata, format, ap);

		if (status != REDIS_OK)
		{
			set_error(command_failed, status);
			return false;
		}

		return true;
	}

	bool command(redisCallbackFn *fn, void *privdata, const char *format, ...)
	{
		if (m_context == nullptr)
		{
			set_error(null_context);
			return false;
		}

		if (m_context->err != 0)
		{
			std::string errstr = (m_context->errstr == nullptr ? std::string() : m_context->errstr);
			set_error(invalid_context, m_context->err, errstr);
			return false;
		}

		va_list ap;
		va_start(ap, format);
		int status = ::redisvAsyncCommand(m_context, fn, privdata, format, ap);
		va_end(ap);

		if (status != REDIS_OK)
		{
			set_error(command_failed, status);
			return false;
		}

		return true;
	}

private:
	void _connect_callback(const redisAsyncContext *context, int status)
	{
		if (context != m_context)
			assert(false && "unexpected context");

		if (status != REDIS_OK)
			m_context = nullptr;

		std::string errstr;
		if (status != REDIS_OK && context->errstr != nullptr)
			errstr = context->errstr;

		m_connect_thunk.addr(m_connect_thunk.arg, *this, status, errstr);
	}

	void _disconnect_callback(const redisAsyncContext *context, int status)
	{
		if (context != m_context)
			assert(false && "unexpected context");

		m_context = nullptr;

		m_disconnect_thunk.addr(m_disconnect_thunk.arg, *this, status);
	}

	static void __connect_callback(const redisAsyncContext *context, int status)
	{
		if (context == nullptr)
			assert(false && "null context");
		if (context->data == nullptr)
			assert(false && "null data");

		static_cast<async_context *>(context->data)->_connect_callback(context, status);
	}

	static void __disconnect_callback(const redisAsyncContext *context, int status)
	{
		if (context == nullptr)
			assert(false && "null context");
		if (context->data == nullptr)
			assert(false && "null data");

		static_cast<async_context *>(context->data)->_disconnect_callback(context, status);
	}

	template <class T, void (T::*method)(const async_context &ctx, int status, const std::string &errstr)>
	static void connect_method_thunk(void *arg, const async_context &ctx, int status, const std::string &errstr)
	{
		(static_cast<T*>(arg)->*method)(ctx, status, errstr);
	}

	template <class T, void (T::*method)(const async_context &ctx, int status)>
	static void disconnect_method_thunk(void *arg, const async_context &ctx, int status)
	{
		(static_cast<T*>(arg)->*method)(ctx, status);
	}

private:
	redisAsyncContext  *m_context;

	evtl::looprefer  m_loop;

	thunk<void (void *arg, const async_context &ctx, int status, const std::string &errstr)>   m_connect_thunk;
	thunk<void (void *arg, const async_context &ctx, int status)>   m_disconnect_thunk;
};


} }


#endif


