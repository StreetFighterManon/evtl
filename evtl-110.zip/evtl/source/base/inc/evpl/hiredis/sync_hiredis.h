

#ifndef __EVPL_HIREDIS_SYNC_HIREDIS_H__
#define __EVPL_HIREDIS_SYNC_HIREDIS_H__

#include <assert.h>
#include <stdarg.h>

#include <string>
#include <cstring>
#include <atomic>

#include <hiredis/hiredis.h>

#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_lock.h>

#include "redis_reply.h"


namespace evpl { namespace hiredis {


template <class lockPolicy = evtl::lock::null_lock>
class sync_session
{
public:
	sync_session(): m_context(nullptr), m_established(false)
	{}

	bool init()
	{
		return m_lock.init();
	}

	void deinit()
	{
		this->close();
		m_lock.deinit();
	}

	evtl::boolrs<std::string> wait_connect(const std::string &ip, int port, long wait_us = -1, long cmd_timeout_us = -1)
	{
		if (ip.empty() || port <= 0)
			return evtl::boolrs<std::string>(false, "invalid address");

		evtl::lock::lockguard<lockPolicy> lg(m_lock);

		if (m_context != nullptr)
		{
			if (m_context->err == 0)
			{
				m_established = true;
				return evtl::boolrs<std::string>(false, "context exist");
			}

			this->close();
		}

		m_established = false;

		struct timeval tv;
		memset(&tv, 0, sizeof(tv));
		if (wait_us >= 0)
		{
			tv.tv_sec  = wait_us/1000000L;
			tv.tv_usec = wait_us%1000000L;
		}

		if (wait_us < 0)
			m_context = ::redisConnect(ip.c_str(), port);
		else
			m_context = ::redisConnectWithTimeout(ip.c_str(), port, tv);

		if (m_context == nullptr)
			return evtl::boolrs<std::string>(false, "return null context");
		if (m_context->err != 0)
		{
			::redisFree(m_context);
			m_context = nullptr;
			return evtl::boolrs<std::string>(false, "connect failed");
		}

		if (cmd_timeout_us >= 0)
			_set_timeout(cmd_timeout_us);

		m_established = true;
		return evtl::boolrs<std::string>(true);
	}

	evtl::boolrs<std::string> reconnect()
	{
		evtl::lock::lockguard<lockPolicy> lg(m_lock);

		if (m_context == nullptr)
		{
			assert(false && "null context");
			return evtl::boolrs<std::string>(false, "null context");
		}

		m_established = false;

		int rt = ::redisReconnect(m_context);
		if (rt != REDIS_OK)
			return evtl::boolrs<std::string>(false, "connect failed");

		if (m_context->err != 0)
		{
			std::string errstr(m_context->errstr);

			::redisFree(m_context);
			m_context = nullptr;
			return evtl::boolrs<std::string>(false, errstr);
		}

		m_established = true;
		return evtl::boolrs<std::string>(true);
	}

	evtl::boolrs<std::string> set_timeout(long us)
	{
		if (us < 0)
			return evtl::boolrs<std::string>(false, "negative timeout");

		evtl::lock::lockguard<lockPolicy> lg(m_lock);

		return _set_timeout(us);
	}

	bool is_established()
	{
		evtl::lock::lockguard<lockPolicy> lg(m_lock);

		if (m_context != nullptr && m_context->err == 0)
			return true;
		return false;
	}

	bool established_flag() const
	{
		return m_established;
	}

	const redisContext * get_context() const
	{
		return m_context;
	}

	void close()
	{
		evtl::lock::lockguard<lockPolicy> lg(m_lock);

		m_established = false;

		if (m_context != nullptr)
			::redisFree(m_context);
		m_context = nullptr;
	}

	redis_reply vcommand(const char *format, va_list ap)
	{
		evtl::lock::lockguard<lockPolicy> lg(m_lock);

		redisReply *reply = nullptr;

		if (format == nullptr)
			assert(false && "null format string");

		if (m_context != nullptr && m_context->err == 0)
			reply = (redisReply *)::redisvCommand(m_context, format, ap);

		if (m_context != nullptr && m_context->err == 0)
			m_established = true;
		else
			m_established = false;

		redis_reply result(reply);

		if (reply != nullptr)
			::freeReplyObject(reply);
		reply = nullptr;

		return result;
	}

	redisReply * vcommandrr(const char *format, va_list ap)
	{
		evtl::lock::lockguard<lockPolicy> lg(m_lock);

		redisReply *reply = nullptr;

		if (format == nullptr)
			assert(false && "null format string");

		if (m_context != nullptr && m_context->err == 0)
			reply = (redisReply *)::redisvCommand(m_context, format, ap);

		if (m_context != nullptr && m_context->err == 0)
			m_established = true;
		else
			m_established = false;

		return reply;
	}

	redis_reply command(const char *format, ...)
	{
		evtl::lock::lockguard<lockPolicy> lg(m_lock);

		redisReply *reply = nullptr;

		if (format == nullptr)
			assert(false && "null format string");

		if (m_context != nullptr && m_context->err == 0)
		{
			va_list  vlist;

			va_start(vlist, format);
			reply = (redisReply *)::redisvCommand(m_context, format, vlist);
			va_end(vlist);
		}

		if (m_context != nullptr && m_context->err == 0)
			m_established = true;
		else
			m_established = false;

		redis_reply result(reply);

		if (reply != nullptr)
			::freeReplyObject(reply);
		reply = nullptr;

		return result;
	}

	redisReply * commandrr(const char *format, ...)
	{
		evtl::lock::lockguard<lockPolicy> lg(m_lock);

		redisReply *reply = nullptr;

		if (format == nullptr)
			assert(false && "null format string");

		if (m_context != nullptr && m_context->err == 0)
		{
			va_list  vlist;

			va_start(vlist, format);
			reply = (redisReply *)::redisvCommand(m_context, format, vlist);
			va_end(vlist);
		}

		if (m_context != nullptr && m_context->err == 0)
			m_established = true;
		else
			m_established = false;

		return reply;
	}

private:
	evtl::boolrs<std::string> _set_timeout(long us)
	{
		if (m_context == nullptr)
			return evtl::boolrs<std::string>(false, "null context");

		struct timeval tv;
		memset(&tv, 0, sizeof(tv));
		tv.tv_sec  = us/1000000L;
		tv.tv_usec = us%1000000L;

		int rt = ::redisSetTimeout(m_context, tv);
		if (rt != REDIS_OK)
			return evtl::boolrs<std::string>(false, "set timeout failed");

		return evtl::boolrs<std::string>(true);
	}

private:
	redisContext      *m_context;
	std::atomic<bool>  m_established;

	lockPolicy   m_lock;
};


} }


#endif


