

#ifndef __EVPL_HIREDIS_ASYNC_HIREDIS_H__
#define __EVPL_HIREDIS_ASYNC_HIREDIS_H__

#include <assert.h>

#include <functional>
#include <string>
#include <utility>

#include <ev/ev++.h>
#include <hiredis/async.h>
#include <hiredis/adapters/libev.h>

#include <evtl/evtl_error.h>
#include <evtl/evtl_eventloop.h>

#include "async_context.h"


namespace evpl { namespace hiredis {


template <class T>
class async_session : public evtl::evtl_error
{
public:
	typedef std::function<void (const T &session, int status, const std::string &errstr)>  connect_callback_t;
	typedef std::function<void (const T &session, int status)>  disconnect_callback_t;

	async_session()
	{
		m_context.set_connect_callback<async_session, &async_session::_connect_callback>(this);
		m_connect_cb = std::bind(&T::connect_callback, static_cast<T*>(this), std::placeholders::_1, std::placeholders::_2, std::placeholders::_3);

		m_context.set_disconnect_callback<async_session, &async_session::_disconnect_callback>(this);
		m_disconnect_cb = std::bind(&T::disconnect_callback, static_cast<T*>(this), std::placeholders::_1, std::placeholders::_2);
	}

	async_context * context()
	{
		return &m_context;
	}

	void set_loop(evtl::looprefer loop)
	{
		m_context.set_loop(loop);
	}

	void set_connect_callback()
	{
		m_context.set_connect_callback<async_session, &async_session::_connect_callback>(this);
		m_connect_cb = std::bind(&T::connect_callback, static_cast<T*>(this), std::placeholders::_1, std::placeholders::_2, std::placeholders::_3);
	}

	void set_connect_callback(connect_callback_t cb)
	{
		m_context.set_connect_callback<async_session, &async_session::_connect_callback>(this);
		m_connect_cb = std::move(cb);
	}

	void set_disconnect_callback()
	{
		m_context.set_disconnect_callback<async_session, &async_session::_disconnect_callback>(this);
		m_disconnect_cb = std::bind(&T::disconnect_callback, static_cast<T*>(this), std::placeholders::_1, std::placeholders::_2);
	}

	void set_disconnect_callback(disconnect_callback_t cb)
	{
		m_context.set_disconnect_callback<async_session, &async_session::_disconnect_callback>(this);
		m_disconnect_cb = std::move(cb);
	}

	bool async_connect(const std::string &ip, int port)
	{
		bool br = m_context.async_connect(ip, port);
		if (!br)
			set_error(m_context);
		return br;
	}

	void async_free()
	{
		return m_context.async_free();
	}

	bool set_timeout(long us)
	{
		bool br = m_context.set_timeout(us);
		if (!br)
			set_error(m_context);
		return br;
	}

	async_context::context_status check_context_status() const
	{
		return m_context.check_context_status();
	}

private:
	void connect_callback(const T &session, int status, const std::string &errstr) { assert(false && "unset callback"); }
	void disconnect_callback(const T &session, int status) { assert(false && "unset callback"); }

	void _connect_callback(const async_context &context, int status, const std::string &errstr)
	{
		if (&context != &m_context)
			assert(false && "unexpected context");

		m_connect_cb(*static_cast<T*>(this), status, errstr);
	}

	void _disconnect_callback(const async_context &context, int status)
	{
		if (&context != &m_context)
			assert(false && "unexpected context");

		m_disconnect_cb(*static_cast<T*>(this), status);
	}

private:
	async_context   m_context;

	connect_callback_t     m_connect_cb;
	disconnect_callback_t  m_disconnect_cb;
};


class simpasync_session : public async_session<simpasync_session>
{};


} }


#endif


