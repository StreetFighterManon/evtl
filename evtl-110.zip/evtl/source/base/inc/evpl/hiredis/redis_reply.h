

#ifndef __EVPL_REDIS_REPLY_H__
#define __EVPL_REDIS_REPLY_H__

#include <sys/types.h>
#include <assert.h>

#include <string>
#include <vector>
#include <algorithm>
#include <utility>

#include <hiredis/hiredis.h>


namespace evpl { namespace hiredis {


enum replystatus
{
	reply_null,
	reply_valid,
	reply_negative_strlen,
	reply_null_strptr,
	reply_negative_arraylen,
	reply_null_arrayptr,
	reply_null_arrayelemptr,
	reply_unknown_type
};

class redis_reply
{
public:
	redis_reply()
		: m_status(reply_null),
		m_type(REDIS_REPLY_NIL),
		m_integer(0),
		m_dval(0.),
		m_len(0),
		m_str(nullptr)
	{}

	explicit redis_reply(redisReply *reply): redis_reply()
	{
		if (reply == nullptr)
		{
			m_status = reply_null;
			return;
		}

		m_status = reply_valid;
		m_type = reply->type;

		switch (m_type)
		{
		case REDIS_REPLY_NIL:
			break;
		case REDIS_REPLY_ERROR:
		case REDIS_REPLY_STATUS:
		case REDIS_REPLY_STRING:
			{
				if ((ssize_t)reply->len < 0)
				{
					m_status = reply_negative_strlen;
					break;
				}
				else if ((ssize_t)reply->len > 0)
				{
					if (reply->str == nullptr)
					{
						m_status = reply_null_strptr;
						break;
					}
				}

				m_str = new char[reply->len + 1];
				if (m_str == nullptr)
					assert(false && "out of memory");

				if (reply->len > 0)
					std::copy(reply->str, reply->str + reply->len, m_str);
				m_str[reply->len] = '\0';

				m_len = (ssize_t)reply->len;
			}
			break;
		case REDIS_REPLY_INTEGER:
			{
				m_integer = reply->integer;
			}
			break;
		case REDIS_REPLY_DOUBLE:
			{
				m_dval = reply->dval;
			}
			break;
		case REDIS_REPLY_ARRAY:
			{
				ssize_t elems = (ssize_t)reply->elements;

				if (elems < 0)
				{
					m_status = reply_negative_arraylen;
					break;
				}
				else if (elems > 0)
				{
					if (reply->element == nullptr)
					{
						m_status = reply_null_arrayptr;
						break;
					}
				}

				for (ssize_t i = 0; i < elems; i++)
				{
					if (reply->element[i] != nullptr)
						m_array.push_back(redis_reply(reply->element[i]));
					else
						m_status = reply_null_arrayelemptr;
				}
			}
			break;
		default:
			{
				m_status = reply_unknown_type;
			}
			break;
		}
	}

	redis_reply(const redis_reply &that) : redis_reply()
	{
		m_status = that.m_status;
		m_type = that.m_type;

		switch (m_type)
		{
		case REDIS_REPLY_NIL:
			break;
		case REDIS_REPLY_ERROR:
		case REDIS_REPLY_STATUS:
		case REDIS_REPLY_STRING:
			{
				if (that.m_len < 0)
				{
					m_status = reply_negative_strlen;
					break;
				}
				else if (that.m_len > 0)
				{
					if (that.m_str == nullptr)
					{
						m_status = reply_null_strptr;
						break;
					}
				}

				if (m_status == reply_valid)
				{
					m_str = new char[that.m_len + 1];
					if (m_str == nullptr)
						assert(false && "out of memory");

					if (that.m_len > 0)
						std::copy(that.m_str, that.m_str + that.m_len, m_str);
					m_str[that.m_len] = '\0';

					m_len = that.m_len;
				}
			}
			break;
		case REDIS_REPLY_INTEGER:
			{
				m_integer = that.m_integer;
			}
			break;
		case REDIS_REPLY_DOUBLE:
			{
				m_dval = that.m_dval;
			}
			break;
		case REDIS_REPLY_ARRAY:
			{
				m_array = that.m_array;
			}
			break;
		default:
			{
				m_status = reply_unknown_type;
			}
			break;
		}
	}

	redis_reply(redis_reply &&that) noexcept
	{
		m_status  = that.m_status;
		m_type    = that.m_type;
		m_integer = that.m_integer;
		m_dval    = that.m_dval;

		m_len     = that.m_len;
		m_str     = that.m_str;

		m_array   = std::move(that.m_array);

		that.m_status  = reply_null;
		that.m_type    = REDIS_REPLY_NIL;
		that.m_integer = 0;
		that.m_dval    = 0.;
		that.m_len     = 0;
		that.m_str     = nullptr;
	}

	~redis_reply()
	{
		_free_data();
	}

	redis_reply& operator = (const redis_reply &that)
	{
		if (&that == this)
			return *this;

		_free_data();

		m_status = that.m_status;
		m_type = that.m_type;

		switch (m_type)
		{
		case REDIS_REPLY_NIL:
			break;
		case REDIS_REPLY_ERROR:
		case REDIS_REPLY_STATUS:
		case REDIS_REPLY_STRING:
			{
				if (that.m_len < 0)
				{
					m_status = reply_negative_strlen;
					break;
				}
				else if (that.m_len > 0)
				{
					if (that.m_str == nullptr)
					{
						m_status = reply_null_strptr;
						break;
					}
				}

				if (m_status == reply_valid)
				{
					m_str = new char[that.m_len + 1];
					if (m_str == nullptr)
						assert(false && "out of memory");

					if (that.m_len > 0)
						std::copy(that.m_str, that.m_str + that.m_len, m_str);
					m_str[that.m_len] = '\0';

					m_len = that.m_len;
				}
			}
			break;
		case REDIS_REPLY_INTEGER:
			{
				m_integer = that.m_integer;
			}
			break;
		case REDIS_REPLY_DOUBLE:
			{
				m_dval = that.m_dval;
			}
			break;
		case REDIS_REPLY_ARRAY:
			{
				m_array = that.m_array;
			}
			break;
		default:
			{
				m_status = reply_unknown_type;
			}
			break;
		}

		return *this;
	}

	redis_reply& operator = (redis_reply &&that) noexcept
	{
		if (&that == this)
			return *this;

		_free_data();

		m_status  = that.m_status;
		m_type    = that.m_type;
		m_integer = that.m_integer;
		m_dval    = that.m_dval;

		m_len     = that.m_len;
		m_str     = that.m_str;

		m_array   = std::move(that.m_array);

		that.m_status  = reply_null;
		that.m_type    = REDIS_REPLY_NIL;
		that.m_integer = 0;
		that.m_dval    = 0.;
		that.m_len     = 0;
		that.m_str     = nullptr;

		return *this;
	}

	replystatus status() const
	{
		return m_status;
	}

	int type() const
	{
		return m_type;
	}

	long long integer() const
	{
		return m_integer;
	}

	double dval() const
	{
		return m_dval;
	}

	const char * str() const
	{
		return m_str;
	}

	ssize_t len() const
	{
		return m_len;
	}

	std::string getstring() const
	{
		if (m_status == reply_valid
			&& (m_type == REDIS_REPLY_ERROR || m_type == REDIS_REPLY_STATUS || m_type == REDIS_REPLY_STRING)
			)
		{
			if (m_len < 0)
				assert(false && "negative strlen");
			else if (m_len > 0 && m_str == nullptr)
				assert(false && "null strptr");

			if (m_len > 0)
				return std::string(m_str, m_len);
		}

		return std::string();
	}

	const std::vector<redis_reply>& getarray() const
	{
		return m_array;
	}

	ssize_t array_size() const
	{
		return (ssize_t)m_array.size();
	}

	const redis_reply& array_elem(ssize_t index) const
	{
		if (index < 0 || index >= (ssize_t)m_array.size())
			assert(false && "index out of bounds");

		return m_array[index];
	}

	const redis_reply& operator [] (ssize_t index) const
	{
		if (index < 0 || index >= (ssize_t)m_array.size())
			assert(false && "index out of bounds");

		return m_array[index];
	}

	void free_data()
	{
		return _free_data();
	}

private:
	void _free_data()
	{
		if (m_type == REDIS_REPLY_ERROR || m_type == REDIS_REPLY_STATUS || m_type == REDIS_REPLY_STRING)
		{
			if (m_str != nullptr)
				delete []m_str;
			m_str = nullptr;
			m_len = 0;
		}

		m_status  = reply_null;
		m_type    = REDIS_REPLY_NIL;
		m_integer = 0;
		m_dval    = 0.;
		m_len     = 0;
		m_str     = nullptr;
		m_array.clear();
	}

private:
	replystatus  m_status;

	int   m_type;

	long long  m_integer;
	double     m_dval;

	ssize_t    m_len;
	char *     m_str;

	std::vector<redis_reply>   m_array;
};


} }


#endif


