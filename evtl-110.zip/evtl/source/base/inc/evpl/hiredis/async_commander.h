

#ifndef __EVPL_HIREDIS_ASYNC_COMMANDER_H__
#define __EVPL_HIREDIS_ASYNC_COMMANDER_H__

#include <assert.h>
#include <stdarg.h>

#include <functional>
#include <utility>

#include <hiredis/async.h>

#include <evtl/evtl_error.h>

#include "async_context.h"


namespace evpl { namespace hiredis {


template <class T>
class async_commander : public evtl::evtl_error
{
public:
	typedef std::function<void (T &cmder, async_context &context, redisReply *reply)>   reply_callback_t;

	enum error_code
	{
		success,
		null_context = 1001
	};

	async_commander(): m_context(nullptr)
	{
		m_reply_cb = std::bind(&T::reply_callback, static_cast<T*>(this), std::placeholders::_1, std::placeholders::_2, std::placeholders::_3);
	}

	void set_context(async_context *context)
	{
		m_context = context;
	}

	void set_reply_callback()
	{
		m_reply_cb = std::bind(&T::reply_callback, static_cast<T*>(this), std::placeholders::_1, std::placeholders::_2, std::placeholders::_3);
	}

	void set_reply_callback(reply_callback_t cb)
	{
		m_reply_cb = std::move(cb);
	}

	bool vcommand(const char *format, va_list ap)
	{
		if (m_context == nullptr)
		{
			set_error(null_context);
			return false;
		}

		bool br = m_context->vcommand(&async_commander::__reply_callback, this, format, ap);

		if (!br)
			set_error(*m_context);

		return br;
	}

	bool command(const char *format, ...)
	{
		if (m_context == nullptr)
		{
			set_error(null_context);
			return false;
		}

		va_list ap;
		va_start(ap, format);
		bool br = m_context->vcommand(&async_commander::__reply_callback, this, format, ap);
		va_end(ap);

		if (!br)
			set_error(*m_context);

		return br;
	}

private:
	void reply_callback(T &cmder, async_context &context, redisReply *reply) { /* default callback */ }

	void _reply_callback(redisAsyncContext *ctx, redisReply *reply)
	{
		if (m_context == nullptr)
			assert(false && "null context");

		if (m_context != ctx->data)
			assert(false && "unexpected ctx");

		m_reply_cb(*static_cast<T*>(this), *m_context, reply);
	}

	static void __reply_callback(redisAsyncContext *ctx, void *reply, void *privdata)
	{
		if (ctx == nullptr)
			assert(false && "null callback context");

		async_commander *pcomm = static_cast<async_commander *>(privdata);
		if (pcomm == nullptr)
			assert(false && "null commander");

		pcomm->_reply_callback(ctx, static_cast<redisReply *>(reply));
	}

private:
	async_context    *m_context;
	reply_callback_t  m_reply_cb;
};


class simpasync_commander : public async_commander<simpasync_commander>
{};


} }


#endif


