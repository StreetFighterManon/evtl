

#ifndef __EVPL_SELECTOR_REQUEST_H__
#define __EVPL_SELECTOR_REQUEST_H__

#include <assert.h>

#include "seltype.h"
#include "selsessbase.h"


namespace evpl { namespace selector {


template <class RT>
class request
{
public:
	request(): m_detected(false)
	{
		m_base = nullptr;
	}

	enum detectret
	{
		det_finish,
		det_continue,
		det_waitrecv
	};

	bool isbaseset() const
	{
		return m_base != nullptr;
	}

	void setbase(selsessbase<RT> *base)
	{
		m_base = base;
	}

	bool request_detected() const
	{
		return m_detected;
	}

	detectret detect_request()
	{
		m_detail.exceptcode = detectexception::none;

		detectresult status = m_base->setting.detect(m_base->recvbuf, m_detail.reqtype);
		switch (status)
		{
		case detectresult::succeed:
			{
				m_detected = true;
				return det_finish;
			}
		case detectresult::badrequest:
			{
				m_detected = true;
				m_detail.exceptcode = detectexception::badrequest;
				return det_finish;
			}
		case detectresult::needmore:
			{
				m_base->recvbuf.crowd();
				if (m_base->recvbuf.headspace() <= 0)
				{
					m_detected = true;
					m_detail.exceptcode = detectexception::bufferfull;
					return det_finish;
				}

				ssize_t rn = m_base->ioif->io_read(m_base->recvbuf.headptr(), m_base->recvbuf.headspace());
				if (rn > 0)
				{
					if (!m_base->recvbuf.head_eaten_whole(rn))
						assert(false && "eaten failed");
					return det_continue;
				}
				return det_waitrecv;
			}
		default:
			assert(false && "invalid status");
			break;
		};

		assert(false && "should not reach here");
		return det_finish;
	}

	const detectdetail<RT>& get_detail() const
	{
		return m_detail;
	}

private:
	selsessbase<RT>  *m_base;
	bool  m_detected;
	detectdetail<RT>  m_detail;
};


} }


#endif


