

#ifndef __EVPL_SELECTOR_SELSESSION_H__
#define __EVPL_SELECTOR_SELSESSION_H__

#include <sys/types.h>
#include <assert.h>
#include <errno.h>
#include <functional>
#include <utility>

#include <evtl/evtl_interface.h>
#include <evtl/evtl_watcher_io.h>
#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_com.h>
#include <evtl/evtl_interface.h>
#include <evtl/evtl_time.h>
#include <evtl/evtl_in.h>
#include <evtl/evtl_wrapper.h>

#include "seltype.h"
#include "selsessbase.h"
#include "selprocess.h"


namespace evpl { namespace selector {


template <class RT>
class selsession : public evtl::watcher_io<selsession<RT>>, public evtl::iio
{
public:
	selsession(): m_starttime_s(0.)
	{}

	typedef std::function<void (selsession *psess)>  recycle_callback_t;

	void init()
	{
		m_base.ioif = this;
		m_process.setbase(&m_base);
		m_starttime_s = evtl::timec::sec_f();
	}

	void set_recycle_callback(recycle_callback_t cb)
	{
		m_recycle_cb = std::move(cb);
	}

	void set_settings(const settings<RT> &setting)
	{
		m_base.setting = setting;
		m_base.recvbuf.reset_capacity(m_base.setting.recvbufsize);
	}

	void set_sockpairaddr(const evtl::sockpairaddr &addr)
	{
		m_sockaddr.set_assign(addr);
	}

	void set_data(const evtl::linearbuf<char> &databuf)
	{
		m_base.recvbuf.extens_store_whole(databuf);
	}

	ssize_t io_read(void *buffer, ssize_t nbytes) override
	{
		if (buffer == nullptr || nbytes <= 0)
			assert(false && "buffer error");

		ssize_t n = this->read(buffer, nbytes);
		if (n > 0)
		{
			return n;
		}
		else if (n < 0)
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
			{
				m_iostatus.orset(evtl::com::rwresult_read_error, errno);
			}
		}
		else
		{
			m_iostatus.orset(evtl::com::rwresult_read_end, 0);
		}

		return n;
	}

	ssize_t io_write(const void *buffer, ssize_t nbytes) override
	{
		if (buffer == nullptr || nbytes <= 0)
			assert(false && "buffer error");

		ssize_t n = this->write(buffer, nbytes);
		if (n > 0)
		{
			return n;
		}
		else if (n < 0)
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
			{
				m_iostatus.orset(evtl::com::rwresult_write_error, errno);
			}
		}
		else
		{
			m_iostatus.orset(evtl::com::rwresult_write_error, 0);
		}

		return n;
	}

	void io_callback(selsession &watcher, int revents)
	{
		if (&watcher != this)
			assert(false && "unexpected watcher");

		m_process.process();

		evtl::com::process_nextstep nextstep = m_process.get_nextstep();
		switch (nextstep)
		{
		case evtl::com::nextstep_wait_to_receive:
			{
				if (m_iostatus.readerror_raised())
				{
					detectdetail<RT> detail;
					detail.exceptcode = detectexception::readfail;
					detail.errnocode  = m_iostatus.read_errno();
					detail.errstr     = m_iostatus.tostring();

					detail.fd = this->get_fd();
					detail.recvdata = m_base.recvbuf;
					if (m_sockaddr.isset())
						detail.addr = m_sockaddr;
					else
						detail.addr.unset();

					this->stop();
					m_base.setting.deliver(detail);
					this->only_reset();
					m_recycle_cb(this);
					return;
				}
				else
				{
					if (this->get_events() != ev::READ)
					{
						this->stop();
						this->set_events(ev::READ);
						this->start();
					}
					else
					{
						if (!this->is_active())
							this->start();
					}
				}
			}
			break;
		case evtl::com::nextstep_wait_to_send:
			{
				if (this->get_events() != ev::WRITE)
				{
					this->stop();
					this->set_events(ev::WRITE);
					this->start();
				}
				else
				{
					if (!this->is_active())
						this->start();
				}
			}
			break;
		case evtl::com::nextstep_done:
			{
				detectdetail<RT> detail = m_process.get_detail();
				detail.fd       = this->get_fd();
				detail.recvdata = m_base.recvbuf;
				if (m_sockaddr.isset())
					detail.addr = m_sockaddr;
				else
					detail.addr.unset();

				this->stop();
				m_base.setting.deliver(detail);
				this->only_reset();
				m_recycle_cb(this);
				return;
			}
			break;
		default:
			assert(false && "invalid step");
			break;
		};
	}

	void deinit()
	{
		this->stop_reset();
	}

	double get_starttime() const
	{
		return m_starttime_s;
	}

	void timeout_deliver()
	{
		const detectdetail<RT> &deta = m_process.get_detail();

		detectdetail<RT> detail;
		detail.exceptcode = detectexception::timeout;
		detail.reqtype    = deta.reqtype;
		detail.fd         = this->get_fd();
		detail.recvdata   = m_base.recvbuf;
		if (m_sockaddr.isset())
			detail.addr = m_sockaddr;
		else
			detail.addr.unset();

		this->stop();
		m_base.setting.deliver(detail);
	}

private:
	selsessbase<RT>  m_base;
	selprocess<RT>   m_process;
	recycle_callback_t   m_recycle_cb;
	evtl::com::rwstatus  m_iostatus;
	double   m_starttime_s;
	evtl::st_var<evtl::sockpairaddr>  m_sockaddr;
};


} }


#endif


