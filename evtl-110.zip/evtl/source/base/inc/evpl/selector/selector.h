

#ifndef __EVPL_SELECTOR_SELECTOR_H__
#define __EVPL_SELECTOR_SELECTOR_H__

#include <sys/types.h>
#include <assert.h>
#include <set>
#include <utility>
#include <functional>

#include <evtl/evtl_error.h>
#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_watcher_timer.h>
#include <evtl/evtl_time.h>
#include <evtl/evtl_in.h>

#include "selsessbase.h"
#include "selsession.h"


namespace evpl { namespace selector {


template <class RT>
class selservice : public evtl::evtl_error
{
public:
	selservice()
	{}

	enum errorcode
	{
		success,
		too_much_data
	};

	void set_detectfunc(detectfunc<RT> func)
	{
		m_setting.detect = std::move(func);
	}

	void set_deliverfunc(deliverfunc<RT> func)
	{
		m_setting.deliver = std::move(func);
	}

	void set_recvbuf_size(ssize_t size)
	{
		if (size > 0)
			m_setting.recvbufsize = size;
	}

	void set_timeout(double second)
	{
		if (second <= 0.)
			second = -1.;
		else if (second < 1.)
			second = 1.;
		m_setting.timeout_s = second;
	}

	void init(evtl::looprefer loop)
	{
		m_loop = loop;
		if (m_setting.timeout_s > 0.)
		{
			m_timer.set(m_loop, 0., _get_repeat(m_setting.timeout_s));
			m_timer.set_callback(std::bind(&selservice::timer_callback, this, std::placeholders::_1, std::placeholders::_2));
			m_timer.again();
		}
	}

	bool receive(int fd)
	{
		if (fd == -1)
			assert(false && "fd == -1");

		selsession<RT> *psess = new selsession<RT>;
		psess->init();
		psess->set_recycle_callback(std::bind(&selservice::recycle, this, std::placeholders::_1));
		psess->set_settings(m_setting);
		psess->set(m_loop);
		psess->set(fd, ev::READ);
		psess->set_callback();
		psess->start();

		std::pair<typename std::set<selsession<RT>*>::const_iterator, bool> br = m_sessions.insert(psess);
		if (!br.second)
			assert(false && "insert failed");
		return true;
	}

	bool receive(int fd, const evtl::linearbuf<char> &databuf)
	{
		if (fd == -1)
			assert(false && "fd == -1");
		if (databuf.size() > 1024*512)
		{
			set_error(too_much_data, "too much data");
			return false;
		}

		selsession<RT> *psess = new selsession<RT>;
		psess->init();
		psess->set_recycle_callback(std::bind(&selservice::recycle, this, std::placeholders::_1));
		psess->set_settings(m_setting);
		psess->set(m_loop);
		psess->set(fd, ev::WRITE);
		psess->set_callback();
		psess->set_data(databuf);
		psess->start();

		std::pair<typename std::set<selsession<RT>*>::const_iterator, bool> br = m_sessions.insert(psess);
		if (!br.second)
			assert(false && "insert failed");

		return true;
	}

	bool receive(const evtl::connection &conn)
	{
		if (conn.fd == -1)
			assert(false && "fd == -1");

		selsession<RT> *psess = new selsession<RT>;
		psess->init();
		psess->set_recycle_callback(std::bind(&selservice::recycle, this, std::placeholders::_1));
		psess->set_settings(m_setting);

		evtl::sockpairaddr addr(conn);
		psess->set_sockpairaddr(addr);
		psess->set(m_loop);
		psess->set(conn.fd, ev::READ);
		psess->set_callback();
		psess->start();

		std::pair<typename std::set<selsession<RT>*>::const_iterator, bool> br = m_sessions.insert(psess);
		if (!br.second)
			assert(false && "insert failed");
		return true;
	}

	bool receive(const evtl::connection &conn, const evtl::linearbuf<char> &databuf)
	{
		if (conn.fd == -1)
			assert(false && "fd == -1");
		if (databuf.size() > 1024*512)
		{
			set_error(too_much_data, "too much data");
			return false;
		}

		selsession<RT> *psess = new selsession<RT>;
		psess->init();
		psess->set_recycle_callback(std::bind(&selservice::recycle, this, std::placeholders::_1));
		psess->set_settings(m_setting);

		evtl::sockpairaddr addr(conn);
		psess->set_sockpairaddr(addr);
		psess->set(m_loop);
		psess->set(conn.fd, ev::WRITE);
		psess->set_callback();
		psess->set_data(databuf);
		psess->start();

		std::pair<typename std::set<selsession<RT>*>::const_iterator, bool> br = m_sessions.insert(psess);
		if (!br.second)
			assert(false && "insert failed");
		return true;
	}

private:
	void recycle(selsession<RT> *psess)
	{
		if (psess == nullptr)
			assert(false && "null session");

		size_t n = m_sessions.erase(psess);
		if (n <= 0)
			assert(false && "session not in set");

		psess->deinit();
		delete psess;
	}

	void timer_callback(evtl::simpwtimer &watcher, int revents)
	{
		if (&watcher != &m_timer)
			assert(false && "unexpected watcher");

		double now_s = evtl::timec::sec_f();
		for (typename std::set<selsession<RT>*>::iterator iter = m_sessions.begin(); iter != m_sessions.end(); )
		{
			selsession<RT> *sess = *iter;
			if (now_s - sess->get_starttime() > m_setting.timeout_s)
			{
				sess->timeout_deliver();
				sess->deinit();
				m_sessions.erase(iter++);
				delete sess;
			}
			else
			{
				++iter;
			}
		}

		watcher.set_repeat(_get_repeat(m_setting.timeout_s) + m_loop.now_difference());
		watcher.again();
	}

	double _get_repeat(double timeout_s) const
	{
		if (timeout_s <= 1.) return 1.;
		else if (timeout_s <= 5.) return 2.;
		else if (timeout_s <= 60.) return timeout_s/2.;
		else if (timeout_s <= 120.) return 40.;
		else if (timeout_s <= 300) return 60.;
		else if (timeout_s <= 600) return 120.;

		double rp = timeout_s/5.;
		if (rp > 24*3600.)
			rp = 24*3600.;

		return rp;
	}

private:
	evtl::looprefer   m_loop;
	std::set<selsession<RT>*>  m_sessions;
	settings<RT>      m_setting;
	evtl::simpwtimer  m_timer;
};


} }


#endif


