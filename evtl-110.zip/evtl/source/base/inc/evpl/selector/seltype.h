

#ifndef __EVPL_SELECTOR_SELTYPE_H__
#define __EVPL_SELECTOR_SELTYPE_H__

#include <string>
#include <functional>

#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_in.h>


namespace evpl { namespace selector {


enum class detectexception
{
	none,
	badrequest,
	bufferfull,
	timeout,
	readfail
};

template <class RT>
struct detectdetail
{
	detectdetail(): exceptcode(detectexception::none), errnocode(0), reqtype(), fd(-1)
	{}

	detectexception  exceptcode;
	int              errnocode;
	std::string      errstr;

	RT  reqtype;

	int fd;
	evtl::linearbuf<char>  recvdata;
	evtl::st_var<evtl::sockpairaddr>  addr;
};

enum class detectresult
{
	succeed,
	badrequest,
	needmore
};


template <class RT>
using detectfunc = std::function<detectresult (const evtl::linearbuf<char> &reqbuf, RT &reqtype)>;

template <class RT>
using deliverfunc = std::function<void (detectdetail<RT> &detail)>;


} }


#endif


