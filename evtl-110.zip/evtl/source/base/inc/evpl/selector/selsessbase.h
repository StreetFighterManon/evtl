

#ifndef __EVPL_SELECTOR_SELSESSBASE_H__
#define __EVPL_SELECTOR_SELSESSBASE_H__

#include <sys/types.h>

#include <evtl/evtl_interface.h>
#include <evtl/evtl_linearbuf.h>

#include "seltype.h"


namespace evpl { namespace selector {


template <class RT>
struct settings
{
	settings(): recvbufsize(1024*32), timeout_s(60.)
	{}

	detectfunc<RT>   detect;
	deliverfunc<RT>  deliver;
	ssize_t          recvbufsize;
	double           timeout_s;
};

template <class RT>
struct selsessbase
{
	selsessbase(): ioif(nullptr)
	{}

	evtl::linearbuf<char>  recvbuf;
	evtl::iio  *ioif;

	settings<RT>  setting;
};


} }


#endif


