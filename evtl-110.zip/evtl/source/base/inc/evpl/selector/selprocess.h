

#ifndef __EVPL_SELECTOR_SELPROCESS_H__
#define __EVPL_SELECTOR_SELPROCESS_H__

#include <assert.h>

#include <evtl/evtl_com.h>

#include "seltype.h"
#include "selsessbase.h"
#include "request.h"


namespace evpl { namespace selector {


template <class RT>
class selprocess
{
public:
	selprocess()
	{
		m_base = nullptr;
	}

	void setbase(selsessbase<RT> *base)
	{
		m_base = base;
	}

	void process()
	{
		set_nextstep(evtl::com::nextstep_unknown);

		if (!m_request.isbaseset())
			m_request.setbase(m_base);

		if (!m_request.request_detected())
		{
			typename request<RT>::detectret ret = m_request.detect_request();
			switch (ret)
			{
			case request<RT>::det_finish:
				set_nextstep(evtl::com::nextstep_done);
				break;
			case request<RT>::det_continue:
				set_nextstep(evtl::com::nextstep_wait_to_send);
				break;
			case request<RT>::det_waitrecv:
				set_nextstep(evtl::com::nextstep_wait_to_receive);
				break;
			default:
				assert(false && "illegal ret");
				break;
			}
			return;
		}

		assert(false && "should not reach here");
	}

	evtl::com::process_nextstep get_nextstep() const
	{
		return m_nextstep;
	}

	const detectdetail<RT>& get_detail() const
	{
		return m_request.get_detail();
	}

private:
	void set_nextstep(evtl::com::process_nextstep step)
	{
		m_nextstep = step;
	}

private:
	selsessbase<RT>  *m_base;
	request<RT>   m_request;
	evtl::com::process_nextstep  m_nextstep;
};


} }


#endif


