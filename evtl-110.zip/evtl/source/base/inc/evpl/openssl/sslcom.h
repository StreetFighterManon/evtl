

#ifndef __EVPL_OPENSSL_SSLCOM_H__
#define __EVPL_OPENSSL_SSLCOM_H__

#include <cstring>
#include <string>

#include <openssl/ssl.h>


namespace evpl { namespace openssl {


struct ioresult
{
	ioresult(): resultcode(SSL_ERROR_NONE), errnocode(0)
	{
		memset(errstr, 0, sizeof(errstr));
	}

	ioresult& operator = (const ioresult &that)
	{
		resultcode = that.resultcode;
		errnocode = that.errnocode;
		for (int i = 0; i < 256; i++)
		{
			if (that.errstr[i] != '\0')
				errstr[i] = that.errstr[i];
			else
			{
				errstr[i] = '\0';
				break;
			}
		}

		errstr[255] = '\0';
		return *this;
	}

	bool error_raised() const
	{
		if (resultcode == SSL_ERROR_NONE || resultcode == SSL_ERROR_WANT_READ || resultcode == SSL_ERROR_WANT_WRITE)
			return false;
		return true;
	}

	void reset()
	{
		resultcode = SSL_ERROR_NONE;
		errnocode = 0;
		errstr[0] = '\0';
	}

	int  resultcode;
	int  errnocode;
	char errstr[256];
};

inline std::string resultstring(int resultcode)
{
	switch (resultcode)
	{
	case SSL_ERROR_NONE:          return "SSL_ERROR_NONE";
	case SSL_ERROR_WANT_READ:     return "SSL_ERROR_WANT_READ";
	case SSL_ERROR_WANT_WRITE:    return "SSL_ERROR_WANT_WRITE";
	case SSL_ERROR_ZERO_RETURN:   return "SSL_ERROR_ZERO_RETURN";
	case SSL_ERROR_SYSCALL:       return "SSL_ERROR_SYSCALL";
	case SSL_ERROR_SSL:           return "SSL_ERROR_SSL";
	case SSL_ERROR_WANT_CONNECT:  return "SSL_ERROR_WANT_CONNECT";
	case SSL_ERROR_WANT_ACCEPT:           return "SSL_ERROR_WANT_ACCEPT";
	case SSL_ERROR_WANT_X509_LOOKUP:      return "SSL_ERROR_WANT_X509_LOOKUP";
	case SSL_ERROR_WANT_ASYNC:            return "SSL_ERROR_WANT_ASYNC";
	case SSL_ERROR_WANT_ASYNC_JOB:        return "SSL_ERROR_WANT_ASYNC_JOB";
	case SSL_ERROR_WANT_CLIENT_HELLO_CB:  return "SSL_ERROR_WANT_CLIENT_HELLO_CB";
	default:
		break;
	}

	return "UNKNOWN";
}


} }


#endif


