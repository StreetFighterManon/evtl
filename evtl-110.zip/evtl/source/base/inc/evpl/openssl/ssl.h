

#ifndef __EVPL_OPENSSL_SSL_H__
#define __EVPL_OPENSSL_SSL_H__

#include <assert.h>
#include <errno.h>

#include <openssl/ssl.h>

#include <evtl/evtl_wrapper.h>

#include "sslcom.h"
#include "sslerr.h"


namespace evpl { namespace openssl {


class sslbase
{
public:
	explicit sslbase(SSL *ssl = nullptr): m_ssl(ssl)
	{}

	void set_ssl(SSL *ssl)
	{
		m_ssl = ssl;
	}

	const SSL * get_ssl() const
	{
		return m_ssl;
	}

	SSL * get_ssl()
	{
		return m_ssl;
	}

	void set_fd(int fd)
	{
		if (m_ssl == nullptr)
			assert(false && "ssl nullptr");

		SSL_set_fd(m_ssl, fd);
	}

	int get_fd() const
	{
		if (m_ssl == nullptr)
		{
			assert(false && "ssl nullptr");
			return -1;
		}

		return SSL_get_fd(m_ssl);
	}

	void set_connect_state()
	{
		if (m_ssl == nullptr)
			assert(false && "ssl nullptr");

		SSL_set_connect_state(m_ssl);
	}

	void set_accept_state()
	{
		if (m_ssl == nullptr)
			assert(false && "ssl nullptr");

		SSL_set_accept_state(m_ssl);
	}

	bool is_server() const
	{
		if (m_ssl == nullptr)
			assert(false && "ssl nullptr");

		return SSL_is_server(m_ssl) == 1;
	}

	int handshake()
	{
		if (m_ssl == nullptr)
			assert(false && "ssl nullptr");

		m_result.reset();
		int ret = SSL_do_handshake(m_ssl);
		if (ret != 1)
			_generate_ioerror(ret);
		else
			m_result.resultcode = SSL_ERROR_NONE;

		return ret;
	}

	int read(void *buf, int nbytes)
	{
		if (m_ssl == nullptr)
			assert(false && "ssl nullptr");
		if (buf == nullptr || nbytes <= 0)
			assert(false && "invalid param");

		m_result.reset();
		int ret = SSL_read(m_ssl, buf, nbytes);
		if (ret > 0)
			m_result.resultcode = SSL_ERROR_NONE;
		else
			_generate_ioerror(ret);

		return ret;
	}

	int write(const void *buf, int nbytes)
	{
		if (m_ssl == nullptr)
			assert(false && "ssl nullptr");
		if (buf == nullptr || nbytes <= 0)
			assert(false && "invalid param");

		m_result.reset();
		int ret = SSL_write(m_ssl, buf, nbytes);
		if (ret > 0)
			m_result.resultcode = SSL_ERROR_NONE;
		else
			_generate_ioerror(ret);

		return ret;
	}

	int shutdown()
	{
		if (m_ssl == nullptr)
			assert(false && "ssl nullptr");

		m_result.reset();
		int ret = SSL_shutdown(m_ssl);
		if (ret < 0)
			_generate_ioerror(ret);
		else
			m_result.resultcode = SSL_ERROR_NONE;

		return ret;
	}

	const ioresult& get_result() const
	{
		return m_result;
	}

	const ioresult& get_first_error() const
	{
		return m_first_error;
	}

	void free()
	{
		if (m_ssl != nullptr)
			SSL_free(m_ssl);
		m_ssl = nullptr;
	}

	void reset()
	{
		m_ssl = nullptr;
		m_result.reset();
		m_first_error.reset();
	}

protected:
	void _generate_ioerror(int ret)
	{
		int resultcode = SSL_get_error(m_ssl, ret);

		m_result.resultcode = resultcode;
		switch (resultcode)
		{
		case SSL_ERROR_NONE:
			break;
		case SSL_ERROR_WANT_READ:
			break;
		case SSL_ERROR_WANT_WRITE:
			break;
		case SSL_ERROR_ZERO_RETURN:
			break;
		case SSL_ERROR_SYSCALL:
			{
				m_result.errnocode = errno;
				sslerr::get_errstr(m_result.errstr, sizeof(m_result.errstr));
			}
			break;
		case SSL_ERROR_SSL:
			sslerr::get_errstr(m_result.errstr, sizeof(m_result.errstr));
			break;
		default:
			sslerr::get_errstr(m_result.errstr, sizeof(m_result.errstr));
			break;
		}

		set_first_error(m_result);
	}

	void set_first_error(const ioresult &result)
	{
		if (!m_first_error.error_raised() && result.error_raised())
			m_first_error = result;
	}

	void move_first_error_to_result()
	{
		m_result = m_first_error;
	}

private:
	SSL      *m_ssl;
	ioresult  m_result;
	ioresult  m_first_error;
};


class simpssl : public sslbase
{
public:
	simpssl(): m_state_set(false)
	{}

	bool is_state_set() const
	{
		return m_state_set;
	}

	void set_connect_state()
	{
		sslbase::set_connect_state();
		m_state_set = true;
	}

	void set_accept_state()
	{
		sslbase::set_accept_state();
		m_state_set = true;
	}

	bool handshake_finished() const
	{
		if (!m_handshake_result.isset())
			return false;
		else
		{
			const ioresult &result = m_handshake_result.refer();
			if (result.resultcode == SSL_ERROR_WANT_READ || result.resultcode == SSL_ERROR_WANT_WRITE)
				return false;
		}

		return true;
	}

	int handshake()
	{
		const ioresult &first = get_first_error();
		if (first.error_raised())
		{
			move_first_error_to_result();
			m_handshake_result.set_assign(first);
			return -1;
		}

		int ret = sslbase::handshake();
		const ioresult& result = sslbase::get_result();
		m_handshake_result.set_assign(result);
		return ret;
	}

	const evtl::var<ioresult>& get_handshake_result() const
	{
		return m_handshake_result;
	}

	int read(void *buf, int nbytes)
	{
		if (buf == nullptr || nbytes <= 0)
			assert(false && "invalid buffer");

		const ioresult &first = get_first_error();
		if (first.error_raised())
		{
			move_first_error_to_result();
			return -1;
		}

		return sslbase::read(buf, nbytes);
	}

	int readv(void *buf, int nbytes, int retry = 0, int *trytimes = nullptr)
	{
		if (buf == nullptr || nbytes <= 0)
			assert(false && "invalid buffer");

		if (trytimes != nullptr)
			*trytimes = 0;

		const ioresult &first = get_first_error();
		if (first.error_raised())
		{
			move_first_error_to_result();
			return -1;
		}

		int tryn = retry;
		int total = 0;

		do
		{
			if (nbytes - total <= 0)
				break;

			if (trytimes != nullptr)
				++*trytimes;

			int ret = sslbase::read(static_cast<char *>(buf) + total, nbytes - total);
			if (ret > 0)
			{
				if (ret > nbytes - total)
					assert(false && "read exception");
				total += ret;
			}
			else
			{
				if (total == 0)
					total = ret;
				break;
			}
		}
		while (tryn-- > 0);

		return total;
	}

	int write(const void *buf, int nbytes)
	{
		if (buf == nullptr || nbytes <= 0)
			assert(false && "invalid buffer");

		const ioresult &first = get_first_error();
		if (first.error_raised())
		{
			move_first_error_to_result();
			return -1;
		}

		return sslbase::write(buf, nbytes);
	}

	int writev(const void *buf, int nbytes, int retry = 0, int *trytimes = nullptr)
	{
		if (buf == nullptr || nbytes <= 0)
			assert(false && "invalid buffer");

		if (trytimes != nullptr)
			*trytimes = 0;

		const ioresult &first = get_first_error();
		if (first.error_raised())
		{
			move_first_error_to_result();
			return -1;
		}

		int tryn = retry;
		int total = 0;

		do
		{
			if (nbytes - total <= 0)
				break;

			if (trytimes != nullptr)
				++*trytimes;

			int ret = sslbase::write(static_cast<const char *>(buf) + total, nbytes - total);
			if (ret > 0)
			{
				if (ret > nbytes - total)
					assert(false && "write exception");
				total += ret;
			}
			else
			{
				if (total == 0)
					total = ret;
				break;
			}
		}
		while (tryn-- > 0);

		return total;
	}

	void reset()
	{
		m_state_set = false;
		m_handshake_result.reset();
		sslbase::reset();
	}

private:
	bool  m_state_set;
	evtl::var<ioresult>  m_handshake_result;
};


} }


#endif


