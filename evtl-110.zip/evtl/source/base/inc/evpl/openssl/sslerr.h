

#ifndef __EVPL_OPENSSL_SSLERR_H__
#define __EVPL_OPENSSL_SSLERR_H__

#include <string>

#include <openssl/err.h>


namespace evpl { namespace openssl {


class sslerr
{
public:
	static unsigned long get_errcode()
	{
		return ERR_get_error();
	}

	static void get_errstr(char *buf, int len)
	{
		if (buf == nullptr || len <= 0)
			assert(false && "invalid buf");

		unsigned long e = ERR_get_error();
		ERR_error_string_n(e, buf, len);
		buf[len - 1] = '\0';
	}

	static std::string get_errstr()
	{
		char buf[256] = { 0 };

		unsigned long e = ERR_get_error();
		ERR_error_string_n(e, buf, sizeof(buf));
		buf[255] = '\0';
		return buf;
	}

	static void clear_error()
	{
		ERR_clear_error();
	}
};


} }


#endif


