

#ifndef __EVTL_DAEMON_H__
#define __EVTL_DAEMON_H__

#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <limits.h>
#include <assert.h>

#include <string>
#include <cstring>

extern char ** environ;


namespace evtl
{


class daemonize
{
public:
	static bool daemon(const std::string &workdir = std::string())
	{
		//run in background.
		pid_t pid = ::fork();
		if (pid == -1)
			return false;
		else if (pid != 0)
			::exit(0);  //parent exit

		//now child inhert console, login session and process group from parent, must be free from them.
		if (::setsid() == -1)
			return false;

		//prevent program from reopenning console.
		pid = ::fork();
		if (pid == -1)
			return false;
		else if (pid != 0)
			::exit(0);  //parent exit

		//change working directory
		if (!workdir.empty())
		{
			if (::chdir(workdir.c_str()) != 0)
				return false;
		}

		//umask 0
		::umask(0);

		return true;
	}

	static bool singleton(const std::string &filename = std::string(), bool absolutepath = false)
	{
		std::string actfilename;

		if (!absolutepath || filename.empty())
		{
			char s[PATH_MAX] = { 0 };
			int rt = readlink("/proc/self/exe", s, sizeof(s) - 1);
			if (rt > 0 && rt < PATH_MAX)
				s[rt] = '\0';
			else
				return false;

			actfilename = s;

			if (filename.empty())
				actfilename += ".singleton";
			else
				actfilename += filename;
		}
		else
		{
			actfilename = filename;
		}

		int fd = ::open(actfilename.c_str(), O_CREAT | O_RDWR, 0600);
		if (fd == -1)
			return false;

		struct flock lock;
		memset(&lock, 0, sizeof(lock));
		lock.l_type   = F_WRLCK;
		lock.l_whence = SEEK_SET;
		lock.l_start  = 0;
		lock.l_len    = 0;

		int rt = ::fcntl(fd, F_SETLK, &lock);
		if (rt == 0)
			return true;

		return false;
	}

	static bool stdout_redirect(int fd)
	{
		if (::dup2(fd, STDOUT_FILENO) == -1)
			return false;

		return true;
	}

	static bool stdout_redirect(const std::string &filename)
	{
		if (filename.empty())
			return false;

		int fd = ::open(filename.c_str(), O_CREAT | O_RDWR, 0644);
		if (fd == -1)
			return false;

		if (::dup2(fd, STDOUT_FILENO) == -1)
			return false;

		return true;
	}

	static bool stderr_redirect(int fd)
	{
		if (::dup2(fd, STDERR_FILENO) == -1)
			return false;

		return true;
	}

	static bool stderr_redirect(const std::string &filename)
	{
		if (filename.empty())
			return false;

		int fd = ::open(filename.c_str(), O_CREAT | O_RDWR, 0644);
		if (fd == -1)
			return false;

		if (::dup2(fd, STDERR_FILENO) == -1)
			return false;

		return true;
	}
};


class proctitle
{
public:
	proctitle(): m_argv(nullptr), m_argv_last(nullptr)
	{}

	static void init(char **argv)
	{
		proctitle::_singleton()->_init_setproctitle(argv);
	}

	static void setproctitle(const char *title)
	{
		proctitle::_singleton()->_setproctitle(title);
	}

private:
	static proctitle * _singleton()
	{
		static proctitle *p = new proctitle;
		if (p == nullptr)
			assert(false && "malloc failed");
		return p;
	}

	void _init_setproctitle(char **argv)
	{
		char *p = nullptr;
		size_t size = 0;
		uintptr_t i = 0;

		m_argv = argv;

		for (i = 0; environ[i]; i++)
		{
			size += strlen(environ[i]) + 1;
		}

		p = (char *)malloc(size);
		if (p == nullptr)
		{
			assert(false && "malloc failed");
			return;
		}

		m_argv_last = m_argv[0];

		for (i = 0; m_argv[i]; i++)
		{
			if (m_argv_last == m_argv[i])
			{
				m_argv_last = m_argv[i] + strlen(m_argv[i]) + 1;
			}
		}

		for (i = 0; environ[i]; i++)
		{
			if (m_argv_last == environ[i])
			{
				size = strlen(environ[i]) + 1;
				m_argv_last = environ[i] + size;

				_ngx_cpystrn(p, (char *) environ[i], size);
				environ[i] = (char *)p;
				p += size;
			}
		}

		m_argv_last--;
	}

	void _setproctitle(const char *title)
	{
		if (title == nullptr)
			assert(false && "invalid param");

		m_argv[1] = NULL;

		char *p = _ngx_cpystrn((char *)m_argv[0], (char *)title, m_argv_last - m_argv[0]);

		if (m_argv_last - (char *)p > 0)
			memset(p, 0, m_argv_last - (char *)p);
	}

	static char * _ngx_cpystrn(char *dst, const char *src, size_t n)
	{
		if (n == 0)
			return dst;

		while (--n)
		{
			*dst = *src;

			if (*dst == '\0')
				return dst;

			dst++;
			src++;
		}

		*dst = '\0';
		return dst;
	}

private:
	char **m_argv;
	char  *m_argv_last;
};


}


#endif


