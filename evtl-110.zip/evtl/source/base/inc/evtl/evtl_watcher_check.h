

#ifndef __EVTL_WATCHER_CHECK_H__
#define __EVTL_WATCHER_CHECK_H__

#include <assert.h>

#include <utility>
#include <functional>

#include <ev/ev++.h>

#include "evtl_gcc.h"
#include "evtl_copyable.h"
#include "evtl_eventloop.h"


namespace evtl
{


template <class T>
class watcher_check : public nocopyc
{
public:
	typedef std::function<void (T &watcher, int revents)>   check_callback_t;

	watcher_check()
	{
		m_check.set(nullptr);
		m_check.set<watcher_check, &watcher_check::_callback>(this);
	}

	void set(looprefer loop)
	{
		if (m_check.is_active())
			m_check.stop();

		m_check.set(loop.ref());
	}

	void set_callback()
	{
		if (m_check.is_active())
			m_check.stop();

		m_check.set<watcher_check, &watcher_check::_callback>(this);
		m_check_callback = nullptr;
	}

	void set_callback(check_callback_t cb)
	{
		if (m_check.is_active())
			m_check.stop();

		m_check.set<watcher_check, &watcher_check::_callback>(this);
		m_check_callback = std::move(cb);
	}

	void set_priority(int priority)
	{
		if (m_check.is_active())
			m_check.stop();

		ev_set_priority(static_cast<ev_check *>(&m_check), priority);
	}

	int get_priority() const
	{
		return ev_priority(static_cast<ev_check *>(&m_check));
	}

	void stop()
	{
		m_check.stop();
	}

	void start()
	{
		m_check.start();
	}

	bool is_active() const
	{
		return m_check.is_active();
	}

	bool is_pending() const
	{
		return m_check.is_pending();
	}

	int clear_pending()
	{
		if (m_check.EV_A == nullptr)
			assert(false && "null loop");

		return ::ev_clear_pending(m_check.EV_A, static_cast<ev_check *>(&m_check));
	}

	looprefer get_loop() const
	{
		return m_check.EV_A;
	}

private:
	void check_callback(T &watcher, int revents) { assert(false && "unset callback"); }

	void _callback(ev::check &watcher, int revents)
	{
		if (evunlike((revents & ev::ERROR) != 0))
			assert(false && "ev_error");
		if (evunlike(&watcher != &m_check))
			assert(false && "unexpected watcher");

		if (m_check_callback)
			m_check_callback(*static_cast<T*>(this), revents);
		else
			static_cast<T*>(this)->check_callback(*static_cast<T*>(this), revents);
	}

private:
	ev::check         m_check;
	check_callback_t  m_check_callback;
};

class simpwcheck : public watcher_check<simpwcheck>
{};


}


#endif


