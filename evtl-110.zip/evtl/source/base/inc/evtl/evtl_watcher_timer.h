

#ifndef __EVTL_WATCHER_TIMER_H__
#define __EVTL_WATCHER_TIMER_H__

#include <assert.h>

#include <utility>
#include <functional>

#include <ev/ev++.h>

#include "evtl_gcc.h"
#include "evtl_copyable.h"
#include "evtl_eventloop.h"


namespace evtl
{


template <class T>
class watcher_timer : public nocopyc
{
public:
	typedef std::function<void (T &watcher, int revents)>   timer_callback_t;

	watcher_timer()
	{
		m_timer.set(nullptr);
		m_timer.set(0., 0.);
		m_timer.set<watcher_timer, &watcher_timer::_callback>(this);
	}

	void set(looprefer loop)
	{
		if (m_timer.is_active())
			m_timer.stop();

		m_timer.set(loop.ref());
	}

	bool set(looprefer loop, ev::tstamp after, ev::tstamp repeat)
	{
		if (after < 0. || repeat < 0.)
			return false;

		if (m_timer.is_active())
			m_timer.stop();

		m_timer.set(loop.ref());
		m_timer.set(after, repeat);
		return true;
	}

	void set_callback()
	{
		if (m_timer.is_active())
			m_timer.stop();

		m_timer.set<watcher_timer, &watcher_timer::_callback>(this);
		m_timer_callback = nullptr;
	}

	void set_callback(timer_callback_t cb)
	{
		if (m_timer.is_active())
			m_timer.stop();

		m_timer.set<watcher_timer, &watcher_timer::_callback>(this);
		m_timer_callback = std::move(cb);
	}

	bool set(ev::tstamp after, ev::tstamp repeat)
	{
		if (after < 0. || repeat < 0.)
			return false;

		if (m_timer.is_active())
			m_timer.stop();

		m_timer.set(after, repeat);
		return true;
	}

	void set_repeat(ev::tstamp repeat)
	{
		if (repeat < 0.)
			return;

		m_timer.repeat = repeat;
	}

	void set_priority(int priority)
	{
		if (m_timer.is_active())
			m_timer.stop();

		ev_set_priority(static_cast<ev_timer *>(&m_timer), priority);
	}

	int get_priority() const
	{
		return ev_priority(static_cast<ev_timer *>(&m_timer));
	}

	void stop()
	{
		m_timer.stop();
	}

	void start()
	{
		m_timer.start();
	}

	void again()
	{
		m_timer.again();
	}

	ev::tstamp remaining()
	{
		return m_timer.remaining();
	}

	bool is_active() const
	{
		return m_timer.is_active();
	}

	bool is_pending() const
	{
		return m_timer.is_pending();
	}

	int clear_pending()
	{
		if (m_timer.EV_A == nullptr)
			assert(false && "null loop");

		return ::ev_clear_pending(m_timer.EV_A, static_cast<ev_timer *>(&m_timer));
	}

	looprefer get_loop() const
	{
		return m_timer.EV_A;
	}

private:
	void timer_callback(T &watcher, int revents) { assert(false && "unset callback"); }

	void _callback(ev::timer &watcher, int revents)
	{
		if (evunlike((revents & ev::ERROR) != 0))
			assert(false && "ev_error");
		if (evunlike(&watcher != &m_timer))
			assert(false && "unexpected watcher");

		if (m_timer_callback)
			m_timer_callback(*static_cast<T*>(this), revents);
		else
			static_cast<T*>(this)->timer_callback(*static_cast<T*>(this), revents);
	}

private:
	ev::timer         m_timer;
	timer_callback_t  m_timer_callback;
};

class simpwtimer : public watcher_timer<simpwtimer>
{};


}


#endif


