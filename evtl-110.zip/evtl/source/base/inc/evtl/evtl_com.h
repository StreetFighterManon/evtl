

#ifndef __EVTL_COM_H__
#define __EVTL_COM_H__

#include <assert.h>

#include <sstream>
#include <string>


namespace evtl { namespace com {


/*
     Only nextstep_done_end mean that the task has completely
   over and you should do recycle, nextstep_error as well.
     In the multiroute programs, nextstep_done may not indicate
   the end of the task because one route which return nextstep_done maybe handled a
   routelock just now which made a previous route keep in nextstep_none state.
     The route lock MUST be freed before returning nextstep_done,
   after which the state should fall into nextstep_done_end naturely.
*/
enum process_nextstep
{
	nextstep_unknown,
	nextstep_wait_to_receive,
	nextstep_wait_to_send,
	nextstep_wait_to_receive_send,
	nextstep_continue,
	nextstep_stop,
	nextstep_none,
	nextstep_cycledone,
	nextstep_done,
	nextstep_done_end,
	nextstep_error,
	nextstep_other,
	nextstep_user1,
	nextstep_user2,
	nextstep_user3,
	nextstep_user4,
	nextstep_user5,
	nextstep_user6,
	nextstep_user7,
	nextstep_user8,
	nextstep_user9,
	nextstep_count
};

struct nextstepstream
{
	nextstepstream()
	{
		clear();
	}

	void set(process_nextstep nstep)
	{
		if (nstep < 0 || nstep >= nextstep_count)
			assert(false && "invalid step");
		clear();
		m_steptable[nstep] = true;
	}

	nextstepstream& operator << (process_nextstep nstep)
	{
		if (nstep < 0 || nstep >= nextstep_count)
			assert(false && "invalid step");
		m_steptable[nstep] = true;
		return *this;
	}

	nextstepstream& operator << (const nextstepstream &stepstream)
	{
		for (int i = 0; i < nextstep_count; i++)
		{
			if (stepstream.m_steptable[i])
				m_steptable[i] = true;
		}
		return *this;
	}

	bool have(process_nextstep nstep) const
	{
		if (nstep < 0 || nstep >= nextstep_count)
			assert(false && "invalid step");
		return m_steptable[nstep];
	}

	bool have_one(const nextstepstream &stepstream) const
	{
		for (int i = 0; i < nextstep_count; i++)
		{
			if (m_steptable[i] && stepstream.m_steptable[i])
				return true;
		}
		return false;
	}

	bool operator == (const nextstepstream &stepstream) const
	{
		for (int i = 0; i < nextstep_count; i++)
		{
			if (m_steptable[i] != stepstream.m_steptable[i])
				return false;
		}
		return true;
	}

	bool operator == (process_nextstep nstep) const
	{
		if (nstep < 0 || nstep >= nextstep_count)
			assert(false && "invalid step");

		for (int i = 0; i < nextstep_count; i++)
		{
			if (i == nstep)
			{
				if (!m_steptable[i])
					return false;
			}
			else
			{
				if (m_steptable[i])
					return false;
			}
		}
		return true;
	}

	bool operator != (const nextstepstream &stepstream) const
	{
		return !this->operator == (stepstream);
	}

	bool operator <= (const nextstepstream &stepstream) const
	{
		for (int i = 0; i < nextstep_count; i++)
		{
			if (!stepstream.m_steptable[i])
			{
				if (m_steptable[i])
					return false;
			}
		}
		return true;
	}

	bool operator >= (const nextstepstream &stepstream) const
	{
		for (int i = 0; i < nextstep_count; i++)
		{
			if (stepstream.m_steptable[i])
			{
				if (!m_steptable[i])
					return false;
			}
		}
		return true;
	}

	bool empty() const
	{
		for (int i = 0; i < nextstep_count; i++)
		{
			if (m_steptable[i])
				return false;
		}
		return true;
	}

	process_nextstep elect() const
	{
		if (m_steptable[nextstep_error])      return nextstep_error;

		if (m_steptable[nextstep_user9])      return nextstep_user9;
		if (m_steptable[nextstep_user8])      return nextstep_user8;
		if (m_steptable[nextstep_user7])      return nextstep_user7;
		if (m_steptable[nextstep_user6])      return nextstep_user6;
		if (m_steptable[nextstep_user5])      return nextstep_user5;
		if (m_steptable[nextstep_user4])      return nextstep_user4;
		if (m_steptable[nextstep_user3])      return nextstep_user3;
		if (m_steptable[nextstep_user2])      return nextstep_user2;
		if (m_steptable[nextstep_user1])      return nextstep_user1;

		if (m_steptable[nextstep_other])      return nextstep_other;
		/* cycledone like the continue, but should only reset the subprocess */
		if (m_steptable[nextstep_cycledone])  return nextstep_cycledone;
		if (m_steptable[nextstep_continue])   return nextstep_continue;
		if (m_steptable[nextstep_wait_to_receive_send])  return nextstep_wait_to_receive_send;
		if (m_steptable[nextstep_wait_to_send])
		{
			if (m_steptable[nextstep_wait_to_receive])
				return nextstep_wait_to_receive_send;
			else
				return nextstep_wait_to_send;
		}
		if (m_steptable[nextstep_wait_to_receive])  return nextstep_wait_to_receive;
		if (m_steptable[nextstep_stop])       return nextstep_stop;

		if (m_steptable[nextstep_done])       return nextstep_done;
		if (m_steptable[nextstep_none])       return nextstep_none;
		if (m_steptable[nextstep_done_end])   return nextstep_done_end;

		return nextstep_unknown;
	}

	void clear()
	{
		for (int i = 0; i < nextstep_count; i++)
		{
			m_steptable[i] = false;
		}
	}

private:
	bool  m_steptable[nextstep_count];
};


enum rwresult
{
	rwresult_allright    = 0,
	rwresult_read_end    = 0x01,
	rwresult_read_error  = 0x02,
	rwresult_write_error = 0x04
};

struct rwstatus
{
	rwstatus(): result(rwresult_allright), rd_errno(0), wr_errno(0)
	{}

	void orset(rwresult res, int errnocode)
	{
		if (res == rwresult_read_end)
		{
			result |= res;
		}
		else if (res == rwresult_read_error)
		{
			result |= res;
			rd_errno = errnocode;
		}
		else if (res == rwresult_write_error)
		{
			result |= res;
			wr_errno = errnocode;
		}
	}

	void reset()
	{
		result = rwresult_allright;
		rd_errno = 0;
		wr_errno = 0;
	}

	bool error_raised() const
	{
		return result != rwresult_allright;
	}

	bool readerror_raised() const
	{
		return (result & (rwresult_read_end | rwresult_read_error)) != 0;
	}

	bool writeerror_raised() const
	{
		return (result & rwresult_write_error) != 0;
	}

	bool read_end() const
	{
		return (result & rwresult_read_end) != 0;
	}

	bool read_error() const
	{
		return (result & rwresult_read_error) != 0;
	}

	bool write_error() const
	{
		return (result & rwresult_write_error) != 0;
	}

	unsigned int get_result() const
	{
		return result;
	}

	int read_errno() const
	{
		return rd_errno;
	}

	int write_errno() const
	{
		return wr_errno;
	}

	std::string tostring()
	{
		if (result == rwresult_allright)
			return "allright";

		bool split = false;
		std::stringstream ss;
		if ((result & rwresult_read_error) != 0)
		{
			ss << "rderrno:" << rd_errno;
			split = true;
		}

		if ((result & rwresult_write_error) != 0)
		{
			if (split)
				ss << " ";
			ss << "wrerrno:" << wr_errno;
			split = true;
		}

		if ((result & rwresult_read_end) != 0)
		{
			if (split)
				ss << " ";
			ss << "rdend";
		}

		return ss.str();
	}

private:
	unsigned int  result;
	int           rd_errno;
	int           wr_errno;
};


} }


#endif


