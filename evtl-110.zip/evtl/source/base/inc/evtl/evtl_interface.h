

#ifndef __EVTL_INTERFACE_H__
#define __EVTL_INTERFACE_H__

#include <sys/types.h>
#include <cstdint>


namespace evtl
{


struct itask
{
	virtual ~itask()
	{}

	virtual void run(void *arg) = 0;
};

template <class PT>
struct ictrl
{
	virtual ~ictrl()
	{}

	virtual void circle_begin(void *arg, int64_t id) = 0;

	virtual void circle_accompany(void *arg, int64_t id, const PT &ptask) = 0;

	virtual void circle_end(void *arg, int64_t id, int64_t taskcount, int64_t consumed_us) = 0;
};


struct iio
{
	virtual ~iio()
	{}

	virtual ssize_t io_read(void *buffer, ssize_t nbytes) = 0;

	virtual ssize_t io_write(const void *buffer, ssize_t nbytes) = 0;
};


}


#endif


