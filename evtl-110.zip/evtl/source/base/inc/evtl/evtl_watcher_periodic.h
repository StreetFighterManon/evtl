

#ifndef __EVTL_WATCHER_PERIODIC_H__
#define __EVTL_WATCHER_PERIODIC_H__

#include <assert.h>

#include <utility>
#include <functional>

#include <ev/ev++.h>

#include "evtl_gcc.h"
#include "evtl_copyable.h"
#include "evtl_eventloop.h"


namespace evtl
{


template <class T>
class watcher_periodic : public nocopyc
{
public:
	typedef std::function<void (T &watcher, int revents)>   periodic_callback_t;

	watcher_periodic()
	{
		m_periodic.set(nullptr);
		m_periodic.set(0., 0.);
		m_periodic.set<watcher_periodic, &watcher_periodic::_callback>(this);
	}

	void set(looprefer loop)
	{
		if (m_periodic.is_active())
			m_periodic.stop();

		m_periodic.set(loop.ref());
	}

	bool set(looprefer loop, ev::tstamp offset, ev::tstamp interval)
	{
		if (offset < 0. || interval < 0.)
			return false;

		if (m_periodic.is_active())
			m_periodic.stop();

		m_periodic.set(loop.ref());
		m_periodic.set(offset, interval);
		return true;
	}

	void set_callback()
	{
		if (m_periodic.is_active())
			m_periodic.stop();

		m_periodic.set<watcher_periodic, &watcher_periodic::_callback>(this);
		m_periodic_callback = nullptr;
	}

	void set_callback(periodic_callback_t cb)
	{
		if (m_periodic.is_active())
			m_periodic.stop();

		m_periodic.set<watcher_periodic, &watcher_periodic::_callback>(this);
		m_periodic_callback = std::move(cb);
	}

	bool set(ev::tstamp offset, ev::tstamp interval)
	{
		if (offset < 0. || interval < 0.)
			return false;

		if (m_periodic.is_active())
			m_periodic.stop();

		m_periodic.set(offset, interval);
		return true;
	}

	void set_priority(int priority)
	{
		if (m_periodic.is_active())
			m_periodic.stop();

		ev_set_priority(static_cast<ev_periodic *>(&m_periodic), priority);
	}

	int get_priority() const
	{
		return ev_priority(static_cast<ev_periodic *>(&m_periodic));
	}

	void stop()
	{
		m_periodic.stop();
	}

	void start()
	{
		m_periodic.start();
	}

	void again()
	{
		m_periodic.again();
	}

	bool is_active() const
	{
		return m_periodic.is_active();
	}

	bool is_pending() const
	{
		return m_periodic.is_pending();
	}

	int clear_pending()
	{
		if (m_periodic.EV_A == nullptr)
			assert(false && "null loop");

		return ::ev_clear_pending(m_periodic.EV_A, static_cast<ev_periodic *>(&m_periodic));
	}

	looprefer get_loop() const
	{
		return m_periodic.EV_A;
	}

private:
	void periodic_callback(T &watcher, int revents) { assert(false && "unset callback"); }

	void _callback(ev::periodic &watcher, int revents)
	{
		if (evunlike((revents & ev::ERROR) != 0))
			assert(false && "ev_error");
		if (evunlike(&watcher != &m_periodic))
			assert(false && "unexpected watcher");

		if (m_periodic_callback)
			m_periodic_callback(*static_cast<T*>(this), revents);
		else
			static_cast<T*>(this)->periodic_callback(*static_cast<T*>(this), revents);
	}

private:
	ev::periodic         m_periodic;
	periodic_callback_t  m_periodic_callback;
};

class simpwperiodic : public watcher_periodic<simpwperiodic>
{};


}


#endif


