

#ifndef __EVTL_WATCHER_IDLE_H__
#define __EVTL_WATCHER_IDLE_H__

#include <assert.h>

#include <utility>
#include <functional>

#include <ev/ev++.h>

#include "evtl_gcc.h"
#include "evtl_copyable.h"
#include "evtl_eventloop.h"


namespace evtl
{


template <class T>
class watcher_idle : public nocopyc
{
public:
	typedef std::function<void (T &watcher, int revents)>   idle_callback_t;

	watcher_idle()
	{
		m_idle.set(nullptr);
		m_idle.set<watcher_idle, &watcher_idle::_callback>(this);
	}

	void set(looprefer loop)
	{
		if (m_idle.is_active())
			m_idle.stop();

		m_idle.set(loop.ref());
	}

	void set_callback()
	{
		if (m_idle.is_active())
			m_idle.stop();

		m_idle.set<watcher_idle, &watcher_idle::_callback>(this);
		m_idle_callback = nullptr;
	}

	void set_callback(idle_callback_t cb)
	{
		if (m_idle.is_active())
			m_idle.stop();

		m_idle.set<watcher_idle, &watcher_idle::_callback>(this);
		m_idle_callback = std::move(cb);
	}

	void set_priority(int priority)
	{
		if (m_idle.is_active())
			m_idle.stop();

		ev_set_priority(static_cast<ev_idle *>(&m_idle), priority);
	}

	int get_priority() const
	{
		return ev_priority(static_cast<ev_idle *>(&m_idle));
	}

	void stop()
	{
		m_idle.stop();
	}

	void start()
	{
		m_idle.start();
	}

	bool is_active() const
	{
		return m_idle.is_active();
	}

	bool is_pending() const
	{
		return m_idle.is_pending();
	}

	int clear_pending()
	{
		if (m_idle.EV_A == nullptr)
			assert(false && "null loop");

		return ::ev_clear_pending(m_idle.EV_A, static_cast<ev_idle *>(&m_idle));
	}

	looprefer get_loop() const
	{
		return m_idle.EV_A;
	}

private:
	void idle_callback(T &watcher, int revents) { assert(false && "unset callback"); }

	void _callback(ev::idle &watcher, int revents)
	{
		if (evunlike((revents & ev::ERROR) != 0))
			assert(false && "ev_error");
		if (evunlike(&watcher != &m_idle))
			assert(false && "unexpected watcher");

		if (m_idle_callback)
			m_idle_callback(*static_cast<T*>(this), revents);
		else
			static_cast<T*>(this)->idle_callback(*static_cast<T*>(this), revents);
	}

private:
	ev::idle         m_idle;
	idle_callback_t  m_idle_callback;
};

class simpwidle : public watcher_idle<simpwidle>
{};


}


#endif


