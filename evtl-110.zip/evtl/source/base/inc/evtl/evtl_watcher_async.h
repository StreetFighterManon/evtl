

#ifndef __EVTL_WATCHER_ASYNC_H__
#define __EVTL_WATCHER_ASYNC_H__

#include <assert.h>

#include <utility>
#include <functional>

#include <ev/ev++.h>

#include "evtl_gcc.h"
#include "evtl_copyable.h"
#include "evtl_eventloop.h"


namespace evtl
{


template <class T>
class watcher_async : public nocopyc
{
public:
	typedef std::function<void (T &watcher, int revents)>   async_callback_t;

	watcher_async()
	{
		m_async.set(nullptr);
		m_async.set<watcher_async, &watcher_async::_callback>(this);
	}

	void set(looprefer loop)
	{
		if (m_async.is_active())
			m_async.stop();

		m_async.set(loop.ref());
	}

	void set_callback()
	{
		if (m_async.is_active())
			m_async.stop();

		m_async.set<watcher_async, &watcher_async::_callback>(this);
		m_async_callback = nullptr;
	}

	void set_callback(async_callback_t cb)
	{
		if (m_async.is_active())
			m_async.stop();

		m_async.set<watcher_async, &watcher_async::_callback>(this);
		m_async_callback = std::move(cb);
	}

	void set_priority(int priority)
	{
		if (m_async.is_active())
			m_async.stop();

		ev_set_priority(static_cast<ev_async *>(&m_async), priority);
	}

	int get_priority() const
	{
		return ev_priority(static_cast<ev_async *>(&m_async));
	}

	void stop()
	{
		m_async.stop();
	}

	void start()
	{
		m_async.start();
	}

	bool is_active() const
	{
		return m_async.is_active();
	}

	bool is_pending() const
	{
		return m_async.is_pending();
	}

	int clear_pending()
	{
		if (m_async.EV_A == nullptr)
			assert(false && "null loop");

		return ::ev_clear_pending(m_async.EV_A, static_cast<ev_async *>(&m_async));
	}

	bool async_pending() const
	{
		return ev_async_pending(static_cast<ev_async *>(&m_async));
	}

	looprefer get_loop() const
	{
		return m_async.EV_A;
	}

	void send()
	{
		m_async.send();
	}

private:
	void async_callback(T &watcher, int revents) { assert(false && "unset callback"); }

	void _callback(ev::async &watcher, int revents)
	{
		if (evunlike((revents & ev::ERROR) != 0))
			assert(false && "ev_error");
		if (evunlike(&watcher != &m_async))
			assert(false && "unexpected watcher");

		if (m_async_callback)
			m_async_callback(*static_cast<T*>(this), revents);
		else
			static_cast<T*>(this)->async_callback(*static_cast<T*>(this), revents);
	}

private:
	ev::async         m_async;
	async_callback_t  m_async_callback;
};

class simpwasync : public watcher_async<simpwasync>
{};


}


#endif


