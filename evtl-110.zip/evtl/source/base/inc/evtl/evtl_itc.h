

#ifndef __EVTL_ITC_H__
#define __EVTL_ITC_H__

#include <functional>
#include <memory>
#include <string>
#include <atomic>


namespace evtl { namespace itc {


template <class T, class _key_T = void *, class _id_T = std::string>
struct interrupt_message
{
	interrupt_message()
		: port(0), key(), id(), event(0)
	{}

	interrupt_message(std::shared_ptr<T> link, int _port, const _key_T &_key, const _id_T &_id, int _event, const std::string &desc)
		: datalink(link), port(_port), key(_key), id(_id), event(_event), description(desc)
	{}

	interrupt_message(const interrupt_message &that) = default;
	interrupt_message(interrupt_message &&that) noexcept = default;

	interrupt_message& operator = (const interrupt_message &that) = default;
	interrupt_message& operator = (interrupt_message &&that) = default;

	std::shared_ptr<T>  datalink;

	int          port;
	_key_T       key;
	_id_T        id;
	int          event;
	std::string  description;
};

template <class T, class _key_T = void *, class _id_T = std::string>
using interrupt_entrance = std::function<bool (const interrupt_message<T, _key_T, _id_T> &message)>;


template <class T, class _key_T = void *, class _id_T = std::string>
class baseprotocol
{
public:
	typedef std::function<bool (std::shared_ptr<T> datalink)>  intr_connector;
	typedef interrupt_message<T, _key_T, _id_T>                intr_message;
	typedef interrupt_entrance<T, _key_T, _id_T>               intr_entrance;

	baseprotocol()
		: m_id(), m_group_id(),
		m_syn(false), m_local_port(0), m_remote_port(0), m_local_key(), m_local_fin(false),
		m_syn_ack(false), m_remote_key(), m_remote_fin(false)
	{}

	bool interrupt_connect(std::shared_ptr<T> link)
	{
		return m_intconnector(link);
	}

	bool interrupt_local(std::shared_ptr<T> link, int event, const std::string &description = std::string())
	{
		intr_message msg(link, m_local_port, m_local_key, m_id, event, description);
		return m_local_interrupt(msg);
	}

	bool interrupt_remote(std::shared_ptr<T> link, int event, const std::string &description = std::string())
	{
		intr_message msg(link, m_remote_port, m_remote_key, m_id, event, description);
		return m_remote_interrupt(msg);
	}

	_id_T    m_id;
	_id_T    m_group_id;

	intr_connector      m_intconnector;

	std::atomic<bool>   m_syn;
	int                 m_local_port;
	int                 m_remote_port;
	_key_T              m_local_key;
	intr_entrance       m_local_interrupt;
	std::atomic<bool>   m_local_fin;

	std::atomic<bool>   m_syn_ack;
	_key_T              m_remote_key;
	intr_entrance       m_remote_interrupt;
	std::atomic<bool>   m_remote_fin;
};


} }


#endif


