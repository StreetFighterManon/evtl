

#ifndef __EVTL_ASYNC_H__
#define __EVTL_ASYNC_H__

#include <unistd.h>
#include <sys/types.h>
#include <sys/prctl.h>
#include <sys/syscall.h>
#include <pthread.h>
#include <assert.h>
#include <string>
#include <list>
#include <atomic>
#include <utility>
#include <functional>

#include "evtl_gcc.h"
#include "evtl_exception.h"
#include "evtl_lock.h"
#include "evtl_thread.h"


namespace evtl
{


class async
{
public:
	async(): m_want_poll(&async::_want_poll), m_done_poll(&async::_done_poll), m_data(nullptr),
		m_reqq_size(0), m_resq_size(0), m_nreqs(0)
	{}

	struct request;
	typedef int (*async_cb)(request *req);

	struct request
	{
		request(): feed(nullptr), finish(nullptr), destroy(nullptr), data(nullptr),
			cancelled(false)
		{}

		void cancel()
		{
			cancelled = true;
		}

		void (*feed)(request *req);
		async_cb finish;
		void (*destroy)(request *req);
		void *data;

		std::atomic<bool>  cancelled;
	};

	struct polltinfo
	{
		polltinfo(async *p = nullptr, unsigned int us = 0): asp(p), sleep_us(us)
		{}

		async *asp;
		unsigned int sleep_us;
	};

	bool init()
	{
		if (!m_reqlock.init())
			return false;
		if (!m_reqcond.init())
		{
			m_reqlock.deinit();
			return false;
		}
		if (!m_reslock.init())
		{
			m_reqcond.deinit();
			m_reqlock.deinit();
			return false;
		}
		return true;
	}

	void set_pollstatus_callback(
		void (*want_poll)(void *data) = &async::_want_poll,
		void (*done_poll)(void *data) = &async::_done_poll,
		void *data = nullptr
		)
	{
		m_want_poll = want_poll;
		m_done_poll = done_poll;
		m_data = data;
	}

	template <class T, void (T::*WANT)(), void (T::*DONE)()>
	void set_pollstatus_callback(T *object)
	{
		m_want_poll = &async::_wantpoll_thunk<T, WANT>;
		m_done_poll = &async::_donepoll_thunk<T, DONE>;
		m_data = object;
	}

	void set_name(const std::string &name)
	{
		m_tname = name;
	}

	bool make_thread(int nthreads, ssize_t stacksize = 0)
	{
		if (nthreads <= 0)
			nthreads = 1;

		for (int i = 0; i < nthreads; i++)
		{
			thread::mdtresult res = thread::make_detached(&async::_proc, this, stacksize);
			if (!res)
				return false;
		}

		return true;
	}

	bool make_pollthread(unsigned int once_sleep_us = 1000, ssize_t stacksize = 0)
	{
		polltinfo *pinfo = new polltinfo(this, once_sleep_us);
		if (pinfo == nullptr)
			throw simpexception("malloc failed");

		thread::mdtresult result = thread::make_detached(&async::_poll_thread, pinfo, stacksize);
		return result;
	}

	request * custom(void (*execute)(request *req), async_cb cb, void *data)
	{
		if (evunlike(execute == nullptr || cb == nullptr))
		{
			assert(false && "invalid param");
			return nullptr;
		}

		request *req = new request;
		if (req == nullptr)
			return nullptr;

		req->feed = execute;
		req->finish = cb;
		req->destroy = &async::_destroy;
		req->data = data;

		submit(req);
		return req;
	}

	template <class T, void (T::*EXE)(request *req), int (T::*FIN)(request *req)>
	request * custom(T *object)
	{
		if (evunlike(object == nullptr))
		{
			assert(false && "null object");
			return nullptr;
		}

		request *req = new request;
		if (req == nullptr)
			return nullptr;

		req->feed = &_execute_thunk<T, EXE>;
		req->finish = &_finish_thunk<T, FIN>;
		req->destroy = &async::_destroy;
		req->data = object;

		submit(req);
		return req;
	}

	void submit(request *req)
	{
		if (evunlike(req->feed == nullptr || req->finish == nullptr || req->destroy == nullptr))
			assert(false && "null callback");

		m_reqlock.lock();
		req_pushback(req);
		m_reqcond.signal();
		m_reqlock.unlock();
	}

	int poll()
	{
		while (true)
		{
			request *req = nullptr;

			m_reslock.lock();
			req = res_popfront();
			if (req != nullptr)
			{
				ssize_t ressize = m_resq_size.load(std::memory_order_relaxed);
				if (ressize < 0)
					assert(false && "negative size");
				if (ressize == 0)
					invoke_done_poll();
			}
			m_reslock.unlock();

			if (req == nullptr)
				return 0;

			int res = finish(req);
			if (res != 0)
				return res;
		}

		return -1;
	}

	ssize_t nreqs() const
	{
		return m_nreqs.load(std::memory_order_relaxed);
	}

	ssize_t nready() const
	{
		return m_reqq_size.load(std::memory_order_relaxed);
	}

	ssize_t npending() const
	{
		return m_resq_size.load(std::memory_order_relaxed);
	}

private:
	static void * _proc(void *arg)
	{
		if (arg == nullptr)
			assert(false && "null arg");

		async *asp = static_cast<async*>(arg);

		std::string threadname = asp->m_tname.empty() ? "async" : asp->m_tname;
		::prctl(PR_SET_NAME, threadname.c_str());
		return asp->asyncproc_O0(threadname, ::syscall(SYS_gettid), pthread_self());
	}

#pragma GCC push_options
#pragma GCC optimize ("O0")
	void * asyncproc_O0(const std::string &thread_name, long kernel_tid, pthread_t posix_tid)
	{
		return asyncproc();
	}
#pragma GCC pop_options

	void * asyncproc()
	{
		while (true)
		{
			request *req = nullptr;

			m_reqlock.lock();
			while (true)
			{
				req = req_popfront();
				if (req == nullptr)
					condition_wait();
				else
					break;
			}
			m_reqlock.unlock();

			execute(req);

			m_reslock.lock();
			if (res_pushback(req) == 0)
				invoke_want_poll();
			m_reslock.unlock();
		}

		assert(false && "bad route");
		return nullptr;
	}

	static void * _poll_thread(void *arg)
	{
		polltinfo *pinfo = static_cast<polltinfo*>(arg);

		std::string name = (pinfo->asp->m_tname.empty() ? "async" : pinfo->asp->m_tname) + "/poll";
		::prctl(PR_SET_NAME, name.c_str());

		return pinfo->asp->poll_thread_O0(name, ::syscall(SYS_gettid), pthread_self(), pinfo);
	}

#pragma GCC push_options
#pragma GCC optimize ("O0")
	void * poll_thread_O0(const std::string &thread_name, long kernel_tid, pthread_t posix_tid, polltinfo *pinfo)
	{
		return poll_thread(pinfo);
	}
#pragma GCC pop_options

	void * poll_thread(polltinfo *pinfo)
	{
		while (true)
		{
			if (nreqs() > 0)
				poll();

			if (pinfo->sleep_us > 0)
				::usleep(pinfo->sleep_us);
		}

		return nullptr;
	}

	static void _want_poll(void *data){}
	static void _done_poll(void *data){}

	static void _destroy(request *req)
	{
		delete req;
	}

	template <class T, void (T::*WANT)()>
	static void _wantpoll_thunk(void *data)
	{
		(static_cast<T*>(data)->*WANT)();
	}

	template <class T, void (T::*DONE)()>
	static void _donepoll_thunk(void *data)
	{
		(static_cast<T*>(data)->*DONE)();
	}

	template <class T, void (T::*EXE)(request *req)>
	static void _execute_thunk(request *req)
	{
		(static_cast<T*>(req->data)->*EXE)(req);
	}

	template <class T, int (T::*FIN)(request *req)>
	static int _finish_thunk(request *req)
	{
		return (static_cast<T*>(req->data)->*FIN)(req);
	}

private:
	void req_pushback(request *req)
	{
		m_req_queue.push_back(req);
		++m_reqq_size;
		++m_nreqs;
	}

	request * req_popfront()
	{
		std::list<request*>::iterator iter = m_req_queue.begin();
		if (iter == m_req_queue.end())
			return nullptr;

		request *req = *iter;
		if (evunlike(req == nullptr))
			assert(false && "null req");

		m_req_queue.erase(iter);
		--m_reqq_size;
		return req;
	}

	ssize_t res_pushback(request *req)
	{
		ssize_t presize = (ssize_t)m_resq_size.load(std::memory_order_relaxed);
		if (evunlike(presize < 0))
			assert(false && "negative size");
		m_res_queue.push_back(req);
		++m_resq_size;
		return presize;
	}

	request * res_popfront()
	{
		std::list<request*>::iterator iter = m_res_queue.begin();
		if (iter == m_res_queue.end())
			return nullptr;

		request *req = *iter;
		if (evunlike(req == nullptr))
			assert(false && "null req");

		m_res_queue.erase(iter);
		--m_resq_size;
		--m_nreqs;
		return req;
	}

	void condition_wait()
	{
		m_reqcond.wait(m_reqlock);
	}

	void execute(request *req)
	{
		if (!req->cancelled)
			req->feed(req);
	}

	int finish(request *req)
	{
		int res = req->finish(req);
		req->destroy(req);
		return res;
	}

	void invoke_want_poll()
	{
		m_want_poll(m_data);
	}

	void invoke_done_poll()
	{
		m_done_poll(m_data);
	}

private:
	void (*m_want_poll)(void *data);
	void (*m_done_poll)(void *data);
	void *m_data;  /* used for want_poll and done_poll */

	std::string  m_tname;

	std::list<request*>   m_req_queue;
	std::atomic<ssize_t>  m_reqq_size;
	lock::mutex_lock      m_reqlock;
	lock::condvar<lock::mutex_lock>  m_reqcond;

	std::list<request*>   m_res_queue;
	std::atomic<ssize_t>  m_resq_size;
	lock::mutex_lock      m_reslock;

	std::atomic<ssize_t>  m_nreqs;
};


template <class T>
class asyncre
{
public:
	asyncre() = default;

	typedef std::function<void (T &asr, async::request &req)> feed_callback_t;
	typedef std::function<int (T &asr, async::request &req)>  finish_callback_t;

	void set_feedcallback()
	{
		m_feed = nullptr;
	}

	void set_feedcallback(feed_callback_t cb)
	{
		m_feed = std::move(cb);
	}

	void set_finishcallback()
	{
		m_finish = nullptr;
	}

	void set_finishcallback(finish_callback_t cb)
	{
		m_finish = std::move(cb);
	}

	async::request * custom(async *asp)
	{
		if (evunlike(asp == nullptr))
			assert(false && "null asp");

		return asp->custom<asyncre, &asyncre::execute, &asyncre::finish>(this);
	}

private:
	void feed_callback(T &asr, async::request &req) { assert(false && "unset callback"); }
	int finish_callback(T &asr, async::request &req) { assert(false && "unset callback"); }

	void execute(async::request *req)
	{
		if (evunlike(req == nullptr || req->data != this))
			assert(false && "bad param");

		if (m_feed)
			m_feed(*static_cast<T*>(this), *req);
		else
			static_cast<T*>(this)->feed_callback(*static_cast<T*>(this), *req);
	}

	int finish(async::request *req)
	{
		if (evunlike(req == nullptr || req->data != this))
			assert(false && "bad param");

		if (m_finish)
			m_finish(*static_cast<T*>(this), *req);
		else
			static_cast<T*>(this)->finish_callback(*static_cast<T*>(this), *req);
	}

private:
	feed_callback_t    m_feed;
	finish_callback_t  m_finish;
};

class simpasyncre : public asyncre<simpasyncre>
{};


}


#endif


