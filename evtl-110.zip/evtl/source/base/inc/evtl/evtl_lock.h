

#ifndef __EVTL_LOCK_H__
#define __EVTL_LOCK_H__

#include <pthread.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <assert.h>

#include <list>
#include <set>
#include <cstring>
#include <utility>

#include "evtl_copyable.h"


namespace evtl { namespace lock {


class null_lock : public nocopyc
{
public:
	null_lock() = default;
	~null_lock() {}

	bool init() { return true; }
	bool deinit() { return true; }

	bool lock() { return true; }
	bool try_lock() { return true; }

	bool rd_lock() { return true; }
	bool try_rlock() { return true; }
	bool wr_lock() { return true; }
	bool try_wlock() { return true; }

	bool unlock() { return true; }
};

class mutex_lock : public nocopyc
{
public:
	template <class K> friend class condvar;

	mutex_lock(): m_mutex(PTHREAD_MUTEX_INITIALIZER)
	{}
	~mutex_lock()
	{}

	bool init()
	{
		if (0 != pthread_mutex_init(&m_mutex, nullptr))
		{
			m_mutex = PTHREAD_MUTEX_INITIALIZER;
			return false;
		}
		return true;
	}

	bool deinit()
	{
		if (0 == pthread_mutex_destroy(&m_mutex))
		{
			m_mutex = PTHREAD_MUTEX_INITIALIZER;
			return true;
		}
		m_mutex = PTHREAD_MUTEX_INITIALIZER;
		return false;
	}

	bool lock()
	{
		return 0 == pthread_mutex_lock(&m_mutex);
	}

	bool try_lock()
	{
		return 0 == pthread_mutex_trylock(&m_mutex);
	}

	bool unlock()
	{
		return 0 == pthread_mutex_unlock(&m_mutex);
	}

private:
	pthread_mutex_t m_mutex;
};

class rw_lock : public nocopyc
{
public:
	rw_lock(): m_rwlock(PTHREAD_RWLOCK_INITIALIZER)
	{}
	~rw_lock()
	{}

	bool init()
	{
		if (0 != pthread_rwlock_init(&m_rwlock, nullptr))
		{
			m_rwlock = PTHREAD_RWLOCK_INITIALIZER;
			return false;
		}
		return true;
	}

	bool deinit()
	{
		if (0 == pthread_rwlock_destroy(&m_rwlock))
		{
			m_rwlock = PTHREAD_RWLOCK_INITIALIZER;
			return true;
		}
		m_rwlock = PTHREAD_RWLOCK_INITIALIZER;
		return false;
	}

	bool rd_lock()
	{
		return 0 == pthread_rwlock_rdlock(&m_rwlock);
	}

	bool try_rlock()
	{
		return 0 == pthread_rwlock_tryrdlock(&m_rwlock);
	}

	bool wr_lock()
	{
		return 0 == pthread_rwlock_wrlock(&m_rwlock);
	}

	bool try_wlock()
	{
		return 0 == pthread_rwlock_trywrlock(&m_rwlock);
	}

	bool unlock()
	{
		return 0 == pthread_rwlock_unlock(&m_rwlock);
	}

private:
	pthread_rwlock_t m_rwlock;
};

class record_lock : public nocopyc
{
public:
	explicit record_lock(int fd = -1): m_fd(fd)
	{}
	~record_lock()
	{}

	void set_fd(int fd)
	{
		m_fd = fd;
	}

	//l_whence: SEEK_SET, SEEK_CUR, SEEK_END
	bool rd_lock(short l_whence = SEEK_SET, off_t l_start = 0, off_t l_len = 0)
	{
		return _setlkw(F_RDLCK, l_whence, l_start, l_len);
	}

	//l_whence: SEEK_SET, SEEK_CUR, SEEK_END
	bool try_rlock(short l_whence = SEEK_SET, off_t l_start = 0, off_t l_len = 0)
	{
		return _setlk(F_RDLCK, l_whence, l_start, l_len);
	}

	//l_whence: SEEK_SET, SEEK_CUR, SEEK_END
	bool wr_lock(short l_whence = SEEK_SET, off_t l_start = 0, off_t l_len = 0)
	{
		return _setlkw(F_WRLCK, l_whence, l_start, l_len);
	}

	//l_whence: SEEK_SET, SEEK_CUR, SEEK_END
	bool try_wlock(short l_whence = SEEK_SET, off_t l_start = 0, off_t l_len = 0)
	{
		return _setlk(F_WRLCK, l_whence, l_start, l_len);
	}

	//l_whence: SEEK_SET, SEEK_CUR, SEEK_END
	bool unlock(short l_whence = SEEK_SET, off_t l_start = 0, off_t l_len = 0)
	{
		return _setlk(F_UNLCK, l_whence, l_start, l_len);
	}

private:
	bool _setlkw(short l_type, short l_whence, off_t l_start, off_t l_len)
	{
		while (true)
		{
			struct flock lock;
			memset(&lock, 0, sizeof(lock));
			lock.l_type   = l_type;
			lock.l_whence = l_whence;
			lock.l_start  = l_start;
			lock.l_len    = l_len;
			lock.l_pid    = 0;

			//F_SETLKW maybe interrupted by signal, should restart.
			int ret = ::fcntl(m_fd, F_SETLKW, &lock);
			if (ret == 0)
				return true;
			else
			{
				if (errno != EINTR)
					return false;
			}
		}

		return false;
	}

	bool _setlk(short l_type, short l_whence, off_t l_start, off_t l_len)
	{
		struct flock lock;
		memset(&lock, 0, sizeof(lock));
		lock.l_type   = l_type;
		lock.l_whence = l_whence;
		lock.l_start  = l_start;
		lock.l_len    = l_len;
		lock.l_pid    = 0;

		//F_SETLKW maybe interrupted by signal, should restart.
		int ret = ::fcntl(m_fd, F_SETLK, &lock);
		if (ret == 0)
			return true;
		return false;
	}

private:
	int m_fd;
};

class spin_lock : public nocopyc
{
public:
	spin_lock(): m_spinlck(pthread_spinlock_t())
	{}

	~spin_lock()
	{}

	bool init()
	{
		if (0 != pthread_spin_init(&m_spinlck, PTHREAD_PROCESS_PRIVATE))
		{
			m_spinlck = pthread_spinlock_t();
			return false;
		}
		return true;
	}

	bool deinit()
	{
		if (0 == pthread_spin_destroy(&m_spinlck))
		{
			m_spinlck = pthread_spinlock_t();
			return true;
		}
		m_spinlck = pthread_spinlock_t();
		return false;
	}

	bool lock()
	{
		return 0 == pthread_spin_lock(&m_spinlck);
	}

	bool try_lock()
	{
		return 0 == pthread_spin_trylock(&m_spinlck);
	}

	bool unlock()
	{
		return 0 == pthread_spin_unlock(&m_spinlck);
	}

private:
	pthread_spinlock_t m_spinlck;
};

class atomic_lock : public nocopyc
{
public:
	atomic_lock(): m_atomlock('\0')
	{}
	~atomic_lock()
	{}

	bool init()
	{
		__atomic_store_n(&m_atomlock, '\0', __ATOMIC_SEQ_CST);
		return true;
	}

	bool deinit()
	{
		return true;
	}

	void lock()
	{
		while (true)
		{
			char expected = '\0';
			bool br = __atomic_compare_exchange_n(&m_atomlock, &expected, 's', false, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST);
			if (br)
				break;
		}
	}

	bool try_lock()
	{
		char expected = '\0';
		return __atomic_compare_exchange_n(&m_atomlock, &expected, 't', true, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST);
	}

	void unlock()
	{
		__atomic_store_n(&m_atomlock, '\0', __ATOMIC_SEQ_CST);
	}

private:
	char m_atomlock;
};

class routelock
{
public:
	routelock(bool initlck = false): m_locked(initlck)
	{}

	bool is_locked() const
	{
		return m_locked;
	}

	bool trylock()
	{
		if (m_locked)
			return false;

		m_locked = true;
		return true;
	}

	void unlock()
	{
		m_locked = false;
	}

private:
	bool  m_locked;
};

struct routelockowner
{
	routelockowner(): m_lockused(false), m_unlockused(false)
	{}

	void reset()
	{
		m_lockused = false;
		m_unlockused = false;
	}

	bool is_lockown() const
	{
		if (m_lockused && !m_unlockused)
			return true;
		return false;
	}

	bool  m_lockused;
	bool  m_unlockused;
};

inline bool routelock_acquire(routelock &lck, routelockowner &owner)
{
	if (!owner.m_lockused)
	{
		if (owner.m_unlockused)
			assert(false && "unlock before lock");

		if (lck.is_locked())
			return false;

		lck.trylock();
		owner.m_lockused = true;
	}

	return true;
}

inline void routelock_release(routelock &lck, routelockowner &owner, bool resetowner = false)
{
	if (!owner.m_lockused)
		assert(false && "lockunused");

	if (!owner.m_unlockused)
	{
		if (!lck.is_locked())
			assert(false && "unlocked");

		lck.unlock();
		owner.m_unlockused = true;
	}

	if (resetowner)
		owner.reset();
}


struct routeorderowner
{
	routeorderowner(): m_registused(false), m_lockused(false), m_unlockused(false), m_unregistused(false)
	{}

	void reset()
	{
		m_registused = false;
		m_lockused = false;
		m_unlockused = false;
		m_unregistused = false;
	}

	void reset_lock()
	{
		m_lockused = false;
		m_unlockused = false;
	}

	bool is_lockown() const
	{
		if (m_lockused && !m_unlockused)
			return true;
		return false;
	}

	bool is_registed() const
	{
		if (m_registused && !m_unregistused)
			return true;
		return false;
	}

	bool  m_registused;
	bool  m_lockused;
	bool  m_unlockused;
	bool  m_unregistused;
};

template <class KEY>
class fifo_order
{
public:
	fifo_order() = default;

	bool regist(const KEY &key)
	{
		if (m_keys.find(key) != m_keys.end())
			return false;

		m_fifolist.push_back(key);
		std::pair<typename std::set<KEY>::const_iterator, bool> rt = m_keys.insert(key);
		if (!rt.second)
			assert(false && "insert failed");

		return true;
	}

	bool turn(const KEY &key) const
	{
		typename std::list<KEY>::const_iterator iter = m_fifolist.begin();
		if (iter == m_fifolist.end())
			return false;
		if (*iter == key)
			return true;
		return false;
	}

	bool unregist(const KEY &key)
	{
		size_t n = m_keys.erase(key);
		if (n <= 0)
			return false;

		for (typename std::list<KEY>::iterator iter = m_fifolist.begin(); iter != m_fifolist.end(); ++iter)
		{
			if (*iter == key)
			{
				m_fifolist.erase(iter);
				return true;
			}
		}

		assert(false && "bad reach");
		return false;
	}

private:
	std::list<KEY>  m_fifolist;
	std::set<KEY>   m_keys;
};

template <class OrderPolicy = fifo_order<void *>, class KEY = void *>
class routeorderlock
{
public:
	routeorderlock()
	{}

	bool regist(const KEY &key, routeorderowner &owner)
	{
		if (!owner.m_registused)
		{
			if (owner.m_lockused)
				assert(false && "lockused is true");
			if (owner.m_unlockused)
				assert(false && "unlockused is true");
			if (owner.m_unregistused)
				assert(false && "unregistered is true");

			if (!m_order.regist(key))
				return false;
			owner.m_registused = true;
		}

		return true;
	}

	bool lock_acquire(const KEY &key, routeorderowner &owner)
	{
		if (!owner.m_registused)
			assert(false && "registused is false");

		if (!owner.m_lockused)
		{
			if (owner.m_unlockused)
				assert(false && "unlockused is true");
			if (owner.m_unregistused)
				assert(false && "unregistused is true");

			if (m_lock.is_locked())
				return false;

			if (!m_order.turn(key))
				return false;

			m_lock.trylock();
			owner.m_lockused = true;
		}

		return true;
	}

	std::pair<bool, bool> regist_acquire(const KEY &key, routeorderowner &owner)
	{
		std::pair<bool, bool> br = std::make_pair(false, false);

		if (!regist(key, owner))
			return br;

		br.first = true;
		if (!lock_acquire(key, owner))
			return br;

		br.second = true;
		return br;
	}

	void lock_release(routeorderowner &owner, bool resetownerlock = false)
	{
		if (!owner.m_registused)
			assert(false && "registused is false");
		if (!owner.m_lockused)
			assert(false && "lockused is false");

		if (!owner.m_unlockused)
		{
			if (owner.m_unregistused)
				assert(false && "unregistused is true");

			if (!m_lock.is_locked())
				assert(false && "not locked");

			m_lock.unlock();
			owner.m_unlockused = true;
		}

		if (resetownerlock)
			owner.reset_lock();
	}

	void unregist(const KEY &key, routeorderowner &owner, bool resetowner = false)
	{
		if (!owner.m_registused)
			assert(false && "registused is false");
		if (owner.is_lockown())
			assert(false && "in locked status");

		if (!owner.m_unregistused)
		{
			if (!m_order.unregist(key))
				assert(false && "unregist failed");
			owner.m_unregistused = true;
		}

		if (resetowner)
			owner.reset();
	}

	void release_unregist(const KEY &key, routeorderowner &owner, bool resetowner = false)
	{
		lock_release(owner, false);
		unregist(key, owner, resetowner);
	}

private:
	lock::routelock  m_lock;
	OrderPolicy  m_order;
};

class routescheduler
{
public:
	routescheduler(): m_yielded(false)
	{}

	bool yield()
	{
		if (!m_yielded)
		{
			m_yielded = true;
			return true;
		}
		return false;
	}

	void reset()
	{
		m_yielded = false;
	}

private:
	bool  m_yielded;
};


template <class LockT>
class lockguard;

template <>
class lockguard<null_lock>
{
public:
	explicit lockguard(null_lock &lock_ref)
	{}

	lockguard(null_lock &lock_ref, bool b_read)
	{}

	~lockguard()
	{}
};

template <>
class lockguard<mutex_lock>
{
public:
	explicit lockguard(mutex_lock &lock_ref): m_lock_ref(lock_ref)
	{
		m_lock_ref.lock();
	}
	~lockguard()
	{
		m_lock_ref.unlock();
	}

private:
	mutex_lock &m_lock_ref;
};

template <>
class lockguard<rw_lock>
{
public:
	explicit lockguard(rw_lock &lock_ref, bool b_read): m_lock_ref(lock_ref)
	{
		if (b_read)
			m_lock_ref.rd_lock();
		else
			m_lock_ref.wr_lock();
	}
	~lockguard()
	{
		m_lock_ref.unlock();
	}

private:
	rw_lock    &m_lock_ref;
};

template <>
class lockguard<record_lock>
{
public:
	explicit lockguard(record_lock &lock_ref, bool b_read): m_lock_ref(lock_ref)
	{
		if (b_read)
			m_lock_ref.rd_lock();
		else
			m_lock_ref.wr_lock();
	}
	~lockguard()
	{
		m_lock_ref.unlock();
	}

private:
	record_lock  &m_lock_ref;
};

template <>
class lockguard<spin_lock>
{
public:
	explicit lockguard(spin_lock &lock_ref): m_lock_ref(lock_ref)
	{
		m_lock_ref.lock();
	}
	~lockguard()
	{
		m_lock_ref.unlock();
	}

private:
	spin_lock &m_lock_ref;
};

template <>
class lockguard<atomic_lock>
{
public:
	explicit lockguard(atomic_lock &lock_ref): m_lock_ref(lock_ref)
	{
		m_lock_ref.lock();
	}
	~lockguard()
	{
		m_lock_ref.unlock();
	}

private:
	atomic_lock &m_lock_ref;
};

template <>
class lockguard<routelock>
{
public:
	explicit lockguard(routelock &lock_ref): m_lock_ref(lock_ref)
	{
		m_locksucc = m_lock_ref.trylock();
	}
	~lockguard()
	{
		if (m_locksucc)
			m_lock_ref.unlock();
	}

private:
	routelock &m_lock_ref;
	bool       m_locksucc;
};

template <class LockT = mutex_lock>
class condvar
{
public:
	condvar() = default;

	bool init() { return true; }
	bool deinit() { return true; }

	bool wait(LockT &) { return true; }
	bool signal() { return true; }
};

template <>
class condvar<mutex_lock>
{
public:
	condvar(): m_cond(PTHREAD_COND_INITIALIZER)
	{}

	bool init()
	{
		if (0 != pthread_cond_init(&m_cond, nullptr))
		{
			m_cond = PTHREAD_COND_INITIALIZER;
			return false;
		}
		return true;
	}

	bool deinit()
	{
		if (0 == pthread_cond_destroy(&m_cond))
		{
			m_cond = PTHREAD_COND_INITIALIZER;
			return true;
		}
		m_cond = PTHREAD_COND_INITIALIZER;
		return false;
	}

	bool wait(mutex_lock &mutex)
	{
		return 0 == pthread_cond_wait(&m_cond, &mutex.m_mutex);
	}

	bool signal()
	{
		return 0 == pthread_cond_signal(&m_cond);
	}

private:
	pthread_cond_t  m_cond;
};


} }


#endif


