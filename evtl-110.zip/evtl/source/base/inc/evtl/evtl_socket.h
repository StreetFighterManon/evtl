

#ifndef __EVTL_SOCKET_H__
#define __EVTL_SOCKET_H__

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <fcntl.h>
#include <unistd.h>
#include <poll.h>

#include <cstring>
#include <utility>


namespace evtl
{


class sockoption
{
public:
	static bool set_block(int fd, bool block)
	{
		int flag = ::fcntl(fd, F_GETFL);
		if (flag == -1)
			return false;

		if (block)
			flag &= ~O_NONBLOCK;
		else
			flag |= O_NONBLOCK;

		int rt = ::fcntl(fd, F_SETFL, flag);
		return rt == 0;
	}

	static std::pair<bool, int> get_error(int fd)
	{
		std::pair<bool, int> result = std::make_pair(false, 0);
		socklen_t len = sizeof(result.second);

		int rt = ::getsockopt(fd, SOL_SOCKET, SO_ERROR, &result.second, &len);
		if (rt == 0)
			result.first = true;

		return result;
	}

	static bool set_reuseaddr(int fd, bool on)
	{
		int val = on ? 1 : 0;

		int rt = ::setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &val, sizeof(val));
		if (rt == 0)
			return true;

		return false;
	}

	static std::pair<bool, int> get_reuseaddr(int fd)
	{
		std::pair<bool, int> result = std::make_pair(false, 0);
		socklen_t len = sizeof(result.second);

		int rt = ::getsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &result.second, &len);
		if (rt == 0)
			result.first = true;

		return result;
	}

	static bool set_reuseport(int fd, bool on)
	{
		int val = on ? 1 : 0;

		int rt = ::setsockopt(fd, SOL_SOCKET, SO_REUSEPORT, &val, sizeof(val));
		if (rt == 0)
			return true;

		return false;
	}

	static std::pair<bool, int> get_reuseport(int fd)
	{
		std::pair<bool, int> result = std::make_pair(false, 0);
		socklen_t len = sizeof(result.second);

		int rt = ::getsockopt(fd, SOL_SOCKET, SO_REUSEPORT, &result.second, &len);
		if (rt == 0)
			result.first = true;

		return result;
	}

	static bool set_keepalive(int fd, bool on)
	{
		int val = on ? 1 : 0;

		int rt = ::setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &val, sizeof(val));
		if (rt == 0)
			return true;

		return false;
	}

	static std::pair<bool, int> get_keepalive(int fd)
	{
		std::pair<bool, int> result = std::make_pair(false, 0);
		socklen_t len = sizeof(result.second);

		int rt = ::getsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &result.second, &len);
		if (rt == 0)
			result.first = true;

		return result;
	}

	static bool set_linger(int fd, bool on, int seconds = 0)
	{
		struct linger ling;
		memset(&ling, 0, sizeof(ling));
		ling.l_onoff  = on;
		ling.l_linger = seconds;

		int rt = ::setsockopt(fd, SOL_SOCKET, SO_LINGER, &ling, sizeof(ling));
		if (rt == 0)
			return true;

		return false;
	}

	static std::pair<bool, struct linger> get_linger(int fd)
	{
		std::pair<bool, struct linger> result = std::make_pair(false, linger());
		socklen_t len = sizeof(result.second);

		int rt = ::getsockopt(fd, SOL_SOCKET, SO_LINGER, &result.second, &len);
		if (rt == 0)
			result.first = true;

		return result;
	}

	static bool set_ip_ttl(int fd, int ttl)
	{
		int val = ttl;

		int rt = ::setsockopt(fd, IPPROTO_IP, IP_TTL, &val, sizeof(val));
		if (rt == 0)
			return true;

		return false;
	}

	static std::pair<bool, int> get_ip_ttl(int fd)
	{
		std::pair<bool, int> result = std::make_pair(false, 0);
		socklen_t len = sizeof(result.second);

		int rt = ::getsockopt(fd, IPPROTO_IP, IP_TTL, &result.second, &len);
		if (rt == 0)
			result.first = true;

		return result;
	}

	static bool set_recvbuf(int fd, int bufsize)
	{
		int val = bufsize;

		int rt = ::setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &val, sizeof(val));
		if (rt == 0)
			return true;

		return false;
	}

	static std::pair<bool, int> get_recvbuf(int fd)
	{
		std::pair<bool, int> result = std::make_pair(false, 0);

		socklen_t len = sizeof(result.second);
		int rt = ::getsockopt(fd, SOL_SOCKET, SO_RCVBUF, &result.second, &len);
		if (rt == 0)
			result.first = true;

		return result;
	}

	static bool set_sendbuf(int fd, int bufsize)
	{
		int val = bufsize;

		int rt = ::setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &val, sizeof(val));
		if (rt == 0)
			return true;

		return false;
	}

	static std::pair<bool, int> get_sendbuf(int fd)
	{
		std::pair<bool, int> result = std::make_pair(false, 0);

		socklen_t len = sizeof(result.second);
		int rt = ::getsockopt(fd, SOL_SOCKET, SO_SNDBUF, &result.second, &len);
		if (rt == 0)
			result.first = true;

		return result;
	}

	static bool set_tcp_maxseg(int fd, int segsize)
	{
		int val = segsize;

		int rt = ::setsockopt(fd, IPPROTO_TCP, TCP_MAXSEG, &val, sizeof(val));
		if (rt == 0)
			return true;

		return false;
	}

	static std::pair<bool, int> get_tcp_maxseg(int fd)
	{
		std::pair<bool, int> result = std::make_pair(false, 0);
		socklen_t len = sizeof(result.second);

		int rt = ::getsockopt(fd, IPPROTO_TCP, TCP_MAXSEG, &result.second, &len);
		if (rt == 0)
			result.first = true;

		return result;
	}

	static bool set_tcp_nodelay(int fd, bool nodelay)
	{
		int val = nodelay ? 1 : 0;

		int rt = ::setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &val, sizeof(val));
		if (rt == 0)
			return true;

		return false;
	}

	static std::pair<bool, int> get_tcp_nodelay(int fd)
	{
		std::pair<bool, int> result = std::make_pair(false, 0);
		socklen_t len = sizeof(result.second);

		int rt = ::getsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &result.second, &len);
		if (rt == 0)
			result.first = true;

		return result;
	}
};


class sockevent
{
public:
	static std::pair<bool, int> poll(int fd)
	{
		struct pollfd fds;
		memset(&fds, 0, sizeof(fds));
		fds.fd      = fd;
		fds.events  = POLLIN | POLLPRI | POLLOUT | POLLRDHUP;
		fds.revents = 0;

		std::pair<bool, int> result = std::make_pair(false, 0);

		int ret = ::poll(&fds, 1, 0);
		if (ret > 0)
			result = std::make_pair(true, fds.revents);
		else if (ret == 0)
			result = std::make_pair(true, 0);

		return result;
	}

	static int poll_exceptrevent(int fd)
	{
		struct pollfd fds;
		memset(&fds, 0, sizeof(fds));
		fds.fd      = fd;
		fds.events  = POLLIN | POLLPRI | POLLOUT | POLLRDHUP;
		fds.revents = 0;

		int ret = ::poll(&fds, 1, 0);
		if (ret > 0)
			return fds.revents & (POLLRDHUP | POLLERR | POLLHUP | POLLNVAL);

		return 0;
	}
};


class socket
{
public:
	static std::pair<int, int> socketpair(int type = SOCK_STREAM, bool nonblock = true)
	{
		int fd[2] = {-1, -1};

		int rt = -1;

		if (nonblock)
			rt = ::socketpair(AF_LOCAL, type | SOCK_NONBLOCK, 0, fd);
		else
			rt = ::socketpair(AF_LOCAL, type, 0, fd);

		if (rt == 0)
			return std::make_pair(fd[0], fd[1]);

		return std::make_pair(-1, -1);
	}

	/* return std::pair<read_fd, write_fd> */
	static std::pair<int, int> pipe(bool nonblock = true)
	{
		int fd[2] = {-1, -1};

		int rt = -1;

		if (nonblock)
			rt = ::pipe2(fd, O_NONBLOCK);
		else
			rt = ::pipe2(fd, 0);

		if (rt == 0)
			return std::make_pair(fd[0], fd[1]);

		return std::make_pair(-1, -1);
	}
};


}


#endif


