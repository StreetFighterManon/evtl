

#ifndef __EVTL_BOUNDEDBUF_H__
#define __EVTL_BOUNDEDBUF_H__

#include <sys/types.h>
#include <assert.h>

#include <atomic>

#include "evtl_gcc.h"
#include "evtl_copyable.h"
#include "evtl_exception.h"


namespace evtl
{


template <class T>
class boundedbuf : public nocopyc
{
public:
	struct blockunit
	{
		friend class boundedbuf;

		blockunit(): _elem(), _valid(false)
		{}

		T& elem()
		{
			return _elem;
		}

		const T& elem() const
		{
			return _elem;
		}

		bool produced() const
		{
			return _valid;
		}

	private:
		T  _elem;
		std::atomic<bool>  _valid;
	};

	explicit boundedbuf(ssize_t count = 0): m_buffer_len(count)
	{
		if (count > 0)
		{
			m_buffer = new blockunit[count];
			if (m_buffer == nullptr)
				throw simpexception("malloc failed");
		}
		else
		{
			if (count < 0)
				assert(false && "negative count");

			m_buffer = nullptr;
		}

		m_produce_pos = 0;
		m_consume_pos = 0;
		m_product_count = 0;
	}

	~boundedbuf()
	{
		if (m_buffer != nullptr)
			delete []m_buffer;

		m_buffer = nullptr;
		m_buffer_len = 0;
		m_produce_pos = 0;
		m_consume_pos = 0;
		m_product_count = 0;
	}

	bool internal_verify() const
	{
		return _verify();
	}

	void reset()
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (m_buffer != nullptr)
			delete []m_buffer;

		m_buffer = nullptr;
		m_buffer_len = 0;
		m_produce_pos = 0;
		m_consume_pos = 0;
		m_product_count = 0;
	}

	void resize(ssize_t nsize)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (nsize < 0)
		{
			assert(false && "negative size");
			return;
		}

		if (nsize == 0)
		{
			if (m_buffer != nullptr)
				delete []m_buffer;
			
			m_buffer = nullptr;
			m_buffer_len = 0;
			m_produce_pos = 0;
			m_consume_pos = 0;
			return;
		}

		if (nsize == m_buffer_len)
			_zeroed_production();
		else
		{
			blockunit *buf = new blockunit[nsize];
			if (buf == nullptr)
				throw simpexception("malloc failed");

			if (m_buffer != nullptr)
				delete []m_buffer;

			m_buffer = buf;
			m_buffer_len = nsize;
		}

		m_produce_pos = 0;
		m_consume_pos = 0;
		m_product_count = 0;
	}

	void zeroed_production()
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		_zeroed_production();
	}

	T* get_produce()
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (m_buffer_len <= 0)
			return nullptr;

		blockunit *pb = m_buffer + m_produce_pos.load(std::memory_order_relaxed);

		if (!pb->_valid)
			return &pb->_elem;
		return nullptr;
	}

	const T* get_produce() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (m_buffer_len <= 0)
			return nullptr;

		const blockunit *pb = m_buffer + m_produce_pos.load(std::memory_order_relaxed);

		if (!pb->_valid)
			return &pb->_elem;
		return nullptr;
	}

	ssize_t get_produce_index() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return m_produce_pos.load(std::memory_order_relaxed);
	}

	void produce_complete(const T *produced = nullptr)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (m_buffer_len <= 0)
			assert(false && "empty buf");

		blockunit *pb = m_buffer + m_produce_pos.load(std::memory_order_relaxed);

		if (produced != nullptr)
		{
			if (produced != &pb->_elem)
				assert(false && "unexpected produced");
		}

		if (pb->_valid)
			assert(false && "already valid");

		m_product_count.fetch_add(1, std::memory_order_relaxed);
		pb->_valid = true;

		ssize_t nextpos = m_produce_pos.load(std::memory_order_relaxed) + 1;
		if (nextpos >= m_buffer_len)
			m_produce_pos = 0;
		else
			m_produce_pos = nextpos;
	}

	T* get_consume()
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (m_buffer_len <= 0)
			return nullptr;

		blockunit *pb = m_buffer + m_consume_pos.load(std::memory_order_relaxed);

		if (pb->_valid)
			return &pb->_elem;
		return nullptr;
	}

	const T* get_consume() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (m_buffer_len <= 0)
			return nullptr;

		blockunit *pb = m_buffer + m_consume_pos.load(std::memory_order_relaxed);

		if (pb->_valid)
			return &pb->_elem;
		return nullptr;
	}

	ssize_t get_consume_index() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return m_consume_pos.load(std::memory_order_relaxed);
	}

	void consume_complete(const T *consumed = nullptr)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (m_buffer_len <= 0)
			assert(false && "empty buf");

		blockunit *pb = m_buffer + m_consume_pos.load(std::memory_order_relaxed);

		if (consumed != nullptr)
		{
			if (consumed != &pb->_elem)
				assert(false && "unexpected consumed");
		}

		if (!pb->_valid)
			assert(false && "consume invalid");

		m_product_count.fetch_sub(1, std::memory_order_relaxed);
		pb->_valid = false;

		ssize_t nextpos = m_consume_pos.load(std::memory_order_relaxed) + 1;
		if (nextpos >= m_buffer_len)
			m_consume_pos = 0;
		else
			m_consume_pos = nextpos;
	}

	ssize_t get_product_count() const
	{
		return m_product_count.load(std::memory_order_relaxed);
	}

	const blockunit& operator [] (ssize_t index) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (evunlike(index < 0 || index >= m_buffer_len))
			assert(false && "index out of bounds");

		return m_buffer[index];
	}

	blockunit& operator [] (ssize_t index)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (evunlike(index < 0 || index >= m_buffer_len))
			assert(false && "index out of bounds");

		return m_buffer[index];
	}

	const blockunit& at(ssize_t index) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (evunlike(index < 0 || index >= m_buffer_len))
			assert(false && "index out of bounds");

		return m_buffer[index];
	}

	blockunit& at(ssize_t index)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (evunlike(index < 0 || index >= m_buffer_len))
			assert(false && "index out of bounds");

		return m_buffer[index];
	}

	ssize_t size() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return m_buffer_len;
	}

	bool empty() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return m_buffer_len <= 0;
	}

private:
	bool _verify() const
	{
		if (m_buffer_len > 0)
		{
			if (m_buffer == nullptr)
				return false;
			if (m_produce_pos.load(std::memory_order_relaxed) < 0 || m_produce_pos.load(std::memory_order_relaxed) >= m_buffer_len)
				return false;
			if (m_consume_pos.load(std::memory_order_relaxed) < 0 || m_consume_pos.load(std::memory_order_relaxed) >= m_buffer_len)
				return false;
		}
		else if (m_buffer_len == 0)
		{
			if (m_buffer != nullptr || m_produce_pos.load(std::memory_order_relaxed) != 0 || m_consume_pos.load(std::memory_order_relaxed) != 0)
				return false;
		}
		else
		{
			return false;
		}

		return true;
	}

	void _zeroed_production()
	{
		for (ssize_t i = 0; i < m_buffer_len; i++)
		{
			m_buffer[i]._valid = false;
		}

		m_produce_pos = 0;
		m_consume_pos = 0;
		m_product_count = 0;
	}

private:
	blockunit  *m_buffer;
	ssize_t     m_buffer_len;

	std::atomic<ssize_t>   m_produce_pos;
	std::atomic<ssize_t>   m_consume_pos;
	std::atomic<ssize_t>   m_product_count;
};


}


#endif


