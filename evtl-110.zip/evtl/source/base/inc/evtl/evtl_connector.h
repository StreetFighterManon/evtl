

#ifndef __EVTL_CONNECTOR_H__
#define __EVTL_CONNECTOR_H__

#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <signal.h>
#include <poll.h>
#include <errno.h>
#include <assert.h>

#include <cstdint>
#include <utility>
#include <cstring>
#include <functional>

#include <ev/ev++.h>

#include "evtl_gcc.h"
#include "evtl_copyable.h"
#include "evtl_error.h"
#include "evtl_eventloop.h"
#include "evtl_in.h"
#include "evtl_inet.h"
#include "evtl_time.h"


namespace evtl
{


template <class T>
class connector : public evtl_error, public nocopyc
{
public:
	enum error_code
	{
		success,
		null_loop,
		invalid_fd,
		invalid_addrtype,
		invalid_host,
		bind_failed,
		connected_fd,
		connector_busy,
		socket_create_failed,
		reuse_addr_failed,
		set_nonblock_failed,
		connect_failed,
		ppoll_connect_failed,
		ppoll_unexpected_revents,
		ppoll_timeout,
		ppoll_failed,
		ppoll_interrupt,
		connect_timeout,
		unexpected_revents,
		getsockopt_failed,
		getsockopt_connect_failed,
		self_connect
	};

	enum connect_type
	{
		connect_type_unknown,
		connect_type_sync,
		connect_type_async,
		connect_type_wait,
		connect_type_nonblock
	};

	enum connect_result
	{
		connect_result_unknown,
		connect_result_success,
		connect_result_waiting,
		connect_result_failed
	};

	struct connect_status
	{
		connect_status(connect_result r = connect_result_unknown, error_code errc = success, int erri = 0)
			: result(r), errcode(errc), errint(erri)
		{}

		void reset()
		{
			result  = connect_result_unknown;
			errcode = success;
			errint = 0;
		}

		connect_result  result;
		error_code      errcode;
		int             errint;
	};

	typedef std::function<void (T &connector, int fd)>  socket_callback_t;
	typedef std::function<void (T &connector, int errcode, int errnocode)>  connect_callback_t;

	connector(): m_connect_type(connect_type_unknown), m_check_self_connect(false)
	{
		memset(&m_peeraddr, 0, sizeof(m_peeraddr));
		m_io.set(nullptr);
		m_io.set(-1, 0);
	}

	void set_loop(looprefer loop)
	{
		m_loop = loop;
	}

	void set_socketcallback()
	{
		m_socket_cb = nullptr;
	}

	void set_socketcallback(socket_callback_t cb)
	{
		m_socket_cb = std::move(cb);
	}

	void set_callback()
	{
		m_connect_cb = nullptr;
	}

	void set_callback(connect_callback_t cb)
	{
		m_connect_cb = std::move(cb);
	}

	int sync_connect(const address &addr, bool check_self_connect = false, const address &localaddr = address())
	{
		if (m_io.fd != -1)
		{
			set_error(connected_fd, m_io.fd);
			return -1;
		}

		if (!addr.host.isip())
		{
			set_error(invalid_addrtype, (int)addr.host.type);
			return -1;
		}

		std::pair<bool, struct sockaddr_storage> peeraddr = inetc::inaddr_pton(addr);
		if (!peeraddr.first)
		{
			set_error(invalid_host, 1, addr.host.str());
			return -1;
		}

		if (peeraddr.second.ss_family != AF_INET && peeraddr.second.ss_family != AF_INET6)
			assert(false && "invalid family");

		m_peeraddr = peeraddr.second;

		std::pair<bool, struct sockaddr_storage> locaddr = std::make_pair(false, sockaddr_storage());
		if (localaddr.host.isip() && !localaddr.host.empty() && localaddr.port >= 0)
		{
			locaddr = inetc::inaddr_pton(localaddr);
			if (!locaddr.first)
			{
				set_error(invalid_host, 2, localaddr.host.str());
				return -1;
			}

			if (locaddr.second.ss_family != AF_INET && locaddr.second.ss_family != AF_INET6)
				assert(false && "invalid family");
		}

		int fd = ::socket(m_peeraddr.ss_family, SOCK_STREAM, 0);
		if (fd == -1)
		{
			set_error(socket_create_failed, errno);
			return -1;
		}

		int flag = 1;
		if (::setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &flag, sizeof(flag)) != 0)
		{
			set_error(reuse_addr_failed, errno);
			::close(fd);
			return -1;
		}

		if (m_socket_cb)
			m_socket_cb(*static_cast<T*>(this), fd);
		else
			static_cast<T*>(this)->socket_callback(*static_cast<T*>(this), fd);

		if (locaddr.first)
		{
			if (0 != ::bind(fd, (const struct sockaddr *)&locaddr.second, sizeof(locaddr.second)))
			{
				set_error(bind_failed, errno);
				close(fd);
				return -1;
			}
		}

		int ret = ::connect(fd, (const struct sockaddr *)&m_peeraddr, sizeof(m_peeraddr));
		if (ret != 0)
		{
			set_error(connect_failed, errno);
			::close(fd);
			return -1;
		}

		if (check_self_connect)
		{
			locaddr = inetc::getsockname(fd);

			if (locaddr.first)
			{
				if (inetc::addrequal(locaddr.second, m_peeraddr, false))
				{
					set_error(self_connect, inetc::getport(m_peeraddr));
					::close(fd);
					return -1;
				}
			}
		}

		m_connect_type = connect_type_sync;
		m_check_self_connect = check_self_connect;

		m_io.fd = fd;
		return fd;
	}

	bool async_connect(const address &addr, bool check_self_connect = false, const address &localaddr = address())
	{
		if (m_loop.is_null())
		{
			set_error(null_loop);
			return false;
		}

		if (m_io.fd != -1)
		{
			set_error(connected_fd, m_io.fd);
			return false;
		}

		if (m_io.is_active())
		{
			set_error(connector_busy);
			return false;
		}

		if (!addr.host.isip())
		{
			set_error(invalid_addrtype, (int)addr.host.type);
			return false;
		}

		std::pair<bool, struct sockaddr_storage> peeraddr = inetc::inaddr_pton(addr);
		if (!peeraddr.first)
		{
			set_error(invalid_host, 1, addr.host.str());
			return false;
		}

		if (peeraddr.second.ss_family != AF_INET && peeraddr.second.ss_family != AF_INET6)
			assert(false && "invalid family");

		m_peeraddr = peeraddr.second;

		std::pair<bool, struct sockaddr_storage> locaddr = std::make_pair(false, sockaddr_storage());
		if (localaddr.host.isip() && !localaddr.host.empty() && localaddr.port >= 0)
		{
			locaddr = inetc::inaddr_pton(localaddr);
			if (!locaddr.first)
			{
				set_error(invalid_host, 2, localaddr.host.str());
				return false;
			}

			if (locaddr.second.ss_family != AF_INET && locaddr.second.ss_family != AF_INET6)
				assert(false && "invalid family");
		}

		int fd = ::socket(m_peeraddr.ss_family, SOCK_STREAM | SOCK_NONBLOCK, 0);
		if (fd < 0)
		{
			set_error(socket_create_failed, errno);
			return false;
		}

		int flag = 1;
		if (::setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &flag, sizeof(flag)) != 0)
		{
			set_error(reuse_addr_failed, errno);
			::close(fd);
			return false;
		}

		if (m_socket_cb)
			m_socket_cb(*static_cast<T*>(this), fd);
		else
			static_cast<T*>(this)->socket_callback(*static_cast<T*>(this), fd);

		if (locaddr.first)
		{
			if (0 != ::bind(fd, (const struct sockaddr *)&locaddr.second, sizeof(locaddr.second)))
			{
				set_error(bind_failed, errno);
				::close(fd);
				return false;
			}
		}

		int ret = ::connect(fd, (const struct sockaddr *)&m_peeraddr, sizeof(m_peeraddr));
		if (ret != 0 && errno != EINPROGRESS)
		{
			set_error(connect_failed, errno);
			::close(fd);
			return false;
		}

		m_io.set(m_loop.ref());
		m_io.set<connector, &connector::io_callback>(this);
		m_io.start(fd, ev::WRITE);

		m_connect_type = connect_type_async;
		m_check_self_connect = check_self_connect;

		return true;
	}

	int wait_connect(const address &addr, long wait_us = -1, bool check_self_connect = false, const address &localaddr = address())
	{
		if (m_io.fd != -1)
		{
			set_error(connected_fd, m_io.fd);
			return -1;
		}

		if (!addr.host.isip())
		{
			set_error(invalid_addrtype, (int)addr.host.type);
			return -1;
		}

		std::pair<bool, struct sockaddr_storage> peeraddr = inetc::inaddr_pton(addr);
		if (!peeraddr.first)
		{
			set_error(invalid_host, 1, addr.host.str());
			return -1;
		}

		if (peeraddr.second.ss_family != AF_INET && peeraddr.second.ss_family != AF_INET6)
			assert(false && "invalid family");

		m_peeraddr = peeraddr.second;

		std::pair<bool, struct sockaddr_storage> locaddr = std::make_pair(false, sockaddr_storage());
		if (localaddr.host.isip() && !localaddr.host.empty() && localaddr.port >= 0)
		{
			locaddr = inetc::inaddr_pton(localaddr);
			if (!locaddr.first)
			{
				set_error(invalid_host, 2, localaddr.host.str());
				return -1;
			}

			if (locaddr.second.ss_family != AF_INET && locaddr.second.ss_family != AF_INET6)
				assert(false && "invalid family");
		}

		int64_t start_us = timec::usec();

		int fd = ::socket(m_peeraddr.ss_family, SOCK_STREAM | SOCK_NONBLOCK, 0);
		if (fd == -1)
		{
			set_error(socket_create_failed, errno);
			return -1;
		}

		int flag = 1;
		if (::setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &flag, sizeof(flag)) != 0)
		{
			set_error(reuse_addr_failed, errno);
			::close(fd);
			return -1;
		}

		if (m_socket_cb)
			m_socket_cb(*static_cast<T*>(this), fd);
		else
			static_cast<T*>(this)->socket_callback(*static_cast<T*>(this), fd);

		if (locaddr.first)
		{
			if (0 != ::bind(fd, (const struct sockaddr *)&locaddr.second, sizeof(locaddr.second)))
			{
				set_error(bind_failed, errno);
				::close(fd);
				return -1;
			}
		}

		int ret = ::connect(fd, (const struct sockaddr *)&m_peeraddr, sizeof(m_peeraddr));
		if (ret != 0 && errno != EINPROGRESS)
		{
			set_error(connect_failed, errno);
			::close(fd);
			return -1;
		}

		while (true)
		{
			struct pollfd fds;
			memset(&fds, 0, sizeof(fds));
			fds.fd      = fd;
			fds.events  = POLLOUT;
			fds.revents = 0;

			int64_t rest_us = -1;
			if (wait_us >= 0)
			{
				int64_t now_us = timec::usec();
				if (now_us <= start_us)
				{
					start_us = now_us;
					rest_us = wait_us;
				}
				else
					rest_us = wait_us - (now_us - start_us);
				if (rest_us < 0)
					rest_us = 0;
			}

			struct timespec tv;
			memset(&tv, 0, sizeof(tv));
			tv.tv_sec  = rest_us/1000000;
			tv.tv_nsec = (rest_us%1000000)*1000;

			if (rest_us < 0)
				ret = ::ppoll(&fds, 1, nullptr, nullptr);
			else
				ret = ::ppoll(&fds, 1, &tv, nullptr);

			if (ret > 0)
			{
				if ((fds.revents & POLLOUT) == 0)
				{
					/* when fd is invalid */
					set_error(ppoll_unexpected_revents, fds.revents);
					close(fd);
					return -1;
				}

				int option = 0;
				socklen_t optlen = sizeof(option);

				int rt = ::getsockopt(fd, SOL_SOCKET, SO_ERROR, &option, &optlen);
				if (rt < 0)
				{
					set_error(getsockopt_failed, errno);
					::close(fd);
					return -1;
				}
				else if (option != 0)
				{
					set_error(getsockopt_connect_failed, option);
					close(fd);
					return -1;
				}

				if ((fds.revents & (POLLERR | POLLHUP | POLLNVAL)) != 0)
				{
					set_error(ppoll_connect_failed, fds.revents);
					::close(fd);
					return -1;
				}

				if (check_self_connect)
				{
					locaddr = inetc::getsockname(fd);
					if (locaddr.first)
					{
						if (inetc::addrequal(locaddr.second, m_peeraddr, false))
						{
							set_error(self_connect, inetc::getport(m_peeraddr));
							close(fd);
							return -1;
						}
					}
				}

				m_connect_type = connect_type_wait;
				m_check_self_connect = check_self_connect;

				m_io.fd = fd;
				return fd;
			}
			else if (ret == 0)
			{
				set_error(ppoll_timeout, wait_us);
				::close(fd);
				return -1;
			}
			else
			{
				if (errno != EINTR)
				{
					set_error(ppoll_failed, errno);
					::close(fd);
					return -1;
				}
			}

			if (rest_us == 0)
			{
				/* poll is interrupted by signal and timeout */
				set_error(connect_timeout, wait_us);
				::close(fd);
				return -1;
			}
		}

		assert(false && "bad routing");
		::close(fd);
		return -1;
	}

	int nonblock_connect(const address &addr, const address &localaddr = address())
	{
		if (m_io.fd != -1)
		{
			set_error(connected_fd, m_io.fd);
			return -1;
		}

		if (!addr.host.isip())
		{
			set_error(invalid_addrtype, (int)addr.host.type);
			return -1;
		}

		std::pair<bool, struct sockaddr_storage> peeraddr = inetc::inaddr_pton(addr);
		if (!peeraddr.first)
		{
			set_error(invalid_host, 1, addr.host.str());
			return -1;
		}

		if (peeraddr.second.ss_family != AF_INET && peeraddr.second.ss_family != AF_INET6)
			assert(false && "invalid family");

		m_peeraddr = peeraddr.second;

		std::pair<bool, struct sockaddr_storage> locaddr = std::make_pair(false, sockaddr_storage());
		if (localaddr.host.isip() && !localaddr.host.empty() && localaddr.port >= 0)
		{
			locaddr = inetc::inaddr_pton(localaddr);
			if (!locaddr.first)
			{
				set_error(invalid_host, 2, localaddr.host.str());
				return -1;
			}

			if (locaddr.second.ss_family != AF_INET && locaddr.second.ss_family != AF_INET6)
				assert(false && "invalid family");
		}

		int fd = ::socket(m_peeraddr.ss_family, SOCK_STREAM | SOCK_NONBLOCK, 0);
		if (fd < 0)
		{
			set_error(socket_create_failed, errno);
			return -1;
		}

		int flag = 1;
		if (::setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &flag, sizeof(flag)) != 0)
		{
			set_error(reuse_addr_failed, errno);
			::close(fd);
			return -1;
		}

		if (m_socket_cb)
			m_socket_cb(*static_cast<T*>(this), fd);
		else
			static_cast<T*>(this)->socket_callback(*static_cast<T*>(this), fd);

		if (locaddr.first)
		{
			if (0 != ::bind(fd, (const struct sockaddr *)&locaddr.second, sizeof(locaddr.second)))
			{
				set_error(bind_failed, errno);
				::close(fd);
				return -1;
			}
		}

		int ret = ::connect(fd, (const struct sockaddr *)&m_peeraddr, sizeof(m_peeraddr));
		if (ret != 0 && errno != EINPROGRESS)
		{
			set_error(connect_failed, errno);
			::close(fd);
			return -1;
		}

		m_connect_type = connect_type_nonblock;
		m_check_self_connect = false;

		m_io.fd = fd;
		return fd;
	}

	int sync_unixconnect(const address &addr, const address &localaddr = address())
	{
		static_assert(sizeof(struct sockaddr_un) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_un");

		if (m_io.fd != -1)
		{
			set_error(connected_fd, m_io.fd);
			return -1;
		}

		if (!addr.host.isunix())
		{
			set_error(invalid_addrtype, (int)addr.host.type);
			return -1;
		}

		std::pair<bool, struct sockaddr_storage> peeraddr = inetc::inaddr_pton(addr);
		if (!peeraddr.first)
		{
			set_error(invalid_host, 1, addr.host.str());
			return -1;
		}

		if (peeraddr.second.ss_family != AF_LOCAL)
			assert(false && "invalid family");

		m_peeraddr = peeraddr.second;

		std::pair<bool, struct sockaddr_storage> locaddr = std::make_pair(false, sockaddr_storage());
		if (localaddr.host.isunix())
		{
			locaddr = inetc::inaddr_pton(localaddr);
			if (!locaddr.first)
			{
				set_error(invalid_host, 2, localaddr.host.str());
				return -1;
			}

			if (locaddr.second.ss_family != AF_LOCAL)
				assert(false && "invalid family");
		}

		int fd = ::socket(m_peeraddr.ss_family, SOCK_STREAM, 0);
		if (fd == -1)
		{
			set_error(socket_create_failed, errno);
			return -1;
		}

		if (m_socket_cb)
			m_socket_cb(*static_cast<T*>(this), fd);
		else
			static_cast<T*>(this)->socket_callback(*static_cast<T*>(this), fd);

		if (locaddr.first)
		{
			if (0 != ::bind(fd, (const struct sockaddr *)&locaddr.second, sizeof(struct sockaddr_un)))
			{
				set_error(bind_failed, errno);
				::close(fd);
				return -1;
			}
		}

		int ret = ::connect(fd, (const struct sockaddr *)&m_peeraddr, sizeof(struct sockaddr_un));
		if (ret != 0)
		{
			set_error(connect_failed, errno);
			::close(fd);
			return -1;
		}

		m_connect_type = connect_type_sync;
		m_check_self_connect = false;

		m_io.fd = fd;
		return fd;
	}

	bool async_unixconnect(const address &addr, const address &localaddr = address())
	{
		static_assert(sizeof(struct sockaddr_un) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_un");

		if (m_loop.is_null())
		{
			set_error(null_loop);
			return false;
		}

		if (m_io.fd != -1)
		{
			set_error(connected_fd, m_io.fd);
			return false;
		}

		if (m_io.is_active())
		{
			set_error(connector_busy);
			return false;
		}

		if (!addr.host.isunix())
		{
			set_error(invalid_addrtype, (int)addr.host.type);
			return false;
		}

		std::pair<bool, struct sockaddr_storage> peeraddr = inetc::inaddr_pton(addr);
		if (!peeraddr.first)
		{
			set_error(invalid_host, 1, addr.host.str());
			return false;
		}

		if (peeraddr.second.ss_family != AF_LOCAL)
			assert(false && "invalid family");

		m_peeraddr = peeraddr.second;

		std::pair<bool, struct sockaddr_storage> locaddr = std::make_pair(false, sockaddr_storage());
		if (localaddr.host.isunix())
		{
			locaddr = inetc::inaddr_pton(localaddr);
			if (!locaddr.first)
			{
				set_error(invalid_host, 2, localaddr.host.str());
				return false;
			}

			if (locaddr.second.ss_family != AF_LOCAL)
				assert(false && "invalid family");
		}

		int fd = ::socket(m_peeraddr.ss_family, SOCK_STREAM | SOCK_NONBLOCK, 0);
		if (fd < 0)
		{
			set_error(socket_create_failed, errno);
			return false;
		}

		if (m_socket_cb)
			m_socket_cb(*static_cast<T*>(this), fd);
		else
			static_cast<T*>(this)->socket_callback(*static_cast<T*>(this), fd);

		if (locaddr.first)
		{
			if (0 != ::bind(fd, (const struct sockaddr *)&locaddr.second, sizeof(struct sockaddr_un)))
			{
				set_error(bind_failed, errno);
				::close(fd);
				return false;
			}
		}

		int ret = ::connect(fd, (const struct sockaddr *)&m_peeraddr, sizeof(struct sockaddr_un));
		if (ret != 0 && errno != EINPROGRESS)
		{
			set_error(connect_failed, errno);
			::close(fd);
			return false;
		}

		m_io.set(m_loop.ref());
		m_io.set<connector, &connector::io_callback>(this);
		m_io.start(fd, ev::WRITE);

		m_connect_type = connect_type_async;
		m_check_self_connect = false;

		return true;
	}

	int wait_unixconnect(const address &addr, long wait_us = -1, const address &localaddr = address())
	{
		static_assert(sizeof(struct sockaddr_un) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_un");

		if (m_io.fd != -1)
		{
			set_error(connected_fd, m_io.fd);
			return -1;
		}

		if (!addr.host.isunix())
		{
			set_error(invalid_addrtype, addr.host.type);
			return -1;
		}

		std::pair<bool, struct sockaddr_storage> peeraddr = inetc::inaddr_pton(addr);
		if (!peeraddr.first)
		{
			set_error(invalid_host, 1, addr.host.str());
			return -1;
		}

		if (peeraddr.second.ss_family != AF_LOCAL)
			assert(false && "invalid family");

		m_peeraddr = peeraddr.second;

		std::pair<bool, struct sockaddr_storage> locaddr = std::make_pair(false, sockaddr_storage());
		if (localaddr.host.isunix())
		{
			locaddr = inetc::inaddr_pton(localaddr);
			if (!locaddr.first)
			{
				set_error(invalid_host, 2, localaddr.host.str());
				return -1;
			}

			if (locaddr.second.ss_family != AF_LOCAL)
				assert(false && "invalid family");
		}

		int64_t start_us = timec::usec();

		int fd = ::socket(m_peeraddr.ss_family, SOCK_STREAM | SOCK_NONBLOCK, 0);
		if (fd == -1)
		{
			set_error(socket_create_failed, errno);
			return -1;
		}

		if (m_socket_cb)
			m_socket_cb(*static_cast<T*>(this), fd);
		else
			static_cast<T*>(this)->socket_callback(*static_cast<T*>(this), fd);

		if (locaddr.first)
		{
			if (0 != ::bind(fd, (const struct sockaddr *)&locaddr.second, sizeof(struct sockaddr_un)))
			{
				set_error(bind_failed, errno);
				::close(fd);
				return -1;
			}
		}

		int ret = ::connect(fd, (const struct sockaddr *)&m_peeraddr, sizeof(struct sockaddr_un));
		if (ret != 0 && errno != EINPROGRESS)
		{
			set_error(connect_failed, errno);
			::close(fd);
			return -1;
		}

		while (true)
		{
			struct pollfd fds;
			memset(&fds, 0, sizeof(fds));
			fds.fd      = fd;
			fds.events  = POLLOUT;
			fds.revents = 0;

			int64_t rest_us = -1;
			if (wait_us >= 0)
			{
				int64_t now_us = timec::usec();
				if (now_us <= start_us)
				{
					start_us = now_us;
					rest_us = wait_us;
				}
				else
					rest_us = wait_us - (now_us - start_us);
				if (rest_us < 0)
					rest_us = 0;
			}

			struct timespec tv;
			memset(&tv, 0, sizeof(tv));
			tv.tv_sec  = rest_us/1000000;
			tv.tv_nsec = (rest_us%1000000)*1000;

			if (rest_us < 0)
				ret = ::ppoll(&fds, 1, nullptr, nullptr);
			else
				ret = ::ppoll(&fds, 1, &tv, nullptr);

			if (ret > 0)
			{
				if ((fds.revents & POLLOUT) == 0)
				{
					/* when fd is invalid */
					set_error(ppoll_unexpected_revents, fds.revents);
					close(fd);
					return -1;
				}

				int option = 0;
				socklen_t optlen = sizeof(option);

				int rt = ::getsockopt(fd, SOL_SOCKET, SO_ERROR, &option, &optlen);
				if (rt < 0)
				{
					set_error(getsockopt_failed, errno);
					::close(fd);
					return -1;
				}
				else if (option != 0)
				{
					set_error(getsockopt_connect_failed, option);
					::close(fd);
					return -1;
				}

				if ((fds.revents & (POLLERR | POLLHUP | POLLNVAL)) != 0)
				{
					set_error(ppoll_connect_failed, fds.revents);
					::close(fd);
					return -1;
				}

				m_connect_type = connect_type_wait;
				m_check_self_connect = false;

				m_io.fd = fd;
				return fd;
			}
			else if (ret == 0)
			{
				set_error(ppoll_timeout, wait_us);
				::close(fd);
				return -1;
			}
			else
			{
				if (errno != EINTR)
				{
					set_error(ppoll_failed, errno);
					close(fd);
					return -1;
				}
			}

			if (rest_us == 0)
			{
				/* poll is interrupted by signal and timeout */
				set_error(connect_timeout, wait_us);
				::close(fd);
				return -1;
			}
		}

		assert(false && "bad routing");
		::close(fd);
		return -1;
	}

	int nonblock_unixconnect(const address &addr, const address &localaddr = address())
	{
		static_assert(sizeof(struct sockaddr_un) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_un");

		if (m_io.fd != -1)
		{
			set_error(connected_fd, m_io.fd);
			return -1;
		}

		if (!addr.host.isunix())
		{
			set_error(invalid_addrtype, (int)addr.host.type);
			return -1;
		}

		std::pair<bool, struct sockaddr_storage> peeraddr = inetc::inaddr_pton(addr);
		if (!peeraddr.first)
		{
			set_error(invalid_host, 1, addr.host.str());
			return -1;
		}

		if (peeraddr.second.ss_family != AF_LOCAL)
			assert(false && "invalid family");

		m_peeraddr = peeraddr.second;

		std::pair<bool, struct sockaddr_storage> locaddr = std::make_pair(false, sockaddr_storage());
		if (localaddr.host.isunix())
		{
			locaddr = inetc::inaddr_pton(localaddr);
			if (!locaddr.first)
			{
				set_error(invalid_host, 2, localaddr.host.str());
				return -1;
			}

			if (locaddr.second.ss_family != AF_LOCAL)
				assert(false && "invalid family");
		}

		int fd = ::socket(m_peeraddr.ss_family, SOCK_STREAM | SOCK_NONBLOCK, 0);
		if (fd < 0)
		{
			set_error(socket_create_failed, errno);
			return -1;
		}

		if (m_socket_cb)
			m_socket_cb(*static_cast<T*>(this), fd);
		else
			static_cast<T*>(this)->socket_callback(*static_cast<T*>(this), fd);

		if (locaddr.first)
		{
			if (0 != ::bind(fd, (const struct sockaddr *)&locaddr.second, sizeof(struct sockaddr_un)))
			{
				set_error(bind_failed, errno);
				::close(fd);
				return -1;
			}
		}

		int ret = ::connect(fd, (const struct sockaddr *)&m_peeraddr, sizeof(struct sockaddr_un));
		if (ret != 0 && errno != EINPROGRESS)
		{
			set_error(connect_failed, errno);
			::close(fd);
			return -1;
		}

		m_connect_type = connect_type_nonblock;
		m_check_self_connect = false;

		m_io.fd = fd;
		return fd;
	}

	connect_status connection_status(bool check_self_connect = false)
	{
		return _check_connection_status(m_io.fd, m_peeraddr, check_self_connect);
	}

	bool is_idle() const
	{
		if (m_io.is_active())
			return false;

		if (m_io.fd != -1)
			return false;

		return true;
	}

	bool is_active() const
	{
		return m_io.is_active();
	}

	connect_type get_connect_type() const
	{
		return m_connect_type;
	}

	int get_fd() const
	{
		return m_io.fd;
	}

	looprefer get_loop() const
	{
		return m_loop;
	}

	const struct sockaddr_storage& get_peeraddr() const
	{
		return m_peeraddr;
	}

	void only_close()
	{
		_only_close();
	}

	void stop_close()
	{
		_stop_close();
	}

	void only_reset()
	{
		_only_reset();
	}

public:
	static connect_status check_connection_status(int fd)
	{
		return _check_connection_status(fd, sockaddr_storage(), false);
	}

	static connect_status check_connection_status(int fd, const struct sockaddr_storage &peeraddr)
	{
		return _check_connection_status(fd, peeraddr, true);
	}

private:
	static connect_status _check_connection_status(int fd, const struct sockaddr_storage &peeraddr, bool check_self_connect)
	{
		if (fd == -1)
			return connect_status(connect_result_failed, invalid_fd, 0);

		struct pollfd fds;
		memset(&fds, 0, sizeof(fds));
		fds.fd      = fd;
		fds.events  = POLLOUT;
		fds.revents = 0;

		struct timespec tv;
		memset(&tv, 0, sizeof(tv));
		tv.tv_sec  = 0;
		tv.tv_nsec = 0;

		int ret = ::ppoll(&fds, 1, &tv, nullptr);

		if (ret > 0)
		{
			if ((fds.revents & POLLOUT) == 0)
			{
				/* when fd is invalid */
				return connect_status(connect_result_failed, ppoll_unexpected_revents, fds.revents);
			}

			int option = 0;
			socklen_t optlen = sizeof(option);

			int rt = ::getsockopt(fd, SOL_SOCKET, SO_ERROR, &option, &optlen);
			if (rt < 0)
				return connect_status(connect_result_failed, getsockopt_failed, errno);
			else if (option != 0)
				return connect_status(connect_result_failed, getsockopt_connect_failed, option);

			if ((fds.revents & (POLLERR | POLLHUP | POLLNVAL)) != 0)
				return connect_status(connect_result_failed, ppoll_connect_failed, fds.revents);

			if (check_self_connect)
			{
				if (peeraddr.ss_family == AF_INET || peeraddr.ss_family == AF_INET6)
				{
					std::pair<bool, struct sockaddr_storage> localaddr = inetc::getsockname(fd);
					if (localaddr.first)
					{
						if (inetc::addrequal(localaddr.second, peeraddr, false))
						{
							return connect_status(connect_result_failed, self_connect, inetc::getport(peeraddr));
						}
					}
				}
			}

			return connect_status(connect_result_success, success, 0);
		}
		else if (ret == 0)
		{
			return connect_status(connect_result_waiting, ppoll_timeout, 0);
		}
		else
		{
			if (errno == EINTR)
				return connect_status(connect_result_waiting, ppoll_interrupt, errno);
		}

		return connect_status(connect_result_failed, ppoll_failed, errno);
	}

protected:
	void socket_callback(T &connector, int fd) { }

	void connect_callback(T &connector, int errcode, int errnocode) { assert(false && "unset callback"); }

	void _stop_close()
	{
		m_io.stop();

		if (m_io.fd != -1)
			::close(m_io.fd);

		m_io.set(-1, 0);

		m_check_self_connect = false;
		m_connect_type = connect_type_unknown;

		memset(&m_peeraddr, 0, sizeof(m_peeraddr));
	}

	void _only_close()
	{
		if (m_io.fd != -1)
			::close(m_io.fd);

		m_io.set(-1, 0);

		m_check_self_connect = false;
		m_connect_type = connect_type_unknown;

		memset(&m_peeraddr, 0, sizeof(m_peeraddr));
	}

	void _only_reset()
	{
		m_io.set(-1, 0);

		m_check_self_connect = false;
		m_connect_type = connect_type_unknown;

		memset(&m_peeraddr, 0, sizeof(m_peeraddr));
	}

private:
	void io_callback(ev::io &watcher, int revents)
	{
		if (evunlike((revents & ev::ERROR) != 0))
			assert(false && "ev_error");
		if (evunlike(&watcher != &m_io))
			assert(false && "unexpected watcher");
		if (evunlike(m_io.fd == -1))
			assert(false && "bad fd");
		if (evunlike(m_connect_type != connect_type_async))
			assert(false && "unexpected connect type");

		if (0 == (revents & ev::WRITE))
		{
			set_error(unexpected_revents, revents);
			_stop_close();

			if (m_connect_cb)
				m_connect_cb(*static_cast<T*>(this), unexpected_revents, revents);
			else
				static_cast<T*>(this)->connect_callback(*static_cast<T*>(this), unexpected_revents, revents);
			return;
		}

		int option = 0;
		socklen_t optlen = sizeof(option);

		int ret = ::getsockopt(m_io.fd, SOL_SOCKET, SO_ERROR, &option, &optlen);
		if (ret < 0)
		{
			set_error(getsockopt_failed, errno);
			_stop_close();

			if (m_connect_cb)
				m_connect_cb(*static_cast<T*>(this), getsockopt_failed, errno);
			else
				static_cast<T*>(this)->connect_callback(*static_cast<T*>(this), getsockopt_failed, errno);
			return;
		}
		else if (option != 0)
		{
			set_error(getsockopt_connect_failed, option);
			_stop_close();

			if (m_connect_cb)
				m_connect_cb(*static_cast<T*>(this), getsockopt_connect_failed, option);
			else
				static_cast<T*>(this)->connect_callback(*static_cast<T*>(this), getsockopt_connect_failed, option);
			return;
		}

		if (m_check_self_connect)
		{
			if (m_peeraddr.ss_family == AF_INET || m_peeraddr.ss_family == AF_INET6)
			{
				std::pair<bool, struct sockaddr_storage> localaddr = inetc::getsockname(m_io.fd);
				if (localaddr.first)
				{
					if (inetc::addrequal(localaddr.second, m_peeraddr, false))
					{
						set_error(self_connect, inetc::getport(localaddr.second));
						_stop_close();

						if (m_connect_cb)
							m_connect_cb(*static_cast<T*>(this), self_connect, inetc::getport(localaddr.second));
						else
							static_cast<T*>(this)->connect_callback(*static_cast<T*>(this), self_connect, inetc::getport(localaddr.second));
						return;
					}
				}
			}
		}

		watcher.stop();

		if (m_connect_cb)
			m_connect_cb(*static_cast<T*>(this), success, 0);
		else
			static_cast<T*>(this)->connect_callback(*static_cast<T*>(this), success, 0);
	}

private:
	connect_type  m_connect_type;

	struct sockaddr_storage  m_peeraddr;
	bool                     m_check_self_connect;

	looprefer  m_loop;
	ev::io     m_io;

	socket_callback_t   m_socket_cb;
	connect_callback_t  m_connect_cb;
};

class simpconnector : public connector<simpconnector>
{};


}


#endif


