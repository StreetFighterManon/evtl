

#ifndef __EVTL_THREAD_H__
#define __EVTL_THREAD_H__

#include <sys/types.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/prctl.h>
#include <pthread.h>
#include <assert.h>
#include <limits.h>

#include <utility>
#include <string>
#include <functional>

#include "evtl_error.h"


namespace evtl { namespace thread {


class threadc : public evtl_error
{
public:
	typedef std::function<void * (void *arg)>  thread_callback_t;

	enum error_code
	{
		success,
		threadid_exist,
		thread_attrinit_failed,
		thread_create_failed
	};

	threadc(): m_tid(0), m_arg(nullptr)
	{}

	void set_callback(thread_callback_t cb)
	{
		m_thread_callback = std::move(cb);
	}

	bool make_thread(void *arg, const std::string &thread_name, ssize_t stacksize = 0)
	{
		if (m_tid != 0)
		{
			set_error(threadid_exist);
			return false;
		}

		m_arg         = arg;
		m_thread_name = thread_name;

		if (stacksize > 0 && stacksize < PTHREAD_STACK_MIN)
			stacksize = PTHREAD_STACK_MIN;

		pthread_attr_t attr;
		if (pthread_attr_init(&attr) != 0)
		{
			set_error(thread_attrinit_failed, errno);
			return false;
		}

		pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
		if (stacksize >= PTHREAD_STACK_MIN)
			pthread_attr_setstacksize(&attr, stacksize);

		pthread_t tid = 0;
		int ret = pthread_create(&tid, &attr, threadproc, this);
		int crerrno = errno;
		pthread_attr_destroy(&attr);

		if (ret != 0)
		{
			set_error(thread_create_failed, crerrno);
			return false;
		}

		m_tid = tid;
		return true;
	}

private:
	static void * threadproc(void *arg)
	{
		threadc *p = static_cast<threadc *>(arg);
		assert(p != nullptr);
		return p->threadproc_O0(p->m_arg, p->m_thread_name, ::syscall(SYS_gettid), pthread_self());
	}

#pragma GCC push_options
#pragma GCC optimize ("O0")
	void * threadproc_O0(void *arg, const std::string &thread_name, long kernel_tid, pthread_t posix_tid)
	{
		if (!thread_name.empty())
			::prctl(PR_SET_NAME, thread_name.c_str());

		return m_thread_callback(m_arg);
	}
#pragma GCC pop_options

private:
	pthread_t           m_tid;
	void *              m_arg;
	std::string         m_thread_name;
	thread_callback_t   m_thread_callback;
};


class methodthreadc : public evtl_error
{
public:
	struct callback_thunk
	{
		callback_thunk(): object(nullptr), callback(nullptr)
		{}

		void *object;
		void *(*callback)(void *object, void *arg);
	};

	enum error_code
	{
		success,
		threadid_exist,
		thread_attrinit_failed,
		thread_create_failed
	};

	methodthreadc(): m_tid(0), m_arg(nullptr)
	{}

	template <class T, void *(T::*method)(void *arg)>
	void set_callback(T *object)
	{
		m_thunk.object    = object;
		m_thunk.callback  = method_thunk<T, method>;
	}

	bool make_thread(void *arg, const std::string &thread_name, ssize_t stacksize = 0)
	{
		if (m_tid != 0)
		{
			set_error(threadid_exist);
			return false;
		}

		m_arg         = arg;
		m_thread_name = thread_name;

		if (stacksize > 0 && stacksize < PTHREAD_STACK_MIN)
			stacksize = PTHREAD_STACK_MIN;

		pthread_attr_t attr;
		if (pthread_attr_init(&attr) != 0)
		{
			set_error(thread_attrinit_failed, errno);
			return false;
		}

		pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
		if (stacksize >= PTHREAD_STACK_MIN)
			pthread_attr_setstacksize(&attr, stacksize);

		pthread_t tid = 0;
		int ret = pthread_create(&tid, &attr, threadproc, this);
		int crerrno = errno;
		pthread_attr_destroy(&attr);

		if (ret != 0)
		{
			set_error(thread_create_failed, crerrno);
			return false;
		}

		m_tid = tid;
		return true;
	}

private:
	static void * threadproc(void *arg)
	{
		methodthreadc *p = static_cast<methodthreadc *>(arg);
		assert(p != nullptr);
		return p->threadproc_O0(p->m_arg, p->m_thread_name, ::syscall(SYS_gettid), pthread_self());
	}

#pragma GCC push_options
#pragma GCC optimize ("O0")
	void * threadproc_O0(void *arg, const std::string &thread_name, long kernel_tid, pthread_t posix_tid)
	{
		if (!thread_name.empty())
			::prctl(PR_SET_NAME, thread_name.c_str());

		return m_thunk.callback(m_thunk.object, m_arg);
	}
#pragma GCC pop_options

private:
	template <class T, void *(T::*method)(void *arg)>
	static void * method_thunk(void *object, void *arg)
	{
		return (static_cast<T*>(object)->*method)(arg);
	}

private:
	pthread_t       m_tid;
	void *          m_arg;
	std::string     m_thread_name;

	callback_thunk  m_thunk;
};


class functhreadc : public evtl_error
{
public:
	typedef void *(*thread_callback_t)(void *arg);

	functhreadc(): m_tid(0), m_arg(nullptr), m_thread_callback(nullptr)
	{}

	enum error_code
	{
		success,
		threadid_exist,
		thread_attrinit_failed,
		thread_create_failed
	};

	void set_callback(thread_callback_t func)
	{
		m_thread_callback = func;
	}

	bool make_thread(void *arg, const std::string &thread_name, ssize_t stacksize = 0)
	{
		if (m_tid != 0)
		{
			set_error(threadid_exist);
			return false;
		}

		m_arg         = arg;
		m_thread_name = thread_name;

		if (stacksize > 0 && stacksize < PTHREAD_STACK_MIN)
			stacksize = PTHREAD_STACK_MIN;

		pthread_attr_t attr;
		if (pthread_attr_init(&attr) != 0)
		{
			set_error(thread_attrinit_failed, errno);
			return false;
		}

		pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
		if (stacksize >= PTHREAD_STACK_MIN)
			pthread_attr_setstacksize(&attr, stacksize);

		pthread_t tid = 0;
		int ret = pthread_create(&tid, &attr, threadproc, this);
		int crerrno = errno;
		pthread_attr_destroy(&attr);

		if (ret != 0)
		{
			set_error(thread_create_failed, crerrno);
			return false;
		}

		m_tid = tid;
		return true;
	}

private:
	static void * threadproc(void *arg)
	{
		functhreadc *p = static_cast<functhreadc *>(arg);
		assert(p != nullptr);
		return p->threadproc_O0(p->m_arg, p->m_thread_name, ::syscall(SYS_gettid), pthread_self());
	}

#pragma GCC push_options
#pragma GCC optimize ("O0")
	void * threadproc_O0(void *arg, const std::string &thread_name, long kernel_tid, pthread_t posix_tid)
	{
		if (!thread_name.empty())
			::prctl(PR_SET_NAME, thread_name.c_str());

		return m_thread_callback(m_arg);
	}
#pragma GCC pop_options

private:
	pthread_t           m_tid;
	void *              m_arg;
	std::string         m_thread_name;
	thread_callback_t   m_thread_callback;
};


struct mdtresult
{
	mdtresult(): result(false), tid(0), errcode(0), errint(0)
	{}

	operator bool () const
	{
		return result;
	}

	bool      result;
	pthread_t tid;
	int       errcode;
	int       errint;
};

inline mdtresult make_detached(void * (*start_routine)(void *), void *arg = nullptr, ssize_t stacksize = 0)
{
	mdtresult mresult;
	mresult.result = false;

	if (stacksize > 0 && stacksize < PTHREAD_STACK_MIN)
		stacksize = PTHREAD_STACK_MIN;

	pthread_attr_t attr;
	if (pthread_attr_init(&attr) != 0)
	{
		mresult.errcode = 1;
		mresult.errint = errno;
		return mresult;
	}

	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
	if (stacksize >= PTHREAD_STACK_MIN)
		pthread_attr_setstacksize(&attr, stacksize);

	int ret = pthread_create(&mresult.tid, &attr, start_routine, arg);
	if (ret == 0)
		mresult.result = true;
	else
	{
		mresult.errcode = 2;
		mresult.errint = errno;
	}
	pthread_attr_destroy(&attr);

	return mresult;
}


} }


#endif


