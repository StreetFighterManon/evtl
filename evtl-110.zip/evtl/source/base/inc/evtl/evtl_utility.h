

#ifndef __EVTL_UTILITY_H__
#define __EVTL_UTILITY_H__

#include <sys/types.h>
#include <assert.h>
#include <string>


namespace evtl { namespace util {


inline int stoi(const std::string &str, int base = 10)
{
	int val = 0;

	try
	{
		val = std::stoi(str, nullptr, base);
	}
	catch (std::exception &)
	{
		val = 0;
	}

	return val;
}

inline long long stoll(const std::string &str, int base = 10)
{
	long long val = 0;

	try
	{
		val = std::stoll(str, nullptr, base);
	}
	catch (std::exception &)
	{
		val = 0;
	}

	return val;
}

inline unsigned long long stoull(const std::string &str, int base = 10)
{
	long long val = 0;

	try
	{
		val = std::stoull(str, nullptr, base);
	}
	catch (std::exception &)
	{
		val = 0;
	}

	return val;
}

inline unsigned int stoui(const std::string &str, int base = 10)
{
	unsigned long long val = stoull(str, base);
	if (val > 0xffffffffuLL)
		return 0;

	return (unsigned int)val;
}

inline float stof(const std::string &str)
{
	float val = 0.f;

	try
	{
		val = std::stof(str, nullptr);
	}
	catch (std::exception &)
	{
		val = 0.f;
	}

	return val;
}

inline double stod(const std::string &str)
{
	double val = 0.;

	try
	{
		val = std::stod(str, nullptr);
	}
	catch (std::exception &)
	{
		val = 0.;
	}

	return val;
}

inline bool isprefixwith(const char *str, ssize_t size, const std::string &prefix)
{
	if (str == nullptr || size < 0)
	{
		assert(false && "invalid str");
		return false;
	}

	ssize_t prefsize = (ssize_t)prefix.size();
	if (prefsize > size)
		return false;

	for (ssize_t i = 0; i < prefsize; i++)
	{
		if (str[i] != prefix[i])
			return false;
	}

	return true;
}

inline bool isprefixwith(const std::string &str, const std::string &prefix)
{
	return isprefixwith(str.c_str(), (ssize_t)str.size(), prefix);
}

inline bool issuffixwith(const char *str, ssize_t size, const std::string &suffix)
{
	if (str == nullptr || size < 0)
	{
		assert(false && "invalid str");
		return false;
	}

	ssize_t sufsize = (ssize_t)suffix.size();
	if (sufsize > size)
		return false;

	for (ssize_t i = 0; i < sufsize; i++)
	{
		if (str[size - 1 - i] != suffix[sufsize - 1 - i])
			return false;
	}

	return true;
}

inline bool issuffixwith(const std::string &str, const std::string &suffix)
{
	return issuffixwith(str.c_str(), (ssize_t)str.size(), suffix);
}


} }


#endif


