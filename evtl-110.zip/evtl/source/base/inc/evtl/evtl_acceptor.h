

#ifndef __EVTL_ACCEPTOR_H__
#define __EVTL_ACCEPTOR_H__

#include <unistd.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <assert.h>

#include <utility>
#include <functional>
#include <vector>
#include <cstring>
#include <string>

#include <ev/ev++.h>

#include "evtl_gcc.h"
#include "evtl_error.h"
#include "evtl_eventloop.h"
#include "evtl_listener.h"
#include "evtl_in.h"


namespace evtl
{


template <class T>
class acceptor : public evtl_error
{
public:
	typedef std::function<void (T &accptor, std::vector<connection> &connections)>  accept_callback_t;
	typedef std::function<void (T &accptor, int errcode, int errnocode)>  accept_error_callback_t;

	enum error_code
	{
		success,
		null_loop,
		null_listener,
		unlistening,
		try_again_later,
		connection_aborted,
		network_error,
		fd_use_up,
		accept_exception
	};

	acceptor(): m_plistener(nullptr), m_once_callback_max_accept(1), m_dummy_fd(-1)
	{
		m_io.set(nullptr);
		m_io.set(-1, 0);
	}

	bool occupy_dummy()
	{
		if (m_dummy_fd == -1)
			m_dummy_fd = ::open("/dev/null", O_RDWR);

		return m_dummy_fd != -1;
	}

	void set_loop(looprefer loop)
	{
		if (m_io.is_active())
			m_io.stop();

		m_loop = loop;
	}

	void set_listener(listener *plistener)
	{
		if (m_io.is_active())
			m_io.stop();

		m_plistener = plistener;
	}

	void set_callback()
	{
		if (m_io.is_active())
			m_io.stop();

		m_accept_cb = nullptr;
	}

	void set_callback(accept_callback_t cb)
	{
		if (m_io.is_active())
			m_io.stop();

		m_accept_cb = std::move(cb);
	}

	void set_accepterror_callback()
	{
		if (m_io.is_active())
			m_io.stop();

		m_accepterror_cb = nullptr;
	}

	void set_accepterror_callback(accept_error_callback_t cb)
	{
		if (m_io.is_active())
			m_io.stop();

		m_accepterror_cb = std::move(cb);
	}

	void set_once_max_accept(int n_acpt)
	{
		if (n_acpt < 1)
			m_once_callback_max_accept = 1;
		else
			m_once_callback_max_accept = n_acpt;
	}

	bool watch()
	{
		if (m_loop.is_null())
		{
			set_error(null_loop);
			return false;
		}

		if (m_plistener == nullptr)
		{
			set_error(null_listener);
			return false;
		}

		if (m_plistener->get_fd() == -1)
		{
			set_error(unlistening);
			return false;
		}

		if (!m_io.is_active())
		{
			m_io.set(m_loop.ref());
			m_io.set<acceptor, &acceptor::_callback>(this);
			m_io.set(m_plistener->get_fd(), ev::READ);
			m_io.start();
		}

		return true;
	}

	bool is_watching() const
	{
		return m_io.is_active();
	}

	void unwatch()
	{
		m_io.stop();
	}

	connection accept(int flags = 0)
	{
		connection conn;

		if (m_plistener == nullptr)
		{
			set_error(null_listener);
			return conn;
		}

		int fd = m_plistener->get_fd();
		if (fd == -1)
		{
			set_error(unlistening);
			return conn;
		}

		accept_result ars;
		accept_one(fd, conn, ars, flags);
		return conn;
	}

	looprefer get_loop() const
	{
		return m_loop;
	}

	void deinit()
	{
		m_io.stop();

		m_accept_cb      = nullptr;
		m_accepterror_cb = nullptr;

		if (m_dummy_fd != -1)
			::close(m_dummy_fd);
		m_dummy_fd = -1;
	}

private:
	void accept_callback(T &accptor, std::vector<connection> &connections) { assert(false && "unset callback"); }

	void accepterror_callback(T &accptor, int errcode, int errnocode)
	{
		if (errcode == accept_exception)
			assert(false && "accept exception occurred");
	}

	struct accept_result
	{
		accept_result(int err = success, int errn = 0)
			: errcode(err), errnocode(errn)
		{}

		void set(int err, int errn)
		{
			errcode   = err;
			errnocode = errn;
		}

		int  errcode;
		int  errnocode;
	};

	void _callback(ev::io &watcher, int revents)
	{
		if (evunlike((revents & ev::ERROR) != 0))
			assert(false && "ev_error");
		if (evunlike(&watcher != &m_io))
			assert(false && "unexpected watcher");
		if (evunlike(watcher.fd == -1))
			assert(false && "bad watcher fd");
		if (evunlike(m_plistener == nullptr))
			assert(false && "null listener");
		if (evunlike(watcher.fd != m_plistener->get_fd()))
			assert(false && "unexpected listen fd");

		if (m_once_callback_max_accept < 1)
			m_once_callback_max_accept = 1;

		accept_result result;

		std::vector<connection> connections;
		for (int i = 0; i < m_once_callback_max_accept; i++)
		{
			connection conn;
			if (accept_one(watcher.fd, conn, result, SOCK_NONBLOCK))
				connections.push_back(conn);
			else
				break;
		}

		if (connections.empty())
		{
			if (result.errcode == fd_use_up || result.errcode == accept_exception)
			{
				if (m_accepterror_cb)
					m_accepterror_cb(*static_cast<T*>(this), result.errcode, result.errnocode);
				else
					static_cast<T*>(this)->accepterror_callback(*static_cast<T*>(this), result.errcode, result.errnocode);
			}
			return;
		}

		if (m_accept_cb)
			m_accept_cb(*static_cast<T*>(this), connections);
		else
			static_cast<T*>(this)->accept_callback(*static_cast<T*>(this), connections);

		if (result.errcode == fd_use_up || result.errcode == accept_exception)
		{
			if (m_accepterror_cb)
				m_accepterror_cb(*static_cast<T*>(this), result.errcode, result.errnocode);
			else
				static_cast<T*>(this)->accepterror_callback(*static_cast<T*>(this), result.errcode, result.errnocode);
		}
	}

	bool accept_one(int listen_fd, connection &conn, accept_result &result, int flags)
	{
		if (evunlike(listen_fd == -1))
			assert(false && "bad listen fd");

		if (m_dummy_fd == -1)
			m_dummy_fd = ::open("/dev/null", O_RDWR);

		struct sockaddr_storage peeraddr;
		memset(&peeraddr, 0, sizeof(peeraddr));

		socklen_t len = sizeof(peeraddr);
		int acpt_fd = ::accept4(listen_fd, (struct sockaddr *)&peeraddr, &len, flags);
		if (acpt_fd < 0)
		{
			if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR)
			{
				set_error(try_again_later, errno);
				result.set(try_again_later, errno);
			}
			else if (errno == ECONNABORTED)
			{
				set_error(connection_aborted, errno);
				result.set(connection_aborted, errno);
			}
			else if (errno == ENETDOWN || errno == EPROTO || errno == ENOPROTOOPT || errno == EHOSTDOWN
				|| errno == ENONET || errno == EHOSTUNREACH || errno == EOPNOTSUPP || errno == ENETUNREACH
				)
			{
				set_error(network_error, errno);
				result.set(network_error, errno);
			}
			else if (errno == EMFILE || errno == ENFILE)
			{
				set_error(fd_use_up, errno);
				result.set(fd_use_up, errno);

				if (m_dummy_fd != -1)
				{
					::close(m_dummy_fd);
					m_dummy_fd = -1;
					len = sizeof(peeraddr);
					acpt_fd = ::accept4(listen_fd, (struct sockaddr *)&peeraddr, &len, 0);
					if (acpt_fd >= 0)
						::close(acpt_fd);
					m_dummy_fd = ::open("/dev/null", O_RDWR);
				}
			}
			else
			{
				set_error(accept_exception, errno);
				result.set(accept_exception, errno);
			}
			return false;
		}
		else
		{
			conn.fd = acpt_fd;
			conn.peeraddr = peeraddr;
			conn.localaddr = m_plistener->get_addr();
		}

		result.set(success, 0);
		return true;
	}

private:
	looprefer   m_loop;

	listener   *m_plistener;
	ev::io      m_io;

	accept_callback_t        m_accept_cb;
	accept_error_callback_t  m_accepterror_cb;

	int    m_once_callback_max_accept;

	int    m_dummy_fd;
};

class simpacceptor : public acceptor<simpacceptor>
{};


}


#endif


