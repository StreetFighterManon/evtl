

#ifndef __EVTL_GCC_H__
#define __EVTL_GCC_H__


#define  evlike(x)        __builtin_expect(!!(x), 1)
#define  evunlike(x)      __builtin_expect(!!(x), 0)

#define  gcc_thread_fence    do { __atomic_thread_fence(__ATOMIC_SEQ_CST); } while (0)


#endif


