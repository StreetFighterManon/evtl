

#ifndef __EVTL_TIME_H__
#define __EVTL_TIME_H__

#include <time.h>

#include <cstdint>
#include <atomic>
#include <functional>
#include <utility>
#include <cstring>

#include "evtl_thread.h"


namespace evtl
{


class timec
{
public:
	static timec * instance()
	{
		return _singleton();
	}

	static bool background_update(int once_sleep_us = 1)
	{
		return _singleton()->_background_update(once_sleep_us);
	}

	static bool is_updating()
	{
		return _singleton()->_is_updating();
	}

	static int64_t sec()
	{
		struct timespec ts;
		memset(&ts, 0, sizeof(ts));
		::clock_gettime(CLOCK_REALTIME, &ts);
		return static_cast<int64_t>(ts.tv_sec);
	}

	static int64_t msec()
	{
		struct timespec ts;
		memset(&ts, 0, sizeof(ts));
		::clock_gettime(CLOCK_REALTIME, &ts);
		return static_cast<int64_t>(ts.tv_sec*1000LL + ts.tv_nsec/1000000LL);
	}

	static int64_t usec()
	{
		struct timespec ts;
		memset(&ts, 0, sizeof(ts));
		::clock_gettime(CLOCK_REALTIME, &ts);
		return static_cast<int64_t>(ts.tv_sec*1000000LL + ts.tv_nsec/1000LL);
	}

	static int64_t nsec()
	{
		struct timespec ts;
		memset(&ts, 0, sizeof(ts));
		::clock_gettime(CLOCK_REALTIME, &ts);
		return static_cast<int64_t>(ts.tv_sec*1000000000LL + ts.tv_nsec);
	}

	static double sec_f()
	{
		struct timespec ts;
		memset(&ts, 0, sizeof(ts));
		::clock_gettime(CLOCK_REALTIME, &ts);
		return (double)ts.tv_sec + (double)ts.tv_nsec/1000000000.;
	}

	static int64_t fast_sec()
	{
		return _singleton()->_fast_sec();
	}

	static int64_t fast_msec()
	{
		return _singleton()->_fast_msec();
	}

	static int64_t fast_usec()
	{
		return _singleton()->_fast_usec();
	}

	static int64_t fast_nsec()
	{
		return _singleton()->_fast_nsec();
	}

	static double fast_sec_f()
	{
		return _singleton()->_fast_sec_f();
	}

public:
	static std::pair<bool, struct tm> gmtime(time_t time_s)
	{
		std::pair<bool, struct tm> result = std::make_pair(false, tm());

		if (::gmtime_r(&time_s, &result.second) != nullptr)
			result.first = true;

		return result;
	}

	static std::pair<bool, struct tm> localtime(time_t time_s)
	{
		std::pair<bool, struct tm> result = std::make_pair(false, tm());

		if (::localtime_r(&time_s, &result.second) != nullptr)
			result.first = true;

		return result;
	}

	// return -1 if error
	static time_t localtime(const struct tm &tmval)
	{
		struct tm temp = tmval;
		return ::mktime(&temp);
	}

	template <unsigned int MaxSize = 1024>
	static std::string strftime(const char *format, const struct tm &tmval)
	{
		static_assert(MaxSize > 0 && MaxSize <= 1024*64, "invalid buffer size");

		char buf[MaxSize + 1] = { 0 };

		ssize_t r = (ssize_t)::strftime(buf, sizeof(buf), format, &tmval);
		if (r <= 0 || r >= (ssize_t)sizeof(buf))
			return std::string();
		else
			return std::string(buf, r);
	}

	template <unsigned int MaxSize = 1024>
	static std::string strfgmtime(const char *format, time_t time_s)
	{
		static_assert(MaxSize > 0 && MaxSize <= 1024*64, "invalid buffer size");

		struct tm tmval;
		memset(&tmval, 0, sizeof(tmval));
		if (::gmtime_r(&time_s, &tmval) == nullptr)
			return std::string();

		char buf[MaxSize + 1] = { 0 };
		ssize_t r = (ssize_t)::strftime(buf, sizeof(buf), format, &tmval);
		if (r <= 0 || r >= (ssize_t)sizeof(buf))
			return std::string();
		else
			return std::string(buf, r);
	}

	template <unsigned int MaxSize = 1024>
	static std::string strflocaltime(const char *format, time_t time_s)
	{
		static_assert(MaxSize > 0 && MaxSize <= 1024*64, "invalid buffer size");

		struct tm tmval;
		memset(&tmval, 0, sizeof(tmval));
		if (::localtime_r(&time_s, &tmval) == nullptr)
			return std::string();

		char buf[MaxSize + 1] = { 0 };
		ssize_t r = (ssize_t)::strftime(buf, sizeof(buf), format, &tmval);
		if (r <= 0 || r >= (ssize_t)sizeof(buf))
			return std::string();
		else
			return std::string(buf, r);
	}

	static std::pair<bool, struct tm> strptime(const std::string &str, const char *format)
	{
		std::pair<bool, struct tm> result = std::make_pair(false, tm());

		if (::strptime(str.c_str(), format, &result.second) != nullptr)
			result.first = true;

		return result;
	}

	// return -1 if error
	static int64_t strplocaltime(const std::string &str, const char *format)
	{
		struct tm tmval;
		memset(&tmval, 0, sizeof(tmval));

		char *p = ::strptime(str.c_str(), format, &tmval);
		if (p != nullptr)
			return ::mktime(&tmval);

		return -1;
	}

public:
	static int64_t process_cputime_sec()
	{
		struct timespec ts;
		memset(&ts, 0, sizeof(ts));
		::clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &ts);
		return static_cast<int64_t>(ts.tv_sec);
	}

	static int64_t process_cputime_msec()
	{
		struct timespec ts;
		memset(&ts, 0, sizeof(ts));
		::clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &ts);
		return static_cast<int64_t>(ts.tv_sec*1000LL + ts.tv_nsec/1000000LL);
	}

	static int64_t process_cputime_usec()
	{
		struct timespec ts;
		memset(&ts, 0, sizeof(ts));
		::clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &ts);
		return static_cast<int64_t>(ts.tv_sec*1000000LL + ts.tv_nsec/1000LL);
	}

	static int64_t process_cputime_nsec()
	{
		struct timespec ts;
		memset(&ts, 0, sizeof(ts));
		::clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &ts);
		return static_cast<int64_t>(ts.tv_sec*1000000000LL + ts.tv_nsec);
	}

	static int64_t thread_cputime_sec()
	{
		struct timespec ts;
		memset(&ts, 0, sizeof(ts));
		::clock_gettime(CLOCK_THREAD_CPUTIME_ID, &ts);
		return static_cast<int64_t>(ts.tv_sec);
	}

	static int64_t thread_cputime_msec()
	{
		struct timespec ts;
		memset(&ts, 0, sizeof(ts));
		::clock_gettime(CLOCK_THREAD_CPUTIME_ID, &ts);
		return static_cast<int64_t>(ts.tv_sec*1000LL + ts.tv_nsec/1000000LL);
	}

	static int64_t thread_cputime_usec()
	{
		struct timespec ts;
		memset(&ts, 0, sizeof(ts));
		::clock_gettime(CLOCK_THREAD_CPUTIME_ID, &ts);
		return static_cast<int64_t>(ts.tv_sec*1000000LL + ts.tv_nsec/1000LL);
	}

	static int64_t thread_cputime_nsec()
	{
		struct timespec ts;
		memset(&ts, 0, sizeof(ts));
		::clock_gettime(CLOCK_THREAD_CPUTIME_ID, &ts);
		return static_cast<int64_t>(ts.tv_sec*1000000000LL + ts.tv_nsec);
	}

private:
	timec(): m_thread_inited(false), m_now_s(0), m_now_ms(0), m_now_us(0), m_now_ns(0)
	{}

	static timec * _singleton()
	{
		static timec *object = new timec;
		if (object == nullptr)
			assert(false && "malloc failed");
		return object;
	}

	int64_t _fast_sec()
	{
		return m_now_s.load(std::memory_order_relaxed);
	}

	int64_t _fast_msec()
	{
		return m_now_ms.load(std::memory_order_relaxed);
	}

	int64_t _fast_usec()
	{
		return m_now_us.load(std::memory_order_relaxed);
	}

	int64_t _fast_nsec()
	{
		return m_now_ns.load(std::memory_order_relaxed);
	}

	double _fast_sec_f()
	{
		return m_now_s_f.load(std::memory_order_relaxed);
	}

	bool _background_update(int once_sleep_us = 1)
	{
		if (once_sleep_us < 0)
			once_sleep_us = 0;

		bool expected = false;
		if (m_thread_inited.compare_exchange_strong(expected, true, std::memory_order_seq_cst, std::memory_order_seq_cst))
		{
			struct timespec tv;
			memset(&tv, 0, sizeof(tv));
			int rt = ::clock_gettime(CLOCK_REALTIME, &tv);
			if (rt == 0)
			{
				m_now_s.store( static_cast<int64_t>(tv.tv_sec), std::memory_order_seq_cst );
				m_now_ms.store( static_cast<int64_t>(tv.tv_sec*1000LL + tv.tv_nsec/1000000LL), std::memory_order_seq_cst );
				m_now_us.store( static_cast<int64_t>(tv.tv_sec*1000000LL + tv.tv_nsec/1000LL), std::memory_order_seq_cst );
				m_now_ns.store( static_cast<int64_t>(tv.tv_sec*1000000000LL + tv.tv_nsec), std::memory_order_seq_cst );
				m_now_s_f.store( static_cast<double>(tv.tv_sec) + static_cast<double>(tv.tv_nsec)/1000000000., std::memory_order_seq_cst );
			}

			m_thread.set_callback<timec, &timec::_update_thread>(this);
			bool br = m_thread.make_thread(reinterpret_cast<void *>(once_sleep_us), "timeupdate");
			return br;
		}

		return false;
	}

	bool _is_updating() const
	{
		return m_thread_inited.load(std::memory_order_relaxed);
	}

	void * _update_thread(void *arg)
	{
		int us = static_cast<int>(reinterpret_cast<int64_t>(arg));
		while (true)
		{
			struct timespec tv;
			memset(&tv, 0, sizeof(tv));
			int rt = ::clock_gettime(CLOCK_REALTIME, &tv);

			if (rt == 0)
			{
				m_now_s.store( static_cast<int64_t>(tv.tv_sec), std::memory_order_relaxed );
				m_now_ms.store( static_cast<int64_t>(tv.tv_sec*1000LL + tv.tv_nsec/1000000LL), std::memory_order_relaxed );
				m_now_us.store( static_cast<int64_t>(tv.tv_sec*1000000LL + tv.tv_nsec/1000LL), std::memory_order_relaxed );
				m_now_ns.store( static_cast<int64_t>(tv.tv_sec*1000000000LL + tv.tv_nsec), std::memory_order_relaxed );
				m_now_s_f.store( static_cast<double>(tv.tv_sec) + static_cast<double>(tv.tv_nsec)/1000000000., std::memory_order_relaxed );
			}

			if (us > 0)
				::usleep(us);
		}

		return nullptr;
	}

private:
	std::atomic<bool>     m_thread_inited;
	thread::methodthreadc  m_thread;

	std::atomic<int64_t>  m_now_s;
	std::atomic<int64_t>  m_now_ms;
	std::atomic<int64_t>  m_now_us;
	std::atomic<int64_t>  m_now_ns;
	std::atomic<double>   m_now_s_f;
};


}


#endif


