

#ifndef __EVTL_WASYNCS_H__
#define __EVTL_WASYNCS_H__

#include <sys/types.h>
#include <atomic>
#include <utility>

#include "evtl_watcher_async.h"
#include "evtl_container.h"
#include "evtl_lock.h"


namespace evtl
{


template
<
	class T,
	class elemType
>
class atomic_wasync : public watcher_async<T>
{
public:
	atomic_wasync(): m_elem(elemType())
	{}

	void set_value(elemType elem)
	{
		m_elem = elem;
	}

	elemType get_value() const
	{
		return m_elem;
	}

private:
	std::atomic<elemType>  m_elem;
};

template <class elemType>
class atomic_simpwasync : public atomic_wasync<atomic_simpwasync<elemType>, elemType>
{};


template
<
	class T,
	class elemType,
	elemType initval
>
class atom_wasync : public watcher_async<T>
{
public:
	atom_wasync()
	{
		__atomic_store_n(&m_elem, initval, __ATOMIC_SEQ_CST);
	}

	void set_value(elemType elem)
	{
		__atomic_store_n(&m_elem, elem, __ATOMIC_SEQ_CST);
	}

	elemType get_value() const
	{
		return __atomic_load_n(&m_elem, __ATOMIC_SEQ_CST);
	}

	void reset_value()
	{
		__atomic_store_n(&m_elem, initval, __ATOMIC_SEQ_CST);
	}

private:
	elemType  m_elem;
};

template <class elemType, elemType initval>
class atom_simpwasync : public atom_wasync<atom_simpwasync<elemType, initval>, elemType, initval>
{};


template
<
	class T,
	class elemType,
	class lockPolicy = lock::mutex_lock
>
class singleton_wasync : public watcher_async<T>
{
public:
	singleton_wasync(): m_elem()
	{}

	bool init()
	{
		return m_lock.init();
	}

	void deinit()
	{
		m_lock.deinit();
	}

	void set_value(const elemType &elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_elem = elem;
	}

	void set_value(elemType &&elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_elem = std::move(elem);
	}

	elemType get_value()
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		return m_elem;
	}

private:
	elemType    m_elem;
	lockPolicy  m_lock;
};

template
<
	class elemType,
	class lockPolicy = lock::mutex_lock
>
class singleton_simpwasync : public singleton_wasync<singleton_simpwasync<elemType, lockPolicy>, elemType, lockPolicy>
{};


template
<
	class T,
	class elemType,
	class lockPolicy = lock::mutex_lock
>
class queue_wasync : public watcher_async<T>
{
public:
	queue_wasync(): m_atomsize(0)
	{}

	bool init()
	{
		m_queue.clear();
		m_atomsize = 0;
		return m_lock.init();
	}

	void deinit()
	{
		m_queue.clear();
		m_atomsize = 0;
		m_lock.deinit();
	}

	void pushback(const elemType &elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_queue.pushback(elem);
		m_atomsize = m_queue.size();
	}

	void pushback(elemType &&elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_queue.pushback(std::move(elem));
		m_atomsize = m_queue.size();
	}

	void pushback(const std::vector<elemType> &elems)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_queue.pushback(elems);
		m_atomsize = m_queue.size();
	}

	void pushfront(const elemType &elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_queue.pushfront(elem);
		m_atomsize = m_queue.size();
	}

	void pushfront(elemType &&elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_queue.pushfront(std::move(elem));
		m_atomsize = m_queue.size();
	}

	void pushfront(const std::vector<elemType> &elems)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_queue.pushfront(elems);
		m_atomsize = m_queue.size();
	}

	bool popback(elemType &elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		bool br = m_queue.popback(elem);
		m_atomsize = m_queue.size();
		return br;
	}

	ssize_t popback(std::vector<elemType> &elems, ssize_t count = 0 /* <= 0 pop all */)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		ssize_t n = m_queue.popback(elems, count);
		m_atomsize = m_queue.size();
		return n;
	}

	bool popfront(elemType &elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		bool br = m_queue.popfront(elem);
		m_atomsize = m_queue.size();
		return br;
	}

	ssize_t popfront(std::vector<elemType> &elems, ssize_t count = 0 /* <= 0 pop all */)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		ssize_t n = m_queue.popfront(elems, count);
		m_atomsize = m_queue.size();
		return n;
	}

	ssize_t size()
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		return m_queue.size();
	}

	ssize_t atom_size() const
	{
		return m_atomsize;
	}

	bool empty()
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		return m_queue.empty();
	}

	bool atom_empty() const
	{
		return m_atomsize <= 0;
	}

	void clear()
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_queue.clear();
		m_atomsize = m_queue.size();
	}

private:
	dequec<elemType>  m_queue;
	std::atomic<ssize_t>    m_atomsize;
	lockPolicy              m_lock;
};

template
<
	class elemType,
	class lockPolicy = lock::mutex_lock
>
class queue_simpwasync : public queue_wasync<queue_simpwasync<elemType, lockPolicy>, elemType, lockPolicy>
{};


template
<
	class T,
	class elemType,
	bool  use_atomic_size = false,
	class lockPolicy = lock::mutex_lock
>
class list_wasync;

template
<
	class T,
	class elemType,
	class lockPolicy
>
class list_wasync<T, elemType, false, lockPolicy> : public watcher_async<T>
{
public:
	list_wasync()
	{}

	bool init()
	{
		m_list.clear();
		return m_lock.init();
	}

	void deinit()
	{
		m_list.clear();
		m_lock.deinit();
	}

	void pushback(const elemType &elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_list.pushback(elem);
	}

	void pushback(elemType &&elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_list.pushback(std::move(elem));
	}

	void pushback(const std::list<elemType> &elems)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_list.pushback(elems);
	}

	void pushfront(const elemType &elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_list.pushfront(elem);
	}

	void pushfront(elemType &&elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_list.pushfront(std::move(elem));
	}

	void pushfront(const std::list<elemType> &elems)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_list.pushfront(elems);
	}

	bool popback(elemType &elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		return m_list.popback(elem);
	}

	ssize_t popback(std::list<elemType> &elems, ssize_t count = 0 /* <= 0 pop all */)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		return m_list.popback(elems, count);
	}

	bool popfront(elemType &elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		return m_list.popfront(elem);
	}

	ssize_t popfront(std::list<elemType> &elems, ssize_t count = 0 /* <= 0 pop all */)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		return m_list.popfront(elems, count);
	}

	ssize_t size()
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		return m_list.size();
	}

	bool empty()
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		return m_list.empty();
	}

	void clear()
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_list.clear();
	}

private:
	listc<elemType>  m_list;
	lockPolicy             m_lock;
};

template
<
	class T,
	class elemType,
	class lockPolicy
>
class list_wasync<T, elemType, true, lockPolicy> : public watcher_async<T>
{
public:
	list_wasync(): m_atomsize(0)
	{}

	bool init()
	{
		m_list.clear();
		m_atomsize = 0;
		return m_lock.init();
	}

	void deinit()
	{
		m_list.clear();
		m_atomsize = 0;
		m_lock.deinit();
	}

	void pushback(const elemType &elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_list.pushback(elem);
		m_atomsize = m_list.size();
	}

	void pushback(elemType &&elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_list.pushback(std::move(elem));
		m_atomsize = m_list.size();
	}

	void pushback(const std::list<elemType> &elems)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_list.pushback(elems);
		m_atomsize = m_list.size();
	}

	void pushfront(const elemType &elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_list.pushfront(elem);
		m_atomsize = m_list.size();
	}

	void pushfront(elemType &&elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_list.pushfront(std::move(elem));
		m_atomsize = m_list.size();
	}

	void pushfront(const std::list<elemType> &elems)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_list.pushfront(elems);
		m_atomsize = m_list.size();
	}

	bool popback(elemType &elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		bool br = m_list.popback(elem);
		m_atomsize = m_list.size();
		return br;
	}

	ssize_t popback(std::list<elemType> &elems, ssize_t count = 0 /* <= 0 pop all */)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		ssize_t n = m_list.popback(elems, count);
		m_atomsize = m_list.size();
		return n;
	}

	bool popfront(elemType &elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		bool br = m_list.popfront(elem);
		m_atomsize = m_list.size();
		return br;
	}

	ssize_t popfront(std::list<elemType> &elems, ssize_t count = 0 /* <= 0 pop all */)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		ssize_t n = m_list.popfront(elems, count);
		m_atomsize = m_list.size();
		return n;
	}

	ssize_t size()
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		return m_list.size();
	}

	ssize_t atom_size() const
	{
		return m_atomsize;
	}

	bool empty()
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		return m_list.empty();
	}

	bool atom_empty() const
	{
		return m_atomsize <= 0;
	}

	void clear()
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_list.clear();
		m_atomsize = m_list.size();
	}

private:
	listc<elemType>  m_list;
	std::atomic<ssize_t>   m_atomsize;
	lockPolicy             m_lock;
};

template
<
	class elemType,
	bool  use_atomic_size = false,
	class lockPolicy = lock::mutex_lock
>
class list_simpwasync : public list_wasync<list_simpwasync<elemType, use_atomic_size, lockPolicy>, elemType, use_atomic_size, lockPolicy>
{};


template
<
	class T,
	class elemType,
	template <class> class Container,
	class lockPolicy = lock::mutex_lock
>
class set_wasync : public watcher_async<T>
{
public:
	set_wasync(): m_atomsize(0)
	{}

	bool init()
	{
		m_set.clear();
		m_atomsize = 0;
		return m_lock.init();
	}

	void deinit()
	{
		m_set.clear();
		m_atomsize = 0;
		m_lock.deinit();
	}

	bool push(const elemType &elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		bool br = m_set.push(elem);
		m_atomsize = m_set.size();
		return br;
	}

	bool push(elemType &&elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		bool br = m_set.push(std::move(elem));
		m_atomsize = m_set.size();
		return br;
	}

	bool pop(elemType &elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		bool br = m_set.pop(elem);
		m_atomsize = m_set.size();
		return br;
	}

	bool find(const elemType &elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		return m_set.find(elem);
	}

	bool erase(const elemType &elem)
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		bool br = m_set.erase(elem);
		m_atomsize = m_set.size();
		return br;
	}

	ssize_t size()
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		return m_set.size();
	}

	ssize_t atom_size() const
	{
		return m_atomsize;
	}

	bool empty()
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		return m_set.empty();
	}

	bool atom_empty() const
	{
		return m_atomsize <= 0;
	}

	void clear()
	{
		lock::lockguard<lockPolicy> lg(m_lock);
		m_set.clear();
		m_atomsize = m_set.size();
	}

private:
	Container<elemType>   m_set;
	std::atomic<ssize_t>  m_atomsize;
	lockPolicy            m_lock;
};

template
<
	class elemType,
	template <class> class Container,
	class lockPolicy = lock::mutex_lock
>
class set_simpwasync : public set_wasync<set_simpwasync<elemType, Container, lockPolicy>, elemType, Container, lockPolicy>
{};


}


#endif


