

#ifndef __EVTL_ERROR_H__
#define __EVTL_ERROR_H__

#include <string>
#include <cstdint>
#include <sstream>
#include <utility>


namespace evtl
{


class evtl_error
{
public:
	evtl_error(): m_error_code(0), m_error_int(0)
	{}

	evtl_error(const evtl_error &that) = default;
	evtl_error(evtl_error &&that) noexcept = default;

	evtl_error& operator = (const evtl_error &that) = default;
	evtl_error& operator = (evtl_error &&that) = default;

	void set_error(int err_code)
	{
		m_error_code = err_code;
		m_error_int = 0;
		m_error_str.clear();
	}

	void set_error(int err_code, int64_t errint)
	{
		m_error_code = err_code;
		m_error_int = errint;
		m_error_str.clear();
	}

	void set_error(int err_code, const std::string &errstr)
	{
		m_error_code = err_code;
		m_error_int = 0;
		m_error_str = errstr;
	}

	void set_error(int err_code, std::string &&errstr)
	{
		m_error_code = err_code;
		m_error_int = 0;
		m_error_str = std::move(errstr);
	}

	void set_error(int err_code, int64_t errint, const std::string &errstr)
	{
		m_error_code = err_code;
		m_error_int = errint;
		m_error_str = errstr;
	}

	void set_error(int err_code, int64_t errint, std::string &&errstr)
	{
		m_error_code = err_code;
		m_error_int = errint;
		m_error_str = std::move(errstr);
	}

	void set_error(const evtl_error &other)
	{
		*this = other;
	}

	int get_error_code() const
	{
		return m_error_code;
	}

	int64_t get_error_int() const
	{
		return m_error_int;
	}

	std::string get_error_string() const
	{
		return m_error_str;
	}

	std::string get_error_combine() const
	{
		std::stringstream ss;
		ss << "<" << m_error_code << ":" << m_error_int << "," << m_error_str << ">";
		return ss.str();
	}

private:
	int          m_error_code;

	int64_t      m_error_int;
	std::string  m_error_str;
};


}


#endif


