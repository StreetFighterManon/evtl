

#ifndef __EVTL_UUID_H__
#define __EVTL_UUID_H__

#include <string>

#include <uuid/uuid.h>


namespace evtl
{


class uuid
{
public:
	static std::string generate(bool upper = false)
	{
		uuid_t id;
		char s[64] = { 0 };

		uuid_generate(id);
		if (upper)
			uuid_unparse_upper(id, s);
		else
			uuid_unparse_lower(id, s);

		s[36] = '\0';
		return s;
	}

	static std::string generate_random(bool upper = false)
	{
		uuid_t id;
		char s[64] = { 0 };

		uuid_generate_random(id);
		if (upper)
			uuid_unparse_upper(id, s);
		else
			uuid_unparse_lower(id, s);

		s[36] = '\0';
		return s;
	}

	static std::string generate_time(bool upper = false)
	{
		uuid_t id;
		char s[64] = { 0 };

		uuid_generate_time(id);
		if (upper)
			uuid_unparse_upper(id, s);
		else
			uuid_unparse_lower(id, s);

		s[36] = '\0';
		return s;
	}

	static std::string generate_time_safe(bool upper = false)
	{
		uuid_t id;
		char s[64] = { 0 };

		uuid_generate_time_safe(id);
		if (upper)
			uuid_unparse_upper(id, s);
		else
			uuid_unparse_lower(id, s);

		s[36] = '\0';
		return s;
	}
};


}


#endif


