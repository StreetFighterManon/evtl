

#ifndef __EVTL_IN_H__
#define __EVTL_IN_H__

#include <cstring>
#include <string>
#include <sstream>
#include <utility>
#include <netinet/in.h>


namespace evtl
{


enum class addrtype
{
	unknown,
	ip,
	unix
};

struct hostaddress
{
	hostaddress(): type(addrtype::unknown), sin6_scope_id(0)
	{}

	hostaddress(addrtype _type, const char *_hostaddr, int _scope_id = 0)
		: type(_type), hostaddr(_hostaddr), sin6_scope_id(_scope_id)
	{}

	hostaddress(addrtype _type, const std::string &_hostaddr, int _scope_id = 0)
		: type(_type), hostaddr(_hostaddr), sin6_scope_id(_scope_id)
	{}

	hostaddress(addrtype _type, std::string &&_hostaddr, int _scope_id = 0)
		: type(_type), hostaddr(std::move(_hostaddr)), sin6_scope_id(_scope_id)
	{}

	void set(addrtype _type, const char *_hostaddr, int _scope_id)
	{
		type = _type;
		hostaddr = _hostaddr;
		sin6_scope_id = _scope_id;
	}

	void set(addrtype _type, const std::string &_hostaddr, int _scope_id)
	{
		type = _type;
		hostaddr = _hostaddr;
		sin6_scope_id = _scope_id;
	}

	void set(addrtype _type, std::string &&_hostaddr, int _scope_id)
	{
		type = _type;
		hostaddr = std::move(_hostaddr);
		sin6_scope_id = _scope_id;
	}

	void ipset(const char *ip, int _scope_id = 0)
	{
		type = addrtype::ip;
		hostaddr = ip;
		sin6_scope_id = _scope_id;
	}

	void ipset(const std::string &ip, int _scope_id = 0)
	{
		type = addrtype::ip;
		hostaddr = ip;
		sin6_scope_id = _scope_id;
	}

	void ipset(std::string &&ip, int _scope_id = 0)
	{
		type = addrtype::ip;
		hostaddr = std::move(ip);
		sin6_scope_id = _scope_id;
	}

	void unixset(const char *path)
	{
		type = addrtype::unix;
		hostaddr = path;
		sin6_scope_id = 0;
	}

	void unixset(const std::string &path)
	{
		type = addrtype::unix;
		hostaddr = path;
		sin6_scope_id = 0;
	}

	void unixset(std::string &&path)
	{
		type = addrtype::unix;
		hostaddr = std::move(path);
		sin6_scope_id = 0;
	}

	bool isip() const
	{
		return type == addrtype::ip;
	}

	bool isunix() const
	{
		return type == addrtype::unix;
	}

	bool typeinvalid() const
	{
		return (type != addrtype::ip && type != addrtype::unix);
	}

	const std::string& ip() const
	{
		return hostaddr;
	}

	const std::string& path() const
	{
		return hostaddr;
	}

	bool empty() const
	{
		return hostaddr.empty();
	}

	std::string str() const
	{
		std::stringstream ss;
		if (type == addrtype::ip)
			ss << "ip:" << hostaddr << '%' << sin6_scope_id;
		else if (type == addrtype::unix)
			ss << "unix:" << hostaddr;
		else
			return "unknown type";
		return ss.str();
	}

	addrtype     type;
	std::string  hostaddr;
	int          sin6_scope_id;
};

struct address
{
	address(): port(-1)
	{}

	address(const hostaddress &_host, int _port)
		: host(_host), port(_port)
	{}

	address(hostaddress &&_host, int _port)
		: host(std::move(_host)), port(_port)
	{}

	address(addrtype type, const char *hostaddr, int scope_id, int _port)
		: host(type, hostaddr, scope_id), port(_port)
	{}

	address(addrtype type, const std::string &hostaddr, int scope_id, int _port)
		: host(type, hostaddr, scope_id), port(_port)
	{}

	address(addrtype type, std::string &&hostaddr, int scope_id, int _port)
		: host(type, std::move(hostaddr), scope_id), port(_port)
	{}

	hostaddress  host;
	int          port;
};

inline hostaddress makeiphost(const char *ip, int scope_id = 0)
{
	return hostaddress(addrtype::ip, ip, scope_id);
}

inline hostaddress makeiphost(const std::string &ip, int scope_id = 0)
{
	return hostaddress(addrtype::ip, ip, scope_id);
}

inline hostaddress makeiphost(std::string &&ip, int scope_id = 0)
{
	return hostaddress(addrtype::ip, std::move(ip), scope_id);
}

inline address makeipaddr(const char *ip, int port)
{
	return address(addrtype::ip, ip, 0, port);
}

inline address makeipaddr(const std::string &ip, int port)
{
	return address(addrtype::ip, ip, 0, port);
}

inline address makeipaddr(std::string &&ip, int port)
{
	return address(addrtype::ip, std::move(ip), 0, port);
}

inline address makeipaddr(const char *ip, int scope_id, int port)
{
	return address(addrtype::ip, ip, scope_id, port);
}

inline address makeipaddr(const std::string &ip, int scope_id, int port)
{
	return address(addrtype::ip, ip, scope_id, port);
}

inline address makeipaddr(std::string &&ip, int scope_id, int port)
{
	return address(addrtype::ip, std::move(ip), scope_id, port);
}

inline address makeunixaddr(const char *path)
{
	return address(addrtype::unix, path, 0, -1);
}

inline address makeunixaddr(const std::string &path)
{
	return address(addrtype::unix, path, 0, -1);
}

inline address makeunixaddr(std::string &&path)
{
	return address(addrtype::unix, std::move(path), 0, -1);
}

struct connection
{
	connection(): fd(-1)
	{
		memset(&peeraddr, 0, sizeof(peeraddr));
		memset(&localaddr, 0, sizeof(localaddr));
	}

	int fd;
	struct sockaddr_storage peeraddr;
	struct sockaddr_storage localaddr;
};

struct sockpairaddr
{
	sockpairaddr()
	{
		memset(&peeraddr, 0, sizeof(peeraddr));
		memset(&localaddr, 0, sizeof(localaddr));
	}

	sockpairaddr(const connection &conn)
	{
		peeraddr  = conn.peeraddr;
		localaddr = conn.localaddr;
	}

	struct sockaddr_storage peeraddr;
	struct sockaddr_storage localaddr;
};


}


#endif


