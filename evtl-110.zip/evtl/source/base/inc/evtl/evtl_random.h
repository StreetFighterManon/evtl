

#ifndef __EVTL_RANDOM_H__
#define __EVTL_RANDOM_H__

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>
#include <assert.h>

#include <string>
#include <sstream>
#include <iomanip>
#include <cstring>


namespace evtl { namespace rand {


class cclock
{
public:
	static uint64_t u64_realtime()
	{
		return _wall_clocktime();
	}

	static std::string str_realtime()
	{
		uint64_t n = _wall_clocktime();

		std::stringstream ss;
		ss << n;
		return ss.str();
	}

private:
	static uint64_t _wall_clocktime()
	{
		struct timespec ts;
		memset(&ts, 0, sizeof(ts));
		clock_gettime(CLOCK_REALTIME, &ts);
		return static_cast<uint64_t>(ts.tv_sec*1000000000ULL + ts.tv_nsec);
	}
};


class urandom
{
public:
	static bool init()
	{
		return _singleton()->_open_device();
	}

	static uint64_t ui64()
	{
		uint64_t randval = 0;

		ssize_t r = _singleton()->_read_bytes(&randval, sizeof(randval));
		if (r != sizeof(randval))
			return cclock::u64_realtime();

		return randval;
	}

	static std::string str_hex(ssize_t len, bool uppercase_hex = false)
	{
		if (len <= 0)
		{
			assert(false && "invalid len");
			return std::string();
		}

		ssize_t nbytes = len/2 + 1;

		unsigned char *buf = new unsigned char[nbytes];
		if (buf == nullptr)
			return _wallclock_hex_string(len, uppercase_hex);

		ssize_t r = _singleton()->_read_bytes(buf, nbytes);
		if (r != nbytes)
		{
			delete []buf;
			return _wallclock_hex_string(len, uppercase_hex);
		}

		std::stringstream ss;
		if (uppercase_hex)
			ss << std::setiosflags(std::ios::uppercase);

		ss << std::setbase(16) << std::setfill('0');

		for (ssize_t i = 0; i < nbytes; i++)
		{
			if ((i + 1)*2 <= len)
				ss << std::setw(2) << (unsigned int)buf[i];
			else
			{
				if ((i + 1)*2 == len + 1)
					ss << std::setw(1) << (unsigned int)(buf[i] & 0x0f);
				break;
			}
		}

		delete []buf;
		return ss.str();
	}

	static std::string str_dec(ssize_t len)
	{
		if (len <= 0)
		{
			assert(false && "invalid len");
			return std::string();
		}

		ssize_t nbytes = len;

		unsigned char *buf = new unsigned char[nbytes];
		if (buf == nullptr)
			return _wallclock_dec_string(len);

		ssize_t r = _singleton()->_read_bytes(buf, nbytes);
		if (r != nbytes)
		{
			delete []buf;
			return _wallclock_dec_string(len);
		}

		std::string s(nbytes, '0');

		for (ssize_t i = 0; i < nbytes; i++)
		{
			s[i] = '0' + (buf[i] % 10);
		}

		delete []buf;
		return s;
	}

	static std::string str_az09(ssize_t len)
	{
		if (len <= 0)
		{
			assert(false && "invalid len");
			return std::string();
		}

		const char *charset = "0123456789abcdefghijklmnopqrstuvwxyz";
		size_t cslen = ::strlen(charset);

		ssize_t count = len;

		unsigned short *buf = new unsigned short[count];
		if (buf == nullptr)
			return _wallclock_dec_string(len);

		ssize_t r = _singleton()->_read_bytes(buf, count*sizeof(unsigned short));
		if (r != (ssize_t)(count*sizeof(unsigned short)))
		{
			delete []buf;
			return _wallclock_dec_string(len);
		}

		std::string s(count, charset[0]);

		for (ssize_t i = 0; i < count; i++)
		{
			s[i] = charset[buf[i] % cslen];
		}

		delete []buf;
		return s;
	}

	static std::string str_charset(ssize_t len, const std::string &charset)
	{
		if (len <= 0)
		{
			assert(false && "invalid len");
			return std::string();
		}

		if (charset.empty() || charset.size() > 2048)
		{
			assert(false && "invalid charset");
			return std::string();
		}

		ssize_t count = len;

		unsigned short *buf = new unsigned short[count];
		if (buf == nullptr)
			return std::string();

		ssize_t r = _singleton()->_read_bytes(buf, count*sizeof(unsigned short));
		if (r != (ssize_t)(count*sizeof(unsigned short)))
		{
			delete []buf;
			return std::string();
		}

		std::string s(count, charset[0]);

		for (ssize_t i = 0; i < count; i++)
		{
			s[i] = charset.at(buf[i] % charset.size());
		}

		delete []buf;
		return s;
	}

private:
	urandom(): m_fd(-1)
	{}

	bool _open_device()
	{
		if (m_fd == -1)
			m_fd = ::open("/dev/urandom", O_RDONLY);

		return m_fd != -1;
	}

	ssize_t _read_bytes(void *buf, ssize_t nbytes)
	{
		if (buf == nullptr || nbytes <= 0)
			return 0;

		if (m_fd == -1)
			return 0;

		unsigned char *ucbuf = reinterpret_cast<unsigned char *>(buf);

		ssize_t total = 0;

		while (total < nbytes)
		{
			ssize_t r = ::read(m_fd, ucbuf + total, nbytes - total);
			if (r > 0)
			{
				if (r > nbytes - total)
					assert(false && "read syscall exception");

				total += r;
			}
			else if (r < 0)
			{
				if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
					break;
			}
			else if (r == 0)
				break;
		}

		return total;
	}

private:
	static urandom * _singleton()
	{
		static urandom *instance = new urandom;
		if (instance == nullptr)
			assert(false && "malloc failed");
		return instance;
	}

	static std::string _wallclock_hex_string(ssize_t len, bool uppercase_hex)
	{
		if (len <= 0)
			return std::string();

		uint64_t n = cclock::u64_realtime();

		std::stringstream ss;
		if (uppercase_hex)
			ss << std::setiosflags(std::ios::uppercase);

		ss << std::setbase(16) << std::setfill('0') << std::setw(1024) << n;

		std::string s = ss.str();

		ssize_t offset = (ssize_t)s.size() - len;
		if (offset > 0)
			return s.substr(offset);
		else if (offset == 0)
			return s;
		else
			return s.insert(0, -offset, '1');
	}

	static std::string _wallclock_dec_string(ssize_t len)
	{
		if (len <= 0)
			return std::string();

		uint64_t n = cclock::u64_realtime();

		std::stringstream ss;
		ss << std::setfill('1') << std::setw(1024) << n;

		std::string s = ss.str();

		ssize_t offset = (ssize_t)s.size() - len;
		if (offset > 0)
			return s.substr(offset);
		else if (offset == 0)
			return s;
		else
			return s.insert(0, -offset, '2');
	}

private:
	int  m_fd;
};


} }


#endif


