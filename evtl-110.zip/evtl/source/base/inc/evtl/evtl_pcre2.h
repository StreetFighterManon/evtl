

#ifndef __EVTL_PCRE2_H__
#define __EVTL_PCRE2_H__

#include <assert.h>

#include <string>
#include <cstring>
#include <cstdint>
#include <sstream>
#include <type_traits>
#include <vector>
#include <map>
#include <set>
#include <functional>
#include <utility>

#define PCRE2_CODE_UNIT_WIDTH 0
#include <pcre2/pcre2.h>

#include "evtl_copyable.h"
#include "evtl_exception.h"


namespace evtl
{


class pcre2_8
{
public:
	static std::string version()
	{
		int size = pcre2_config_8(PCRE2_CONFIG_VERSION, nullptr);
		if (size <= 0)
			return std::string();
		if (size > 1024)
			return "version string too long";

		char *ver = new char[size + 1];
		memset(ver, 0, size + 1);

		int rt = pcre2_config_8(PCRE2_CONFIG_VERSION, ver);
		if (rt < 0)
		{
			delete []ver;
			return std::string();
		}

		ver[size] = '\0';
		std::string verstr(ver);

		delete []ver;
		return verstr;
	}

	class regex : public nocopyc
	{
	public:
		friend class pcre2_8;

		explicit regex(int id = 0): m_id(id), m_pcre2code(nullptr)
		{}

		explicit regex(const std::string &expr, int id = 0, uint32_t options = PCRE2_DOTALL)
			: m_id(id), m_pcre2code(nullptr)
		{
			compile(expr, options);
		}

		regex(regex &&that) noexcept : m_id(that.m_id), m_pcre2code(that.m_pcre2code)
		{
			that.m_id        = 0;
			that.m_pcre2code = nullptr;
		}

		~regex()
		{
			free_code();
		}

		regex& operator = (regex &&that) noexcept
		{
			if (&that == this)
				return *this;

			free_code();

			m_id        = that.m_id;
			m_pcre2code = that.m_pcre2code;

			that.m_id        = 0;
			that.m_pcre2code = nullptr;
			return *this;
		}

		regex& assign(const std::string &expr, int id = 0, uint32_t options = PCRE2_DOTALL)
		{
			m_id = id;

			free_code();
			compile(expr, options);
			return *this;
		}

		void clear()
		{
			free_code();
		}

		int getid() const
		{
			return m_id;
		}

		const pcre2_code_8 * getcode() const
		{
			return m_pcre2code;
		}

	private:
		void compile(const std::string &expr, uint32_t options)
		{
			int        errcode = 0;
			PCRE2_SIZE erroffset = 0;

			pcre2_code_8 *code = pcre2_compile_8(reinterpret_cast<PCRE2_SPTR8>(expr.c_str()),
				expr.size(),
				options,
				&errcode,
				&erroffset,
				nullptr
				);

			if (code == nullptr)
			{
				PCRE2_UCHAR8 buffer[256] = { 0 };
				pcre2_get_error_message_8(errcode, buffer, sizeof(buffer));
				buffer[255] = '\0';

				std::stringstream ss;
				ss << "compilation failed (regexid: " << m_id << ", erroffset: " << erroffset << ", errcode: " << errcode << ", " << buffer << ")";
				throw simpexception(ss.str());
			}

			m_pcre2code = code;
		}

		void free_code()
		{
			if (m_pcre2code != nullptr)
				pcre2_code_free_8(m_pcre2code);
			m_pcre2code = nullptr;
		}

	private:
		int           m_id;
		pcre2_code_8 *m_pcre2code;
	};

	template <class T>
	class sub_match
	{
		static_assert(std::is_same<T, char>::value || std::is_same<T, unsigned char>::value, "T should be char or unsigned char");

	public:
		sub_match(): matched(false), first(nullptr), second(nullptr)
		{}

		sub_match(const sub_match &that) = default;
		sub_match(sub_match &&that) noexcept = default;

		sub_match& operator = (const sub_match &that) = default;
		sub_match& operator = (sub_match &&that) noexcept = default;

		bool matched;

		const T *first;
		const T *second;

		size_t size() const
		{
			if (matched)
			{
				if (first == nullptr || first > second)
					assert(false && "bad submatch, bad pointer");

				return second - first;
			}
			return 0;
		}

		bool empty() const
		{
			if (matched)
			{
				if (first == nullptr || first > second)
					assert(false && "bad submatch, bad pointer");

				if (second > first)
					return false;
			}
			return true;
		}

		std::string str() const
		{
			if (matched)
			{
				if (first == nullptr || first > second)
					assert(false && "bad submatch, bad pointer");

				return std::string(reinterpret_cast<const char *>(first), second - first);
			}
			return std::string();
		}

		bool equal(const void *pdata, ssize_t nbytes) const
		{
			if (nbytes < 0 || (pdata == nullptr && nbytes > 0))
				assert(false && "invalid param");

			if (matched)
			{
				if (first == nullptr || first > second)
					assert(false && "bad submatch, bad pointer");

				if (nbytes != second - first)
					return false;
				if (nbytes == 0)
					return true;
				if (::memcmp(first, pdata, nbytes) == 0)
					return true;
			}
			return false;
		}

		bool equal(const char *str) const
		{
			return equal(str, (ssize_t)::strlen(str));
		}

		bool equal(const std::string &str) const
		{
			return equal(str.c_str(), (ssize_t)str.size());
		}
	};

	template <class T>
	class match_results
	{
		static_assert(std::is_same<T, char>::value || std::is_same<T, unsigned char>::value, "T should be char or unsigned char");

	public:
		friend class pcre2_8;

		match_results() = default;

		match_results(const match_results &that) = default;
		match_results(match_results &&that) noexcept = default;

		match_results& operator = (const match_results &that) = default;
		match_results& operator = (match_results &&that) = default;

		size_t size() const
		{
			return m_submatches.size();
		}

		bool empty() const
		{
			return m_submatches.empty();
		}

		const sub_match<T>& operator [] (int32_t pos) const
		{
			if (pos < 0 || pos >= (int32_t)m_submatches.size())
				assert(false && "position out of range");

			return m_submatches[pos];
		}

		void clear()
		{
			m_submatches.clear();
		}

	private:
		std::vector<sub_match<T>>  m_submatches;
	};

	template <class T>
	static bool regex_search(const T *first, const T *last, match_results<T> &m, const regex &e, int id = 0, uint32_t options = 0)
	{
		static_assert(std::is_same<T, char>::value || std::is_same<T, unsigned char>::value, "T should be char or unsigned char");

		if (first == nullptr || first > last)
			assert(false && "bad subject");

		if (e.m_pcre2code == nullptr)
			assert(false && "null regex");

		std::stringstream ss;

		pcre2_match_data_8 *match_data = pcre2_match_data_create_from_pattern_8(e.m_pcre2code, nullptr);

		if (match_data == nullptr)
		{
			ss << "match data create failed(regexid: " << e.getid() << ", searchid:" << id << ")";
			throw simpexception(ss.str());
		}

		PCRE2_SPTR8 subjects = reinterpret_cast<PCRE2_SPTR8>(first);
		PCRE2_SIZE  len      = last - first;

		int rc = pcre2_match_8(e.m_pcre2code, subjects, len, 0, options, match_data, nullptr);
		if (rc < 0)
		{
			pcre2_match_data_free_8(match_data);
			match_data = nullptr;

			if (rc == PCRE2_ERROR_NOMATCH)
				return false;
			else
			{
				PCRE2_UCHAR8 buffer[256] = { 0 };
				pcre2_get_error_message_8(rc, buffer, sizeof(buffer));
				buffer[255] = '\0';

				ss << "match failed (regexid: " << e.getid() << ", searchid:" << id << ", errcode: " << rc << ", " << buffer << ")";
				throw simpexception(ss.str());
			}
		}

		/* The output vector wasn't big enough. This should not happen, because we used
		pcre2_match_data_create_from_pattern() above. */
		if (rc == 0)
		{
			pcre2_match_data_free_8(match_data);
			match_data = nullptr;

			ss << "pcre2 internal error (ovector was not big enough, regexid: " << e.getid() << ", searchid: " << id << ")";
			throw simpexception(ss.str());
		}

		/* Match succeded. Get a pointer to the output vector, where string offsets are
		stored. */
		PCRE2_SIZE *ovector = pcre2_get_ovector_pointer_8(match_data);
		if (ovector == nullptr)
		{
			pcre2_match_data_free_8(match_data);
			match_data = nullptr;
			ss << "pcre2 internal error (ovector is nullptr, regexid: " << e.getid() << ", searchid: " << id << ")";
			throw simpexception(ss.str());
		}

		int32_t ocount = (int32_t)pcre2_get_ovector_count_8(match_data);
		if (ocount < 1 || rc > ocount)
		{
			pcre2_match_data_free_8(match_data);
			match_data = nullptr;

			ss << "pcre2 internal error (ovector count: " << ocount << ", rc: " << rc << ", regexid: " << e.getid() << ", searchid: " << id << ")";
			throw simpexception(ss.str());
		}

		/* We must guard against patterns such as /(?=.\K)/ that use \K in an assertion
		to set the start of a match later than its end. we just detect this case and give up. */
		if (ovector[0] > ovector[1])
		{
			pcre2_match_data_free_8(match_data);
			match_data = nullptr;

			ss << "\\K was used in an assertion to set the match start after its end (regexid: " << e.getid() << ", searchid: " << id << ")";
			throw simpexception(ss.str());
		}

		m.m_submatches.clear();

		for (int32_t i = 0; i < ocount; i++)
		{
			sub_match<T> sm;
			if (i < rc)
			{
				long begin = (long)ovector[2*i];
				long end   = (long)ovector[2*i + 1];

				if (begin < 0 || end < 0)
					m.m_submatches.push_back(sm);
				else
				{
					if (begin > end)
					{
						pcre2_match_data_free_8(match_data);
						match_data = nullptr;

						ss << "ovector match begin after end (regexid: " << e.getid() << ", searchid: " << id << ")";
						throw simpexception(ss.str());
					}

					if (first + end > last)
					{
						pcre2_match_data_free_8(match_data);
						match_data = nullptr;

						ss << "ovector match out of range (regexid: " << e.getid() << ", searchid: " << id << ")";
						throw simpexception(ss.str());
					}

					sm.first   = first + begin;
					sm.second  = first + end;
					sm.matched = true;
					m.m_submatches.push_back(sm);
				}
			}
			else
			{
				m.m_submatches.push_back(sm);
			}
		}

		pcre2_match_data_free_8(match_data);
		match_data = nullptr;

		return true;
	}

	template <class T>
	static bool regex_search(const T *first, const T *last, const regex &e, int id = 0, uint32_t options = 0)
	{
		static_assert(std::is_same<T, char>::value || std::is_same<T, unsigned char>::value, "T should be char or unsigned char");

		match_results<T> m;

		bool br = regex_search<T>(first, last, m, e, id, options);
		if (br)
		{
			if (m.empty())
				assert(false && "empty match results");

			if (m[0].matched)
				return true;
		}

		return false;
	}

	template <class T>
	static bool regex_search(const std::string &s, match_results<T> &m, const regex &e, int id = 0, uint32_t options = 0)
	{
		static_assert(std::is_same<T, char>::value || std::is_same<T, unsigned char>::value, "T should be char or unsigned char");

		const T *first = reinterpret_cast<const T*>(s.c_str());
		return regex_search<T>(first, first + s.size(), m, e, id, options);
	}

	static bool regex_search(const std::string &s, const regex &e, int id = 0, uint32_t options = 0)
	{
		match_results<char> m;
		const char *first = s.c_str();

		bool br = regex_search<char>(first, first + s.size(), m, e, id, options);
		if (br)
		{
			if (m.empty())
				assert(false && "empty match results");

			if (m[0].matched)
				return true;
		}

		return false;
	}

	template <class T>
	static bool regex_match(const T *first, const T *last, match_results<T> &m, const regex &e, int id = 0, uint32_t options = 0)
	{
		static_assert(std::is_same<T, char>::value || std::is_same<T, unsigned char>::value, "T should be char or unsigned char");

		return regex_search<T>(first, last, m, e, id, options | PCRE2_ANCHORED | PCRE2_ENDANCHORED);
	}

	template <class T>
	static bool regex_match(const T *first, const T *last, const regex &e, int id = 0, uint32_t options = 0)
	{
		static_assert(std::is_same<T, char>::value || std::is_same<T, unsigned char>::value, "T should be char or unsigned char");

		match_results<T> m;

		bool br = regex_search<T>(first, last, m, e, id, options | PCRE2_ANCHORED | PCRE2_ENDANCHORED);
		if (br)
		{
			if (m.empty())
				assert(false && "empty match results");

			if (m[0].matched)
				return true;
		}

		return false;
	}

	template <class T>
	static bool regex_match(const std::string &s, match_results<T> &m, const regex &e, int id = 0, uint32_t options = 0)
	{
		static_assert(std::is_same<T, char>::value || std::is_same<T, unsigned char>::value, "T should be char or unsigned char");

		const T *first = reinterpret_cast<const T*>(s.c_str());
		return regex_search<T>(first, first + s.size(), m, e, id, options | PCRE2_ANCHORED | PCRE2_ENDANCHORED);
	}

	static bool regex_match(const std::string &s, const regex &e, int id = 0, uint32_t options = 0)
	{
		match_results<char> m;
		const char *first = s.c_str();

		bool br = regex_search<char>(first, first + s.size(), m, e, id, options | PCRE2_ANCHORED | PCRE2_ENDANCHORED);
		if (br)
		{
			if (m.empty())
				assert(false && "empty match results");

			if (m[0].matched)
				return true;
		}

		return false;
	}

	template <class T>
	class regex_iterator
	{
		static_assert(std::is_same<T, char>::value || std::is_same<T, unsigned char>::value, "T should be char or unsigned char");

	public:
		explicit regex_iterator(int id = 0): m_id(id), m_first(nullptr), m_last(nullptr), m_regex(nullptr), m_options(0)
		{ /* end iterator */ }

		regex_iterator(const T *first, const T *last, const regex &e, int id = 0, uint32_t options = 0)
			: m_id(id), m_first(nullptr), m_last(nullptr), m_regex(nullptr), m_options(0)
		{
			if (first > last)
				assert(false && "bad subject param");

			if (first == nullptr || last == nullptr || first == last || e.m_pcre2code == nullptr)
				return;  //end iterator

			bool br = pcre2_8::regex_search<T>(first, last, m_matches, e, m_id, options);
			if (!br)
			{
				set_end();
				return;  //end iterator
			}

			if (!m_matches[0].matched)
			{
				set_end();
				return;  //end iterator
			}

			m_first    = first;
			m_last     = last;
			m_regex    = &e;
			m_options  = options;

			if (!verify_value())
				assert(false && "bad value");
		}

		regex_iterator(const std::string &s, const regex &e, int id = 0, uint32_t options = 0)
			: m_id(id), m_first(nullptr), m_last(nullptr), m_regex(nullptr), m_options(0)
		{
			if (s.empty() || e.m_pcre2code == nullptr)
				return;  //end iterator

			bool br = pcre2_8::regex_search<T>(reinterpret_cast<const T*>(s.c_str()),
				reinterpret_cast<const T*>(s.c_str() + s.size()),
				m_matches,
				e,
				m_id,
				options
				);

			if (!br)
			{
				set_end();
				return;  //end iterator
			}

			if (!m_matches[0].matched)
			{
				set_end();
				return;  //end iterator
			}

			m_first    = reinterpret_cast<const T*>(s.c_str());
			m_last     = reinterpret_cast<const T*>(s.c_str() + s.size());
			m_regex    = &e;
			m_options  = options;

			if (!verify_value())
				assert(false && "bad value");
		}

		regex_iterator(const regex_iterator &that)
			: m_id(that.m_id),
			m_first(that.m_first), m_last(that.m_last),
			m_regex(that.m_regex),
			m_options(that.m_options),
			m_matches(that.m_matches)
		{
			if (!verify_subject())
				assert(false && "bad subject");
			if (!verify_value())
				assert(false && "bad value");
		}

		regex_iterator(regex_iterator &&that) noexcept
			: m_id(that.m_id),
			m_first(that.m_first), m_last(that.m_last),
			m_regex(that.m_regex),
			m_options(that.m_options),
			m_matches(std::move(that.m_matches))
		{
			that.m_id      = 0;
			that.m_first   = nullptr;
			that.m_last    = nullptr;
			that.m_regex   = nullptr;
			that.m_options = 0;
		}

		~regex_iterator()
		{
			m_id      = 0;
			m_first   = nullptr;
			m_last    = nullptr;
			m_regex   = nullptr;
			m_options = 0;
		}

		regex_iterator& operator = (const regex_iterator &that)
		{
			if (!that.verify_subject())
				assert(false && "bad subject assign");
			if (!that.verify_value())
				assert(false && "bad value");

			if (&that == this)
				return *this;

			m_id       = that.m_id;
			m_first    = that.m_first;
			m_last     = that.m_last;
			m_regex    = that.m_regex;
			m_options  = that.m_options;
			m_matches  = that.m_matches;

			return *this;
		}

		regex_iterator& operator = (regex_iterator &&that) noexcept
		{
			if (&that == this)
				return *this;

			m_id       = that.m_id;
			m_first    = that.m_first;
			m_last     = that.m_last;
			m_regex    = that.m_regex;
			m_options  = that.m_options;
			m_matches  = std::move(that.m_matches);

			that.m_id      = 0;
			that.m_first   = nullptr;
			that.m_last    = nullptr;
			that.m_regex   = nullptr;
			that.m_options = 0;

			return *this;
		}

		const match_results<T>& operator * () const
		{
			if (!verify_subject())
				assert(false && "bad subject");
			if (is_end())
				assert(false && "dereference end iterator");
			if (!verify_value())
				assert(false && "bad value");

			return m_matches;
		}

		const match_results<T> * operator -> () const
		{
			if (!verify_subject())
				assert(false && "bad subject");
			if (is_end())
				assert(false && "dereference end iterator");
			if (!verify_value())
				assert(false && "bad value");

			return &m_matches;
		}

		regex_iterator& operator ++ ()
		{
			if (!verify_subject())
				assert(false && "bad subject");

			if (is_end())
				return *this;

			if (!verify_value())
				assert(false && "bad value");

			m_first = m_matches[0].second;
			if (m_first >= m_last)
			{
				set_end();
				return *this;
			}

			bool br = pcre2_8::regex_search<T>(m_first, m_last, m_matches, *m_regex, m_id, m_options);
			if (!br)
			{
				set_end();
				return *this;
			}

			if (!m_matches[0].matched)
			{
				set_end();
				return *this;
			}

			if (!verify_value())
				assert(false && "bad value after ++");

			return *this;
		}

		regex_iterator operator ++ (int)
		{
			if (!verify_subject())
				assert(false && "bad subject");

			if (is_end())
				return *this;

			if (!verify_value())
				assert(false && "bad value");

			regex_iterator rt(*this);

			m_first = m_matches[0].second;
			if (m_first >= m_last)
			{
				set_end();
				return rt;
			}

			bool br = pcre2_8::regex_search<T>(m_first, m_last, m_matches, *m_regex, m_id, m_options);
			if (!br)
			{
				set_end();
				return rt;
			}

			if (!m_matches[0].matched)
			{
				set_end();
				return rt;
			}

			if (!verify_value())
				assert(false && "bad value after ++");

			return rt;
		}

		bool operator == (const regex_iterator &that) const
		{
			if (!verify_subject())
				assert(false && "bad subject");
			if (!that.verify_subject())
				assert(false && "bad subject param");

			if (is_end())
			{
				if (that.is_end())
					return true;
				else
					return false;
			}
			else
			{
				if (that.is_end())
					return false;
			}

			if (!verify_value())
				assert(false && "bad value");
			if (!that.verify_value())
				assert(false && "bad value param");

			if (m_first == that.m_first
				&& m_last == that.m_last
				&& m_regex == that.m_regex
				&& m_options == that.m_options
				)
				return true;

			return false;
		}

		bool operator != (const regex_iterator &that) const
		{
			return !this->operator == (that);
		}

	private:
		bool verify_subject() const
		{
			if (m_first > m_last)
				return false;
			return true;
		}

		bool verify_value() const
		{
			if (!is_end())
			{
				if (m_matches.empty())
					return false;

				const sub_match<T> &sub = m_matches[0];
				if (!sub.matched)
					return false;
				if (sub.first < m_first || sub.first > m_last || sub.second < sub.first || sub.second > m_last)
					return false;
			}
			return true;
		}

		bool is_end() const
		{
			if (m_first == nullptr || m_last == nullptr || m_first == m_last || m_regex == nullptr || m_regex->m_pcre2code == nullptr)
				return true;

			return false;
		}

		void set_end()
		{
			m_first   = nullptr;
			m_last    = nullptr;
			m_regex   = nullptr;
			m_options = 0;
			m_matches.clear();
		}

	private:
		int               m_id;

		const T          *m_first;
		const T          *m_last;
		const regex      *m_regex;
		uint32_t          m_options;

		match_results<T>  m_matches;
	};

	template <class T>
	class regex_token_iterator
	{
		static_assert(std::is_same<T, char>::value || std::is_same<T, unsigned char>::value, "T should be char or unsigned char");

	public:
		explicit regex_token_iterator(int id = 0)
			: m_id(id), m_first(nullptr), m_last(nullptr), m_regex(nullptr), m_submatch(0), m_options(0)
		{ /* end iterator */ }

		regex_token_iterator(const T *first, const T *last, const regex &e, int id = 0, int submatch = 0, uint32_t options = 0)
			: m_id(id), m_first(nullptr), m_last(nullptr), m_regex(nullptr), m_submatch(0), m_options(0)
		{
			if (first > last)
				assert(false && "bad subject param");

			if (submatch > 0)
				assert(false && "unsupportable submatch");

			if (first == nullptr || last == nullptr || first == last || e.m_pcre2code == nullptr)
				return;  /* end iterator */

			bool br = pcre2_8::regex_search<T>(first, last, m_token_matches, e, m_id, options);
			if (!br || !m_token_matches[0].matched)
			{
				m_token_matches.clear();

				if (submatch >= 0)
					return;  /* end iterator */
				else
				{
					m_first     = first;
					m_last      = last;
					m_regex     = &e;
					m_submatch  = submatch;
					m_options   = options;

					sub_match<T> sm;
					sm.first    = m_first;
					sm.second   = m_last;
					sm.matched  = true;

					m_splitfield_matches.m_submatches.push_back(sm);

					if (!verify_value())
						assert(false && "bad value");

					return;
				}
			}

			m_first     = first;
			m_last      = last;
			m_regex     = &e;
			m_submatch  = submatch;
			m_options   = options;

			if (submatch < 0)
			{
				const sub_match<T> &sub = m_token_matches[0];

				if (sub.first < m_first || sub.first > m_last || sub.second < sub.first || sub.second > m_last)
					assert(false && "bad token matches");

				sub_match<T> sm;
				sm.first    = m_first;
				sm.second   = sub.first;
				sm.matched  = true;

				m_splitfield_matches.m_submatches.push_back(sm);
			}

			if (!verify_value())
				assert(false && "bad value");
		}

		regex_token_iterator(const std::string &s, const regex &e, int id = 0, int submatch = 0, uint32_t options = 0)
			: m_id(id), m_first(nullptr), m_last(nullptr), m_regex(nullptr), m_submatch(0), m_options(0)
		{
			if (submatch > 0)
				assert(false && "unsupportable submatch");

			if (s.empty() || e.m_pcre2code == nullptr)
				return;  /* end iterator */

			bool br = pcre2_8::regex_search<T>(reinterpret_cast<const T*>(s.c_str()),
				reinterpret_cast<const T*>(s.c_str() + s.size()),
				m_token_matches,
				e,
				m_id,
				options
				);

			if (!br || !m_token_matches[0].matched)
			{
				m_token_matches.clear();

				if (submatch >= 0)
					return;  /* end iterator */
				else
				{
					m_first     = reinterpret_cast<const T*>(s.c_str());
					m_last      = reinterpret_cast<const T*>(s.c_str() + s.size());
					m_regex     = &e;
					m_submatch  = submatch;
					m_options   = options;

					sub_match<T> sm;
					sm.first    = m_first;
					sm.second   = m_last;
					sm.matched  = true;

					m_splitfield_matches.m_submatches.push_back(sm);

					if (!verify_value())
						assert(false && "bad value");

					return;
				}
			}

			m_first     = reinterpret_cast<const T*>(s.c_str());
			m_last      = reinterpret_cast<const T*>(s.c_str() + s.size());
			m_regex     = &e;
			m_submatch  = submatch;
			m_options   = options;

			if (submatch < 0)
			{
				const sub_match<T> &sub = m_token_matches[0];

				if (sub.first < m_first || sub.first > m_last || sub.second < sub.first || sub.second > m_last)
					assert(false && "bad token matches");

				sub_match<T> sm;
				sm.first    = m_first;
				sm.second   = sub.first;
				sm.matched  = true;

				m_splitfield_matches.m_submatches.push_back(sm);
			}

			if (!verify_value())
				assert(false && "bad value");
		}

		regex_token_iterator(const regex_token_iterator &that)
			: m_id(that.m_id),
			m_first(that.m_first), m_last(that.m_last),
			m_regex(that.m_regex),
			m_submatch(that.m_submatch),
			m_options(that.m_options),
			m_token_matches(that.m_token_matches),
			m_splitfield_matches(that.m_splitfield_matches)
		{
			if (!verify_subject())
				assert(false && "bad subject");
			if (!verify_value())
				assert(false && "bad value");
		}

		regex_token_iterator(regex_token_iterator &&that) noexcept
			: m_id(that.m_id),
			m_first(that.m_first), m_last(that.m_last),
			m_regex(that.m_regex),
			m_submatch(that.m_submatch),
			m_options(that.m_options),
			m_token_matches(std::move(that.m_token_matches)),
			m_splitfield_matches(std::move(that.m_splitfield_matches))
		{
			that.m_id       = 0;
			that.m_first    = nullptr;
			that.m_last     = nullptr;
			that.m_regex    = nullptr;
			that.m_submatch = 0;
			that.m_options  = 0;
		}

		~regex_token_iterator()
		{
			m_id       = 0;
			m_first    = nullptr;
			m_last     = nullptr;
			m_regex    = nullptr;
			m_submatch = 0;
			m_options  = 0;
		}

		regex_token_iterator& operator = (const regex_token_iterator &that)
		{
			if (that.verify_subject())
				assert(false && "bad subject assign");
			if (that.verify_value())
				assert(false && "bad subject value");

			if (&that == this)
				return *this;

			m_id       = that.m_id;
			m_first    = that.m_first;
			m_last     = that.m_last;
			m_regex    = that.m_regex;
			m_submatch = that.m_submatch;
			m_options  = that.m_options;

			m_token_matches       = that.m_token_matches;
			m_splitfield_matches  = that.m_splitfield_matches;

			return *this;
		}

		regex_token_iterator& operator = (regex_token_iterator &&that) noexcept
		{
			if (&that == this)
				return *this;

			m_id       = that.m_id;
			m_first    = that.m_first;
			m_last     = that.m_last;
			m_regex    = that.m_regex;
			m_submatch = that.m_submatch;
			m_options  = that.m_options;

			m_token_matches       = std::move(that.m_token_matches);
			m_splitfield_matches  = std::move(that.m_splitfield_matches);

			that.m_id       = 0;
			that.m_first    = nullptr;
			that.m_last     = nullptr;
			that.m_regex    = nullptr;
			that.m_submatch = 0;
			that.m_options  = 0;

			return *this;
		}

		const match_results<T>& operator * () const
		{
			if (!verify_subject())
				assert(false && "bad subject");
			if (is_end())
				assert(false && "dereference end iterator");
			if (!verify_value())
				assert(false && "bad value");

			if (m_submatch >= 0)
				return m_token_matches;
			else
				return m_splitfield_matches;
		}

		const match_results<T> * operator -> () const
		{
			if (!verify_subject())
				assert(false && "bad subject");
			if (is_end())
				assert(false && "dereference end iterator");
			if (!verify_value())
				assert(false && "bad value");

			if (m_submatch >= 0)
				return &m_token_matches;
			else
				return &m_splitfield_matches;
		}

		regex_token_iterator& operator ++ ()
		{
			if (!verify_subject())
				assert(false && "bad subject");

			if (is_end())
				return *this;

			if (!verify_value())
				assert(false && "bad value");

			if (m_submatch >= 0)
			{
				m_first = m_token_matches[0].second;
				if (m_first >= m_last)
				{
					set_end();
					return *this;
				}

				bool br = pcre2_8::regex_search<T>(m_first, m_last, m_token_matches, *m_regex, m_id, m_options);
				if (!br)
				{
					set_end();
					return *this;
				}

				if (!m_token_matches[0].matched)
				{
					set_end();
					return *this;
				}
			}
			else
			{
				if (m_token_matches.empty())
				{
					set_end();
					return *this;
				}

				m_first = m_token_matches[0].second;
				if (m_first >= m_last)
				{
					set_end();
					return *this;
				}

				bool br = pcre2_8::regex_search<T>(m_first, m_last, m_token_matches, *m_regex, m_id, m_options);
				if (!br || !m_token_matches[0].matched)
				{
					m_token_matches.clear();
					m_splitfield_matches.clear();

					sub_match<T> sm;
					sm.first   = m_first;
					sm.second  = m_last;
					sm.matched = true;
					m_splitfield_matches.m_submatches.push_back(sm);
				}
				else
				{
					const sub_match<T> &sub = m_token_matches[0];

					if (sub.first < m_first || sub.first > m_last || sub.second < sub.first || sub.second > m_last)
						assert(false && "bad token matches");

					m_splitfield_matches.clear();

					sub_match<T> sm;
					sm.first   = m_first;
					sm.second  = sub.first;
					sm.matched = true;
					m_splitfield_matches.m_submatches.push_back(sm);
				}
			}

			if (!verify_value())
				assert(false && "bad value");

			return *this;
		}

		regex_token_iterator operator ++ (int)
		{
			if (!verify_subject())
				assert(false && "bad subject");

			if (is_end())
				return *this;

			if (!verify_value())
				assert(false && "bad value");

			regex_token_iterator rt(*this);

			this->operator ++ ();
			return rt;
		}

		bool operator == (const regex_token_iterator &that) const
		{
			if (!verify_subject())
				assert(false && "bad subject");
			if (!that.verify_subject())
				assert(false && "bad subject param");

			if (is_end())
			{
				if (that.is_end())
					return true;
				else
					return false;
			}
			else
			{
				if (that.is_end())
					return false;
			}

			if (!verify_value())
				assert(false && "bad value");
			if (!that.verify_value())
				assert(false && "bad value param");

			if (m_first == that.m_first
				|| m_last == that.m_last
				|| m_regex == that.m_regex
				|| m_submatch == that.m_submatch
				|| m_options == that.m_options
				)
				return true;

			return false;
		}

		bool operator != (const regex_token_iterator &that) const
		{
			return !this->operator == (that);
		}

	private:
		bool verify_subject() const
		{
			if (m_first > m_last)
				return false;
			if (m_submatch > 0)
				return false;
			return true;
		}

		bool verify_value() const
		{
			if (!is_end())
			{
				if (m_submatch >= 0)
				{
					if (m_token_matches.empty())
						return false;

					const sub_match<T> &sub = m_token_matches[0];
					if (!sub.matched)
						return false;
					if (sub.first < m_first || sub.first > m_last || sub.second < sub.first || sub.second > m_last)
						return false;
				}
				else
				{
					if (m_splitfield_matches.empty())
						return false;

					const sub_match<T> &sub = m_splitfield_matches[0];
					if (!sub.matched)
						return false;
					if (sub.first < m_first || sub.first > m_last || sub.second < sub.first || sub.second > m_last)
						return false;
				}
			}

			return true;
		}

		bool is_end() const
		{
			if (m_first == nullptr || m_last == nullptr || m_first == m_last || m_regex == nullptr || m_regex->m_pcre2code == nullptr)
				return true;

			return false;
		}

		void set_end()
		{
			m_first     = nullptr;
			m_last      = nullptr;
			m_regex     = nullptr;
			m_submatch  = 0;
			m_options   = 0;

			m_token_matches.clear();
			m_splitfield_matches.clear();
		}

	private:
		int               m_id;
		const T          *m_first;
		const T          *m_last;
		const regex      *m_regex;
		int               m_submatch;
		uint32_t          m_options;

		match_results<T>  m_token_matches;
		match_results<T>  m_splitfield_matches;
	};

	template <class T>
	static std::string regex_replace(const T *first, const T *last, const regex &e, const std::string &replace, int32_t matchindex = 0,
		int replacecount = -1, int id = 0, uint32_t options = 0)
	{
		static_assert(std::is_same<T, char>::value || std::is_same<T, unsigned char>::value, "T should be char or unsigned char");

		if (matchindex < 0)
			assert(false && "negative matchindex");

		std::string result;

		regex_iterator<T> iter(first, last, e, id, options);
		regex_iterator<T> end;

		const T *p1 = first, *p2 = first, *p3 = first, *p4 = first;
		int count = 0;

		for ( ; iter != end; ++iter)
		{
			if (replacecount >= 0 && count++ >= replacecount)
				break;

			const match_results<T> &matches = *iter;
			if (matchindex >= (int32_t)matches.size())
				assert(false && "matchindex too large");

			const sub_match<T> &sm0 = matches[0];
			const sub_match<T> &sm = matches[matchindex];
			if (!sm0.matched)
				assert(false && "whole unmatched");

			p1 = p4;
			p2 = sm.first;
			p3 = sm.second;
			p4 = sm0.second;

			if (p4 <= p1)
				assert(false && "regex infinite match");

			if (sm.matched)
			{
				if (p2 < p1 || p3 < p2 || p4 < p3)
					assert(false && "match pos error");
				result.append(reinterpret_cast<const char *>(p1), p2 - p1);
				result.append(replace);
				result.append(reinterpret_cast<const char *>(p3), p4 - p3);
			}
			else
			{
				result.append(reinterpret_cast<const char *>(p1), p4 - p1);
			}
		}

		if (p4 > last)
			assert(false && "p4 out of range");
		if (p4 < last)
			result.append(reinterpret_cast<const char *>(p4), last - p4);

		return result;
	}

	static std::string regex_replace(const std::string &s, const regex &e, const std::string &replace, int32_t matchindex = 0,
		int replacecount = -1, int id = 0, uint32_t options = 0)
	{
		const char* first = s.c_str();
		return regex_replace<char>(first, first + s.size(), e, replace, matchindex, replacecount, id, options);
	}

	template <class T>
	static std::string regex_replace(const T *first, const T *last, const regex &e,
		const std::map<int32_t, std::string, std::less<int32_t>> &indexreplace, int replacecount = -1, int id = 0, uint32_t options = 0)
	{
		static_assert(std::is_same<T, char>::value || std::is_same<T, unsigned char>::value, "T should be char or unsigned char");

		std::string result;

		regex_iterator<T> iter(first, last, e, id, options);
		regex_iterator<T> end;

		const T *p1 = first, *p2 = first, *p3 = first, *p4 = first;
		int count = 0;

		for ( ; iter != end; ++iter)
		{
			if (replacecount >= 0 && count++ >= replacecount)
				break;

			const match_results<T> &matchs = *iter;
			const sub_match<T> &sm0 = matchs[0];
			if (!sm0.matched)
				assert(false && "whole unmatched");

			p1 = p4;
			p2 = p4;
			p3 = p4;
			p4 = sm0.second;
			if (p4 <= p1)
				assert(false && "regex infinite match");

			for (std::map<int32_t, std::string, std::less<int32_t>>::const_iterator iter = indexreplace.begin(); iter != indexreplace.end(); ++iter)
			{
				if (iter->first < 0 || iter->first >= matchs.size())
					assert(false && "index out of range");

				const sub_match<T> &sm = matchs[iter->first];
				if (!sm.matched || sm.first < p3 || sm.second < p3)
					continue;

				p2 = sm.first;
				p3 = sm.second;
				if (p2 < p1 || p3 < p2 || p4 < p3)
					assert(false && "match pos error");
				result.append(reinterpret_cast<const char *>(p1), p2 - p1);
				result.append(iter->second);
				p1 = p3;
				p2 = p3;
			}
			if (p4 > p3)
				result.append(reinterpret_cast<const char *>(p3), p4 - p3);
		}

		if (p4 > last)
			assert(false && "p4 out of range");
		if (p4 < last)
			result.append(reinterpret_cast<const char *>(p4), last - p4);

		return result;
	}

	static std::string regex_replace(const std::string &s, const regex &e,
		const std::map<int32_t, std::string, std::less<int32_t>> &indexreplace, int replacecount = -1, int id = 0, uint32_t options = 0)
	{
		const char *first = s.c_str();
		return regex_replace<char>(first, first + s.size(), e, indexreplace, replacecount, id, options);
	}

	template <class T>
	using replacefunc = std::function<std::string (const match_results<T> &m, int32_t index)>;

	template <class T>
	static std::string regex_replace_func(const T *first, const T *last, const regex &e, const replacefunc<T> &replace, int32_t matchindex = 0,
		int replacecount = -1, int id = 0, uint32_t options = 0)
	{
		static_assert(std::is_same<T, char>::value || std::is_same<T, unsigned char>::value, "T should be char or unsigned char");

		if (matchindex < 0)
			assert(false && "negative matchindex");

		std::string result;

		regex_iterator<T> iter(first, last, e, id, options);
		regex_iterator<T> end;

		const T *p1 = first, *p2 = first, *p3 = first, *p4 = first;
		int count = 0;

		for ( ; iter != end; ++iter)
		{
			if (replacecount >= 0 && count++ >= replacecount)
				break;

			const match_results<T> &matches = *iter;
			if (matchindex >= (int32_t)matches.size())
				assert(false && "matchindex too large");
	
			const sub_match<T> &sm0 = matches[0];
			const sub_match<T> &sm = matches[matchindex];
			if (!sm0.matched)
				assert(false && "whole unmatched");

			p1 = p4;
			p2 = sm.first;
			p3 = sm.second;
			p4 = sm0.second;

			if (p4 <= p1)
				assert(false && "regex infinite match");

			if (sm.matched)
			{
				if (p2 < p1 || p3 < p2 || p4 < p3)
					assert(false && "match pos error");
				result.append(reinterpret_cast<const char *>(p1), p2 - p1);
				result.append(replace(matches, matchindex));
				result.append(reinterpret_cast<const char *>(p3), p4 - p3);
			}
			else
			{
				result.append(reinterpret_cast<const char *>(p1), p4 - p1);
			}
		}

		if (p4 > last)
			assert(false && "p4 out of range");
		if (p4 < last)
			result.append(reinterpret_cast<const char *>(p4), last - p4);

		return result;
	}

	static std::string regex_replace_func(const std::string &s, const regex &e, const replacefunc<char> &replace, int32_t matchindex = 0,
		int replacecount = -1, int id = 0, uint32_t options = 0)
	{
		const char *first = s.c_str();
		return regex_replace_func<char>(first, first + s.size(), e, replace, matchindex, replacecount, id, options);
	}

	template <class T>
	static std::string regex_replace_func(const T *first, const T *last, const regex &e, const std::set<int32_t, std::less<int32_t>> &index,
		const replacefunc<T> &replace, int replacecount = -1, int id = 0, uint32_t options = 0)
	{
		static_assert(std::is_same<T, char>::value || std::is_same<T, unsigned char>::value, "T should be char or unsigned char");

		std::string result;

		regex_iterator<T> iter(first, last, e, id, options);
		regex_iterator<T> end;

		const T *p1 = first, *p2 = first, *p3 = first, *p4 = first;
		int count = 0;

		for ( ; iter != end; ++iter)
		{
			if (replacecount >= 0 && count++ >= replacecount)
				break;

			const match_results<T> &matchs = *iter;

			const sub_match<T> &sm0 = matchs[0];
			if (!sm0.matched)
				assert(false && "whole unmatched");

			p1 = p4;
			p2 = p4;
			p3 = p4;
			p4 = sm0.second;
			if (p4 <= p1)
				assert(false && "regex infinite match");

			for (std::set<int32_t, std::less<int32_t>>::const_iterator iter = index.begin(); iter != index.end(); ++iter)
			{
				int32_t idx = *iter;
				if (idx < 0 || idx >= matchs.size())
					assert(false && "index out of range");

				const sub_match<T> &sm = matchs[idx];
				if (!sm.matched || sm.first < p3 || sm.second < p3)
					continue;

				p2 = sm.first;
				p3 = sm.second;
				if (p2 < p1 || p3 < p2 || p4 < p3)
					assert(false && "match pos error");
				result.append(reinterpret_cast<const char *>(p1), p2 - p1);
				result.append(replace(matchs, idx));
				p1 = p3;
				p2 = p3;
			}
			if (p4 > p3)
				result.append(reinterpret_cast<const char *>(p3), p4 - p3);
		}

		if (p4 > last)
			assert(false && "p4 out of range");
		if (p4 < last)
			result.append(reinterpret_cast<const char *>(p4), last - p4);

		return result;
	}

	static std::string regex_replace_func(const std::string &s, const regex &e, const std::set<int32_t, std::less<int32_t>> &index,
		const replacefunc<char> &replace, int replacecount = -1, int id = 0, uint32_t options = 0)
	{
		const char *first = s.c_str();
		return regex_replace_func<char>(first, first + s.size(), e, index, replace, replacecount, id, options);
	}
};


}


#endif


