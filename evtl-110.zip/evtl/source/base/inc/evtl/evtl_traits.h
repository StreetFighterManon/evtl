

#ifndef __EVTL_TRAITS_H__
#define __EVTL_TRAITS_H__

#include "evtl_copyable.h"


namespace evtl { namespace traits {


template <bool copyable>
struct copyable_traits;

template <>
struct copyable_traits<false>
{
	typedef nocopyc type;
};

template <>
struct copyable_traits<true>
{
	typedef cancopyc type;
};


} }


#endif


