

#ifndef __EVTL_EXCEPTION_H__
#define __EVTL_EXCEPTION_H__

#include <exception>
#include <string>


namespace evtl
{


class simpexception : public std::exception
{
public:
	simpexception(const std::string &errstr): m_content(errstr)
	{}

	virtual const char * what() const noexcept override
	{
		return m_content.c_str();
	}

private:
	std::string  m_content;
};


}


#endif


