

#ifndef __EVTL_EIO_H__
#define __EVTL_EIO_H__

#include <unistd.h>
#include <assert.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/prctl.h>

#include <functional>
#include <utility>

#include <eio/eio.h>

#include "evtl_thread.h"


namespace evtl
{


class geio
{
public:
	geio() = delete;

	static int init(void (*want_poll)(void) = &geio::_default_wantpoll, void (*done_poll)(void) = &geio::_default_donepoll)
	{
		return ::eio_init(want_poll, done_poll);
	}

	static bool make_pollthread(unsigned int once_sleep_us = 1000, ssize_t stacksize = 0)
	{
		thread::mdtresult result = thread::make_detached(&geio::_poll_thread, reinterpret_cast<void *>(once_sleep_us), stacksize);
		return result;
	}

	static int poll()
	{
		return ::eio_poll();
	}

	static unsigned int nreqs()
	{
		return ::eio_nreqs();
	}

	static unsigned int nready()
	{
		return ::eio_nready();
	}

	static unsigned int npending()
	{
		return ::eio_npending();
	}

	static unsigned int nthreads()
	{
		return ::eio_nthreads();
	}

	static void cancel(eio_req *req)
	{
		if (req == nullptr)
			assert(false && "null req");

		::eio_cancel(req);
	}

	static void set_min_parallel(unsigned int nthreads)
	{
		::eio_set_min_parallel(nthreads);
	}

	static void set_max_parallel(unsigned int nthreads)
	{
		::eio_set_max_parallel(nthreads);
	}

private:
	static void _default_wantpoll(){}
	static void _default_donepoll(){}

	static void * _poll_thread(void *arg)
	{
		::prctl(PR_SET_NAME, "eiopoll");

		unsigned int sleepus = static_cast<unsigned int>(reinterpret_cast<unsigned long>(arg));
		while (true)
		{
			if (::eio_nreqs() > 0)
				::eio_poll();

			if (sleepus > 0)
				::usleep(sleepus);
		}

		return nullptr;
	}
};

template <class T>
class eio
{
public:
	typedef std::function<int (T &eios, eio_req *req, ssize_t result, char *buf)>  read_callback_t;
	typedef std::function<int (T &eios, eio_req *req, ssize_t result)>  result_callback_t;
	typedef std::function<void (T &eios, eio_req *req)>  destroy_callback_t;

	eio() = default;

	void set_readcallback()
	{
		m_read_cb = nullptr;
	}

	void set_readcallback(read_callback_t cb)
	{
		m_read_cb = std::move(cb);
	}

	void set_writecallback()
	{
		m_write_cb = nullptr;
	}

	void set_writecallback(result_callback_t cb)
	{
		m_write_cb = std::move(cb);
	}

	void set_destroycallback()
	{
		m_destroy_cb = nullptr;
	}

	void set_destroycallback(destroy_callback_t cb)
	{
		m_destroy_cb = std::move(cb);
	}

	eio_req * submit_read(int fd, void *buf, size_t length, off_t offset, bool handledestroy = false, int pri = EIO_PRI_DEFAULT)
	{
		if (fd == -1 || length <= 0 || offset < 0)
		{
			assert(false && "invalid param");
			return nullptr;
		}

		eio_req *req = _req(EIO_READ, pri, handledestroy);
		if (req == nullptr)
			assert(false && "null req");

		req->int1 = fd;
		req->offs = offset;
		req->size = length;
		req->ptr2 = buf;

		::eio_submit(req);
		return req;
	}

	eio_req * submit_write(int fd, void *buf, size_t length, off_t offset, bool handledestroy = false, int pri = EIO_PRI_DEFAULT)
	{
		if (fd == -1 || buf == nullptr || length <= 0 || offset < 0)
		{
			assert(false && "invalid param");
			return nullptr;
		}

		eio_req *req = _req(EIO_WRITE, pri, handledestroy);
		if (req == nullptr)
			assert(false && "null req");

		req->int1 = fd;
		req->offs = offset;
		req->size = length;
		req->ptr2 = buf;

		::eio_submit(req);
		return req;
	}

private:
	eio_req * _req(int type, int pri, bool handledestroy)
	{
		eio_req *req = (eio_req *)calloc(1, sizeof(eio_req));
		if (req == nullptr)
			assert(false && "malloc failed");

		req->type = type;
		req->pri  = pri;
		req->finish = eio::__eio_callback;
		req->data = this;
		if (handledestroy)
			req->destroy = eio::__api_destroy;
		else
			req->destroy = eio::__emp_api_destroy;
		return req;
	}

	static int __eio_callback(eio_req *req)
	{
		if (req == nullptr || req->data == nullptr)
			assert(false && "bad param");

		int ret = 0;
		switch (req->type)
		{
		case EIO_READ:
			ret = static_cast<eio*>(req->data)->_read_callback(req);
			break;
		case EIO_WRITE:
			ret = static_cast<eio*>(req->data)->_write_callback(req);
			break;
		default:
			assert(false && "bad type");
			break;
		}

		return ret;
	}

	int _read_callback(eio_req *req)
	{
		if (m_read_cb)
			return m_read_cb(*static_cast<T*>(this), req, EIO_RESULT(req), (char *)EIO_BUF(req));
		else
			return static_cast<T*>(this)->read_callback(*static_cast<T*>(this), req, EIO_RESULT(req), (char *)EIO_BUF(req));
	}

	int _write_callback(eio_req *req)
	{
		if (m_write_cb)
			return m_write_cb(*static_cast<T*>(this), req, EIO_RESULT(req));
		else
			return static_cast<T*>(this)->write_callback(*static_cast<T*>(this), req, EIO_RESULT(req));
	}

	int read_callback(T &eios, eio_req *req, ssize_t result, char *buf) { assert(false && "unset callback"); return 0; }
	int write_callback(T &eios, eio_req *req, ssize_t result) { assert(false && "unset callback"); return 0; }

	static void __emp_api_destroy(eio_req *req)
	{
		if (req != nullptr)
			::free(req);
	}

	static void __api_destroy(eio_req *req)
	{
		if (req == nullptr || req->data == nullptr)
			assert(false && "bad param");

		static_cast<eio*>(req->data)->_destroy_callback(req);
		::free(req);
	}

	void _destroy_callback(eio_req *req)
	{
		if (m_destroy_cb)
			m_destroy_cb(*static_cast<T*>(this), req);
		else
			static_cast<T*>(this)->destroy_callback(*static_cast<T*>(this), req);
	}

	void destroy_callback(T &eios, eio_req *req) { assert(false && "unset callback"); }

private:
	read_callback_t     m_read_cb;
	result_callback_t   m_write_cb;
	destroy_callback_t  m_destroy_cb;
};

class simpeio : public eio<simpeio>
{};


inline void __eio_api_destroy(eio_req *req)
{
	if (req != nullptr)
		::free(req);
}

template <class T, void (T::*method)(eio_req *req)>
void __eio_execute_mthunk(eio_req *req)
{
	if (req == nullptr || req->data == nullptr)
		assert(false && "bad param");

	(static_cast<T*>(req->data)->*method)(req);
}

template <int (*func)(eio_req *req, ssize_t result, char *buf)>
int __eio_readcb_fthunk(eio_req *req)
{
	if (req == nullptr)
		assert(false && "bad param");

	if (req->type == EIO_READ)
		return (*func)(req, EIO_RESULT(req), (char *)EIO_BUF(req));
	else
		assert(false && "invalid type");
	return 0;
}

template <class T, int (T::*method)(eio_req *req, ssize_t result, char *buf)>
int __eio_readcb_mthunk(eio_req *req)
{
	if (req == nullptr || req->data == nullptr)
		assert(false && "bad param");

	if (req->type == EIO_READ)
		return (static_cast<T*>(req->data)->*method)(req, EIO_RESULT(req), (char *)EIO_BUF(req));
	else
		assert(false && "invalid type");
	return 0;
}

template <int (*func)(eio_req *req, ssize_t result)>
int __eio_resultcb_fthunk(eio_req *req)
{
	if (req == nullptr)
		assert(false && "bad param");

	return (*func)(req, EIO_RESULT(req));
}

template <class T, int (T::*method)(eio_req *req, ssize_t result)>
int __eio_resultcb_mthunk(eio_req *req)
{
	if (req == nullptr || req->data == nullptr)
		assert(false && "bad param");

	return (static_cast<T*>(req->data)->*method)(req, EIO_RESULT(req));
}

template <void (*func)(eio_req *req)>
void __eio_api_destroy_fthunk(eio_req *req)
{
	if (req == nullptr)
		assert(false && "bad param");

	(*func)(req);
	::free(req);
}

template <class T, void (T::*method)(eio_req *req)>
void __eio_api_destroy_mthunk(eio_req *req)
{
	if (req == nullptr || req->data == nullptr)
		assert(false && "bad param");

	(static_cast<T*>(req->data)->*method)(req);
	::free(req);
}

inline eio_req * eio_read(int fd, void *buf, size_t length, off_t offset, eio_cb cb, void *data, int pri = EIO_PRI_DEFAULT, void (*destroy)(eio_req *req) = __eio_api_destroy)
{
	if (fd == -1 || length <= 0 || offset < 0)
	{
		assert(false && "invalid param");
		return nullptr;
	}

	eio_req *req = (eio_req *)calloc(1, sizeof(eio_req));
	if (req == nullptr)
		assert(false && "malloc failed");

	req->type = EIO_READ;
	req->pri  = pri;
	req->finish = cb;
	req->data = data;
	req->destroy = destroy;

	req->int1 = fd;
	req->offs = offset;
	req->size = length;
	req->ptr2 = buf;

	::eio_submit(req);
	return req;
}

template <int (*readcbfunc)(eio_req *req, ssize_t result, char *buf)>
eio_req * eio_readf(int fd, void *buf, size_t length, off_t offset, void* data, int pri = EIO_PRI_DEFAULT)
{
	if (fd == -1 || length <= 0 || offset < 0 || data == nullptr)
	{
		assert(false && "invalid param");
		return nullptr;
	}

	eio_req *req = (eio_req *)calloc(1, sizeof(eio_req));
	if (req == nullptr)
		assert(false && "malloc failed");

	req->type = EIO_READ;
	req->pri  = pri;
	req->finish = __eio_readcb_fthunk<readcbfunc>;
	req->data = data;
	req->destroy = __eio_api_destroy;

	req->int1 = fd;
	req->offs = offset;
	req->size = length;
	req->ptr2 = buf;

	::eio_submit(req);
	return req;
}

template <int (*readcbfunc)(eio_req *req, ssize_t result, char *buf), void (*destroycbfunc)(eio_req *req)>
eio_req * eio_readf(int fd, void *buf, size_t length, off_t offset, void* data, int pri = EIO_PRI_DEFAULT)
{
	if (fd == -1 || length <= 0 || offset < 0 || data == nullptr)
	{
		assert(false && "invalid param");
		return nullptr;
	}

	eio_req *req = (eio_req *)calloc(1, sizeof(eio_req));
	if (req == nullptr)
		assert(false && "malloc failed");

	req->type = EIO_READ;
	req->pri  = pri;
	req->finish = __eio_readcb_fthunk<readcbfunc>;
	req->data = data;
	req->destroy = __eio_api_destroy_fthunk<destroycbfunc>;

	req->int1 = fd;
	req->offs = offset;
	req->size = length;
	req->ptr2 = buf;

	::eio_submit(req);
	return req;
}

template <class T, int (T::*readcbmethod)(eio_req *req, ssize_t result, char *buf)>
eio_req * eio_readm(int fd, void *buf, size_t length, off_t offset, T* object, int pri = EIO_PRI_DEFAULT)
{
	if (fd == -1 || length <= 0 || offset < 0 || object == nullptr)
	{
		assert(false && "invalid param");
		return nullptr;
	}

	eio_req *req = (eio_req *)calloc(1, sizeof(eio_req));
	if (req == nullptr)
		assert(false && "malloc failed");

	req->type = EIO_READ;
	req->pri  = pri;
	req->finish = __eio_readcb_mthunk<T, readcbmethod>;
	req->data = object;
	req->destroy = __eio_api_destroy;

	req->int1 = fd;
	req->offs = offset;
	req->size = length;
	req->ptr2 = buf;

	::eio_submit(req);
	return req;
}

template <class T, int (T::*readcbmethod)(eio_req *req, ssize_t result, char *buf), void (T::*destroycbmethod)(eio_req *req)>
eio_req * eio_readm(int fd, void *buf, size_t length, off_t offset, T* object, int pri = EIO_PRI_DEFAULT)
{
	if (fd == -1 || length <= 0 || offset < 0 || object == nullptr)
	{
		assert(false && "invalid param");
		return nullptr;
	}

	eio_req *req = (eio_req *)calloc(1, sizeof(eio_req));
	if (req == nullptr)
		assert(false && "malloc failed");

	req->type = EIO_READ;
	req->pri  = pri;
	req->finish = __eio_readcb_mthunk<T, readcbmethod>;
	req->data = object;
	req->destroy = __eio_api_destroy_mthunk<T, destroycbmethod>;

	req->int1 = fd;
	req->offs = offset;
	req->size = length;
	req->ptr2 = buf;

	::eio_submit(req);
	return req;
}

inline eio_req * eio_write(int fd, void *buf, size_t length, off_t offset, eio_cb cb, void *data, int pri = EIO_PRI_DEFAULT, void (*destroy)(eio_req *req) = __eio_api_destroy)
{
	if (fd == -1 || buf == nullptr || length <= 0 || offset < 0)
	{
		assert(false && "invalid param");
		return nullptr;
	}

	eio_req *req = (eio_req *)calloc(1, sizeof(eio_req));
	if (req == nullptr)
		assert(false && "malloc failed");

	req->type = EIO_WRITE;
	req->pri  = pri;
	req->finish = cb;
	req->data = data;
	req->destroy = destroy;

	req->int1 = fd;
	req->offs = offset;
	req->size = length;
	req->ptr2 = buf;

	::eio_submit(req);
	return req;
}

template <int (*resultcbfunc)(eio_req *req, ssize_t result)>
eio_req * eio_writef(int fd, void *buf, size_t length, off_t offset, void* data, int pri = EIO_PRI_DEFAULT)
{
	if (fd == -1 || buf == nullptr || length <= 0 || offset < 0 || data == nullptr)
	{
		assert(false && "invalid param");
		return nullptr;
	}

	eio_req *req = (eio_req *)calloc(1, sizeof(eio_req));
	if (req == nullptr)
		assert(false && "malloc failed");

	req->type = EIO_WRITE;
	req->pri  = pri;
	req->finish = __eio_resultcb_fthunk<resultcbfunc>;
	req->data = data;
	req->destroy = __eio_api_destroy;

	req->int1 = fd;
	req->offs = offset;
	req->size = length;
	req->ptr2 = buf;

	::eio_submit(req);
	return req;
}

template <int (*resultcbfunc)(eio_req *req, ssize_t result), void (*destroycbfunc)(eio_req *req)>
eio_req * eio_writef(int fd, void *buf, size_t length, off_t offset, void* data, int pri = EIO_PRI_DEFAULT)
{
	if (fd == -1 || buf == nullptr || length <= 0 || offset < 0 || data == nullptr)
	{
		assert(false && "invalid param");
		return nullptr;
	}

	eio_req *req = (eio_req *)calloc(1, sizeof(eio_req));
	if (req == nullptr)
		assert(false && "malloc failed");

	req->type = EIO_WRITE;
	req->pri  = pri;
	req->finish = __eio_resultcb_fthunk<resultcbfunc>;
	req->data = data;
	req->destroy = __eio_api_destroy_fthunk<destroycbfunc>;

	req->int1 = fd;
	req->offs = offset;
	req->size = length;
	req->ptr2 = buf;

	::eio_submit(req);
	return req;
}

template <class T, int (T::*resultcbmethod)(eio_req *req, ssize_t result)>
eio_req * eio_writem(int fd, void *buf, size_t length, off_t offset, T* object, int pri = EIO_PRI_DEFAULT)
{
	if (fd == -1 || buf == nullptr || length <= 0 || offset < 0 || object == nullptr)
	{
		assert(false && "invalid param");
		return nullptr;
	}

	eio_req *req = (eio_req *)calloc(1, sizeof(eio_req));
	if (req == nullptr)
		assert(false && "malloc failed");

	req->type = EIO_WRITE;
	req->pri  = pri;
	req->finish = __eio_resultcb_mthunk<T, resultcbmethod>;
	req->data = object;
	req->destroy = __eio_api_destroy;

	req->int1 = fd;
	req->offs = offset;
	req->size = length;
	req->ptr2 = buf;

	::eio_submit(req);
	return req;
}

template <class T, int (T::*resultcbmethod)(eio_req *req, ssize_t result), void (T::*destroycbmethod)(eio_req *req)>
eio_req * eio_writem(int fd, void *buf, size_t length, off_t offset, T* object, int pri = EIO_PRI_DEFAULT)
{
	if (fd == -1 || buf == nullptr || length <= 0 || offset < 0 || object == nullptr)
	{
		assert(false && "invalid param");
		return nullptr;
	}

	eio_req *req = (eio_req *)calloc(1, sizeof(eio_req));
	if (req == nullptr)
		assert(false && "malloc failed");

	req->type = EIO_WRITE;
	req->pri  = pri;
	req->finish = __eio_resultcb_mthunk<T, resultcbmethod>;
	req->data = object;
	req->destroy = __eio_api_destroy_mthunk<T, destroycbmethod>;

	req->int1 = fd;
	req->offs = offset;
	req->size = length;
	req->ptr2 = buf;

	::eio_submit(req);
	return req;
}

inline eio_req * eio_custom(void (*execute)(eio_req *), eio_cb cb, void *data, int pri = EIO_PRI_DEFAULT, void (*destroy)(eio_req *req) = __eio_api_destroy)
{
	if (execute == nullptr || cb == nullptr)
	{
		assert(false && "invalid param");
		return nullptr;
	}

	eio_req *req = (eio_req *)calloc(1, sizeof(eio_req));
	if (req == nullptr)
		assert(false && "malloc failed");

	req->type = EIO_CUSTOM;
	req->pri  = pri;
	req->finish = cb;
	req->data = data;
	req->destroy = destroy;

	req->feed = execute;

	::eio_submit(req);
	return req;
}

template <int (*resultcbfunc)(eio_req *req, ssize_t result)>
eio_req * eio_customf(void (*execute)(eio_req *), void* data, int pri = EIO_PRI_DEFAULT)
{
	if (execute == nullptr)
	{
		assert(false && "invalid param");
		return nullptr;
	}

	eio_req *req = (eio_req *)calloc(1, sizeof(eio_req));
	if (req == nullptr)
		assert(false && "malloc failed");

	req->type = EIO_CUSTOM;
	req->pri  = pri;
	req->finish = __eio_resultcb_fthunk<resultcbfunc>;
	req->data = data;
	req->destroy = __eio_api_destroy;

	req->feed = execute;

	::eio_submit(req);
	return req;
}

template <int (*resultcbfunc)(eio_req *req, ssize_t result), void (*destroycbfunc)(eio_req *req)>
eio_req * eio_customf(void (*execute)(eio_req *), void* data, int pri = EIO_PRI_DEFAULT)
{
	if (data == nullptr)
	{
		assert(false && "invalid param");
		return nullptr;
	}

	eio_req *req = (eio_req *)calloc(1, sizeof(eio_req));
	if (req == nullptr)
		assert(false && "malloc failed");

	req->type = EIO_CUSTOM;
	req->pri  = pri;
	req->finish = __eio_resultcb_fthunk<resultcbfunc>;
	req->data = data;
	req->destroy = __eio_api_destroy_fthunk<destroycbfunc>;

	req->feed = execute;

	::eio_submit(req);
	return req;
}

template <class T, void (T::*executemethod)(eio_req *req), int (T::*resultcbmethod)(eio_req *req, ssize_t result)>
eio_req * eio_customm(T* object, int pri = EIO_PRI_DEFAULT)
{
	if (object == nullptr)
	{
		assert(false && "invalid param");
		return nullptr;
	}

	eio_req *req = (eio_req *)calloc(1, sizeof(eio_req));
	if (req == nullptr)
		assert(false && "malloc failed");

	req->type = EIO_CUSTOM;
	req->pri  = pri;
	req->finish = __eio_resultcb_mthunk<T, resultcbmethod>;
	req->data = object;
	req->destroy = __eio_api_destroy;

	req->feed = __eio_execute_mthunk<T, executemethod>;

	::eio_submit(req);
	return req;
}

template <class T, void (T::*executemethod)(eio_req *req), int (T::*resultcbmethod)(eio_req *req, ssize_t result), void (T::*destroycbmethod)(eio_req *req)>
eio_req * eio_customm(T* object, int pri = EIO_PRI_DEFAULT)
{
	if (object == nullptr)
	{
		assert(false && "invalid param");
		return nullptr;
	}

	eio_req *req = (eio_req *)calloc(1, sizeof(eio_req));
	if (req == nullptr)
		assert(false && "malloc failed");

	req->type = EIO_CUSTOM;
	req->pri  = pri;
	req->finish = __eio_resultcb_mthunk<T, resultcbmethod>;
	req->data = object;
	req->destroy = __eio_api_destroy_mthunk<T, destroycbmethod>;

	req->feed = __eio_execute_mthunk<T, executemethod>;

	::eio_submit(req);
	return req;
}


}


#endif


