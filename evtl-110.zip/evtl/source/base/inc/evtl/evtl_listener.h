

#ifndef __EVTL_LISTENER_H__
#define __EVTL_LISTENER_H__

#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <assert.h>

#include <functional>
#include <cstring>
#include <string>

#include "evtl_error.h"
#include "evtl_in.h"
#include "evtl_inet.h"


namespace evtl
{


class listener : public evtl_error
{
public:
	enum error_code
	{
		success,
		invalid_host,
		invalid_backlog,
		invalid_family,
		already_listening,
		socket_create_fail,
		reuse_addr_fail,
		reuse_port_fail,
		bind_failed,
		listen_failed
	};

	typedef std::function<void (listener &lsn, int fd)>  socket_callback_t;

	listener(): m_fd(-1)
	{
		memset(&m_listenaddr, 0, sizeof(m_listenaddr));
	}

	bool set_address(const address &addr)
	{
		std::pair<bool, struct sockaddr_storage> listenaddr = inetc::inaddr_pton(addr);
		if (!listenaddr.first)
		{
			set_error(invalid_host, addr.host.str());
			return false;
		}

		if (listenaddr.second.ss_family != AF_INET && listenaddr.second.ss_family != AF_INET6 && listenaddr.second.ss_family != AF_LOCAL)
			assert(false && "invalid family");

		m_listenaddr = listenaddr.second;
		return true;
	}

	void set_socketcallback(socket_callback_t cb)
	{
		m_socket_cb = std::move(cb);
	}

	void clear_socketcallback()
	{
		m_socket_cb = nullptr;
	}

	bool tcplisten(int backlog, bool nonblock = true, bool reuseport = false)
	{
		if (m_fd != -1)
		{
			set_error(already_listening, m_fd);
			return false;
		}

		if (backlog < 0)
		{
			set_error(invalid_backlog);
			return false;
		}

		if (m_listenaddr.ss_family != AF_INET && m_listenaddr.ss_family != AF_INET6)
		{
			set_error(invalid_family, m_listenaddr.ss_family);
			return false;
		}

		int fd = -1;
		if (nonblock)
			fd = ::socket(m_listenaddr.ss_family, SOCK_STREAM | SOCK_NONBLOCK, 0);
		else
			fd = ::socket(m_listenaddr.ss_family, SOCK_STREAM, 0);

		if (fd == -1)
		{
			set_error(socket_create_fail, errno);
			return false;
		}

		int flag = 1;
		if (::setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &flag, sizeof(flag)) != 0)
		{
			set_error(reuse_addr_fail, errno);
			::close(fd);
			return false;
		}

		if (reuseport)
		{
			flag = 1;
			if (::setsockopt(fd, SOL_SOCKET, SO_REUSEPORT, &flag, sizeof(flag)) != 0)
			{
				set_error(reuse_port_fail, errno);
				::close(fd);
				return false;
			}
		}

		if (m_socket_cb)
			m_socket_cb(*this, fd);

		if (::bind(fd, (const struct sockaddr *)&m_listenaddr, sizeof(m_listenaddr)) != 0)
		{
			set_error(bind_failed, errno);
			::close(fd);
			return false;
		}

		if (::listen(fd, backlog) != 0)
		{
			set_error(listen_failed, errno);
			::close(fd);
			return false;
		}

		m_fd = fd;
		return true;
	}

	bool unixlisten(int backlog, bool nonblock = true)
	{
		static_assert(sizeof(struct sockaddr_un) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_un");

		if (m_fd != -1)
		{
			set_error(already_listening, m_fd);
			return false;
		}

		if (backlog < 0)
		{
			set_error(invalid_backlog);
			return false;
		}

		if (m_listenaddr.ss_family != AF_LOCAL)
		{
			set_error(invalid_family, m_listenaddr.ss_family);
			return false;
		}

		int fd = -1;
		if (nonblock)
			fd = ::socket(m_listenaddr.ss_family, SOCK_STREAM | SOCK_NONBLOCK, 0);
		else
			fd = ::socket(m_listenaddr.ss_family, SOCK_STREAM, 0);

		if (fd == -1)
		{
			set_error(socket_create_fail, errno);
			return false;
		}

		if (m_socket_cb)
			m_socket_cb(*this, fd);

		if (::bind(fd, (const struct sockaddr *)&m_listenaddr, sizeof(struct sockaddr_un)) != 0)
		{
			set_error(bind_failed, errno);
			::close(fd);
			return false;
		}

		if (::listen(fd, backlog) != 0)
		{
			set_error(listen_failed, errno);
			::close(fd);
			return false;
		}

		m_fd = fd;
		return true;
	}

	const struct sockaddr_storage& get_addr() const
	{
		return m_listenaddr;
	}

	int get_fd() const
	{
		return m_fd;
	}

	void close()
	{
		if (m_fd != -1)
			::close(m_fd);
		m_fd = -1;

		memset(&m_listenaddr, 0, sizeof(m_listenaddr));
		m_socket_cb = nullptr;
	}

private:
	struct sockaddr_storage  m_listenaddr;
	int  m_fd;

	socket_callback_t  m_socket_cb;
};


}


#endif


