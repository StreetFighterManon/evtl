

#ifndef __EVTL_EVENTLOOP_H__
#define __EVTL_EVENTLOOP_H__

#include <assert.h>

#include <utility>
#include <functional>
#include <cstdint>
#include <string>
#include <type_traits>

#include <ev/ev++.h>

#include "evtl_gcc.h"
#include "evtl_thread.h"
#include "evtl_time.h"


namespace evtl
{


class looprefer
{
public:
	looprefer(): m_loop(nullptr)
	{}

	looprefer(EV_P): m_loop(EV_A)
	{}

	looprefer(const ev::loop_ref &loop): m_loop(loop)
	{}

	looprefer(const looprefer &that) = default;
	looprefer& operator = (const looprefer &that) = default;

	bool operator == (const looprefer &that) const
	{
		return m_loop == that.m_loop;
	}

	bool operator != (const looprefer &that) const
	{
		return !(m_loop == that.m_loop);
	}

	bool is_null() const
	{
		return m_loop == nullptr;
	}

	operator ev::loop_ref () const
	{
		return m_loop;
	}

	ev::loop_ref ref() const
	{
		return m_loop;
	}

	struct ev_loop * raw_loop() const
	{
		return m_loop;
	}

	void inc_ref()
	{
		m_loop.ref();
	}

	void dec_ref()
	{
		m_loop.unref();
	}

	bool is_default() const
	{
		return m_loop.is_default();
	}

	int run(int flags)
	{
		return ::ev_run(m_loop, flags);
	}

	ev::tstamp now() const
	{
		return m_loop.now();
	}

	void now_update()
	{
		::ev_now_update(m_loop);
	}

	ev::tstamp now_difference() const
	{
		ev::tstamp diff = ::ev_time() - m_loop.now();
		if (diff > 0.)
			return diff;

		return 0.;
	}

	ev::tstamp fast_now_difference() const
	{
		ev::tstamp diff = timec::fast_sec_f() - m_loop.now();
		if (diff > 0.)
			return diff;

		return 0.;
	}

	unsigned int backend() const
	{
		return m_loop.backend();
	}

	void set_io_collect_interval(ev::tstamp interval)
	{
		return m_loop.set_io_collect_interval(interval);
	}

	void set_timeout_collect_interval(ev::tstamp interval)
	{
		return m_loop.set_timeout_collect_interval(interval);
	}

	void break_loop(ev::how_t how)
	{
		m_loop.break_loop(how);
	}

public:
	static std::pair<int, int> version()
	{
		int major = ::ev_version_major();
		int minor = ::ev_version_minor();

		return std::make_pair(major, minor);
	}

	static ev::tstamp time()
	{
		return ::ev_time();
	}

	static unsigned int supported_backends()
	{
		return ::ev_supported_backends();
	}

	static unsigned int recommended_backends()
	{
		return ::ev_recommended_backends();
	}

private:
	ev::loop_ref  m_loop;
};


class default_loop : public looprefer
{
public:
	explicit default_loop(unsigned int flags = ev::AUTO): looprefer(::ev_default_loop(flags))
	{
		if (is_null())
			throw ev::bad_loop();
	}

	static struct ev_loop * preinit(unsigned int flags = ev::AUTO)
	{
		/* this function can handle SIGCHLD */
		return ::ev_default_loop(flags);
	}

private:
	default_loop(const default_loop &) = delete;
	default_loop& operator = (const default_loop &) = delete;
};


class dynamic_loop : public looprefer
{
public:
	explicit dynamic_loop(unsigned int flags = ev::AUTO): looprefer(::ev_loop_new(flags))
	{
		if (is_null())
			throw ev::bad_loop();
	}

	~dynamic_loop() noexcept
	{
		if (!is_null())
			::ev_loop_destroy(raw_loop());
	}

private:
	dynamic_loop(const dynamic_loop &) = delete;
	dynamic_loop& operator = (const dynamic_loop &) = delete;
};


template <class T, class LpT = default_loop>
class eventloop : public evtl_error
{
	static_assert(std::is_same<LpT, default_loop>::value || std::is_same<LpT, dynamic_loop>::value, "invalid type LpT");

public:
	enum run_mode
	{
		current_thread,
		background_thread
	};

	enum loop_status
	{
		loop_unready,
		loop_comein,
		loop_jumpout
	};

	typedef std::function<void (T &loop, int runflags)>  run_callback_t;
	typedef std::function<void (T &loop)>                iterbefore_callback_t;
	typedef std::function<void (T &loop, int refcount)>  iterafter_callback_t;

	explicit eventloop(unsigned int flags = ev::AUTO): m_loop(flags), m_runflags(0), m_loopstat(loop_unready)
	{}

	looprefer ref() const
	{
		return m_loop;
	}

	void set_runflags(int flags)
	{
		m_runflags = flags;
	}

	int get_runflags() const
	{
		return m_runflags;
	}

	void set_run_callback()
	{
		m_run_cb = nullptr;
	}

	void set_run_callback(run_callback_t run)
	{
		m_run_cb = std::move(run);
	}

	void set_before_callback()
	{
		m_before_cb = std::bind(&T::before_callback, static_cast<T*>(this), std::placeholders::_1);
	}

	void set_before_callback(iterbefore_callback_t before)
	{
		m_before_cb = std::move(before);
	}

	void clear_before_callback()
	{
		m_before_cb = nullptr;
	}

	void set_after_callback()
	{
		m_after_cb = std::bind(&T::after_callback, static_cast<T*>(this), std::placeholders::_1, std::placeholders::_2);
	}

	void set_after_callback(iterafter_callback_t after)
	{
		m_after_cb = std::move(after);
	}

	void clear_after_callback()
	{
		m_after_cb = nullptr;
	}

	bool run_loop(eventloop::run_mode mode = eventloop::current_thread, const std::string &thread_name = std::string(), ssize_t stacksize = 0)
	{
		if (mode == eventloop::background_thread)
		{
			m_thread.set_callback<eventloop, &eventloop::background>(this);
			if (!m_thread.make_thread(nullptr, thread_name, stacksize))
			{
				this->evtl_error::operator = (m_thread);
				return false;
			}
			return true;
		}

		_loop_run();
		return true;
	}

	eventloop::loop_status loopstat() const
	{
		return m_loopstat;
	}

	void inc_ref()
	{
		m_loop.inc_ref();
	}

	void dec_ref()
	{
		m_loop.dec_ref();
	}

	ev::tstamp now() const
	{
		return m_loop.now();
	}

	void now_update()
	{
		m_loop.now_update();
	}

	ev::tstamp now_difference() const
	{
		return m_loop.now_difference();
	}

	ev::tstamp fast_now_difference() const
	{
		return m_loop.fast_now_difference();
	}

	unsigned int backend() const
	{
		return m_loop.backend();
	}

	void set_io_collect_interval(ev::tstamp interval)
	{
		return m_loop.set_io_collect_interval(interval);
	}

	void set_timeout_collect_interval(ev::tstamp interval)
	{
		return m_loop.set_timeout_collect_interval(interval);
	}

	void break_loop(ev::how_t how)
	{
		m_loop.break_loop(how);
	}

public:
	static ev::tstamp time()
	{
		return ::ev_time();
	}

private:
	void * background(void *arg)
	{
		_loop_run();
		return nullptr;
	}

	void _loop_run()
	{
		if (m_run_cb)
			m_run_cb(*static_cast<T*>(this), m_runflags);
		else
			static_cast<T*>(this)->run_callback(*static_cast<T*>(this), m_runflags);
	}

private:
	void run_callback(T &loop, int runflags)
	{
		if (evunlike(&loop != static_cast<T*>(this)))
			assert(false && "unexpected loop");
		if (evunlike(runflags != m_runflags))
			assert(false && "unexpected runflags");

		int refcount = 0;

		switch (m_runflags)
		{
		case 0:
			{
				if (m_before_cb)
					m_before_cb(*static_cast<T*>(this));

				m_loopstat = eventloop::loop_comein;
				refcount = m_loop.run(m_runflags);
				m_loopstat = eventloop::loop_jumpout;
		
				if (evlike(m_after_cb))
					m_after_cb(*static_cast<T*>(this), refcount);
				else
					assert(false && "loop jumped out.");
			}
			break;
		case ev::NOWAIT:
			{
				while (true)
				{
					if (m_before_cb)
						m_before_cb(*static_cast<T*>(this));

					m_loopstat = eventloop::loop_comein;
					refcount = m_loop.run(m_runflags);
					m_loopstat = eventloop::loop_jumpout;
		
					if (m_after_cb)
						m_after_cb(*static_cast<T*>(this), refcount);
				}
			}
			break;
		case ev::ONCE:
			{
				if (m_before_cb)
					m_before_cb(*static_cast<T*>(this));

				m_loopstat = eventloop::loop_comein;
				refcount = m_loop.run(m_runflags);
				m_loopstat = eventloop::loop_jumpout;

				if (m_after_cb)
					m_after_cb(*static_cast<T*>(this), refcount);
			}
			break;
		default:
			assert(false && "invalid runflags");
			break;
		}
	}

	void before_callback(T &loop)               { assert(false && "unset callback"); }
	void after_callback(T &loop, int refcount)  { assert(false && "unset callback"); }

private:
	LpT          m_loop;
	int          m_runflags;

	run_callback_t  m_run_cb;

	iterbefore_callback_t  m_before_cb;
	iterafter_callback_t   m_after_cb;
	loop_status            m_loopstat;

	thread::methodthreadc  m_thread;
};

template <class LpT = default_loop>
class simpeventloop : public eventloop<simpeventloop<LpT>, LpT>
{
public:
	explicit simpeventloop(unsigned int flags = ev::AUTO): eventloop<simpeventloop<LpT>, LpT>(flags)
	{}
};


}


#endif


