

#ifndef __EVTL_WATCHER_IO_H__
#define __EVTL_WATCHER_IO_H__

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <assert.h>

#include <utility>
#include <functional>

#include <ev/ev++.h>

#include "evtl_gcc.h"
#include "evtl_copyable.h"
#include "evtl_eventloop.h"


namespace evtl
{


template <class T>
class watcher_io : public nocopyc
{
public:
	typedef std::function<void (T &watcher, int revents)>  io_callback_t;

	watcher_io()
	{
		m_io.set(nullptr);
		m_io.set(-1, 0);
		m_io.set<watcher_io, &watcher_io::_callback>(this);
	}

	void set(looprefer loop)
	{
		if (m_io.is_active())
			m_io.stop();

		m_io.set(loop.ref());
	}

	void set_callback()
	{
		if (m_io.is_active())
			m_io.stop();

		m_io.set<watcher_io, &watcher_io::_callback>(this);
		m_io_callback = nullptr;
	}

	void set_callback(io_callback_t cb)
	{
		if (m_io.is_active())
			m_io.stop();

		m_io.set<watcher_io, &watcher_io::_callback>(this);
		m_io_callback = std::move(cb);
	}

	void set(int fd, int events)
	{
		if (m_io.is_active())
			m_io.stop();

		events &= (ev::READ | ev::WRITE);
		m_io.set(fd, events);
	}

	void set_fd(int fd)
	{
		if (m_io.is_active())
			m_io.stop();

		m_io.fd = fd;
	}

	void set_events(int events)
	{
		if (m_io.is_active())
			m_io.stop();

		events &= (ev::READ | ev::WRITE);
		m_io.set(events);
	}

	void set_priority(int priority)
	{
		if (m_io.is_active())
			m_io.stop();

		ev_set_priority(static_cast<ev_io *>(&m_io), priority);
	}

	int get_priority() const
	{
		return ev_priority(static_cast<ev_io *>(&m_io));
	}

	bool start()
	{
		if (m_io.fd == -1)
			return false;

		m_io.start();
		return true;
	}

	void stop()
	{
		m_io.stop();
	}

	bool is_active() const
	{
		return m_io.is_active();
	}

	bool is_pending() const
	{
		return m_io.is_pending();
	}

	int clear_pending()
	{
		if (m_io.EV_A == nullptr)
			assert(false && "null loop");

		return ::ev_clear_pending(m_io.EV_A, static_cast<ev_io *>(&m_io));
	}

	looprefer get_loop() const
	{
		return m_io.EV_A;
	}

	int get_fd() const
	{
		return m_io.fd;
	}

	int get_events() const
	{
		return (m_io.events & (ev::READ | ev::WRITE));
	}

	void feed_event(int revents)
	{
		m_io.feed_event(revents & (ev::READ | ev::WRITE));
	}

	ssize_t read(void *buf, size_t nbytes)
	{
		return ::read(m_io.fd, buf, nbytes);
	}

	ssize_t write(const void *buf, size_t nbytes)
	{
		return ::write(m_io.fd, buf, nbytes);
	}

	ssize_t recv(void *buf, size_t nbytes, int flags = 0)
	{
		return ::recv(m_io.fd, buf, nbytes, flags);
	}

	ssize_t send(const void *buf, size_t nbytes, int flags = 0)
	{
		return ::send(m_io.fd, buf, nbytes, flags);
	}

	ssize_t recvfrom(void *buf, size_t nbytes, struct sockaddr_storage &srcaddr, int flags = 0)
	{
		socklen_t addrlen = sizeof(srcaddr);
		return ::recvfrom(m_io.fd, buf, nbytes, flags, (struct sockaddr *)&srcaddr, &addrlen);
	}

	ssize_t recvfrom(void *buf, size_t nbytes, int flags = 0)
	{
		return ::recvfrom(m_io.fd, buf, nbytes, flags, nullptr, nullptr);
	}

	ssize_t sendto(const void *buf, size_t nbytes, const struct sockaddr_storage &destaddr, int flags = 0)
	{
		static_assert(sizeof(struct sockaddr_un) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_un");

		ssize_t r = 0;

		if (destaddr.ss_family == AF_LOCAL)
			r = ::sendto(m_io.fd, buf, nbytes, flags, (const struct sockaddr *)&destaddr, sizeof(struct sockaddr_un));
		else
			r = ::sendto(m_io.fd, buf, nbytes, flags, (const struct sockaddr *)&destaddr, sizeof(destaddr));

		return r;
	}

	void only_close()
	{
		if (m_io.fd != -1)
			::close(m_io.fd);

		m_io.set(-1, 0);
	}

	void stop_close()
	{
		m_io.stop();

		if (m_io.fd != -1)
			::close(m_io.fd);

		m_io.set(-1, 0);
	}

	void only_reset()
	{
		m_io.set(-1, 0);
	}

	void stop_reset()
	{
		m_io.stop();
		m_io.set(-1, 0);
	}

private:
	void io_callback(T &watcher, int revents) { assert(false && "unset callback"); }

	void _callback(ev::io &watcher, int revents)
	{
		if (evunlike((revents & ev::ERROR) != 0))
			assert(false && "ev_error");
		if (evunlike(&watcher != &m_io))
			assert(false && "unexpected watcher");

		if (m_io_callback)
			m_io_callback(*static_cast<T*>(this), revents);
		else
			static_cast<T*>(this)->io_callback(*static_cast<T*>(this), revents);
	}

private:
	ev::io         m_io;
	io_callback_t  m_io_callback;
};

class simpwio : public watcher_io<simpwio>
{};


}


#endif


