

#ifndef __EVTL_NETIOCTL_H__
#define __EVTL_NETIOCTL_H__

#include <unistd.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <vector>
#include <string>
#include <cstring>
#include <utility>

#include "evtl_inet.h"


namespace evtl
{


struct ifconfinfo
{
	std::string  ifname;
	std::string  ifaddr;
};

struct ifflags
{
	ifflags(): flags_valid(false),
		up(false), broadcast(false), debug(false), loopback(false), pointtopoint(false), running(false),
		noarp(false), promisc(false), notrailers(false), allmulti(false), master(false), slave(false),
		multicast(false), portsel(false),
		automedia(false), dynamic(false)
	{}

	explicit operator bool () const
	{
		return flags_valid;
	}

	bool  flags_valid;

	bool  up;
	bool  broadcast;
	bool  debug;
	bool  loopback;
	bool  pointtopoint;
	bool  running;
	bool  noarp;
	bool  promisc;
	bool  notrailers;
	bool  allmulti;
	bool  master;
	bool  slave;
	bool  multicast;
	bool  portsel;

	bool  automedia;
	bool  dynamic;
};


/* netdevice(7) */
class netioctl
{
public:
	static std::vector<ifconfinfo> ipv4_ifconfig()
	{
		std::vector<ifconfinfo> res;

		struct ifreq ifs[512];
		memset(&ifs, 0, sizeof(ifs));

		struct ifconf conf;
		memset(&conf, 0, sizeof(conf));
		conf.ifc_len = sizeof(ifs);
		conf.ifc_req = ifs;

		int fd = ::socket(AF_INET, SOCK_DGRAM, 0);
		if (fd < 0)
			return res;

		if (::ioctl(fd, SIOCGIFCONF, &conf) < 0)
		{
			::close(fd);
			return res;
		}

		::close(fd);

		int if_count = conf.ifc_len/sizeof(struct ifreq);
		for (int i = 0; i < if_count; i++)
		{
			if (ifs[i].ifr_addr.sa_family != AF_INET)
				continue;

			ifs[i].ifr_name[sizeof(ifs[i].ifr_name) - 1] = '\0';

			ifconfinfo info;
			info.ifname = ifs[i].ifr_name;
			info.ifaddr = inetc::inet_ntop4(((const struct sockaddr_in &)ifs[i].ifr_addr).sin_addr);
			res.push_back(std::move(info));
		}

		return res;
	}

	static std::string ipv4_ifaddr(const std::string &ifname)
	{
		struct ifreq info;

		memset(&info, 0, sizeof(info));
		strncpy(info.ifr_name, ifname.c_str(), sizeof(info.ifr_name) - 1);
		info.ifr_name[sizeof(info.ifr_name) - 1] = '\0';
		info.ifr_addr.sa_family = AF_INET;

		std::string res;

		int fd = ::socket(AF_INET, SOCK_DGRAM, 0);
		if (fd < 0)
			return res;

		if (::ioctl(fd, SIOCGIFADDR, &info) < 0)
		{
			::close(fd);
			return res;
		}

		::close(fd);

		if (info.ifr_addr.sa_family != AF_INET)
			return res;

		res = inetc::inet_ntop4(((const struct sockaddr_in &)info.ifr_addr).sin_addr);
		return res;
	}

	static std::string ipv4_bcastaddr(const std::string &ifname)
	{
		struct ifreq info;
		memset(&info, 0, sizeof(info));

		strncpy(info.ifr_name, ifname.c_str(), sizeof(info.ifr_name) - 1);
		info.ifr_name[sizeof(info.ifr_name) - 1] = '\0';
		info.ifr_addr.sa_family = AF_INET;

		std::string res;

		int fd = ::socket(AF_INET, SOCK_DGRAM, 0);
		if (fd < 0)
			return res;

		if (::ioctl(fd, SIOCGIFBRDADDR, &info) < 0)
		{
			::close(fd);
			return res;
		}

		::close(fd);

		if (info.ifr_addr.sa_family != AF_INET)
			return res;

		res = inetc::inet_ntop4(((const struct sockaddr_in &)info.ifr_broadaddr).sin_addr);
		return res;
	}

	static std::string ipv4_netmask(const std::string &ifname)
	{
		struct ifreq info;
		memset(&info, 0, sizeof(info));

		strncpy(info.ifr_name, ifname.c_str(), sizeof(info.ifr_name) - 1);
		info.ifr_name[sizeof(info.ifr_name) - 1] = '\0';
		info.ifr_addr.sa_family = AF_INET;

		std::string res;

		int fd = ::socket(AF_INET, SOCK_DGRAM, 0);
		if (fd < 0)
			return res;

		if (::ioctl(fd, SIOCGIFNETMASK, &info) < 0)
		{
			::close(fd);
			return res;
		}

		::close(fd);

		if (info.ifr_addr.sa_family != AF_INET)
			return res;

		res = inetc::inet_ntop4(((const struct sockaddr_in &)info.ifr_netmask).sin_addr);
		return res;
	}

	static ifflags dev_flags(const std::string &ifname)
	{
		struct ifreq info;
		memset(&info, 0, sizeof(info));

		strncpy(info.ifr_name, ifname.c_str(), sizeof(info.ifr_name) - 1);
		info.ifr_name[sizeof(info.ifr_name) - 1] = '\0';

		ifflags res;

		int fd = ::socket(AF_INET, SOCK_DGRAM, 0);
		if (fd < 0)
			return res;

		if (::ioctl(fd, SIOCGIFFLAGS, &info) < 0)
		{
			::close(fd);
			return res;
		}

		::close(fd);

		res.up            = ((info.ifr_flags & IFF_UP) != 0);
		res.broadcast     = ((info.ifr_flags & IFF_BROADCAST) != 0);
		res.debug         = ((info.ifr_flags & IFF_DEBUG) != 0);
		res.loopback      = ((info.ifr_flags & IFF_LOOPBACK) != 0);
		res.pointtopoint  = ((info.ifr_flags & IFF_POINTOPOINT) != 0);
		res.running       = ((info.ifr_flags & IFF_RUNNING) != 0);
		res.noarp         = ((info.ifr_flags & IFF_NOARP) != 0);
		res.promisc       = ((info.ifr_flags & IFF_PROMISC) != 0);
		res.notrailers    = ((info.ifr_flags & IFF_NOTRAILERS) != 0);
		res.allmulti      = ((info.ifr_flags & IFF_ALLMULTI) != 0);
		res.master        = ((info.ifr_flags & IFF_MASTER) != 0);
		res.slave         = ((info.ifr_flags & IFF_SLAVE) != 0);
		res.multicast     = ((info.ifr_flags & IFF_MULTICAST) != 0);
		res.portsel       = ((info.ifr_flags & IFF_PORTSEL) != 0);

		res.automedia     = ((info.ifr_flags & IFF_AUTOMEDIA) != 0);
		res.dynamic       = ((info.ifr_flags & IFF_DYNAMIC) != 0);

		res.flags_valid = true;
		return res;
	}

	/* error: return 0 */
	static unsigned int if_nametoindex(const std::string &name)
	{
		return ::if_nametoindex(name.c_str());
	}

	static std::string if_indextoname(unsigned int index)
	{
		char name[IF_NAMESIZE + 1] = { 0 };

		const char *rs = ::if_indextoname(index, name);
		if (rs == nullptr)
			return std::string();

		name[sizeof(name) - 1] = '\0';
		return name;
	}
};


}


#endif


