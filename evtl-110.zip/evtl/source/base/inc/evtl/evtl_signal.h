

#ifndef __EVTL_SIGNAL_H__
#define __EVTL_SIGNAL_H__

#include <signal.h>
#include <cstring>


namespace evtl
{


class signalc
{
public:
	static bool sigaction(int signum, void (*signal_handler)(int))
	{
		struct sigaction sa;
		memset(&sa, 0, sizeof(sa));

		sa.sa_handler = signal_handler;
		sigemptyset(&sa.sa_mask);

		return 0 == ::sigaction(signum, &sa, nullptr);
	}

	static bool sigaction(int signum, void (*signal_sigaction_handler)(int, siginfo_t *, void *))
	{
		struct sigaction sa;
		memset(&sa, 0, sizeof(sa));

		sa.sa_sigaction = signal_sigaction_handler;
		sa.sa_flags     = SA_SIGINFO;

		sigemptyset(&sa.sa_mask);

		return 0 == ::sigaction(signum, &sa, nullptr);
	}

	static bool sig_default(int signum)
	{
		return signalc::sigaction(signum, SIG_DFL);
	}

	static bool sig_ignore(int signum)
	{
		return signalc::sigaction(signum, SIG_IGN);
	}

	static bool sig_block(int signum)
	{
		sigset_t sgset;
		sigemptyset(&sgset);
		sigaddset(&sgset, signum);

		if (sigprocmask(SIG_BLOCK, &sgset, nullptr) != 0)
			return false;

		return true;
	}

	static bool sig_unblock(int signum)
	{
		sigset_t sgset;
		sigemptyset(&sgset);
		sigaddset(&sgset, signum);

		if (sigprocmask(SIG_UNBLOCK, &sgset, nullptr) != 0)
			return false;

		return true;
	}

	static bool typical_ignore()
	{
		bool br = true;

		if (!signalc::sigaction(SIGINT, SIG_IGN))
			br = false;

		// send when console closed, can be deamon to cast off
		if (!signalc::sigaction(SIGHUP, SIG_IGN))
			br = false;

		if (!signalc::sigaction(SIGTERM, SIG_IGN))
			br = false;

		if (!signalc::sigaction(SIGQUIT, SIG_IGN))
			br = false;

		// avoid zombie process
		if (!signalc::sigaction(SIGCHLD, SIG_IGN))
			br = false;

		if (!signalc::sigaction(SIGPIPE, SIG_IGN))
			br = false;

		if (!signalc::sigaction(SIGALRM, SIG_IGN))
			br = false;

		// used for signal-driven I/O model
		if (!signalc::sigaction(SIGIO, SIG_IGN))
			br = false;

		if (!signalc::sigaction(SIGSYS, SIG_IGN))
			br = false;

		if (!signalc::sigaction(SIGWINCH, SIG_IGN))
			br = false;

		if (!signalc::sigaction(SIGXCPU, SIG_IGN))
			br = false;

		return br;
	}

	static bool typical_block()
	{
		sigset_t sgset;

		sigemptyset(&sgset);
		sigaddset(&sgset, SIGCHLD);
		sigaddset(&sgset, SIGALRM);
		sigaddset(&sgset, SIGIO);
		sigaddset(&sgset, SIGINT);
		sigaddset(&sgset, SIGHUP);
		sigaddset(&sgset, SIGWINCH);
		sigaddset(&sgset, SIGTERM);
		sigaddset(&sgset, SIGQUIT);
		sigaddset(&sgset, SIGXCPU);

		if (sigprocmask(SIG_BLOCK, &sgset, nullptr) != 0)
			return false;

		return true;
	}

	static bool typical_unblock()
	{
		sigset_t sgset;

		sigemptyset(&sgset);
		sigaddset(&sgset, SIGCHLD);
		sigaddset(&sgset, SIGALRM);
		sigaddset(&sgset, SIGIO);
		sigaddset(&sgset, SIGINT);
		sigaddset(&sgset, SIGHUP);
		sigaddset(&sgset, SIGWINCH);
		sigaddset(&sgset, SIGTERM);
		sigaddset(&sgset, SIGQUIT);
		sigaddset(&sgset, SIGXCPU);

		if (sigprocmask(SIG_UNBLOCK, &sgset, nullptr) != 0)
			return false;

		return true;
	}

	static void suspend_all()
	{
		sigset_t sgset;

		sigemptyset(&sgset);
		sigsuspend(&sgset);
	}
};


}


#endif


