

#ifndef __EVTL_WATCHER_PREPARE_H__
#define __EVTL_WATCHER_PREPARE_H__

#include <assert.h>

#include <utility>
#include <functional>

#include <ev/ev++.h>

#include "evtl_gcc.h"
#include "evtl_copyable.h"
#include "evtl_eventloop.h"


namespace evtl
{


template <class T>
class watcher_prepare : public nocopyc
{
public:
	typedef std::function<void (T &watcher, int revents)>   prepare_callback_t;

	watcher_prepare()
	{
		m_prepare.set(nullptr);
		m_prepare.set<watcher_prepare, &watcher_prepare::_callback>(this);
	}

	void set(looprefer loop)
	{
		if (m_prepare.is_active())
			m_prepare.stop();

		m_prepare.set(loop.ref());
	}

	void set_callback()
	{
		if (m_prepare.is_active())
			m_prepare.stop();

		m_prepare.set<watcher_prepare, &watcher_prepare::_callback>(this);
		m_prepare_callback = nullptr;
	}

	void set_callback(prepare_callback_t cb)
	{
		if (m_prepare.is_active())
			m_prepare.stop();

		m_prepare.set<watcher_prepare, &watcher_prepare::_callback>(this);
		m_prepare_callback = std::move(cb);
	}

	void set_priority(int priority)
	{
		if (m_prepare.is_active())
			m_prepare.stop();

		ev_set_priority(static_cast<ev_prepare *>(&m_prepare), priority);
	}

	int get_priority() const
	{
		return ev_priority(static_cast<ev_prepare *>(&m_prepare));
	}

	void stop()
	{
		m_prepare.stop();
	}

	void start()
	{
		m_prepare.start();
	}

	bool is_active() const
	{
		return m_prepare.is_active();
	}

	bool is_pending() const
	{
		return m_prepare.is_pending();
	}

	int clear_pending()
	{
		if (m_prepare.EV_A == nullptr)
			assert(false && "null loop");

		return ::ev_clear_pending(m_prepare.EV_A, static_cast<ev_prepare *>(&m_prepare));
	}

	looprefer get_loop() const
	{
		return m_prepare.EV_A;
	}

private:
	void prepare_callback(T &watcher, int revents) { assert(false && "unset callback"); }

	void _callback(ev::prepare &watcher, int revents)
	{
		if (evunlike((revents & ev::ERROR) != 0))
			assert(false && "ev_error");
		if (evunlike(&watcher != &m_prepare))
			assert(false && "unexpected watcher");

		if (m_prepare_callback)
			m_prepare_callback(*static_cast<T*>(this), revents);
		else
			static_cast<T*>(this)->prepare_callback(*static_cast<T*>(this), revents);
	}

private:
	ev::prepare         m_prepare;
	prepare_callback_t  m_prepare_callback;
};

class simpwprepare : public watcher_prepare<simpwprepare>
{};


}


#endif


