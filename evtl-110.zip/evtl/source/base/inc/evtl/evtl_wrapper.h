

#ifndef __EVTL_WRAPPER_H__
#define __EVTL_WRAPPER_H__

#include <type_traits>
#include <utility>

#include "evtl_copyable.h"
#include "evtl_traits.h"


namespace evtl
{


template
<
	class T,
	bool atomicset = false,
	bool forbidcopy = false
>
class variable;

template <class T, bool forbidcopy>
class variable<T, false, forbidcopy> : public traits::copyable_traits<!forbidcopy>::type
{
public:
	variable(): m_isset(false), m_value()
	{}

	variable(const T &val, bool bset): m_isset(bset), m_value(val)
	{}

	variable(T &&val, bool bset): m_isset(bset), m_value(std::forward<T>(val))
	{}

	void set()
	{
		m_isset = true;
	}

	void unset()
	{
		m_isset = false;
	}

#undef isset
	bool isset() const
	{
		return m_isset;
	}

	void reset()
	{
		m_isset = false;
		m_value = T();
	}

	variable& assign(const T &val)
	{
		m_value = val;
		return *this;
	}

	variable& assign(T &&val)
	{
		m_value = std::forward<T>(val);
		return *this;
	}

	variable& set_assign(const T &val)
	{
		m_value = val;
		m_isset = true;
		return *this;
	}

	variable& set_assign(T &&val)
	{
		m_value = std::forward<T>(val);
		m_isset = true;
		return *this;
	}

	const T& refer() const
	{
		return m_value;
	}

	T& refer()
	{
		return m_value;
	}

	operator const T& () const
	{
		return m_value;
	}

private:
	bool  m_isset;
	T     m_value;
};

template <class T, bool forbidcopy>
class variable<T, true, forbidcopy> : public nocopyc
{
public:
	variable(): m_value()
	{
		__atomic_store_n(&m_isset, false, __ATOMIC_SEQ_CST);
	}

	variable(const T &val, bool bset): m_value(val)
	{
		__atomic_store_n(&m_isset, bset, __ATOMIC_SEQ_CST);
	}

	variable(T &&val, bool bset): m_value(std::forward<T>(val))
	{
		__atomic_store_n(&m_isset, bset, __ATOMIC_SEQ_CST);
	}

	void set()
	{
		__atomic_store_n(&m_isset, true, __ATOMIC_SEQ_CST);
	}

	void unset()
	{
		__atomic_store_n(&m_isset, false, __ATOMIC_SEQ_CST);
	}

	bool isset() const
	{
		return __atomic_load_n(&m_isset, __ATOMIC_SEQ_CST);
	}

	void reset()
	{
		__atomic_store_n(&m_isset, false, __ATOMIC_SEQ_CST);
		m_value = T();
	}

	variable& assign(const T &val)
	{
		m_value = val;
		return *this;
	}

	variable& assign(T &&val)
	{
		m_value = std::forward<T>(val);
		return *this;
	}

	variable& set_assign(const T &val)
	{
		m_value = val;
		__atomic_store_n(&m_isset, true, __ATOMIC_SEQ_CST);
		return *this;
	}

	variable& set_assign(T &&val)
	{
		m_value = std::forward<T>(val);
		__atomic_store_n(&m_isset, true, __ATOMIC_SEQ_CST);
		return *this;
	}

	const T& refer() const
	{
		return m_value;
	}

	T& refer()
	{
		return m_value;
	}

	operator const T& () const
	{
		return m_value;
	}

private:
	bool  m_isset;
	T     m_value;
};

template
<
	class T,
	bool atomicset = false,
	bool forbidcopy = false
>
using var = variable<T, atomicset, forbidcopy>;

template
<
	class T,
	bool atomicset = false,
	bool forbidcopy = false
>
using static_variable = variable<T, atomicset, forbidcopy>;

template
<
	class T,
	bool atomicset = false,
	bool forbidcopy = false
>
using st_var = static_variable<T, atomicset, forbidcopy>;

template
<
	class T,
	bool atomicset = false,
	bool forbidcopy = false
>
using dynamic_variable = variable<T, atomicset, forbidcopy>;

template
<
	class T,
	bool atomicset = false,
	bool forbidcopy = false
>
using dn_var = dynamic_variable<T, atomicset, forbidcopy>;


template
<
	class T,
	bool atomicbool = false,
	bool forbidcopy = false
>
class bool_variable;

template <class T, bool forbidcopy>
class bool_variable<T, false, forbidcopy> : public traits::copyable_traits<!forbidcopy>::type
{
public:
	bool_variable(): m_isvalid(false), m_value()
	{}

	bool_variable(const T &val, bool valid): m_isvalid(valid), m_value(val)
	{}

	bool_variable(T &&val, bool valid): m_isvalid(valid), m_value(std::forward<T>(val))
	{}

	void set_valid()
	{
		m_isvalid = true;
	}

	void set_invalid()
	{
		m_isvalid = false;
	}

	bool isvalid() const
	{
		return m_isvalid;
	}

	void reset()
	{
		m_isvalid = false;
		m_value   = T();
	}

	bool_variable& assign(const T &val)
	{
		m_value = val;
		return *this;
	}

	bool_variable& assign(T &&val)
	{
		m_value = std::forward<T>(val);
		return *this;
	}

	bool_variable& valid_assign(const T &val)
	{
		m_value   = val;
		m_isvalid = true;
		return *this;
	}

	bool_variable& valid_assign(T &&val)
	{
		m_value   = std::forward<T>(val);
		m_isvalid = true;
		return *this;
	}

	const T& refer() const
	{
		return m_value;
	}

	T& refer()
	{
		return m_value;
	}

	operator const T& () const
	{
		return m_value;
	}

private:
	bool  m_isvalid;
	T	   m_value;
};

template <class T, bool forbidcopy>
class bool_variable<T, true, forbidcopy> : public nocopyc
{
public:
	bool_variable(): m_value()
	{
		__atomic_store_n(&m_isvalid, false, __ATOMIC_SEQ_CST);
	}

	bool_variable(const T &val, bool valid): m_value(val)
	{
		__atomic_store_n(&m_isvalid, valid, __ATOMIC_SEQ_CST);
	}

	bool_variable(T &&val, bool valid): m_value(std::forward<T>(val))
	{
		__atomic_store_n(&m_isvalid, valid, __ATOMIC_SEQ_CST);
	}

	void set_valid()
	{
		__atomic_store_n(&m_isvalid, true, __ATOMIC_SEQ_CST);
	}

	void set_invalid()
	{
		__atomic_store_n(&m_isvalid, false, __ATOMIC_SEQ_CST);
	}

	bool isvalid() const
	{
		return __atomic_load_n(&m_isvalid, __ATOMIC_SEQ_CST);
	}

	void reset()
	{
		__atomic_store_n(&m_isvalid, false, __ATOMIC_SEQ_CST);
		m_value = T();
	}

	bool_variable& assign(const T &val)
	{
		m_value = val;
		return *this;
	}

	bool_variable& assign(T &&val)
	{
		m_value = std::forward<T>(val);
		return *this;
	}

	bool_variable& valid_assign(const T &val)
	{
		m_value = val;
		__atomic_store_n(&m_isvalid, true, __ATOMIC_SEQ_CST);
		return *this;
	}

	bool_variable& valid_assign(T &&val)
	{
		m_value = std::forward<T>(val);
		__atomic_store_n(&m_isvalid, true, __ATOMIC_SEQ_CST);
		return *this;
	}

	const T& refer() const
	{
		return m_value;
	}

	T& refer()
	{
		return m_value;
	}

	operator const T& () const
	{
		return m_value;
	}

private:
	bool  m_isvalid;
	T     m_value;
};

template
<
	class T,
	bool atomicbool = false,
	bool forbidcopy = false
>
using boolvar = bool_variable<T, atomicbool, forbidcopy>;


template
<
	class RS,
	bool atomicbool = false,
	bool forbidcopy = false
>
class bool_reason;

template <class RS, bool forbidcopy>
class bool_reason<RS, false, forbidcopy> : public traits::copyable_traits<!forbidcopy>::type
{
public:
	bool_reason(): m_value(false), m_reason()
	{}

	explicit bool_reason(bool bval): m_value(bval), m_reason()
	{}

	bool_reason(bool bval, const RS &reason): m_value(bval), m_reason(reason)
	{}

	bool_reason(bool bval, RS &&reason): m_value(bval), m_reason(std::forward<RS>(reason))
	{}

	void set(bool bval, const RS &reason)
	{
		m_value  = bval;
		m_reason = reason;
	}

	void set(bool bval, RS &&reason)
	{
		m_value  = bval;
		m_reason = std::forward<RS>(reason);
	}

	void set_false()
	{
		m_value = false;
	}

	void set_true()
	{
		m_value = true;
	}

	void set_reason(const RS &reason)
	{
		m_reason = reason;
	}

	void set_reason(RS &&reason)
	{
		m_reason = std::forward<RS>(reason);
	}

	bool is_true() const
	{
		return m_value;
	}

	const RS& reason() const
	{
		return m_reason;
	}

	RS& reason()
	{
		return m_reason;
	}

	void reset()
	{
		m_value = false;
		m_reason = RS();
	}

	operator bool () const
	{
		return m_value;
	}

private:
	bool  m_value;
	RS    m_reason;
};

template <class RS, bool forbidcopy>
class bool_reason<RS, true, forbidcopy> : public nocopyc
{
public:
	bool_reason(): m_reason()
	{
		__atomic_store_n(&m_value, false, __ATOMIC_SEQ_CST);
	}

	explicit bool_reason(bool bval): m_reason()
	{
		__atomic_store_n(&m_value, bval, __ATOMIC_SEQ_CST);
	}

	bool_reason(bool bval, const RS &reason): m_reason(reason)
	{
		__atomic_store_n(&m_value, bval, __ATOMIC_SEQ_CST);
	}

	bool_reason(bool bval, RS &&reason): m_reason(std::forward<RS>(reason))
	{
		__atomic_store_n(&m_value, bval, __ATOMIC_SEQ_CST);
	}

	void set(bool bval, const RS &reason)
	{
		m_reason = reason;
		__atomic_store_n(&m_value, bval, __ATOMIC_SEQ_CST);
	}

	void set(bool bval, RS &&reason)
	{
		m_reason = std::forward<RS>(reason);
		__atomic_store_n(&m_value, bval, __ATOMIC_SEQ_CST);
	}

	void set_false()
	{
		__atomic_store_n(&m_value, false, __ATOMIC_SEQ_CST);
	}

	void set_true()
	{
		__atomic_store_n(&m_value, true, __ATOMIC_SEQ_CST);
	}

	void set_reason(const RS &reason)
	{
		m_reason = reason;
	}

	void set_reason(RS &&reason)
	{
		m_reason = std::forward<RS>(reason);
	}

	bool is_true() const
	{
		return __atomic_load_n(&m_value, __ATOMIC_SEQ_CST);
	}

	const RS& reason() const
	{
		return m_reason;
	}

	RS& reason()
	{
		return m_reason;
	}

	void reset()
	{
		m_reason = RS();
		__atomic_store_n(&m_value, false, __ATOMIC_SEQ_CST);
	}

	operator bool () const
	{
		return __atomic_load_n(&m_value, __ATOMIC_SEQ_CST);
	}

private:
	bool  m_value;
	RS    m_reason;
};

template
<
	class RS,
	bool atomicbool = false,
	bool forbidcopy = false
>
using boolrs = bool_reason<RS, atomicbool, forbidcopy>;


template
<
	class T,
	bool atomicstatus = false,
	bool forbidcopy = false
>
class status_variable;

template <class T, bool forbidcopy>
class status_variable<T, false, forbidcopy> : public traits::copyable_traits<!forbidcopy>::type
{
public:
	status_variable(): m_status(0), m_value()
	{}

	status_variable(const T &val, short status): m_status(status), m_value(val)
	{}

	status_variable(T &&val, short status): m_status(status), m_value(std::forward<T>(val))
	{}

	void set_valid()
	{
		m_status = 1;
	}

	void unset()
	{
		m_status = 0;
	}

	void set_invalid()
	{
		m_status = 2;
	}

	bool isunset() const
	{
		return m_status == 0;
	}

	bool isvalid() const
	{
		return m_status == 1;
	}

	bool isinvalid() const
	{
		return m_status != 0 && m_status != 1;
	}

	void reset()
	{
		m_status = 0;
		m_value  = T();
	}

	status_variable& assign(const T &val)
	{
		m_value = val;
		return *this;
	}

	status_variable& assign(T &&val)
	{
		m_value = std::forward<T>(val);
		return *this;
	}

	status_variable& valid_assign(const T &val)
	{
		m_value  = val;
		m_status = 1;
		return *this;
	}

	status_variable& valid_assign(T &&val)
	{
		m_value  = std::forward<T>(val);
		m_status = 1;
		return *this;
	}

	const T& refer() const
	{
		return m_value;
	}

	T& refer()
	{
		return m_value;
	}

	operator const T& () const
	{
		return m_value;
	}

private:
	short  m_status;  //0: not assigned  1: valid assigned  else: invalid
	T      m_value;
};

template <class T, bool forbidcopy>
class status_variable<T, true, forbidcopy> : public nocopyc
{
public:
	status_variable(): m_value()
	{
		__atomic_store_n(&m_status, 0, __ATOMIC_SEQ_CST);
	}

	status_variable(const T &val, short status): m_value(val)
	{
		__atomic_store_n(&m_status, status, __ATOMIC_SEQ_CST);
	}

	status_variable(T &&val, short status): m_value(std::forward<T>(val))
	{
		__atomic_store_n(&m_status, status, __ATOMIC_SEQ_CST);
	}

	void set_valid()
	{
		__atomic_store_n(&m_status, 1, __ATOMIC_SEQ_CST);
	}

	void unset()
	{
		__atomic_store_n(&m_status, 0, __ATOMIC_SEQ_CST);
	}

	void set_invalid()
	{
		__atomic_store_n(&m_status, 2, __ATOMIC_SEQ_CST);
	}

	bool isunset() const
	{
		return __atomic_load_n(&m_status, __ATOMIC_SEQ_CST) == 0;
	}

	bool isvalid() const
	{
		return __atomic_load_n(&m_status, __ATOMIC_SEQ_CST) == 1;
	}

	bool isinvalid() const
	{
		short status = __atomic_load_n(&m_status, __ATOMIC_SEQ_CST);
		return status != 0 && status != 1;
	}

	void reset()
	{
		__atomic_store_n(&m_status, 0, __ATOMIC_SEQ_CST);
		m_value  = T();
	}

	status_variable& assign(const T &val)
	{
		m_value = val;
		return *this;
	}

	status_variable& assign(T &&val)
	{
		m_value = std::forward<T>(val);
		return *this;
	}

	status_variable& valid_assign(const T &val)
	{
		m_value  = val;
		__atomic_store_n(&m_status, 1, __ATOMIC_SEQ_CST);
		return *this;
	}

	status_variable& valid_assign(T &&val)
	{
		m_value  = std::forward<T>(val);
		__atomic_store_n(&m_status, 1, __ATOMIC_SEQ_CST);
		return *this;
	}

	const T& refer() const
	{
		return m_value;
	}

	T& refer()
	{
		return m_value;
	}

	operator const T& () const
	{
		return m_value;
	}

private:
	short  m_status;  //0: not assigned  1: valid assigned  else: invalid
	T      m_value;
};

template
<
	class T,
	bool atomicstatus = false,
	bool forbidcopy = false
>
using statvar = status_variable<T, atomicstatus, forbidcopy>;


template
<
	class T,
	class RS,
	bool atomicstatus = false,
	bool forbidcopy = false
>
class statusreason_variable;

template <class T, class RS, bool forbidcopy>
class statusreason_variable<T, RS, false, forbidcopy> : public traits::copyable_traits<!forbidcopy>::type
{
public:
	statusreason_variable(): m_status(0), m_value(), m_reason()
	{}

	statusreason_variable(const T &val, short status): m_status(status), m_value(val), m_reason()
	{}

	statusreason_variable(T &&val, short status): m_status(status), m_value(std::forward<T>(val)), m_reason()
	{}

	void set_valid()
	{
		m_status = 1;
	}

	void unset()
	{
		m_status = 0;
	}

	void set_invalid()
	{
		m_status = 2;
	}

	void set_invalid(const RS &reason)
	{
		m_status = 2;
		m_reason = reason;
	}

	void set_invalid(RS &&reason)
	{
		m_status = 2;
		m_reason = std::forward<RS>(reason);
	}

	void set_reason(const RS &reason)
	{
		m_reason = reason;
	}

	void set_reason(RS &&reason)
	{
		m_reason = std::forward<RS>(reason);
	}

	bool isunset() const
	{
		return m_status == 0;
	}

	bool isvalid() const
	{
		return m_status == 1;
	}

	bool isinvalid() const
	{
		return m_status != 0 && m_status != 1;
	}

	void reset()
	{
		m_status = 0;
		m_value  = T();
		m_reason = RS();
	}

	void reset_reason()
	{
		m_reason = RS();
	}

	statusreason_variable& assign(const T &val)
	{
		m_value = val;
		return *this;
	}

	statusreason_variable& assign(T &&val)
	{
		m_value = std::forward<T>(val);
		return *this;
	}

	statusreason_variable& valid_assign(const T &val)
	{
		m_value  = val;
		m_status = 1;
		return *this;
	}

	statusreason_variable& valid_assign(T &&val)
	{
		m_value  = std::forward<T>(val);
		m_status = 1;
		return *this;
	}

	const T& refer() const
	{
		return m_value;
	}

	T& refer()
	{
		return m_value;
	}

	const RS& reason() const
	{
		return m_reason;
	}

	RS& reason()
	{
		return m_reason;
	}

	operator const T& () const
	{
		return m_value;
	}

private:
	short  m_status;  //0: not assigned  1: valid assigned  else: invalid
	T      m_value;
	RS     m_reason;
};

template <class T, class RS, bool forbidcopy>
class statusreason_variable<T, RS, true, forbidcopy> : public nocopyc
{
public:
	statusreason_variable(): m_value(), m_reason()
	{
		__atomic_store_n(&m_status, 0, __ATOMIC_SEQ_CST);
	}

	statusreason_variable(const T &val, short status): m_value(val), m_reason()
	{
		__atomic_store_n(&m_status, status, __ATOMIC_SEQ_CST);
	}

	statusreason_variable(T &&val, short status): m_value(std::forward<T>(val)), m_reason()
	{
		__atomic_store_n(&m_status, status, __ATOMIC_SEQ_CST);
	}

	void set_valid()
	{
		__atomic_store_n(&m_status, 1, __ATOMIC_SEQ_CST);
	}

	void set_invalid(const RS &reason)
	{
		__atomic_store_n(&m_status, 2, __ATOMIC_SEQ_CST);
		m_reason = reason;
	}

	void set_invalid(RS &&reason)
	{
		__atomic_store_n(&m_status, 2, __ATOMIC_SEQ_CST);
		m_reason = std::forward<RS>(reason);
	}

	void set_reason(const RS &reason)
	{
		m_reason = reason;
	}

	void set_reason(RS &&reason)
	{
		m_reason = std::forward<RS>(reason);
	}

	void unset()
	{
		__atomic_store_n(&m_status, 0, __ATOMIC_SEQ_CST);
	}

	void set_invalid()
	{
		__atomic_store_n(&m_status, 2, __ATOMIC_SEQ_CST);
	}

	bool isunset() const
	{
		return __atomic_load_n(&m_status, __ATOMIC_SEQ_CST) == 0;
	}

	bool isvalid() const
	{
		return __atomic_load_n(&m_status, __ATOMIC_SEQ_CST) == 1;
	}

	bool isinvalid() const
	{
		short status = __atomic_load_n(&m_status, __ATOMIC_SEQ_CST);
		return status != 0 && status != 1;
	}

	void reset()
	{
		__atomic_store_n(&m_status, 0, __ATOMIC_SEQ_CST);
		m_value  = T();
		m_reason = RS();
	}

	void reset_reason()
	{
		m_reason = RS();
	}

	statusreason_variable& assign(const T &val)
	{
		m_value = val;
		return *this;
	}

	statusreason_variable& assign(T &&val)
	{
		m_value = std::forward<T>(val);
		return *this;
	}

	statusreason_variable& valid_assign(const T &val)
	{
		m_value  = val;
		__atomic_store_n(&m_status, 1, __ATOMIC_SEQ_CST);
		return *this;
	}

	statusreason_variable& valid_assign(T &&val)
	{
		m_value  = std::forward<T>(val);
		__atomic_store_n(&m_status, 1, __ATOMIC_SEQ_CST);
		return *this;
	}

	const T& refer() const
	{
		return m_value;
	}

	T& refer()
	{
		return m_value;
	}

	const RS& reason() const
	{
		return m_reason;
	}

	RS& reason()
	{
		return m_reason;
	}

	operator const T& () const
	{
		return m_value;
	}

private:
	short  m_status;  //0: not assigned  1: valid assigned  else: invalid
	T      m_value;
	RS     m_reason;
};

template
<
	class T,
	class RS,
	bool atomicstatus = false,
	bool forbidcopy = false
>
using statrs_var = statusreason_variable<T, RS, atomicstatus, forbidcopy>;


template <class T, T init_value, bool is_atomic = false>
class intflag;

template <class T, T init_value>
class intflag<T, init_value, false>
{
public:
	intflag(): m_flag(init_value)
	{}

	intflag& operator = (T val)
	{
		m_flag = val;
		return *this;
	}

	intflag& assign(T val)
	{
		m_flag = val;
		return *this;
	}

	void reset()
	{
		m_flag = init_value;
	}

	operator T () const
	{
		return m_flag;
	}

	T refer() const
	{
		return m_flag;
	}

	bool operator == (T val) const
	{
		return m_flag == val;
	}

	intflag& operator |= (T val)
	{
		static_assert(!std::is_enum<T>::value && !std::is_same<T, bool>::value, "only int can be operated on with logical operator");

		m_flag |= val;
		return *this;
	}

	intflag& operator &= (T val)
	{
		static_assert(!std::is_enum<T>::value && !std::is_same<T, bool>::value, "only int can be operated on with logical operator");

		m_flag &= val;
		return *this;
	}

	bool compare_exchange(T expected, T desired)
	{
		if (m_flag != expected)
			return false;

		m_flag = desired;
		return true;
	}

private:
	T  m_flag;
};

template <class T, T init_value>
class intflag<T, init_value, true> : public nocopyc
{
public:
	intflag()
	{
		__atomic_store_n(&m_flag, init_value, __ATOMIC_SEQ_CST);
	}

	intflag& operator = (T val)
	{
		__atomic_store_n(&m_flag, val, __ATOMIC_SEQ_CST);
		return *this;
	}

	intflag& assign(T val)
	{
		__atomic_store_n(&m_flag, val, __ATOMIC_SEQ_CST);
		return *this;
	}

	void reset()
	{
		__atomic_store_n(&m_flag, init_value, __ATOMIC_SEQ_CST);
	}

	operator T () const
	{
		return __atomic_load_n(&m_flag, __ATOMIC_SEQ_CST);
	}

	T refer() const
	{
		return __atomic_load_n(&m_flag, __ATOMIC_SEQ_CST);
	}

	bool operator == (T val) const
	{
		return __atomic_load_n(&m_flag, __ATOMIC_SEQ_CST) == val;
	}

	intflag& operator |= (T val)
	{
		static_assert(!std::is_enum<T>::value && !std::is_same<T, bool>::value, "only int can be operated on with logical operator");

		__atomic_or_fetch(&m_flag, val, __ATOMIC_SEQ_CST);
		return *this;
	}

	intflag& operator &= (T val)
	{
		static_assert(!std::is_enum<T>::value && !std::is_same<T, bool>::value, "only int can be operated on with logical operator");

		__atomic_and_fetch(&m_flag, val, __ATOMIC_SEQ_CST);
		return *this;
	}

	bool atomic_compare_exchange(T expected, T desired, bool weak = false)
	{
		T expect = expected;
		return __atomic_compare_exchange_n(&m_flag, &expect, desired, weak, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST);
	}

private:
	T  m_flag;
};

template <bool init_value, bool is_atomic = false>
using boolflag = intflag<bool, init_value, is_atomic>;

template <class T, T init_value, bool is_atomic = false>
using enumflag = intflag<T, init_value, is_atomic>;


template <class T, T init_value, class Val, bool attr_atomic = false, bool forbidcopy = false>
class attribute_variable;

template <class T, T init_value, class Val, bool forbidcopy>
class attribute_variable<T, init_value, Val, false, forbidcopy> : public traits::copyable_traits<!forbidcopy>::type
{
public:
	attribute_variable(): m_attr(init_value), m_value()
	{}

	attribute_variable(T attr, const Val &value): m_attr(attr), m_value(value)
	{}

	attribute_variable(T attr, Val &&value): m_attr(attr), m_value(std::forward<Val>(value))
	{}

	void set(T attr, const Val &value)
	{
		m_value = value;
		m_attr  = attr;
	}

	void set(T attr, Val &&value)
	{
		m_value = std::forward<Val>(value);
		m_attr  = attr;
	}

	void set_attr(T attr)
	{
		m_attr = attr;
	}

	void set_value(const Val &value)
	{
		m_value = value;
	}

	void set_value(Val &&value)
	{
		m_value = std::forward<Val>(value);
	}

	void reset()
	{
		m_value = Val();
		m_attr  = init_value;
	}

	T attr() const
	{
		return m_attr;
	}

	T& attr()
	{
		return m_attr;
	}

	const Val& value() const
	{
		return m_value;
	}

	Val& value()
	{
		return m_value;
	}

private:
	T    m_attr;
	Val  m_value;
};

template <class T, T init_value, class Val, bool forbidcopy>
class attribute_variable<T, init_value, Val, true, forbidcopy> : public traits::copyable_traits<!forbidcopy>::type
{
public:
	attribute_variable(): m_value()
	{
		__atomic_store_n(&m_attr, init_value, __ATOMIC_SEQ_CST);
	}

	attribute_variable(T attr, const Val &value): m_value(value)
	{
		__atomic_store_n(&m_attr, attr, __ATOMIC_SEQ_CST);
	}

	attribute_variable(T attr, Val &&value): m_value(std::forward<Val>(value))
	{
		__atomic_store_n(&m_attr, attr, __ATOMIC_SEQ_CST);
	}

	void set(T attr, const Val &value)
	{
		m_value = value;
		__atomic_store_n(&m_attr, attr, __ATOMIC_SEQ_CST);
	}

	void set(T attr, Val &&value)
	{
		m_value = std::forward<Val>(value);
		__atomic_store_n(&m_attr, attr, __ATOMIC_SEQ_CST);
	}

	void set_attr(T attr)
	{
		__atomic_store_n(&m_attr, attr, __ATOMIC_SEQ_CST);
	}

	void set_value(const Val &value)
	{
		m_value = value;
	}

	void set_value(Val &&value)
	{
		m_value = std::forward<Val>(value);
	}

	void reset()
	{
		m_value = Val();
		__atomic_store_n(&m_attr, init_value, __ATOMIC_SEQ_CST);
	}

	T attr() const
	{
		return __atomic_load_n(&m_attr, __ATOMIC_SEQ_CST);
	}

	const Val& value() const
	{
		return m_value;
	}

	Val& value()
	{
		return m_value;
	}

private:
	T    m_attr;
	Val  m_value;
};

template <class T, T init_value, class Val, bool attr_atomic = false, bool forbidcopy = false>
using attr_val = attribute_variable<T, init_value, Val, attr_atomic, forbidcopy>;


template <class T, T init_value, class Desc, bool code_atomic = false, bool forbidcopy = false>
class code_description;

template <class T, T init_value, class Desc, bool forbidcopy>
class code_description<T, init_value, Desc, false, forbidcopy> : public traits::copyable_traits<!forbidcopy>::type
{
public:
	code_description(): m_code(init_value), m_desc()
	{}

	code_description(T code, const Desc &desc): m_code(code), m_desc(desc)
	{}

	code_description(T code, Desc &&desc): m_code(code), m_desc(std::forward<Desc>(desc))
	{}

	void set(T code, const Desc &desc)
	{
		m_code = code;
		m_desc = desc;
	}

	void set(T code, Desc &&desc)
	{
		m_code = code;
		m_desc = std::forward<Desc>(desc);
	}

	void set_code(T code)
	{
		m_code = code;
	}

	void set_desc(const Desc &desc)
	{
		m_desc = desc;
	}

	void set_desc(Desc &&desc)
	{
		m_desc = std::forward<Desc>(desc);
	}

	void reset()
	{
		m_code = init_value;
		m_desc = Desc();
	}

	T code() const
	{
		return m_code;
	}

	T& code()
	{
		return m_code;
	}

	const Desc& desc() const
	{
		return m_desc;
	}

	Desc& desc()
	{
		return m_desc;
	}

private:
	T     m_code;
	Desc  m_desc;
};

template <class T, T init_value, class Desc, bool forbidcopy>
class code_description<T, init_value, Desc, true, forbidcopy> : public nocopyc
{
public:
	code_description(): m_desc()
	{
		__atomic_store_n(&m_code, init_value, __ATOMIC_SEQ_CST);
	}

	code_description(T code, const Desc &desc): m_desc(desc)
	{
		__atomic_store_n(&m_code, code, __ATOMIC_SEQ_CST);
	}

	code_description(T code, Desc &&desc): m_desc(std::forward<Desc>(desc))
	{
		__atomic_store_n(&m_code, code, __ATOMIC_SEQ_CST);
	}

	void set(T code, const Desc &desc)
	{
		__atomic_store_n(&m_code, code, __ATOMIC_SEQ_CST);
		m_desc = desc;
	}

	void set(T code, Desc &&desc)
	{
		__atomic_store_n(&m_code, code, __ATOMIC_SEQ_CST);
		m_desc = std::forward<Desc>(desc);
	}

	void set_code(T code)
	{
		__atomic_store_n(&m_code, code, __ATOMIC_SEQ_CST);
	}

	void set_desc(const Desc &desc)
	{
		m_desc = desc;
	}

	void set_desc(Desc &&desc)
	{
		m_desc = std::forward<Desc>(desc);
	}

	void reset()
	{
		__atomic_store_n(&m_code, init_value, __ATOMIC_SEQ_CST);
		m_desc = Desc();
	}

	T code() const
	{
		return __atomic_load_n(&m_code, __ATOMIC_SEQ_CST);
	}

	const Desc& desc() const
	{
		return m_desc;
	}

	Desc& desc()
	{
		return m_desc;
	}

private:
	T     m_code;
	Desc  m_desc;
};

template <class T, T init_value, class Desc, bool code_atomic = false, bool forbidcopy = false>
using code_desc = code_description<T, init_value, Desc, code_atomic, forbidcopy>;


}


#endif


