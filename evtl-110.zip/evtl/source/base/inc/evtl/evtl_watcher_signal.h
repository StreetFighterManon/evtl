

#ifndef __EVTL_WATCHER_SIGNAL_H__
#define __EVTL_WATCHER_SIGNAL_H__

#include <assert.h>

#include <utility>
#include <functional>

#include <ev/ev++.h>

#include "evtl_gcc.h"
#include "evtl_copyable.h"
#include "evtl_eventloop.h"


namespace evtl
{


template <class T>
class watcher_signal : public nocopyc
{
public:
	typedef std::function<void (T &watcher, int revents)>   signal_callback_t;

	watcher_signal()
	{
		m_signal.set(nullptr);
		m_signal.set(0);
		m_signal.set<watcher_signal, &watcher_signal::_callback>(this);
	}

	void set(looprefer loop)
	{
		if (m_signal.is_active())
			m_signal.stop();

		m_signal.set(loop.ref());
	}

	void set(looprefer loop, int signum)
	{
		if (m_signal.is_active())
			m_signal.stop();

		m_signal.set(loop.ref());
		m_signal.set(signum);
	}

	void set_callback()
	{
		if (m_signal.is_active())
			m_signal.stop();

		m_signal.set<watcher_signal, &watcher_signal::_callback>(this);
		m_signal_callback = nullptr;
	}

	void set_callback(signal_callback_t cb)
	{
		if (m_signal.is_active())
			m_signal.stop();

		m_signal.set<watcher_signal, &watcher_signal::_callback>(this);
		m_signal_callback = std::move(cb);
	}

	void setsig(int signum)
	{
		if (m_signal.is_active())
			m_signal.stop();

		m_signal.set(signum);
	}

	void set_priority(int priority)
	{
		if (m_signal.is_active())
			m_signal.stop();

		ev_set_priority(static_cast<ev_signal *>(&m_signal), priority);
	}

	int get_priority() const
	{
		return ev_priority(static_cast<ev_signal *>(&m_signal));
	}

	void stop()
	{
		m_signal.stop();
	}

	void start()
	{
		m_signal.start();
	}

	bool is_active() const
	{
		return m_signal.is_active();
	}

	bool is_pending() const
	{
		return m_signal.is_pending();
	}

	int clear_pending()
	{
		if (m_signal.EV_A == nullptr)
			assert(false && "null loop");

		return ::ev_clear_pending(m_signal.EV_A, static_cast<ev_signal *>(&m_signal));
	}

	looprefer get_loop() const
	{
		return m_signal.EV_A;
	}

private:
	void signal_callback(T &watcher, int revents) { assert(false && "unset callback"); }

	void _callback(ev::sig &watcher, int revents)
	{
		if (evunlike((revents & ev::ERROR) != 0))
			assert(false && "ev_error");
		if (evunlike(&watcher != &m_signal))
			assert(false && "unexpected watcher");

		if (m_signal_callback)
			m_signal_callback(*static_cast<T*>(this), revents);
		else
			static_cast<T*>(this)->signal_callback(*static_cast<T*>(this), revents);
	}

private:
	ev::sig            m_signal;
	signal_callback_t  m_signal_callback;
};

class simpwsignal : public watcher_signal<simpwsignal>
{};


}


#endif


