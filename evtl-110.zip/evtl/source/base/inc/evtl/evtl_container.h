

#ifndef __EVTL_CONTAINER_H__
#define __EVTL_CONTAINER_H__

#include <sys/types.h>

#include <deque>
#include <list>
#include <vector>
#include <set>
#include <unordered_set>
#include <utility>


namespace evtl
{


template <class T>
class listc
{
public:
	listc()
	{}

	void pushback(const T &elem)
	{
		m_elems.push_back(elem);
	}

	void pushback(T &&elem)
	{
		m_elems.push_back(std::move(elem));
	}

	void pushback(const std::list<T> &elems)
	{
		if (elems.empty())
			return;

		m_elems.insert(m_elems.end(), elems.begin(), elems.end());
	}

	void pushfront(const T &elem)
	{
		m_elems.push_front(elem);
	}

	void pushfront(T &&elem)
	{
		m_elems.push_front(std::move(elem));
	}

	void pushfront(const std::list<T> &elems)
	{
		if (elems.empty())
			return;

		m_elems.insert(m_elems.begin(), elems.begin(), elems.end());
	}

	bool popback(T &elem)
	{
		if (!m_elems.empty())
		{
			elem = m_elems.back();
			m_elems.pop_back();
			return true;
		}
		return false;
	}

	ssize_t popback(std::list<T> &elems, ssize_t count /* <= 0 pop all */)
	{
		if (m_elems.empty())
			return 0;

		ssize_t popn = 0;

		typename std::list<T>::const_iterator iter;
		if (count <= 0)
		{
			iter = m_elems.begin();
			popn = (ssize_t)m_elems.size();
		}
		else
		{
			iter = m_elems.end();
			while (iter != m_elems.begin())
			{
				if (count-- > 0)
				{
					--iter;
					++popn;
				}
				else
					break;
			}
		}

		elems.splice(elems.end(), m_elems, iter, m_elems.end());
		return popn;
	}

	bool popfront(T &elem)
	{
		if (!m_elems.empty())
		{
			elem = m_elems.front();
			m_elems.pop_front();
			return true;
		}
		return false;
	}

	ssize_t popfront(std::list<T> &elems, ssize_t count /* <= 0 pop all */)
	{
		if (m_elems.empty())
			return 0;

		ssize_t popn = 0;

		typename std::list<T>::const_iterator iter;
		if (count <= 0)
		{
			iter = m_elems.end();
			popn = (ssize_t)m_elems.size();
		}
		else
		{
			iter = m_elems.begin();
			while (iter != m_elems.end())
			{
				if (count-- > 0)
				{
					++iter;
					++popn;
				}
				else
					break;
			}
		}

		elems.splice(elems.end(), m_elems, m_elems.begin(), iter);
		return popn;
	}

	ssize_t size() const
	{
		return (ssize_t)m_elems.size();
	}

	bool empty() const
	{
		return m_elems.empty();
	}

	void clear()
	{
		m_elems.clear();
	}

private:
	std::list<T>  m_elems;
};


template <class T>
class dequec
{
public:
	dequec()
	{}

	void pushback(const T &elem)
	{
		m_elems.push_back(elem);
	}

	void pushback(T &&elem)
	{
		m_elems.push_back(std::move(elem));
	}

	void pushback(const std::vector<T> &elems)
	{
		if (elems.empty())
			return;

		m_elems.insert(m_elems.end(), elems.begin(), elems.end());
	}

	void pushfront(const T &elem)
	{
		m_elems.push_front(elem);
	}

	void pushfront(T &&elem)
	{
		m_elems.push_front(std::move(elem));
	}

	void pushfront(const std::vector<T> &elems)
	{
		if (elems.empty())
			return;

		m_elems.insert(m_elems.begin(), elems.begin(), elems.end());
	}

	bool popback(T &elem)
	{
		if (!m_elems.empty())
		{
			elem = m_elems.back();
			m_elems.pop_back();
			return true;
		}
		return false;
	}

	ssize_t popback(std::vector<T> &elems, ssize_t count = 0 /* <= 0 pop all */)
	{
		if (m_elems.empty())
			return 0;

		ssize_t popn = count;

		if (popn <= 0 || popn > (ssize_t)m_elems.size())
			popn = m_elems.size();

		elems.insert(elems.begin(), m_elems.end() - popn, m_elems.end());
		m_elems.erase(m_elems.end() - popn, m_elems.end());

		return popn;
	}

	bool popfront(T &elem)
	{
		if (!m_elems.empty())
		{
			elem = m_elems.front();
			m_elems.pop_front();
			return true;
		}
		return false;
	}

	ssize_t popfront(std::vector<T> &elems, ssize_t count = 0 /* <= 0 pop all */)
	{
		if (m_elems.empty())
			return 0;

		ssize_t popn = count;

		if (popn <= 0 || popn > (ssize_t)m_elems.size())
			popn = m_elems.size();

		elems.insert(elems.begin(), m_elems.begin(), m_elems.begin() + popn);
		m_elems.erase(m_elems.begin(), m_elems.begin() + popn);

		return popn;
	}

	ssize_t size() const
	{
		return (ssize_t)m_elems.size();
	}

	bool empty() const
	{
		return m_elems.empty();
	}

	T& operator [] (ssize_t index)
	{
		return m_elems[index];
	}

	const T& operator [] (ssize_t index) const
	{
		return m_elems[index];
	}

	void clear()
	{
		m_elems.clear();
	}

private:
	std::deque<T> m_elems;
};


template <class T>
class setc
{
public:
	setc()
	{}

	bool push(const T &elem)
	{
		std::pair<typename std::set<T>::const_iterator, bool> pr = m_elems.insert(elem);
		return pr.second;
	}

	bool push(T &&elem)
	{
		std::pair<typename std::set<T>::const_iterator, bool> pr = m_elems.insert(std::move(elem));
		return pr.second;
	}

	bool pop(T &elem)
	{
		typename std::set<T>::const_iterator iter = m_elems.begin();
		if (iter != m_elems.end())
		{
			elem = *iter;
			m_elems.erase(iter);
			return true;
		}
		return false;
	}

	bool find(const T &elem) const
	{
		if (m_elems.find(elem) == m_elems.end())
			return false;
		return true;
	}

	bool erase(const T &elem)
	{
		return m_elems.erase(elem) > 0;
	}

	ssize_t size() const
	{
		return m_elems.size();
	}

	bool empty() const
	{
		return m_elems.empty();
	}

	void clear()
	{
		m_elems.clear();
	}

private:
	std::set<T> m_elems;
};


template <class T>
class unordered_setc
{
public:
	unordered_setc()
	{}

	bool push(const T &elem)
	{
		std::pair<typename std::unordered_set<T>::const_iterator, bool> pr = m_elems.insert(elem);
		return pr.second;
	}

	bool push(T &&elem)
	{
		std::pair<typename std::unordered_set<T>::const_iterator, bool> pr = m_elems.insert(std::move(elem));
		return pr.second;
	}

	bool pop(T &elem)
	{
		typename std::unordered_set<T>::const_iterator iter = m_elems.begin();
		if (iter != m_elems.end())
		{
			elem = *iter;
			m_elems.erase(iter);
			return true;
		}
		return false;
	}

	bool find(const T &elem) const
	{
		if (m_elems.find(elem) == m_elems.end())
			return false;
		return true;
	}

	bool erase(const T &elem)
	{
		return m_elems.erase(elem) > 0;
	}

	ssize_t size() const
	{
		return m_elems.size();
	}

	bool empty() const
	{
		return m_elems.empty();
	}

	void clear()
	{
		m_elems.clear();
	}

private:
	std::unordered_set<T> m_elems;
};


}


#endif


