

#ifndef __EVTL_DGRAMSOCK_H__
#define __EVTL_DGRAMSOCK_H__

#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <errno.h>
#include <assert.h>

#include <cstring>
#include <string>
#include <utility>
#include <functional>

#include <ev/ev++.h>

#include "evtl_gcc.h"
#include "evtl_copyable.h"
#include "evtl_error.h"
#include "evtl_eventloop.h"
#include "evtl_in.h"
#include "evtl_inet.h"


namespace evtl
{


template <class T>
class dgramsock : public evtl_error, public nocopyc
{
public:
	typedef std::function<void (T &watcher, int fd)>  socket_callback_t;
	typedef std::function<void (T &watcher, int revents)>  io_callback_t;

	enum error_code
	{
		success,
		socket_failed,
		invalid_fd,
		invalid_host,
		bind_error,
		reuseaddr_failed,
		connect_failed,
		disconnect_failed,
		setsockopt_failed
	};

	dgramsock()
	{
		m_io.set(nullptr);
		m_io.set(-1, 0);
		m_io.set<dgramsock, &dgramsock::_callback>(this);
	}

	void set(looprefer loop)
	{
		if (m_io.is_active())
			m_io.stop();

		m_io.set(loop.ref());
	}

	bool set(int fd, int events)
	{
		if (m_io.is_active())
			m_io.stop();

		events &= (ev::READ | ev::WRITE);
		m_io.set(fd, events);
		return true;
	}

	void set_events(int events)
	{
		if (m_io.is_active())
			m_io.stop();

		events &= (ev::READ | ev::WRITE);
		m_io.set(events);
	}

	bool set_fd(int fd)
	{
		if (m_io.is_active())
			m_io.stop();

		m_io.fd = fd;
		return true;
	}

	void set_socketcallback()
	{
		m_sockcallback = nullptr;
	}

	void set_socketcallback(socket_callback_t cb)
	{
		m_sockcallback = std::move(cb);
	}

	bool udpsocket(int family = AF_INET, bool nonblock = true, bool reuseaddr = false)
	{
		if (evunlike(family != AF_INET && family != AF_INET6))
			assert(false && "invalid family");

		int fd = -1;

		if (nonblock)
			fd = ::socket(family, SOCK_DGRAM | SOCK_NONBLOCK, 0);
		else
			fd = ::socket(family, SOCK_DGRAM, 0);

		if (fd < 0)
		{
			set_error(socket_failed, errno);
			return false;
		}

		/* reuse addr is only recommended for multicast and broadcast socket */
		if (reuseaddr)
		{
			int flag = 1;
			if (::setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &flag, sizeof(flag)) != 0)
			{
				set_error(reuseaddr_failed, errno);
				::close(fd);
				return false;
			}
		}

		if (m_sockcallback)
			m_sockcallback(*static_cast<T*>(this), fd);
		else
			static_cast<T*>(this)->socket_callback(*static_cast<T*>(this), fd);

		if (m_io.is_active())
			m_io.stop();

		m_io.fd = fd;
		return true;
	}

	bool unixsocket(bool nonblock = true)
	{
		int fd = -1;

		if (nonblock)
			fd = ::socket(AF_LOCAL, SOCK_DGRAM | SOCK_NONBLOCK, 0);
		else
			fd = ::socket(AF_LOCAL, SOCK_DGRAM, 0);

		if (fd < 0)
		{
			set_error(socket_failed, errno);
			return false;
		}

		if (m_sockcallback)
			m_sockcallback(*static_cast<T*>(this), fd);
		else
			static_cast<T*>(this)->socket_callback(*static_cast<T*>(this), fd);

		if (m_io.is_active())
			m_io.stop();

		m_io.fd = fd;
		return true;
	}

	bool bind(const address &addr)
	{
		static_assert(sizeof(struct sockaddr_un) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_un");

		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		std::pair<bool, struct sockaddr_storage> inaddr = inetc::inaddr_pton(addr);
		if (!inaddr.first)
		{
			set_error(invalid_host, addr.host.type, addr.host.str());
			return false;
		}

		socklen_t addrlen = 0;

		if (inaddr.second.ss_family == AF_INET || inaddr.second.ss_family == AF_INET6)
			addrlen = sizeof(struct sockaddr_storage);
		else if (inaddr.second.ss_family == AF_LOCAL)
			addrlen = sizeof(struct sockaddr_un);
		else
			assert(false && "invalid family");

		int rt = ::bind(m_io.fd, (const struct sockaddr *)&inaddr.second, addrlen);
		if (rt != 0)
		{
			set_error(bind_error, errno);
			return false;
		}

		return true;
	}

	bool connect(const address &addr)
	{
		static_assert(sizeof(struct sockaddr_un) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_un");

		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		std::pair<bool, struct sockaddr_storage> inaddr = inetc::inaddr_pton(addr);
		if (!inaddr.first)
		{
			set_error(invalid_host, addr.host.type, addr.host.str());
			return false;
		}

		socklen_t addrlen = 0;

		if (inaddr.second.ss_family == AF_INET || inaddr.second.ss_family == AF_INET6)
			addrlen = sizeof(struct sockaddr_storage);
		else if (inaddr.second.ss_family == AF_LOCAL)
			addrlen = sizeof(struct sockaddr_un);
		else
			assert(false && "invalid family");

		int rt = ::connect(m_io.fd, (const struct sockaddr *)&inaddr.second, addrlen);
		if (rt != 0)
		{
			set_error(connect_failed, errno);
			return false;
		}

		return true;
	}

	bool disconnect()
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, -1);
			return false;
		}

		struct sockaddr_storage addr;
		memset(&addr, 0, sizeof(addr));
		addr.ss_family = AF_UNSPEC;

		int rt = ::connect(m_io.fd, (const struct sockaddr *)&addr, sizeof(addr));
		if (rt != 0)
		{
			set_error(disconnect_failed, errno);
			return false;
		}

		return true;
	}

	void set_callback()
	{
		if (m_io.is_active())
			m_io.stop();

		m_io.set<dgramsock, &dgramsock::_callback>(this);
		m_iocallback = nullptr;
	}

	void set_callback(io_callback_t cb)
	{
		if (m_io.is_active())
			m_io.stop();

		m_io.set<dgramsock, &dgramsock::_callback>(this);
		m_iocallback = std::move(cb);
	}

	bool start()
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, -1);
			return false;
		}

		m_io.start();
		return true;
	}

	void stop()
	{
		m_io.stop();
	}

	bool is_active() const
	{
		return m_io.is_active();
	}

	bool is_pending() const
	{
		return m_io.is_pending();
	}

	int clear_pending()
	{
		if (m_io.EV_A == nullptr)
			assert(false && "null loop");

		return ::ev_clear_pending(m_io.EV_A, static_cast<ev_io *>(&m_io));
	}

	looprefer get_loop() const
	{
		return m_io.EV_A;
	}

	int get_fd() const
	{
		return m_io.fd;
	}

	int get_events() const
	{
		return (m_io.events & (ev::READ | ev::WRITE));
	}

	bool enable_broadcast(bool enable)
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		int val = enable ? 1 : 0;
		int rt = ::setsockopt(m_io.fd, SOL_SOCKET, SO_BROADCAST, &val, sizeof(val));
		if (rt != 0)
		{
			set_error(setsockopt_failed, errno);
			return false;
		}

		return true;
	}

	bool set_multicast_interface(const std::string &if_ip)
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		std::pair<bool, struct in_addr> addr = inetc::inet_pton4(if_ip);
		if (!addr.first)
		{
			set_error(invalid_host, if_ip);
			return false;
		}

		int rt = ::setsockopt(m_io.fd, IPPROTO_IP, IP_MULTICAST_IF, &addr.second, sizeof(addr.second));
		if (rt != 0)
		{
			set_error(setsockopt_failed, errno);
			return false;
		}

		return true;
	}

	bool set_multicast_interface_ipv6(int if_index)
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		int rt = ::setsockopt(m_io.fd, IPPROTO_IPV6, IPV6_MULTICAST_IF, &if_index, sizeof(if_index));
		if (rt != 0)
		{
			set_error(setsockopt_failed, errno);
			return false;
		}

		return true;
	}

	bool set_multicast_ttl(unsigned int ttl)
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		unsigned char cttl = (unsigned char)ttl;

		int rt = ::setsockopt(m_io.fd, IPPROTO_IP, IP_MULTICAST_TTL, &cttl, sizeof(cttl));
		if (rt != 0)
		{
			set_error(setsockopt_failed, errno);
			return false;
		}

		return true;
	}

	bool set_multicast_hops_ipv6(unsigned int hops)
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		unsigned char chops = (unsigned char)hops;

		int rt = ::setsockopt(m_io.fd, IPPROTO_IPV6, IPV6_MULTICAST_HOPS, &chops, sizeof(chops));
		if (rt != 0)
		{
			set_error(setsockopt_failed, errno);
			return false;
		}

		return true;
	}

	bool set_multicast_loop(bool enable)
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		unsigned char val = enable ? 1 : 0;

		int rt = ::setsockopt(m_io.fd, IPPROTO_IP, IP_MULTICAST_LOOP, &val, sizeof(val));
		if (rt != 0)
		{
			set_error(setsockopt_failed, errno);
			return false;
		}

		return true;
	}

	bool set_multicast_loop_ipv6(bool enable)
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		unsigned char val = enable ? 1 : 0;

		int rt = ::setsockopt(m_io.fd, IPPROTO_IPV6, IPV6_MULTICAST_LOOP, &val, sizeof(val));
		if (rt != 0)
		{
			set_error(setsockopt_failed, errno);
			return false;
		}

		return true;
	}

	bool add_membership(const std::string &multi_ip, const std::string &if_ip)
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		std::pair<bool, struct in_addr> multi_addr = inetc::inet_pton4(multi_ip);
		if (!multi_addr.first)
		{
			set_error(invalid_host, 1, multi_ip);
			return false;
		}

		std::pair<bool, struct in_addr> if_addr = inetc::inet_pton4(if_ip);
		if (!if_addr.first)
		{
			set_error(invalid_host, 2, if_ip);
			return false;
		}

		struct ip_mreq mreq;
		memset(&mreq, 0, sizeof(mreq));
		mreq.imr_multiaddr = multi_addr.second;  /* ipv4 class D multicast addr */
		mreq.imr_interface = if_addr.second;     /* ipv4 addr of local interface */

		int rt = ::setsockopt(m_io.fd, IPPROTO_IP, IP_ADD_MEMBERSHIP, &mreq, sizeof(mreq));
		if (rt != 0)
		{
			set_error(setsockopt_failed, errno);
			return false;
		}

		return true;
	}

	bool join_group_ipv6(const std::string &multi_ip, unsigned int if_index)
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		std::pair<bool, struct in6_addr> multi_addr = inetc::inet_pton6(multi_ip);
		if (!multi_addr.first)
		{
			set_error(invalid_host, multi_ip);
			return false;
		}

		struct ipv6_mreq mreq;
		memset(&mreq, 0, sizeof(mreq));
		mreq.ipv6mr_multiaddr = multi_addr.second;  /* ipv6 multicast addr */
		mreq.ipv6mr_interface = if_index;           /* interface index, or 0 */

		int rt = ::setsockopt(m_io.fd, IPPROTO_IPV6, IPV6_JOIN_GROUP, &mreq, sizeof(mreq));
		if (rt != 0)
		{
			set_error(setsockopt_failed, errno);
			return false;
		}

		return true;
	}

	bool drop_membership(const std::string &multi_ip, const std::string &if_ip)
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		std::pair<bool, struct in_addr> multi_addr = inetc::inet_pton4(multi_ip);
		if (!multi_addr.first)
		{
			set_error(invalid_host, 1, multi_ip);
			return false;
		}

		std::pair<bool, struct in_addr> if_addr = inetc::inet_pton4(if_ip);
		if (!if_addr.first)
		{
			set_error(invalid_host, 2, if_ip);
			return false;
		}

		struct ip_mreq mreq;
		memset(&mreq, 0, sizeof(mreq));
		mreq.imr_multiaddr = multi_addr.second;  /* ipv4 class D multicast addr */
		mreq.imr_interface = if_addr.second;     /* ipv4 addr of local interface */

		int rt = ::setsockopt(m_io.fd, IPPROTO_IP, IP_DROP_MEMBERSHIP, &mreq, sizeof(mreq));
		if (rt != 0)
		{
			set_error(setsockopt_failed, errno);
			return false;
		}

		return true;
	}

	bool leave_group_ipv6(const std::string &multi_ip, unsigned int if_index)
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		std::pair<bool, struct in6_addr> multi_addr = inetc::inet_pton6(multi_ip);
		if (!multi_addr.first)
		{
			set_error(invalid_host, multi_ip);
			return false;
		}

		struct ipv6_mreq mreq;
		memset(&mreq, 0, sizeof(mreq));
		mreq.ipv6mr_multiaddr = multi_addr.second;  /* ipv6 multicast addr */
		mreq.ipv6mr_interface = if_index;           /* interface index, or 0 */

		int rt = ::setsockopt(m_io.fd, IPPROTO_IPV6, IPV6_LEAVE_GROUP, &mreq, sizeof(mreq));
		if (rt != 0)
		{
			set_error(setsockopt_failed, errno);
			return false;
		}

		return true;
	}

	bool add_source_membership(const std::string &multi_ip, const std::string &if_ip, const std::string &multi_source_ip)
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		std::pair<bool, struct in_addr> multi_addr = inetc::inet_pton4(multi_ip);
		if (!multi_addr.first)
		{
			set_error(invalid_host, 1, multi_ip);
			return false;
		}

		std::pair<bool, struct in_addr> if_addr = inetc::inet_pton4(if_ip);
		if (!if_addr.first)
		{
			set_error(invalid_host, 2, if_ip);
			return false;
		}

		std::pair<bool, struct in_addr> src_addr = inetc::inet_pton4(multi_source_ip);
		if (!src_addr.first)
		{
			set_error(invalid_host, 3, multi_source_ip);
			return false;
		}

		struct ip_mreq_source mreq;
		memset(&mreq, 0, sizeof(mreq));
		mreq.imr_multiaddr  = multi_addr.second;  /* ipv4 class D multicast addr */
		mreq.imr_sourceaddr = src_addr.second;    /* ipv4 source addr */
		mreq.imr_interface  = if_addr.second;     /* ipv4 addr of local interface */

		int rt = ::setsockopt(m_io.fd, IPPROTO_IP, IP_ADD_SOURCE_MEMBERSHIP, &mreq, sizeof(mreq));
		if (rt != 0)
		{
			set_error(setsockopt_failed, errno);
			return false;
		}

		return true;
	}

	bool join_source_group_ipv6(const hostaddress &multi_ipaddr, unsigned int if_index, const hostaddress &multi_source_ipaddr)
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		if (!multi_ipaddr.isip())
		{
			set_error(invalid_host, 1, multi_ipaddr.str());
			return false;
		}

		if (!multi_source_ipaddr.isip())
		{
			set_error(invalid_host, 2, multi_source_ipaddr.str());
			return false;
		}

		std::pair<bool, struct sockaddr_in6> multi_addr = inetc::inaddr_pton6(multi_ipaddr, 0);
		if (!multi_addr.first)
		{
			set_error(invalid_host, 3, multi_ipaddr.str());
			return false;
		}

		if (evunlike(multi_addr.second.sin6_family != AF_INET6))
			assert(false && "invalid family");

		std::pair<bool, struct sockaddr_in6> src_addr = inetc::inaddr_pton6(multi_source_ipaddr, 0);
		if (!src_addr.first)
		{
			set_error(invalid_host, 4, multi_source_ipaddr.str());
			return false;
		}

		if (evunlike(src_addr.second.sin6_family != AF_INET6))
			assert(false && "invalid family");

		struct group_source_req req;
		memset(&req, 0, sizeof(req));

		static_assert(sizeof(req.gsr_group) >= sizeof(struct sockaddr_in6), "gsr_group size less than sockaddr_in6");
		static_assert(sizeof(req.gsr_source) >= sizeof(struct sockaddr_in6), "gsr_source size less than sockaddr_in6");

		req.gsr_interface = if_index;           /* interface index, or 0 */
		memcpy(&req.gsr_group, &multi_addr.second, sizeof(struct sockaddr_in6));  /* ipv4 or ipv6 multicast addr */
		memcpy(&req.gsr_source, &src_addr.second, sizeof(struct sockaddr_in6));   /* ipv4 or ipv6 source addr */

		int rt = ::setsockopt(m_io.fd, IPPROTO_IPV6, MCAST_JOIN_SOURCE_GROUP, &req, sizeof(req));
		if (rt != 0)
		{
			set_error(setsockopt_failed, errno);
			return false;
		}

		return true;
	}

	bool drop_source_membership(const std::string &multi_ip, const std::string &if_ip, const std::string &multi_source_ip)
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		std::pair<bool, struct in_addr> multi_addr = inetc::inet_pton4(multi_ip);
		if (!multi_addr.first)
		{
			set_error(invalid_host, 1, multi_ip);
			return false;
		}

		std::pair<bool, struct in_addr> if_addr = inetc::inet_pton4(if_ip);
		if (!if_addr.first)
		{
			set_error(invalid_host, 2, if_ip);
			return false;
		}

		std::pair<bool, struct in_addr> src_addr = inetc::inet_pton4(multi_source_ip);
		if (!src_addr.first)
		{
			set_error(invalid_host, 3, multi_source_ip);
			return false;
		}

		struct ip_mreq_source mreq;
		memset(&mreq, 0, sizeof(mreq));
		mreq.imr_multiaddr  = multi_addr.second;  /* ipv4 class D multicast addr */
		mreq.imr_sourceaddr = src_addr.second;    /* ipv4 source addr */
		mreq.imr_interface  = if_addr.second;     /* ipv4 addr of local interface */

		int rt = ::setsockopt(m_io.fd, IPPROTO_IP, IP_DROP_SOURCE_MEMBERSHIP, &mreq, sizeof(mreq));
		if (rt != 0)
		{
			set_error(setsockopt_failed, errno);
			return false;
		}

		return true;
	}

	bool leave_source_group_ipv6(const hostaddress &multi_ipaddr, unsigned int if_index, const hostaddress &multi_source_ipaddr)
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		if (!multi_ipaddr.isip())
		{
			set_error(invalid_host, 1, multi_ipaddr.str());
			return false;
		}

		if (!multi_source_ipaddr.isip())
		{
			set_error(invalid_host, 2, multi_source_ipaddr.str());
			return false;
		}

		std::pair<bool, struct sockaddr_in6> multi_addr = inetc::inaddr_pton6(multi_ipaddr, 0);
		if (!multi_addr.first)
		{
			set_error(invalid_host, 3, multi_ipaddr.str());
			return false;
		}

		if (evunlike(multi_addr.second.sin6_family != AF_INET6))
			assert(false && "invalid family");

		std::pair<bool, struct sockaddr_in6> src_addr = inetc::inaddr_pton6(multi_source_ipaddr, 0);
		if (!src_addr.first)
		{
			set_error(invalid_host, 4, multi_source_ipaddr.str());
			return false;
		}

		if (evunlike(src_addr.second.sin6_family != AF_INET6))
			assert(false && "invalid family");

		struct group_source_req req;
		memset(&req, 0, sizeof(req));

		static_assert(sizeof(req.gsr_group) >= sizeof(struct sockaddr_in6), "gsr_group size less than sockaddr_in6");
		static_assert(sizeof(req.gsr_source) >= sizeof(struct sockaddr_in6), "gsr_source size less than sockaddr_in6");

		req.gsr_interface = if_index;  /* interface index, or 0 */
		memcpy(&req.gsr_group, &multi_addr.second, sizeof(struct sockaddr_in6));  /* ipv4 or ipv6 multicast addr */
		memcpy(&req.gsr_source, &src_addr.second, sizeof(struct sockaddr_in6));   /* ipv4 or ipv6 source addr */

		int rt = ::setsockopt(m_io.fd, IPPROTO_IPV6, MCAST_LEAVE_SOURCE_GROUP, &req, sizeof(req));
		if (rt != 0)
		{
			set_error(setsockopt_failed, errno);
			return false;
		}

		return true;
	}

	bool block_source(const std::string &multi_ip, const std::string &if_ip, const std::string &multi_source_ip)
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		std::pair<bool, struct in_addr> multi_addr = inetc::inet_pton4(multi_ip);
		if (!multi_addr.first)
		{
			set_error(invalid_host, 1, multi_ip);
			return false;
		}

		std::pair<bool, struct in_addr> if_addr = inetc::inet_pton4(if_ip);
		if (!if_addr.first)
		{
			set_error(invalid_host, 2, if_ip);
			return false;
		}

		std::pair<bool, struct in_addr> src_addr = inetc::inet_pton4(multi_source_ip);
		if (!src_addr.first)
		{
			set_error(invalid_host, 3, multi_source_ip);
			return false;
		}

		struct ip_mreq_source mreq;
		memset(&mreq, 0, sizeof(mreq));
		mreq.imr_multiaddr  = multi_addr.second;  /* ipv4 class D multicast addr */
		mreq.imr_sourceaddr = src_addr.second;    /* ipv4 source addr */
		mreq.imr_interface  = if_addr.second;     /* ipv4 addr of local interface */

		int rt = ::setsockopt(m_io.fd, IPPROTO_IP, IP_BLOCK_SOURCE, &mreq, sizeof(mreq));
		if (rt != 0)
		{
			set_error(setsockopt_failed, errno);
			return false;
		}

		return true;
	}

	bool block_source_ipv6(const hostaddress &multi_ipaddr, unsigned int if_index, const hostaddress &multi_source_ipaddr)
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		std::pair<bool, struct sockaddr_in6> multi_addr = inetc::inaddr_pton6(multi_ipaddr, 0);
		if (!multi_addr.first)
		{
			set_error(invalid_host, 1, multi_ipaddr.str());
			return false;
		}

		if (evunlike(multi_addr.second.sin6_family != AF_INET6))
			assert(false && "invalid family");

		std::pair<bool, struct sockaddr_in6> src_addr = inetc::inaddr_pton6(multi_source_ipaddr, 0);
		if (!src_addr.first)
		{
			set_error(invalid_host, 2, multi_source_ipaddr.str());
			return false;
		}

		if (evunlike(src_addr.second.sin6_family != AF_INET6))
			assert(false && "invalid family");

		struct group_source_req req;
		memset(&req, 0, sizeof(req));

		static_assert(sizeof(req.gsr_group) >= sizeof(struct sockaddr_in6), "gsr_group size less than sockaddr_in6");
		static_assert(sizeof(req.gsr_source) >= sizeof(struct sockaddr_in6), "gsr_source size less than sockaddr_in6");

		req.gsr_interface = if_index;  /* interface index, or 0 */
		memcpy(&req.gsr_group, &multi_addr.second, sizeof(struct sockaddr_in6));  /* ipv4 or ipv6 multicast addr */
		memcpy(&req.gsr_source, &src_addr.second, sizeof(struct sockaddr_in6));   /* ipv4 or ipv6 source addr */

		int rt = ::setsockopt(m_io.fd, IPPROTO_IPV6, MCAST_BLOCK_SOURCE, &req, sizeof(req));
		if (rt != 0)
		{
			set_error(setsockopt_failed, errno);
			return false;
		}

		return true;
	}

	bool unblock_source(const std::string &multi_ip, const std::string &if_ip, const std::string &multi_source_ip)
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		std::pair<bool, struct in_addr> multi_addr = inetc::inet_pton4(multi_ip);
		if (!multi_addr.first)
		{
			set_error(invalid_host, 1, multi_ip);
			return false;
		}

		std::pair<bool, struct in_addr> if_addr = inetc::inet_pton4(if_ip);
		if (!if_addr.first)
		{
			set_error(invalid_host, 2, if_ip);
			return false;
		}

		std::pair<bool, struct in_addr> src_addr = inetc::inet_pton4(multi_source_ip);
		if (!src_addr.first)
		{
			set_error(invalid_host, 3, multi_source_ip);
			return false;
		}

		struct ip_mreq_source mreq;
		memset(&mreq, 0, sizeof(mreq));
		mreq.imr_multiaddr  = multi_addr.second;  /* ipv4 class D multicast addr */
		mreq.imr_sourceaddr = src_addr.second;    /* ipv4 source addr */
		mreq.imr_interface  = if_addr.second;     /* ipv4 addr of local interface */

		int rt = ::setsockopt(m_io.fd, IPPROTO_IP, IP_UNBLOCK_SOURCE, &mreq, sizeof(mreq));
		if (rt != 0)
		{
			set_error(setsockopt_failed, errno);
			return false;
		}

		return true;
	}

	bool unblock_source_ipv6(const hostaddress &multi_ipaddr, unsigned int if_index, const hostaddress &multi_source_ipaddr)
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		std::pair<bool, struct sockaddr_in6> multi_addr = inetc::inaddr_pton6(multi_ipaddr, 0);
		if (!multi_addr.first)
		{
			set_error(invalid_host, 1, multi_ipaddr.str());
			return false;
		}

		if (evunlike(multi_addr.second.sin6_family != AF_INET6))
			assert(false && "invalid family");

		std::pair<bool, struct sockaddr_in6> src_addr = inetc::inaddr_pton6(multi_source_ipaddr, 0);
		if (!src_addr.first)
		{
			set_error(invalid_host, 2, multi_source_ipaddr.str());
			return false;
		}

		if (evunlike(src_addr.second.sin6_family != AF_INET6))
			assert(false && "invalid family");

		struct group_source_req req;
		memset(&req, 0, sizeof(req));

		static_assert(sizeof(req.gsr_group) >= sizeof(struct sockaddr_in6), "gsr_group size less than sockaddr_in6");
		static_assert(sizeof(req.gsr_source) >= sizeof(struct sockaddr_in6), "gsr_source size less than sockaddr_in6");

		req.gsr_interface = if_index;  /* interface index, or 0 */
		memcpy(&req.gsr_group, &multi_addr.second, sizeof(struct sockaddr_in6));  /* ipv4 or ipv6 multicast addr */
		memcpy(&req.gsr_source, &src_addr.second, sizeof(struct sockaddr_in6));   /* ipv4 or ipv6 source addr */

		int rt = ::setsockopt(m_io.fd, IPPROTO_IPV6, MCAST_UNBLOCK_SOURCE, &req, sizeof(req));
		if (rt != 0)
		{
			set_error(setsockopt_failed, errno);
			return false;
		}

		return true;
	}

	bool multicast_all(bool mc_all)
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		int val = mc_all ? 1 : 0;

		int rt = ::setsockopt(m_io.fd, IPPROTO_IP, IP_MULTICAST_ALL, &val, sizeof(val));
		if (rt != 0)
		{
			set_error(setsockopt_failed, errno);
			return false;
		}

		return true;
	}

	bool multicast_all_ipv6(bool mc_all)
	{
		if (m_io.fd == -1)
		{
			set_error(invalid_fd, m_io.fd);
			return false;
		}

		int val = mc_all ? 1 : 0;

		int rt = ::setsockopt(m_io.fd, IPPROTO_IPV6, IPV6_MULTICAST_ALL, &val, sizeof(val));
		if (rt != 0)
		{
			set_error(setsockopt_failed, errno);
			return false;
		}

		return true;
	}

	ssize_t recvfrom(void *buf, size_t nbytes, struct sockaddr_storage &srcaddr, int flags = 0)
	{
		socklen_t addrlen = sizeof(srcaddr);
		return ::recvfrom(m_io.fd, buf, nbytes, flags, (struct sockaddr *)&srcaddr, &addrlen);
	}

	ssize_t recvfrom(void *buf, size_t nbytes, int flags = 0)
	{
		return ::recvfrom(m_io.fd, buf, nbytes, flags, nullptr, nullptr);
	}

	ssize_t sendto(const void *buf, size_t nbytes, const struct sockaddr_storage &destaddr, int flags = 0)
	{
		static_assert(sizeof(struct sockaddr_un) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_un");

		ssize_t r = 0;

		if (destaddr.ss_family == AF_LOCAL)
			r = ::sendto(m_io.fd, buf, nbytes, flags, (const struct sockaddr *)&destaddr, sizeof(struct sockaddr_un));
		else
			r = ::sendto(m_io.fd, buf, nbytes, flags, (const struct sockaddr *)&destaddr, sizeof(destaddr));

		return r;
	}

	ssize_t recv(void *buf, size_t nbytes, int flags = 0)
	{
		return ::recv(m_io.fd, buf, nbytes, flags);
	}

	ssize_t send(const void *buf, size_t nbytes, int flags = 0)
	{
		return ::send(m_io.fd, buf, nbytes, flags);
	}

	ssize_t read(void *buf, size_t nbytes)
	{
		return ::read(m_io.fd, buf, nbytes);
	}

	ssize_t write(const void *buf, size_t nbytes)
	{
		return ::write(m_io.fd, buf, nbytes);
	}

	void stop_close()
	{
		m_io.stop();

		if (m_io.fd != -1)
			::close(m_io.fd);

		m_io.set(-1, 0);
	}

	void only_close()
	{
		if (m_io.fd != -1)
			::close(m_io.fd);

		m_io.set(-1, 0);
	}

	void stop_reset()
	{
		m_io.stop();
		m_io.set(-1, 0);
	}

	void only_reset()
	{
		m_io.set(-1, 0);
	}

private:
	void socket_callback(T &watcher, int fd) { }

	void io_callback(T &watcher, int revents) { assert(false && "unset callback"); }

	void _callback(ev::io &watcher, int revents)
	{
		if (evunlike((revents & ev::ERROR) != 0))
			assert(false && "ev_error");
		if (evunlike(&watcher != &m_io))
			assert(false && "unexpected watcher");

		if (m_iocallback)
			m_iocallback(*static_cast<T*>(this), revents);
		else
			static_cast<T*>(this)->io_callback(*static_cast<T*>(this), revents);
	}

private:
	ev::io  m_io;

	io_callback_t       m_iocallback;
	socket_callback_t   m_sockcallback;
};

class simpdgramsock : public dgramsock<simpdgramsock>
{};


}


#endif


