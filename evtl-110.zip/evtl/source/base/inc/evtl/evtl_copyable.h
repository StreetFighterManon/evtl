

#ifndef __EVTL_COPYABLE_H__
#define __EVTL_COPYABLE_H__


namespace evtl
{


class nocopyc
{
protected:
	nocopyc() = default;
	~nocopyc() {}

private:
	nocopyc(const nocopyc &) = delete;
	nocopyc& operator = (const nocopyc &) = delete;
};


class cancopyc
{};


}


#endif


