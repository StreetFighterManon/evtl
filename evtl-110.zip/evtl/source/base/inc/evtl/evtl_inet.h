

#ifndef __EVTL_INET_H__
#define __EVTL_INET_H__

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/un.h>

#include <cstring>
#include <string>
#include <utility>

#include "evtl_in.h"


namespace evtl
{


class inetc
{
public:
	static int ipversion(const std::string &ip)
	{
		struct in_addr addr4;
		struct in6_addr addr6;

		int r = ::inet_pton(AF_INET, ip.c_str(), &addr4);
		if (r == 1)
			return 4;

		r = ::inet_pton(AF_INET6, ip.c_str(), &addr6);
		if (r == 1)
			return 6;

		return 0;
	}

	static std::string inet_ntop4(const struct in_addr &addr)
	{
		char dst[INET_ADDRSTRLEN + 1] = { 0 };
		const char *pdst = ::inet_ntop(AF_INET, &addr, dst, INET_ADDRSTRLEN + 1);
		if (pdst == nullptr)
			return std::string();

		dst[INET_ADDRSTRLEN] = '\0';
		return std::string(dst);
	}

	static std::pair<bool, struct in_addr> inet_pton4(const std::string &addrstr)
	{
		std::pair<bool, struct in_addr> result = std::make_pair(false, in_addr());

		if (addrstr.empty())
			return result;

		int r = ::inet_pton(AF_INET, addrstr.c_str(), &result.second);
		if (r == 1)
			result.first = true;

		return result;
	}

	static std::string inet_ntop6(const struct in6_addr &addr)
	{
		char dst[INET6_ADDRSTRLEN + 1] = { 0 };
		const char *pdst = ::inet_ntop(AF_INET6, &addr, dst, INET6_ADDRSTRLEN + 1);
		if (pdst == nullptr)
			return std::string();

		dst[INET6_ADDRSTRLEN] = '\0';
		return std::string(dst);
	}

	static std::pair<bool, struct in6_addr> inet_pton6(const std::string &addrstr)
	{
		std::pair<bool, struct in6_addr> result = std::make_pair(false, in6_addr());

		if (addrstr.empty())
			return result;

		int r = ::inet_pton(AF_INET6, addrstr.c_str(), &result.second);
		if (r == 1)
			result.first = true;

		return result;
	}

	static std::pair<bool, struct sockaddr_in> getsockname4(int fd)
	{
		std::pair<bool, struct sockaddr_in> result = std::make_pair(false, sockaddr_in());
		socklen_t socklen = sizeof(result.second);

		if (fd == -1)
			return result;

		int r = ::getsockname(fd, (struct sockaddr *)&result.second, &socklen);
		if (r != 0)
			return result;

		if (socklen != sizeof(result.second))
			return result;
		if (result.second.sin_family != AF_INET)
			return result;

		result.first = true;
		return result;
	}

	static address getsocknamesi4(int fd)
	{
		address result;

		if (fd == -1)
			return result;

		std::pair<bool, struct sockaddr_in> sockaddr = getsockname4(fd);
		if (sockaddr.first)
		{
			result.host.type = addrtype::ip;
			result.host.hostaddr = inet_ntop4(sockaddr.second.sin_addr);
			result.port = ntohs(sockaddr.second.sin_port);
		}

		return result;
	}

	static std::pair<bool, struct sockaddr_in> getpeername4(int fd)
	{
		std::pair<bool, struct sockaddr_in> result = std::make_pair(false, sockaddr_in());
		socklen_t socklen = sizeof(result.second);

		if (fd == -1)
			return result;

		int r = ::getpeername(fd, (struct sockaddr *)&result.second, &socklen);
		if (r != 0)
			return result;

		if (socklen != sizeof(result.second))
			return result;
		if (result.second.sin_family != AF_INET)
			return result;

		result.first = true;
		return result;
	}

	static address getpeernamesi4(int fd)
	{
		address result;

		if (fd == -1)
			return result;

		std::pair<bool, struct sockaddr_in> sockaddr = getpeername4(fd);
		if (sockaddr.first)
		{
			result.host.type = addrtype::ip;
			result.host.hostaddr = inet_ntop4(sockaddr.second.sin_addr);
			result.port = ntohs(sockaddr.second.sin_port);
		}

		return result;
	}

	static std::pair<bool, struct sockaddr_in6> getsockname6(int fd)
	{
		std::pair<bool, struct sockaddr_in6> result = std::make_pair(false, sockaddr_in6());
		socklen_t socklen = sizeof(result.second);

		if (fd == -1)
			return result;

		int r = ::getsockname(fd, (struct sockaddr *)&result.second, &socklen);
		if (r != 0)
			return result;

		if (socklen != sizeof(result.second))
			return result;
		if (result.second.sin6_family != AF_INET6)
			return result;

		result.first = true;
		return result;
	}

	static address getsocknamesi6(int fd)
	{
		address result;

		if (fd == -1)
			return result;

		std::pair<bool, struct sockaddr_in6> sockaddr = getsockname6(fd);
		if (sockaddr.first)
		{
			result.host.type = addrtype::ip;
			result.host.hostaddr = inet_ntop6(sockaddr.second.sin6_addr);
			result.host.sin6_scope_id = sockaddr.second.sin6_scope_id;
			result.port = ntohs(sockaddr.second.sin6_port);
		}

		return result;
	}

	static std::pair<bool, struct sockaddr_in6> getpeername6(int fd)
	{
		std::pair<bool, struct sockaddr_in6> result = std::make_pair(false, sockaddr_in6());
		socklen_t socklen = sizeof(result.second);

		if (fd == -1)
			return result;

		int r = ::getpeername(fd, (struct sockaddr *)&result.second, &socklen);
		if (r != 0)
			return result;

		if (socklen != sizeof(result.second))
			return result;
		if (result.second.sin6_family != AF_INET6)
			return result;

		result.first = true;
		return result;
	}

	static address getpeernamesi6(int fd)
	{
		address result;

		if (fd == -1)
			return result;

		std::pair<bool, struct sockaddr_in6> sockaddr = getpeername6(fd);
		if (sockaddr.first)
		{
			result.host.type = addrtype::ip;
			result.host.hostaddr = inet_ntop6(sockaddr.second.sin6_addr);
			result.host.sin6_scope_id = sockaddr.second.sin6_scope_id;
			result.port = ntohs(sockaddr.second.sin6_port);
		}

		return result;
	}

	static std::pair<bool, struct sockaddr_un> getsocknameunix(int fd)
	{
		std::pair<bool, struct sockaddr_un> result = std::make_pair(false, sockaddr_un());
		socklen_t socklen = sizeof(result.second);

		if (fd == -1)
			return result;

		int r = ::getsockname(fd, (struct sockaddr *)&result.second, &socklen);
		if (r != 0)
			return result;

		if (socklen < sizeof(result.second.sun_family) || socklen > sizeof(result.second))
			return result;
		if (result.second.sun_family != AF_LOCAL)
			return result;

		result.second.sun_path[sizeof(result.second.sun_path) - 1] = '\0';
		result.first = true;
		return result;
	}

	static address getsocknamesiunix(int fd)
	{
		address result;

		if (fd == -1)
			return result;

		struct sockaddr_un addr;
		socklen_t socklen = sizeof(addr);

		int r = ::getsockname(fd, (struct sockaddr *)&addr, &socklen);
		if (r != 0)
			return result;
		if (socklen < sizeof(addr.sun_family) || socklen > sizeof(addr))
			return result;
		if (addr.sun_family != AF_LOCAL)
			return result;
		addr.sun_path[sizeof(addr.sun_path) - 1] = '\0';

		result.host.set(addrtype::unix, addr.sun_path, 0);
		return result;
	}

	static std::pair<bool, struct sockaddr_un> getpeernameunix(int fd)
	{
		std::pair<bool, struct sockaddr_un> result = std::make_pair(false, sockaddr_un());
		socklen_t socklen = sizeof(result.second);

		if (fd == -1)
			return result;

		int r = ::getpeername(fd, (struct sockaddr *)&result.second, &socklen);
		if (r != 0)
			return result;

		if (socklen < sizeof(result.second.sun_family) || socklen > sizeof(result.second))
			return result;
		if (result.second.sun_family != AF_LOCAL)
			return result;

		result.second.sun_path[sizeof(result.second.sun_path) - 1] = '\0';
		result.first = true;
		return result;
	}

	static address getpeernamesiunix(int fd)
	{
		address result;

		if (fd == -1)
			return result;

		struct sockaddr_un addr;
		socklen_t socklen = sizeof(addr);

		int r = ::getpeername(fd, (struct sockaddr *)&addr, &socklen);
		if (r != 0)
			return result;
		if (socklen < sizeof(addr.sun_family) || socklen > sizeof(addr))
			return result;
		if (addr.sun_family != AF_LOCAL)
			return result;
		addr.sun_path[sizeof(addr.sun_path) - 1] = '\0';

		result.host.set(addrtype::unix, addr.sun_path, 0);
		return result;
	}

	static std::pair<bool, struct sockaddr_storage> getsockname(int fd)
	{
		std::pair<bool, struct sockaddr_storage> result = std::make_pair(false, sockaddr_storage());
		socklen_t socklen = sizeof(result.second);

		if (fd == -1)
			return result;

		int r = ::getsockname(fd, (struct sockaddr *)&result.second, &socklen);
		if (r != 0)
			return result;
		if (socklen < sizeof(result.second.ss_family))
			return result;

		result.first = true;
		return result;
	}

	static std::pair<bool, struct sockaddr_storage> getpeername(int fd)
	{
		std::pair<bool, struct sockaddr_storage> result = std::make_pair(false, sockaddr_storage());
		socklen_t socklen = sizeof(result.second);

		if (fd == -1)
			return result;

		int r = ::getpeername(fd, (struct sockaddr *)&result.second, &socklen);
		if (r != 0)
			return result;
		if (socklen < sizeof(result.second.ss_family))
			return result;

		result.first = true;
		return result;
	}

	static address getsocknamesi(int fd)
	{
		static_assert(sizeof(struct sockaddr_in) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_in");
		static_assert(sizeof(struct sockaddr_in6) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_in6");
		static_assert(sizeof(struct sockaddr_un) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_un");

		address result;

		if (fd == -1)
			return result;

		std::pair<bool, struct sockaddr_storage> sockaddr = getsockname(fd);
		if (sockaddr.first)
		{
			if (sockaddr.second.ss_family == AF_INET)
			{
				const struct sockaddr_in &addr4 = reinterpret_cast<const struct sockaddr_in &>(sockaddr.second);
				result.host.type = addrtype::ip;
				result.host.hostaddr = inetc::inet_ntop4(addr4.sin_addr);
				result.port = ntohs(addr4.sin_port);
			}
			else if (sockaddr.second.ss_family == AF_INET6)
			{
				const struct sockaddr_in6 &addr6 = reinterpret_cast<const struct sockaddr_in6 &>(sockaddr.second);
				result.host.type = addrtype::ip;
				result.host.hostaddr = inetc::inet_ntop6(addr6.sin6_addr);
				result.host.sin6_scope_id = addr6.sin6_scope_id;
				result.port = ntohs(addr6.sin6_port);
			}
			else if (sockaddr.second.ss_family == AF_LOCAL)
			{
				const struct sockaddr_un &addru = reinterpret_cast<const struct sockaddr_un &>(sockaddr.second);
				int i = 0;
				while (i < (int)sizeof(addru.sun_path) && addru.sun_path[i] != '\0')
					++i;
				if (i < (int)sizeof(addru.sun_path))
					result.host.set(addrtype::unix, addru.sun_path, 0);
			}
		}

		return result;
	}

	static address getpeernamesi(int fd)
	{
		static_assert(sizeof(struct sockaddr_in) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_in");
		static_assert(sizeof(struct sockaddr_in6) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_in6");
		static_assert(sizeof(struct sockaddr_un) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_un");

		address result;

		if (fd == -1)
			return result;

		std::pair<bool, struct sockaddr_storage> sockaddr = getpeername(fd);
		if (sockaddr.first)
		{
			if (sockaddr.second.ss_family == AF_INET)
			{
				const struct sockaddr_in &addr4 = reinterpret_cast<const struct sockaddr_in &>(sockaddr.second);
				result.host.type = addrtype::ip;
				result.host.hostaddr = inetc::inet_ntop4(addr4.sin_addr);
				result.port = ntohs(addr4.sin_port);
			}
			else if (sockaddr.second.ss_family == AF_INET6)
			{
				const struct sockaddr_in6 &addr6 = reinterpret_cast<const struct sockaddr_in6 &>(sockaddr.second);
				result.host.type = addrtype::ip;
				result.host.hostaddr = inetc::inet_ntop6(addr6.sin6_addr);
				result.host.sin6_scope_id = addr6.sin6_scope_id;
				result.port = ntohs(addr6.sin6_port);
			}
			else if (sockaddr.second.ss_family == AF_LOCAL)
			{
				const struct sockaddr_un &addru = reinterpret_cast<const struct sockaddr_un &>(sockaddr.second);
				int i = 0;
				while (i < (int)sizeof(addru.sun_path) && addru.sun_path[i] != '\0')
					++i;
				if (i < (int)sizeof(addru.sun_path))
					result.host.set(addrtype::unix, addru.sun_path, 0);
			}
		}

		return result;
	}

	static address inaddr_ntop4(const struct sockaddr_in &addr)
	{
		address result;

		if (addr.sin_family != AF_INET)
			return result;

		result.host.type = addrtype::ip;
		result.host.hostaddr = inetc::inet_ntop4(addr.sin_addr);
		result.port = ntohs(addr.sin_port);
		return result;
	}

	static std::pair<bool, struct sockaddr_in> inaddr_pton4(const std::string &ip, int port)
	{
		std::pair<bool, struct sockaddr_in> result = std::make_pair(false, sockaddr_in());

		std::pair<bool, struct in_addr> inaddr = inetc::inet_pton4(ip);
		if (inaddr.first)
		{
			result.second.sin_family = AF_INET;
			result.second.sin_addr   = inaddr.second;
			result.second.sin_port   = htons(port);
			result.first = true;
		}

		return result;
	}

	static std::pair<bool, struct sockaddr_in> inaddr_pton4(const hostaddress &hostaddr, int port)
	{
		if (!hostaddr.isip())
			return std::make_pair(false, sockaddr_in());

		return inaddr_pton4(hostaddr.ip(), port);
	}

	static std::pair<bool, struct sockaddr_in> inaddr_pton4(const address &addr)
	{
		if (!addr.host.isip())
			return std::make_pair(false, sockaddr_in());

		return inaddr_pton4(addr.host.ip(), addr.port);
	}

	static address inaddr_ntop6(const struct sockaddr_in6 &addr)
	{
		address result;

		if (addr.sin6_family != AF_INET6)
			return result;

		result.host.type = addrtype::ip;
		result.host.hostaddr = inetc::inet_ntop6(addr.sin6_addr);
		result.host.sin6_scope_id = addr.sin6_scope_id;
		result.port = ntohs(addr.sin6_port);
		return result;
	}

	static std::pair<bool, struct sockaddr_in6> inaddr_pton6(const std::string &ip, int scope_id, int port)
	{
		std::pair<bool, struct sockaddr_in6> result = std::make_pair(false, sockaddr_in6());
		if (ip.empty())
			return result;

		std::pair<bool, struct in6_addr> inaddr = inetc::inet_pton6(ip);
		if (inaddr.first)
		{
			result.second.sin6_family = AF_INET6;
			result.second.sin6_addr   = inaddr.second;
			result.second.sin6_scope_id = scope_id;
			result.second.sin6_port   = htons(port);
			result.first = true;
		}

		return result;
	}

	static std::pair<bool, struct sockaddr_in6> inaddr_pton6(const hostaddress &host, int port)
	{
		if (!host.isip())
			return std::make_pair(false, sockaddr_in6());

		return inaddr_pton6(host.hostaddr, host.sin6_scope_id, port);
	}

	static std::pair<bool, struct sockaddr_in6> inaddr_pton6(const address &addr)
	{
		std::pair<bool, struct sockaddr_in6> result = std::make_pair(false, sockaddr_in6());
		if (!addr.host.isip())
			return result;

		std::pair<bool, struct in6_addr> inaddr = inetc::inet_pton6(addr.host.hostaddr);
		if (inaddr.first)
		{
			result.second.sin6_family = AF_INET6;
			result.second.sin6_addr   = inaddr.second;
			result.second.sin6_scope_id = addr.host.sin6_scope_id;
			result.second.sin6_port   = htons(addr.port);
			result.first = true;
		}

		return result;
	}

	static address inaddr_ntopunix(const struct sockaddr_un &addr)
	{
		address result;

		if (addr.sun_family != AF_LOCAL)
			return result;

		int i = 0;
		while (i < (int)sizeof(addr.sun_path) && addr.sun_path[i] != '\0')
			++i;
		if (i < (int)sizeof(addr.sun_path))
			result.host.set(addrtype::unix, addr.sun_path, 0);

		return result;
	}

	static std::pair<bool, struct sockaddr_un> inaddr_ptonunix(const address &addr)
	{
		std::pair<bool, struct sockaddr_un> result = std::make_pair(false, sockaddr_un());
		if (!addr.host.isunix())
			return result;

		size_t size = addr.host.hostaddr.size();
		if (size >= sizeof(result.second.sun_path))
			return result;

		result.second.sun_family = AF_LOCAL;
		::strncpy(result.second.sun_path, addr.host.hostaddr.c_str(), size);
		result.second.sun_path[size] = '\0';
		return result;
	}

	static address inaddr_ntop(const struct sockaddr_storage &addr)
	{
		static_assert(sizeof(struct sockaddr_in) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_in");
		static_assert(sizeof(struct sockaddr_in6) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_in6");
		static_assert(sizeof(struct sockaddr_un) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_un");

		address result;

		if (addr.ss_family == AF_INET)
			result = inaddr_ntop4(reinterpret_cast<const struct sockaddr_in &>(addr));
		else if (addr.ss_family == AF_INET6)
			result = inaddr_ntop6(reinterpret_cast<const struct sockaddr_in6 &>(addr));
		else if (addr.ss_family == AF_LOCAL)
			result = inaddr_ntopunix(reinterpret_cast<const struct sockaddr_un &>(addr));

		return result;
	}

	static std::pair<bool, struct sockaddr_storage> inaddr_pton(const hostaddress &hostaddr, int port)
	{
		static_assert(sizeof(struct sockaddr_in) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_in");
		static_assert(sizeof(struct sockaddr_in6) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_in6");
		static_assert(sizeof(struct sockaddr_un) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_un");

		std::pair<bool, struct sockaddr_storage> result = std::make_pair(false, sockaddr_storage());

		if (hostaddr.isip())
		{
			std::pair<bool, struct in_addr> addr4 = inetc::inet_pton4(hostaddr.ip());
			if (addr4.first)
			{
				struct sockaddr_in &inaddr4 = reinterpret_cast<struct sockaddr_in &>(result.second);
				inaddr4.sin_family = AF_INET;
				inaddr4.sin_addr   = addr4.second;
				inaddr4.sin_port   = htons(port);

				result.first = true;
			}
			else
			{
				std::pair<bool, struct in6_addr> addr6 = inetc::inet_pton6(hostaddr.ip());
				if (addr6.first)
				{
					struct sockaddr_in6 &inaddr6 = reinterpret_cast<struct sockaddr_in6 &>(result.second);
					inaddr6.sin6_family = AF_INET6;
					inaddr6.sin6_addr   = addr6.second;
					inaddr6.sin6_scope_id = hostaddr.sin6_scope_id;
					inaddr6.sin6_port   = htons(port);

					result.first = true;
				}
			}
		}
		else if (hostaddr.isunix())
		{
			struct sockaddr_un &unaddr = reinterpret_cast<struct sockaddr_un &>(result.second);

			size_t size = hostaddr.hostaddr.size();
			if (size >= sizeof(unaddr.sun_path))
				return result;
			unaddr.sun_family = AF_LOCAL;
			::strncpy(unaddr.sun_path, hostaddr.hostaddr.c_str(), size);
			unaddr.sun_path[size] = '\0';

			result.first = true;
		}

		return result;
	}

	static std::pair<bool, struct sockaddr_storage> inaddr_pton(const address &addr)
	{
		if (addr.host.typeinvalid())
			return std::make_pair(false, sockaddr_storage());

		return inaddr_pton(addr.host, addr.port);
	}

	static bool addrequal(const struct sockaddr_storage &addr1, const struct sockaddr_storage &addr2, bool compare_scopeid = true)
	{
		static_assert(sizeof(struct sockaddr_in) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_in");
		static_assert(sizeof(struct sockaddr_in6) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_in6");
		static_assert(sizeof(struct sockaddr_un) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_un");

		if (addr1.ss_family != addr2.ss_family)
			return false;

		if (addr1.ss_family == AF_INET)
		{
			const struct sockaddr_in &addrin1 = reinterpret_cast<const struct sockaddr_in &>(addr1);
			const struct sockaddr_in &addrin2 = reinterpret_cast<const struct sockaddr_in &>(addr2);

			if (addrin1.sin_addr.s_addr == addrin2.sin_addr.s_addr
				&& addrin1.sin_port == addrin2.sin_port
				)
				return true;
		}
		else if (addr1.ss_family == AF_INET6)
		{
			const struct sockaddr_in6 &addrin61 = reinterpret_cast<const struct sockaddr_in6 &>(addr1);
			const struct sockaddr_in6 &addrin62 = reinterpret_cast<const struct sockaddr_in6 &>(addr2);

			if (addrin61.sin6_port == addrin62.sin6_port
				&& (!compare_scopeid || addrin61.sin6_scope_id == addrin62.sin6_scope_id)
				&& memcmp(&addrin61.sin6_addr.s6_addr, &addrin62.sin6_addr.s6_addr, sizeof(addrin61.sin6_addr.s6_addr)) == 0
				)
				return true;
		}
		else if (addr1.ss_family == AF_LOCAL)
		{
			const struct sockaddr_un &addrun1 = reinterpret_cast<const struct sockaddr_un &>(addr1);
			const struct sockaddr_un &addrun2 = reinterpret_cast<const struct sockaddr_un &>(addr2);

			if (::strncmp(addrun1.sun_path, addrun2.sun_path, sizeof(addrun1.sun_path)) == 0)
				return true;
		}

		return false;
	}

	static hostaddress gethost(const struct sockaddr_storage &addr)
	{
		static_assert(sizeof(struct sockaddr_in) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_in");
		static_assert(sizeof(struct sockaddr_in6) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_in6");
		static_assert(sizeof(struct sockaddr_un) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_un");

		hostaddress host;

		if (addr.ss_family == AF_INET)
		{
			const struct sockaddr_in &addr4 = reinterpret_cast<const struct sockaddr_in &>(addr);
			host.type = addrtype::ip;
			host.hostaddr = inet_ntop4(addr4.sin_addr);
		}
		else if (addr.ss_family == AF_INET6)
		{
			const struct sockaddr_in6 &addr6 = reinterpret_cast<const struct sockaddr_in6 &>(addr);
			host.type = addrtype::ip;
			host.hostaddr = inet_ntop6(addr6.sin6_addr);
			host.sin6_scope_id = addr6.sin6_scope_id;
		}
		else if (addr.ss_family == AF_LOCAL)
		{
			const struct sockaddr_un &addrun = reinterpret_cast<const struct sockaddr_un &>(addr);
			int i = 0;
			while (i < (int)sizeof(addrun.sun_path) && addrun.sun_path[i] != '\0')
				++i;
			if (i < (int)sizeof(addrun.sun_path))
				host.set(addrtype::unix, addrun.sun_path, 0);
		}

		return host;
	}

	static int getport(const struct sockaddr_storage &addr)
	{
		static_assert(sizeof(struct sockaddr_in) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_in");
		static_assert(sizeof(struct sockaddr_in6) <= sizeof(struct sockaddr_storage), "sockaddr_storage size less than sockaddr_in6");

		if (addr.ss_family == AF_INET)
		{
			const struct sockaddr_in &addr4 = reinterpret_cast<const struct sockaddr_in &>(addr);
			return ntohs(addr4.sin_port);
		}
		else if (addr.ss_family == AF_INET6)
		{
			const struct sockaddr_in6 &addr6 = reinterpret_cast<const struct sockaddr_in6 &>(addr);
			return ntohs(addr6.sin6_port);
		}

		return -1;
	}
};


}


#endif


