

#ifndef __EVTL_DLGTRINGBUF_H__
#define __EVTL_DLGTRINGBUF_H__

#include <sys/types.h>
#include <assert.h>

#include <type_traits>
#include <utility>
#include <algorithm>
#include <string>

#include "evtl_gcc.h"
#include "evtl_exception.h"


namespace evtl
{


template <class T>
class linearbuf;

template <class T>
class ringbuf;

template <class T>
class dlgtlinbuf;

template <class T>
class dlgtringbuf
{
	static_assert(std::is_same<T, char>::value || std::is_same<T, unsigned char>::value,
		"template parameter should be char or unsigned char");

	template <class K> friend class linearbuf;
	template <class K> friend class ringbuf;
	template <class K> friend class dlgtlinbuf;
	template <class K> friend class dlgtringbuf;

public:
	typedef T elem_type;

public:
	dlgtringbuf()
		: m_buffer_len(0), m_buffer(nullptr), m_pdata_start(nullptr), m_pdata_end(nullptr)
	{}

	dlgtringbuf(void *pbuffer, ssize_t len)
		: m_buffer_len(0), m_buffer(nullptr), m_pdata_start(nullptr), m_pdata_end(nullptr)
	{
		if (pbuffer == nullptr)
		{
			if (len == 0)
				return;
			else
			{
				assert(false && "invalid buffer");
				return;
			}
		}
		else
		{
			if (len <= 1)
			{
				assert(false && "invalid len");
				return;
			}
		}

		m_buffer      = static_cast<T*>(pbuffer);
		m_buffer_len  = len;
		m_pdata_start = m_buffer;
		m_pdata_end   = m_pdata_start;
	}

	dlgtringbuf(void *pbuffer, ssize_t len, void *pdatastart, void *pdataend)
		: m_buffer_len(0), m_buffer(nullptr), m_pdata_start(nullptr), m_pdata_end(nullptr)
	{
		if (pbuffer == nullptr)
		{
			if (len == 0)
				return;
			else
			{
				assert(false && "invalid buffer");
				return;
			}
		}
		else
		{
			if (len <= 1)
			{
				assert(false && "invalid len");
				return;
			}
		}

		if (pdatastart < pbuffer || pdatastart >= static_cast<T*>(pbuffer) + len)
		{
			assert(false && "bad datastart");
			return;
		}

		if (pdataend < pbuffer || pdataend >= static_cast<T*>(pbuffer) + len)
		{
			assert(false && "bad dataend");
			return;
		}

		m_buffer      = static_cast<T*>(pbuffer);
		m_buffer_len  = len;
		m_pdata_start = static_cast<T*>(pdatastart);
		m_pdata_end   = static_cast<T*>(pdataend);

		if (m_pdata_start == m_pdata_end)
		{
			m_pdata_start = m_buffer;
			m_pdata_end = m_pdata_start;
		}
	}

	dlgtringbuf(const dlgtringbuf &that): dlgtringbuf(that, 0)
	{}

	dlgtringbuf(dlgtringbuf &&that) noexcept : dlgtringbuf(std::forward<dlgtringbuf>(that), 0)
	{}

	template <class K>
	dlgtringbuf(const dlgtringbuf<K> &that): dlgtringbuf(that, 0)
	{}

	template <class K>
	dlgtringbuf(dlgtringbuf<K> &&that) noexcept : dlgtringbuf(std::forward<dlgtringbuf<K>>(that), 0)
	{}

	~dlgtringbuf()
	{
		m_buffer      = nullptr;
		m_buffer_len  = 0;
		m_pdata_start = nullptr;
		m_pdata_end   = nullptr;
	}

	dlgtringbuf& operator = (const dlgtringbuf &that)
	{
		return this->operator = <T>(that);
	}

	dlgtringbuf& operator = (dlgtringbuf &&that) noexcept
	{
		return this->operator = <T>(std::forward<dlgtringbuf>(that));
	}

	template <class K>
	dlgtringbuf& operator = (const dlgtringbuf<K> &that)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!that._verify()))
			assert(false && "that verify error");

		if (static_cast<const void *>(&that) == this)
			return *this;

		m_buffer      = reinterpret_cast<T*>(that.m_buffer);
		m_buffer_len  = that.m_buffer_len;
		m_pdata_start = reinterpret_cast<T*>(that.m_pdata_start);
		m_pdata_end   = reinterpret_cast<T*>(that.m_pdata_end);

		if (m_pdata_end == m_pdata_start)
		{
			m_pdata_start = m_buffer;
			m_pdata_end = m_pdata_start;
		}

		return *this;
	}

	template <class K>
	dlgtringbuf& operator = (dlgtringbuf<K> &&that) noexcept
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!that._verify()))
			assert(false && "that verify error");

		if (static_cast<const void *>(&that) == this)
			return *this;

		m_buffer      = reinterpret_cast<T*>(that.m_buffer);
		m_buffer_len  = that.m_buffer_len;
		m_pdata_start = reinterpret_cast<T*>(that.m_pdata_start);
		m_pdata_end   = reinterpret_cast<T*>(that.m_pdata_end);

		if (m_pdata_end == m_pdata_start)
		{
			m_pdata_start = m_buffer;
			m_pdata_end = m_pdata_start;
		}

		return *this;
	}

	bool operator < (const dlgtringbuf &that) const
	{
		return this->operator < <T>(that);
	}

	bool operator <= (const dlgtringbuf &that) const
	{
		return this->operator <= <T>(that);
	}

	bool operator > (const dlgtringbuf &that) const
	{
		return this->operator > <T>(that);
	}

	bool operator >= (const dlgtringbuf &that) const
	{
		return this->operator >= <T>(that);
	}

	bool operator == (const dlgtringbuf &that) const
	{
		return this->operator == <T>(that);
	}

	bool operator != (const dlgtringbuf &that) const
	{
		return this->operator != <T>(that);
	}

	template <class K>
	bool operator < (const dlgtringbuf<K> &that) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!that._verify()))
			assert(false && "verify error");
		if (static_cast<const void *>(&that) == this)
			assert(false && "self compare");

		return _compare(that) < 0;
	}

	template <class K>
	bool operator <= (const dlgtringbuf<K> &that) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!that._verify()))
			assert(false && "verify error");
		if (static_cast<const void *>(&that) == this)
			assert(false && "self compare");

		return _compare(that) <= 0;
	}

	template <class K>
	bool operator > (const dlgtringbuf<K> &that) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!that._verify()))
			assert(false && "verify error");
		if (static_cast<const void *>(&that) == this)
			assert(false && "self compare");

		return _compare(that) > 0;
	}

	template <class K>
	bool operator >= (const dlgtringbuf<K> &that) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!that._verify()))
			assert(false && "verify error");
		if (static_cast<const void *>(&that) == this)
			assert(false && "self compare");

		return _compare(that) >= 0;
	}

	template <class K>
	bool operator == (const dlgtringbuf<K> &that) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!that._verify()))
			assert(false && "verify error");
		if (static_cast<const void *>(&that) == this)
			assert(false && "self compare");

		return _compare(that) == 0;
	}

	template <class K>
	bool operator != (const dlgtringbuf<K> &that) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!that._verify()))
			assert(false && "verify error");
		if (static_cast<const void *>(&that) == this)
			assert(false && "self compare");

		return _compare(that) != 0;
	}

	void reset()
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		m_buffer      = nullptr;
		m_pdata_start = m_buffer;
		m_pdata_end   = m_pdata_start;
		m_buffer_len  = 0;
	}

	void set_buffer(void *pbuffer, ssize_t len)
	{
		if (pbuffer == nullptr)
		{
			if (len == 0)
			{
				m_buffer = nullptr;
				m_buffer_len = 0;
				m_pdata_start = m_buffer;
				m_pdata_end = m_pdata_start;
			}
			else
			{
				assert(false && "invalid buffer");
				return;
			}
		}
		else
		{
			if (len <= 1)
			{
				assert(false && "invalid buffer");
				return;
			}

			m_buffer      = static_cast<T*>(pbuffer);
			m_buffer_len  = len;
			m_pdata_start = m_buffer;
			m_pdata_end   = m_pdata_start;
		}
	}

	void set_buffer(void *pbuffer, ssize_t len, void *pdatastart, void *pdataend)
	{
		if (pbuffer == nullptr)
		{
			if (len == 0)
			{
				if (pdatastart != nullptr || pdataend != nullptr)
				{
					assert(false && "bad dataptr");
					return;
				}

				m_buffer = nullptr;
				m_buffer_len = 0;
				m_pdata_start = m_buffer;
				m_pdata_end = m_pdata_start;
				return;
			}
			else
			{
				assert(false && "invalid buffer");
				return;
			}
		}
		else
		{
			if (len <= 1)
			{
				assert(false && "invalid buffer");
				return;
			}
		}

		if (pdatastart < pbuffer || pdatastart >= static_cast<T*>(pbuffer) + len)
		{
			assert(false && "bad datastart");
			return;
		}

		if (pdataend < pbuffer || pdataend >= static_cast<T*>(pbuffer) + len)
		{
			assert(false && "bad dataend");
			return;
		}

		m_buffer      = static_cast<T*>(pbuffer);
		m_buffer_len  = len;
		m_pdata_start = static_cast<T*>(pdatastart);
		m_pdata_end   = static_cast<T*>(pdataend);

		if (m_pdata_start == m_pdata_end)
		{
			m_pdata_start = m_buffer;
			m_pdata_end = m_pdata_start;
		}
	}

	bool internal_verify() const
	{
		return _verify();
	}

	ssize_t capacity() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return _capacity();
	}

	bool empty_capacity() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return _capacity() <= 0;
	}

	bool store_whole(const void *pdata, ssize_t nbytes)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return _store_whole(pdata, nbytes);
	}

	bool store_whole(const std::string &str)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return _store_whole(str.c_str(), (ssize_t)str.size());
	}

	template <class K>
	bool store_whole(const ringbuf<K> &buf)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		ssize_t bufsz = buf._size();
		if (bufsz <= 0)
		{
			m_pdata_start = m_buffer;
			m_pdata_end = m_pdata_start;
			return true;
		}

		if (_capacity() < bufsz)
			return false;

		m_pdata_start = m_buffer;
		m_pdata_end = m_pdata_start;

		if (buf.m_pdata_end >= buf.m_pdata_start)
			std::copy(buf.m_pdata_start, buf.m_pdata_end, m_pdata_end);
		else
		{
			ssize_t sz_r = buf.m_buffer + buf.m_buffer_len - buf.m_pdata_start;
			ssize_t sz_l = buf.m_pdata_end - buf.m_buffer;

			if (sz_r <= 0 || sz_l < 0 || sz_r + sz_l != bufsz)
				assert(false && "buf error");

			std::copy(buf.m_pdata_start, buf.m_pdata_start + sz_r, m_pdata_end);
			if (sz_l > 0)
				std::copy(buf.m_buffer, buf.m_pdata_end, m_pdata_end + sz_r);
		}

		m_pdata_end += bufsz;
		return true;
	}

	template <class K>
	bool store_whole(const dlgtringbuf<K> &buf)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(static_cast<const void *>(&buf) == this))
			assert(false && "store myself");
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		ssize_t bufsz = buf._size();
		if (bufsz <= 0)
		{
			m_pdata_start = m_buffer;
			m_pdata_end = m_pdata_start;
			return true;
		}

		if (_capacity() < bufsz)
			return false;

		m_pdata_start = m_buffer;
		m_pdata_end = m_pdata_start;

		if (buf.m_pdata_end >= buf.m_pdata_start)
			std::copy(buf.m_pdata_start, buf.m_pdata_end, m_pdata_end);
		else
		{
			ssize_t sz_r = buf.m_buffer + buf.m_buffer_len - buf.m_pdata_start;
			ssize_t sz_l = buf.m_pdata_end - buf.m_buffer;

			if (sz_r <= 0 || sz_l < 0 || sz_r + sz_l != bufsz)
				assert(false && "buf error");

			std::copy(buf.m_pdata_start, buf.m_pdata_start + sz_r, m_pdata_end);
			if (sz_l > 0)
				std::copy(buf.m_buffer, buf.m_pdata_end, m_pdata_end + sz_r);
		}

		m_pdata_end += bufsz;
		return true;
	}

	template <class K>
	bool store_whole(const linearbuf<K> &buf)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		return _store_whole(buf.m_pdata_start, buf.m_pdata_end - buf.m_pdata_start);
	}

	template <class K>
	bool store_whole(const dlgtlinbuf<K> &buf)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		return _store_whole(buf.m_pdata_start, buf.m_pdata_end - buf.m_pdata_start);
	}

	ssize_t append(const void *pdata, ssize_t nbytes)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (nbytes == 0)
			return 0;

		if (pdata == nullptr || nbytes < 0)
		{
			assert(false && "invalid param");
			return 0;
		}

		if (_space_left() <= 0)
			return 0;

		ssize_t apndn = _append_forward_entire(static_cast<const T*>(pdata), nbytes);

		if (apndn > nbytes)
			assert(false && "append too much");

		return apndn;
	}

	template <class K>
	ssize_t append(const ringbuf<K> &buf, ssize_t max_bytes = 0)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		if (buf.m_pdata_start == buf.m_pdata_end)
			return 0;

		if (buf.m_pdata_end >= buf.m_pdata_start)
		{
			ssize_t sz = buf.m_pdata_end - buf.m_pdata_start;
			if (max_bytes > 0 && max_bytes < sz)
				sz = max_bytes;

			ssize_t apndn = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), sz);

			if (apndn > sz)
				assert(false && "append too much");

			return apndn;
		}
		else
		{
			ssize_t sz_r = buf.m_buffer + buf.m_buffer_len - buf.m_pdata_start;
			ssize_t sz_l = buf.m_pdata_end - buf.m_buffer;

			if (sz_r <= 0 || sz_l < 0)
				assert(false && "buf error");

			if (max_bytes > 0)
			{
				if (max_bytes <= sz_r)
				{
					sz_r = max_bytes;
					sz_l = 0;
				}
				else if (max_bytes <= sz_r + sz_l)
				{
					sz_l = max_bytes - sz_r;
				}
			}

			ssize_t apndn_1 = 0;
			ssize_t apndn_2 = 0;

			if (sz_r > 0)
				apndn_1 = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), sz_r);
			if (sz_l > 0)
				apndn_2 = _append_forward_entire(reinterpret_cast<const T*>(buf.m_buffer), sz_l);

			if (apndn_1 + apndn_2 > sz_r + sz_l)
				assert(false && "append too much");

			return apndn_1 + apndn_2;
		}
	}

	template <class K>
	ssize_t append(const dlgtringbuf<K> &buf, ssize_t max_bytes = 0)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(static_cast<void *>(&buf) == this))
			assert(false && "append myself");
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		if (buf.m_pdata_start == buf.m_pdata_end)
			return 0;

		if (buf.m_pdata_end >= buf.m_pdata_start)
		{
			ssize_t sz = buf.m_pdata_end - buf.m_pdata_start;
			if (max_bytes > 0 && max_bytes < sz)
				sz = max_bytes;

			ssize_t apndn = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), sz);

			if (apndn > sz)
				assert(false && "append too much");

			return apndn;
		}
		else
		{
			ssize_t sz_r = buf.m_buffer + buf.m_buffer_len - buf.m_pdata_start;
			ssize_t sz_l = buf.m_pdata_end - buf.m_buffer;

			if (sz_r <= 0 || sz_l < 0)
				assert(false && "buf error");

			if (max_bytes > 0)
			{
				if (max_bytes <= sz_r)
				{
					sz_r = max_bytes;
					sz_l = 0;
				}
				else if (max_bytes <= sz_r + sz_l)
				{
					sz_l = max_bytes - sz_r;
				}
			}

			ssize_t apndn_1 = 0;
			ssize_t apndn_2 = 0;

			if (sz_r > 0)
				apndn_1 = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), sz_r);
			if (sz_l > 0)
				apndn_2 = _append_forward_entire(reinterpret_cast<const T*>(buf.m_buffer), sz_l);

			if (apndn_1 + apndn_2 > sz_r + sz_l)
				assert(false && "append too much");

			return apndn_1 + apndn_2;
		}
	}

	template <class K>
	ssize_t append(const linearbuf<K> &buf, ssize_t max_bytes = 0)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "rnbuf verify error");
		if (evunlike(!buf._verify()))
			assert(false && "lnbuf verify error");

		ssize_t apndsz = buf._size();
		if (apndsz <= 0)
			return 0;

		if (max_bytes > 0 && max_bytes < apndsz)
			apndsz = max_bytes;

		if (_space_left() <= 0)
			return 0;

		ssize_t apndn = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), apndsz);
		if (apndn > apndsz)
			assert(false && "append too much");

		return apndn;
	}

	template <class K>
	ssize_t append(const dlgtlinbuf<K> &buf, ssize_t max_bytes = 0)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "rnbuf verify error");
		if (evunlike(!buf._verify()))
			assert(false && "lnbuf verify error");

		ssize_t apndsz = buf._size();
		if (apndsz <= 0)
			return 0;

		if (max_bytes > 0 && max_bytes < apndsz)
			apndsz = max_bytes;

		if (_space_left() <= 0)
			return 0;

		ssize_t apndn = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), apndsz);
		if (apndn > apndsz)
			assert(false && "append too much");

		return apndn;
	}

	bool append_whole(const void *pdata, ssize_t nbytes)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (nbytes == 0)
			return true;

		if (pdata == nullptr || nbytes < 0)
		{
			assert(false && "invalid param");
			return false;
		}

		if (_space_left() < nbytes)
			return false;

		const T* pdata_c = static_cast<const T*>(pdata);

		ssize_t apndn_1 = 0;
		ssize_t apndn_2 = 0;

		apndn_1 = _append_forward(pdata_c, nbytes);
		if (apndn_1 < nbytes)
			apndn_2 = _append_forward(pdata_c + apndn_1, nbytes - apndn_1);

		if (apndn_1 + apndn_2 != nbytes)
			assert(false && "append error");

		return true;
	}

	template <class K>
	bool append_whole(const ringbuf<K> &buf)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		if (_space_left() < buf._size())
			return false;

		if (buf.m_pdata_start == buf.m_pdata_end)
			return true;

		if (buf.m_pdata_end > buf.m_pdata_start)
		{
			ssize_t sz    = buf.m_pdata_end - buf.m_pdata_start;
			ssize_t apndn = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), sz);

			if (apndn != sz)
				assert(false && "append error");
		}
		else
		{
			ssize_t sz_r = buf.m_buffer + buf.m_buffer_len - buf.m_pdata_start;
			ssize_t sz_l = buf.m_pdata_end - buf.m_buffer;

			if (sz_r <= 0 || sz_l < 0)
				assert(false && "buf error");

			ssize_t apndn_1 = 0;
			ssize_t apndn_2 = 0;

			if (sz_r > 0)
				apndn_1 = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), sz_r);
			if (sz_l > 0)
				apndn_2 = _append_forward_entire(reinterpret_cast<const T*>(buf.m_buffer), sz_l);

			if (apndn_1 + apndn_2 != sz_r + sz_l)
				assert(false && "append error");
		}

		return true;
	}

	template <class K>
	bool append_whole(const dlgtringbuf<K> &buf)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(static_cast<void *>(&buf) == this))
			assert(false && "append myself");
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		if (_space_left() < buf._size())
			return false;

		if (buf.m_pdata_start == buf.m_pdata_end)
			return true;

		if (buf.m_pdata_end > buf.m_pdata_start)
		{
			ssize_t sz    = buf.m_pdata_end - buf.m_pdata_start;
			ssize_t apndn = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), sz);

			if (apndn != sz)
				assert(false && "append error");
		}
		else
		{
			ssize_t sz_r = buf.m_buffer + buf.m_buffer_len - buf.m_pdata_start;
			ssize_t sz_l = buf.m_pdata_end - buf.m_buffer;

			if (sz_r <= 0 || sz_l < 0)
				assert(false && "buf error");

			ssize_t apndn_1 = 0;
			ssize_t apndn_2 = 0;

			if (sz_r > 0)
				apndn_1 = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), sz_r);
			if (sz_l > 0)
				apndn_2 = _append_forward_entire(reinterpret_cast<const T*>(buf.m_buffer), sz_l);

			if (apndn_1 + apndn_2 != sz_r + sz_l)
				assert(false && "append error");
		}

		return true;
	}

	template <class K>
	bool append_whole(const linearbuf<K> &buf)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "rnbuf verify error");
		if (evunlike(!buf._verify()))
			assert(false && "lnbuf verify error");

		ssize_t apndsz = buf._size();
		if (apndsz <= 0)
			return true;

		if (_space_left() < apndsz)
			return false;

		ssize_t apndn = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), apndsz);

		if (apndn != apndsz)
			assert(false && "append error");

		return true;
	}

	template <class K>
	bool append_whole(const dlgtlinbuf<K> &buf)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "rnbuf verify error");
		if (evunlike(!buf._verify()))
			assert(false && "lnbuf verify error");

		ssize_t apndsz = buf._size();
		if (apndsz <= 0)
			return true;

		if (_space_left() < apndsz)
			return false;

		ssize_t apndn = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), apndsz);

		if (apndn != apndsz)
			assert(false && "append error");

		return true;
	}

	template <class K>
	ssize_t eat(ringbuf<K> &buf, ssize_t max_bytes = 0)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		if (buf.m_pdata_start == buf.m_pdata_end)
			return 0;

		if (buf.m_pdata_end >= buf.m_pdata_start)
		{
			ssize_t sz = buf.m_pdata_end - buf.m_pdata_start;
			if (max_bytes > 0 && max_bytes < sz)
				sz = max_bytes;

			ssize_t eatn = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), sz);

			if (eatn > sz)
				assert(false && "append too much");

			buf._start_forward(eatn);
			return eatn;
		}
		else
		{
			ssize_t sz_r = buf.m_buffer + buf.m_buffer_len - buf.m_pdata_start;
			ssize_t sz_l = buf.m_pdata_end - buf.m_buffer;

			if (sz_r <= 0 || sz_l < 0)
				assert(false && "buf error");

			if (max_bytes > 0)
			{
				if (max_bytes <= sz_r)
				{
					sz_r = max_bytes;
					sz_l = 0;
				}
				else if (max_bytes <= sz_r + sz_l)
				{
					sz_l = max_bytes - sz_r;
				}
			}

			ssize_t eatn_1 = 0;
			ssize_t eatn_2 = 0;

			if (sz_r > 0)
				eatn_1 = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), sz_r);
			if (sz_l > 0)
				eatn_2 = _append_forward_entire(reinterpret_cast<const T*>(buf.m_buffer), sz_l);

			if (eatn_1 + eatn_2 > sz_r + sz_l)
				assert(false && "append too much");

			buf._start_forward(eatn_1 + eatn_2);
			return eatn_1 + eatn_2;
		}
	}

	template <class K>
	ssize_t eat(dlgtringbuf<K> &buf, ssize_t max_bytes = 0)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(static_cast<void *>(&buf) == this))
			assert(false && "eat myself");
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		if (buf.m_pdata_start == buf.m_pdata_end)
			return 0;

		if (buf.m_pdata_end >= buf.m_pdata_start)
		{
			ssize_t sz = buf.m_pdata_end - buf.m_pdata_start;
			if (max_bytes > 0 && max_bytes < sz)
				sz = max_bytes;

			ssize_t eatn = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), sz);

			if (eatn > sz)
				assert(false && "append too much");

			buf._start_forward(eatn);
			return eatn;
		}
		else
		{
			ssize_t sz_r = buf.m_buffer + buf.m_buffer_len - buf.m_pdata_start;
			ssize_t sz_l = buf.m_pdata_end - buf.m_buffer;

			if (sz_r <= 0 || sz_l < 0)
				assert(false && "buf error");

			if (max_bytes > 0)
			{
				if (max_bytes <= sz_r)
				{
					sz_r = max_bytes;
					sz_l = 0;
				}
				else if (max_bytes <= sz_r + sz_l)
				{
					sz_l = max_bytes - sz_r;
				}
			}

			ssize_t eatn_1 = 0;
			ssize_t eatn_2 = 0;

			if (sz_r > 0)
				eatn_1 = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), sz_r);
			if (sz_l > 0)
				eatn_2 = _append_forward_entire(reinterpret_cast<const T*>(buf.m_buffer), sz_l);

			if (eatn_1 + eatn_2 > sz_r + sz_l)
				assert(false && "append too much");

			buf._start_forward(eatn_1 + eatn_2);
			return eatn_1 + eatn_2;
		}
	}

	template <class K>
	ssize_t eat(linearbuf<K> &buf, ssize_t max_bytes = 0)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "rnbuf verify error");
		if (evunlike(!buf._verify()))
			assert(false && "lnbuf verify error");

		ssize_t eatsz = buf._size();
		if (eatsz <= 0)
			return 0;

		if (max_bytes > 0 && max_bytes < eatsz)
			eatsz = max_bytes;

		if (_space_left() <= 0)
			return 0;

		ssize_t eatn = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), eatsz);
		if (eatn > eatsz)
			assert(false && "append too much");

		buf.m_pdata_start += eatn;
		if (buf.m_pdata_start >= buf.m_pdata_end)
		{
			buf.m_pdata_start = buf.m_buffer;
			buf.m_pdata_end = buf.m_pdata_start;
		}

		return eatn;
	}

	template <class K>
	ssize_t eat(dlgtlinbuf<K> &buf, ssize_t max_bytes = 0)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "rnbuf verify error");
		if (evunlike(!buf._verify()))
			assert(false && "lnbuf verify error");

		ssize_t eatsz = buf._size();
		if (eatsz <= 0)
			return 0;

		if (max_bytes > 0 && max_bytes < eatsz)
			eatsz = max_bytes;

		if (_space_left() <= 0)
			return 0;

		ssize_t eatn = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), eatsz);
		if (eatn > eatsz)
			assert(false && "append too much");

		buf.m_pdata_start += eatn;
		if (buf.m_pdata_start >= buf.m_pdata_end)
		{
			buf.m_pdata_start = buf.m_buffer;
			buf.m_pdata_end = buf.m_pdata_start;
		}

		return eatn;
	}

	template <class K>
	bool eat_whole(ringbuf<K> &buf)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		if (_space_left() < buf._size())
			return false;

		if (buf.m_pdata_start == buf.m_pdata_end)
			return true;

		if (buf.m_pdata_end > buf.m_pdata_start)
		{
			ssize_t sz   = buf.m_pdata_end - buf.m_pdata_start;
			ssize_t eatn = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), sz);

			if (eatn != sz)
				assert(false && "append error");

			buf._start_forward(eatn);
		}
		else
		{
			ssize_t sz_r = buf.m_buffer + buf.m_buffer_len - buf.m_pdata_start;
			ssize_t sz_l = buf.m_pdata_end - buf.m_buffer;

			if (sz_r <= 0 || sz_l < 0)
				assert(false && "buf error");

			ssize_t eatn_1 = 0;
			ssize_t eatn_2 = 0;

			if (sz_r > 0)
				eatn_1 = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), sz_r);
			if (sz_l > 0)
				eatn_2 = _append_forward_entire(reinterpret_cast<const T*>(buf.m_buffer), sz_l);

			if (eatn_1 + eatn_2 != sz_r + sz_l)
				assert(false && "append error");

			buf._start_forward(eatn_1 + eatn_2);
		}

		return true;
	}

	template <class K>
	bool eat_whole(dlgtringbuf<K> &buf)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(static_cast<void *>(&buf) == this))
			assert(false && "eat myself");
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		if (_space_left() < buf._size())
			return false;

		if (buf.m_pdata_start == buf.m_pdata_end)
			return true;

		if (buf.m_pdata_end > buf.m_pdata_start)
		{
			ssize_t sz   = buf.m_pdata_end - buf.m_pdata_start;
			ssize_t eatn = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), sz);

			if (eatn != sz)
				assert(false && "append error");

			buf._start_forward(eatn);
		}
		else
		{
			ssize_t sz_r = buf.m_buffer + buf.m_buffer_len - buf.m_pdata_start;
			ssize_t sz_l = buf.m_pdata_end - buf.m_buffer;

			if (sz_r <= 0 || sz_l < 0)
				assert(false && "buf error");

			ssize_t eatn_1 = 0;
			ssize_t eatn_2 = 0;

			if (sz_r > 0)
				eatn_1 = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), sz_r);
			if (sz_l > 0)
				eatn_2 = _append_forward_entire(reinterpret_cast<const T*>(buf.m_buffer), sz_l);

			if (eatn_1 + eatn_2 != sz_r + sz_l)
				assert(false && "append error");

			buf._start_forward(eatn_1 + eatn_2);
		}

		return true;
	}

	template <class K>
	bool eat_whole(linearbuf<K> &buf)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "rnbuf verify error");
		if (evunlike(!buf._verify()))
			assert(false && "lnbuf verify error");

		ssize_t eatsz = buf._size();
		if (eatsz <= 0)
			return true;

		if (_space_left() < eatsz)
			return false;

		ssize_t eatn = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), eatsz);

		if (eatn != eatsz)
			assert(false && "append error");

		buf.m_pdata_start = buf.m_buffer;
		buf.m_pdata_end = buf.m_pdata_start;

		return true;
	}

	template <class K>
	bool eat_whole(dlgtlinbuf<K> &buf)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "rnbuf verify error");
		if (evunlike(!buf._verify()))
			assert(false && "lnbuf verify error");

		ssize_t eatsz = buf._size();
		if (eatsz <= 0)
			return true;

		if (_space_left() < eatsz)
			return false;

		ssize_t eatn = _append_forward_entire(reinterpret_cast<const T*>(buf.m_pdata_start), eatsz);

		if (eatn != eatsz)
			assert(false && "append error");

		buf.m_pdata_start = buf.m_buffer;
		buf.m_pdata_end = buf.m_pdata_start;

		return true;
	}

	ssize_t shit(ssize_t nbytes)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (nbytes == 0)
			return 0;

		if (nbytes < 0)
		{
			assert(false && "negative nbytes");
			return 0;
		}

		ssize_t shit_bytes = _size();
		if (shit_bytes <= 0)
			return 0;

		if (shit_bytes > nbytes)
			shit_bytes = nbytes;

		_start_forward(shit_bytes);
		return shit_bytes;
	}

	bool shit_whole(ssize_t nbytes)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (nbytes == 0)
			return true;

		if (nbytes < 0)
		{
			assert(false && "negative nbytes");
			return false;
		}

		if (nbytes > _size())
			return false;

		_start_forward(nbytes);
		return true;
	}

	ssize_t shit_to(ssize_t nbytes)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (nbytes < 0)
		{
			assert(false && "negative nbytes");
			return 0;
		}

		ssize_t shtsz = _size();

		if (nbytes > 0)
			shtsz -= nbytes;
		if (shtsz < 0)
			shtsz = 0;

		if (shtsz > 0)
			_start_forward(shtsz);

		return shtsz;
	}

	int compare(const void *pdata, ssize_t nbytes) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return _compare(pdata, nbytes);
	}

	int compare(const std::string &str) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return _compare(str.c_str(), (ssize_t)str.size());
	}

	template <class K>
	int compare(const dlgtringbuf<K> &buf) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");
		if (static_cast<const void *>(&buf) == this)
			assert(false && "self compare");

		return _compare(buf);
	}

	void clear()
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		m_pdata_start = m_buffer;
		m_pdata_end = m_pdata_start;
	}

	ssize_t size() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return _size();
	}

	bool empty() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return m_pdata_start == m_pdata_end;
	}

	bool full() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (_capacity() <= 0)
			return true;
		else
		{
			const T* p_end_next = m_pdata_end + 1;
			if (p_end_next >= m_buffer + m_buffer_len)
				p_end_next = m_buffer;

			return p_end_next == m_pdata_start;
		}
	}

	ssize_t space() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return _space_left();
	}

	ssize_t headspace() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return _head_space();
	}

	ssize_t headsize() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return _head_size();
	}

	const T& at(ssize_t index) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (evunlike(index < 0 || index >= _size()))
			assert(false && "index out of bounds");

		return _at(index);
	}

	T& at(ssize_t index)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (evunlike(index < 0 || index >= _size()))
			assert(false && "index out of bounds");

		return _at(index);
	}

	const T& operator [] (ssize_t index) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (evunlike(index < 0 || index >= _size()))
			assert(false && "index out of bounds");

		return _at(index);
	}

	T& operator [] (ssize_t index)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (evunlike(index < 0 || index >= _size()))
			assert(false && "index out of bounds");

		return _at(index);
	}

	const T* dataptr() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return m_pdata_start;
	}

	const T* headptr() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return m_pdata_end;
	}

	T* headptr()
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return m_pdata_end;
	}

	ssize_t head_eaten(ssize_t nbytes)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (nbytes == 0)
			return 0;

		if (nbytes < 0)
		{
			assert(false && "negative nbytes");
			return 0;
		}

		ssize_t maxsize = _head_space();
		if (nbytes > maxsize)
			nbytes = maxsize;

		if (nbytes > 0)
			_end_forward(nbytes);

		return nbytes;
	}

	bool head_eaten_whole(ssize_t nbytes)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (nbytes < 0)
		{
			assert(false && "negative nbytes");
			return false;
		}

		if (nbytes > _head_space())
			return false;

		if (nbytes > 0)
			_end_forward(nbytes);

		return true;
	}

	ssize_t forward_eaten(ssize_t nbytes)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (nbytes == 0)
			return 0;

		if (nbytes < 0)
		{
			assert(false && "negative nbytes");
			return 0;
		}

		ssize_t maxsize = _space_left();
		if (nbytes > maxsize)
			nbytes = maxsize;

		if (nbytes > 0)
			_end_forward(nbytes);

		return nbytes;
	}

	bool forward_eaten_whole(ssize_t nbytes)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (nbytes < 0)
		{
			assert(false && "negative nbytes");
			return false;
		}

		if (nbytes > _space_left())
			return false;

		if (nbytes > 0)
			_end_forward(nbytes);

		return true;
	}

	ssize_t copy_out(void *pbuf, ssize_t nbytes, ssize_t from_pos = 0) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (from_pos < 0)
		{
			assert(false && "negative frompos");
			return 0;
		}

		if (nbytes == 0)
			return 0;

		if (pbuf == nullptr || nbytes < 0)
		{
			assert(false && "invalid param");
			return 0;
		}

		ssize_t sz = _size();
		if (from_pos >= sz)
			return 0;

		T* pbuf_c = static_cast<T*>(pbuf);

		ssize_t cp_1 = 0;
		ssize_t cp_2 = 0;

		cp_1 = _copy_out_1(pbuf_c, nbytes, from_pos);
		if (cp_1 < nbytes)
			cp_2 = _copy_out_2(pbuf_c + cp_1, nbytes - cp_1, from_pos);

		return cp_1 + cp_2;
	}

	bool copy_out_whole(void *pbuf, ssize_t nbytes, ssize_t from_pos = 0) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (from_pos < 0)
		{
			assert(false && "negative frompos");
			return false;
		}

		if (nbytes == 0)
			return false;

		if (pbuf == nullptr || nbytes < 0)
		{
			assert(false && "invalid param");
			return false;
		}

		ssize_t sz = _size();
		if (from_pos >= sz)
			return false;
		if (nbytes > sz - from_pos)
			return false;

		T *pbuf_c = static_cast<T*>(pbuf);

		ssize_t cp_1 = 0;
		ssize_t cp_2 = 0;

		cp_1 = _copy_out_1(pbuf_c, nbytes, from_pos);
		if (cp_1 < nbytes)
			cp_2 = _copy_out_2(pbuf_c + cp_1, nbytes - cp_1, from_pos);

		if (cp_1 + cp_2 != nbytes)
			assert(false && "copy bytes error");

		return true;
	}

	ssize_t find(T c, ssize_t from_pos = 0, ssize_t max_search_bytes = 0) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (from_pos < 0)
		{
			assert(false && "negative frompos");
			return -1;
		}

		ssize_t endpos = _size();

		if (from_pos < 0 || from_pos >= endpos)
			return -1;

		if (max_search_bytes > 0 && from_pos + max_search_bytes < endpos)
			endpos = from_pos + max_search_bytes;

		for (ssize_t i = from_pos; i < endpos; i++)
		{
			if (_at(i) == c)
				return i;
		}

		return -1;
	}

	ssize_t finds(const void *pmatch, ssize_t match_bytes, ssize_t from_pos = 0, ssize_t max_search_bytes = 0) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (from_pos < 0)
		{
			assert(false && "negative frompos");
			return -1;
		}

		if (match_bytes == 0)
			return -1;

		if (pmatch == nullptr || match_bytes < 0)
		{
			assert(false && "invalid match bytes");
			return -1;
		}

		ssize_t endpos = _size();

		if (from_pos < 0 || from_pos >= endpos)
			return -1;

		if (max_search_bytes > 0 && from_pos + max_search_bytes < endpos)
			endpos = from_pos + max_search_bytes;

		const T* pmatch_c = static_cast<const T*>(pmatch);

		for (ssize_t i = from_pos; i < endpos - match_bytes + 1; i++)
		{
			ssize_t j;
			for (j = 0; j < match_bytes; j++)
			{
				if (pmatch_c[j] != _at(i + j))
					break;
			}
			if (j >= match_bytes)
				return i;
		}

		return -1;
	}

	template <class K>
	void swap(dlgtringbuf<K> &buf)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		if (evunlike(static_cast<void *>(&buf) == this))
			return;

		ssize_t buffer_len  = m_buffer_len;
		T*      buffer      = m_buffer;
		T*      pdata_start = m_pdata_start;
		T*      pdata_end   = m_pdata_end;

		m_buffer_len  = buf.m_buffer_len;
		m_buffer      = reinterpret_cast<T*>(buf.m_buffer);
		m_pdata_start = reinterpret_cast<T*>(buf.m_pdata_start);
		m_pdata_end   = reinterpret_cast<T*>(buf.m_pdata_end);

		buf.m_buffer_len  = buffer_len;
		buf.m_buffer      = reinterpret_cast<K*>(buffer);
		buf.m_pdata_start = reinterpret_cast<K*>(pdata_start);
		buf.m_pdata_end   = reinterpret_cast<K*>(pdata_end);
	}

	template <class K>
	linearbuf<K> minlinear_clone() const
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "verify error");

		linearbuf<K> buf;

		ssize_t datasz = _size();
		if (datasz > 0)
		{
			K *buffer = new K[datasz];
			if (buffer == nullptr)
				throw simpexception("malloc failed");
			else
			{
				if (m_pdata_end >= m_pdata_start)
				{
					if (m_pdata_end - m_pdata_start != datasz)
						assert(false && "size error");

					std::copy(m_pdata_start, m_pdata_end, buffer);
					buf.m_buffer      = buffer;
					buf.m_buffer_len  = datasz;
					buf.m_pdata_start = buf.m_buffer;
					buf.m_pdata_end   = buf.m_pdata_start + datasz;
				}
				else
				{
					ssize_t sz_r = m_buffer + m_buffer_len - m_pdata_start;
					ssize_t sz_l = m_pdata_end - m_buffer;

					if (sz_r <= 0 || sz_l < 0)
						assert(false && "buf error");
					if (sz_r + sz_l != datasz)
						assert(false && "size error");

					std::copy(m_pdata_start, m_pdata_start + sz_r, buffer);
					if (sz_l > 0)
						std::copy(m_buffer, m_pdata_end, buffer + sz_r);

					buf.m_buffer      = buffer;
					buf.m_buffer_len  = datasz;
					buf.m_pdata_start = buf.m_buffer;
					buf.m_pdata_end   = buf.m_pdata_start + datasz;
				}
			}
		}

		return buf;
	}

	template <class K>
	ringbuf<K> minring_clone() const
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "verify error");

		ringbuf<K> buf;

		ssize_t datasz = _size();
		if (datasz > 0)
		{
			K *buffer = new K[datasz + 1];
			if (buffer == nullptr)
				throw simpexception("malloc failed");
			else
			{
				if (m_pdata_end >= m_pdata_start)
				{
					if (m_pdata_end - m_pdata_start != datasz)
						assert(false && "size error");

					std::copy(m_pdata_start, m_pdata_end, buffer);
					buf.m_buffer      = buffer;
					buf.m_buffer_len  = datasz + 1;
					buf.m_pdata_start = buf.m_buffer;
					buf.m_pdata_end   = buf.m_pdata_start + datasz;
				}
				else
				{
					ssize_t sz_r = m_buffer + m_buffer_len - m_pdata_start;
					ssize_t sz_l = m_pdata_end - m_buffer;

					if (sz_r <= 0 || sz_l < 0)
						assert(false && "buf error");
					if (sz_r + sz_l != datasz)
						assert(false && "size error");

					std::copy(m_pdata_start, m_pdata_start + sz_r, buffer);
					if (sz_l > 0)
						std::copy(m_buffer, m_pdata_end, buffer + sz_r);

					buf.m_buffer      = buffer;
					buf.m_buffer_len  = datasz + 1;
					buf.m_pdata_start = buf.m_buffer;
					buf.m_pdata_end   = buf.m_pdata_start + datasz;
				}
			}
		}

		return buf;
	}

	std::string tostring(ssize_t max_size = 0) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		std::string s;

		if (m_pdata_end > m_pdata_start)
		{
			ssize_t sz = m_pdata_end - m_pdata_start;
			if (max_size > 0 && max_size < sz)
				sz = max_size;

			s.assign(reinterpret_cast<const char *>(m_pdata_start), sz);
		}
		else if (m_pdata_end < m_pdata_start)
		{
			ssize_t r_sz = m_buffer + m_buffer_len - m_pdata_start;
			ssize_t l_sz = m_pdata_end - m_buffer;

			if (r_sz <= 0 || l_sz < 0)
				assert(false && "bad buffer");

			const char *pdatastart = reinterpret_cast<const char *>(m_pdata_start);
			const char *buffer = reinterpret_cast<const char *>(m_buffer);

			if (max_size <= 0)
			{
				s.append(pdatastart, r_sz);
				if (l_sz > 0)
					s.append(buffer, l_sz);
			}
			else if (max_size <= r_sz)
			{
				s.assign(pdatastart, max_size);
			}
			else if (max_size <= r_sz + l_sz)
			{
				s.append(pdatastart, r_sz);
				s.append(buffer, max_size - r_sz);
			}
			else
			{
				s.append(pdatastart, r_sz);
				if (l_sz > 0)
					s.append(buffer, l_sz);
			}
		}

		return s;
	}

private:
	template <class K>
	dlgtringbuf(const dlgtringbuf<K> &that, int)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!that._verify()))
			assert(false && "that verify error");

		m_buffer      = reinterpret_cast<T*>(that.m_buffer);
		m_buffer_len  = that.m_buffer_len;
		m_pdata_start = reinterpret_cast<T*>(that.m_pdata_start);
		m_pdata_end   = reinterpret_cast<T*>(that.m_pdata_end);
	}

	template <class K>
	dlgtringbuf(dlgtringbuf<K> &&that, int) noexcept
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!that._verify()))
			assert(false && "that verify error");

		m_buffer      = reinterpret_cast<T*>(that.m_buffer);
		m_buffer_len  = that.m_buffer_len;
		m_pdata_start = reinterpret_cast<T*>(that.m_pdata_start);
		m_pdata_end   = reinterpret_cast<T*>(that.m_pdata_end);
	}

	bool _verify() const
	{
		if (m_buffer_len > 1)
		{
			if (m_buffer == nullptr)
				return false;
			if (m_pdata_start < m_buffer || m_pdata_start >= m_buffer + m_buffer_len)
				return false;
			if (m_pdata_end < m_buffer || m_pdata_end >= m_buffer + m_buffer_len)
				return false;
		}
		else if (m_buffer_len == 1)
			return false;
		else if (m_buffer_len == 0)
		{
			if (m_buffer != nullptr || m_pdata_start != nullptr || m_pdata_end != nullptr)
				return false;
		}
		else
		{
			return false;
		}

		return true;
	}

	ssize_t _capacity() const
	{
		if (m_buffer_len <= 1)
			return 0;

		return m_buffer_len - 1;
	}

	ssize_t _size() const
	{
		ssize_t sz = 0;

		if (m_buffer_len <= 1)
			sz = 0;
		else
		{
			if (m_pdata_end >= m_pdata_start)
				sz = m_pdata_end - m_pdata_start;
			else
				sz = m_buffer_len - (m_pdata_start - m_pdata_end);
		}

		if (evunlike(sz < 0))
			assert(false && "size negative");

		if (evunlike(m_buffer_len > 0 && sz >= m_buffer_len))
			assert(false && "size too large");

		return sz;
	}

	ssize_t _space_left() const
	{
		ssize_t sp = 0;

		if (m_buffer_len <= 1)
			sp = 0;
		else
		{
			if (m_pdata_end < m_pdata_start)
				sp = m_pdata_start - m_pdata_end - 1;
			else
				sp = m_buffer_len - (m_pdata_end - m_pdata_start) - 1;
		}

		if (evunlike(sp < 0))
			assert(false && "space negative");

		if (evunlike(m_buffer_len > 0 && sp >= m_buffer_len))
			assert(false && "space too large");

		return sp;
	}

	ssize_t _head_space() const
	{
		ssize_t sp = 0;

		if (m_buffer_len <= 1)
			sp = 0;
		else
		{
			if (m_pdata_end < m_pdata_start)
				sp = m_pdata_start - m_pdata_end - 1;
			else
			{
				if (m_pdata_start <= m_buffer)
					sp = m_buffer + m_buffer_len - m_pdata_end - 1;
				else
					sp = m_buffer + m_buffer_len - m_pdata_end;
			}
		}

		if (evunlike(sp < 0))
			assert(false && "space negative");

		return sp;
	}

	ssize_t _head_size() const
	{
		ssize_t sz = 0;

		if (m_buffer_len <= 1)
			sz = 0;
		else
		{
			if (m_pdata_end >= m_pdata_start)
				sz = m_pdata_end - m_pdata_start;
			else
				sz = m_buffer + m_buffer_len - m_pdata_start;
		}

		if (evunlike(sz < 0))
			assert(false && "size negative");

		return sz;
	}

	ssize_t _append_forward(const T* pdata, ssize_t nbytes)
	{
		if (m_buffer_len <= 1)
			return 0;
		else
		{
			ssize_t cp = 0;

			if (m_pdata_end >= m_pdata_start)
			{
				cp = m_buffer + m_buffer_len - m_pdata_end;
				if (cp > nbytes)
					cp = nbytes;
				else if (m_pdata_start <= m_buffer)
					--cp;
			}
			else
			{
				cp = m_pdata_start - m_pdata_end - 1;
				if (cp > nbytes)
					cp = nbytes;
			}

			if (cp > 0)
				std::copy(pdata, pdata + cp, m_pdata_end);
			else if (cp < 0)
				assert(false && "negative copy");

			if (cp > 0)
				_end_forward(cp);
			return cp;
		}
	}

	ssize_t _append_forward_entire(const T* pdata, ssize_t nbytes)
	{
		ssize_t eatn_1 = 0;
		ssize_t eatn_2 = 0;

		eatn_1 = _append_forward(pdata, nbytes);
		if (eatn_1 < nbytes)
			eatn_2 = _append_forward(pdata + eatn_1, nbytes - eatn_1);

		return eatn_1 + eatn_2;
	}

	void _start_forward(ssize_t nbytes)
	{
		if (m_buffer_len > 1)
		{
			ssize_t offset = (m_pdata_start - m_buffer + nbytes) % m_buffer_len;
			m_pdata_start = m_buffer + offset;

			if (m_pdata_start == m_pdata_end)
			{
				m_pdata_start = m_buffer;
				m_pdata_end = m_pdata_start;
			}
		}
		else
		{
			m_pdata_start = m_buffer;
		}
	}

	void _end_forward(ssize_t nbytes)
	{
		if (m_buffer_len > 1)
		{
			ssize_t offset = (m_pdata_end - m_buffer + nbytes) % m_buffer_len;
			m_pdata_end = m_buffer + offset;
		}
		else
		{
			m_pdata_end = m_buffer;
		}
	}

	const T& _at(ssize_t index) const
	{
		if (evlike(m_buffer_len > 1))
		{
			ssize_t offset = (m_pdata_start - m_buffer + index) % m_buffer_len;
			return m_buffer[offset];
		}
		else
		{
			assert(false && "empty buf");
			return *static_cast<const T*>(nullptr);
		}
	}

	T& _at(ssize_t index)
	{
		if (evlike(m_buffer_len > 1))
		{
			ssize_t offset = (m_pdata_start - m_buffer + index) % m_buffer_len;
			return m_buffer[offset];
		}
		else
		{
			assert(false && "empty buf");
			return *static_cast<T*>(nullptr);
		}
	}

	ssize_t _copy_out_1(T* pbuf, ssize_t nbytes, ssize_t from_pos) const
	{
		if (m_buffer_len > 1)
		{
			const T* cp_end = m_pdata_start;
			if (m_pdata_end >= m_pdata_start)
				cp_end = m_pdata_end;
			else
				cp_end = m_buffer + m_buffer_len;

			if (cp_end < m_pdata_start)
				assert(false && "buf internal error");

			const T* cp_start = m_pdata_start + from_pos;
			if (cp_start >= cp_end)
				return 0;

			ssize_t cp = cp_end - cp_start;
			if (cp > nbytes)
				cp = nbytes;

			std::copy(cp_start, cp_start + cp, pbuf);
			return cp;
		}

		return 0;
	}

	ssize_t _copy_out_2(T* pbuf, ssize_t nbytes, ssize_t from_pos) const
	{
		if (m_buffer_len > 1)
		{
			if (m_pdata_end < m_pdata_start)
			{
				const T* cp_start = m_pdata_start + from_pos;
				if (cp_start < m_buffer + m_buffer_len)
					cp_start = m_buffer;
				else
					cp_start -= m_buffer_len;

				if (cp_start >= m_pdata_end)
					return 0;

				ssize_t cp = m_pdata_end - cp_start;
				if (cp > nbytes)
					cp = nbytes;

				std::copy(cp_start, cp_start + cp, pbuf);
				return cp;
			}
		}

		return 0;
	}

	bool _store_whole(const void *pdata, ssize_t nbytes)
	{
		if (nbytes == 0)
		{
			m_pdata_start = m_buffer;
			m_pdata_end = m_pdata_start;
			return true;
		}

		if (pdata == nullptr || nbytes < 0)
		{
			assert(false && "invalid param");
			return false;
		}

		if (nbytes < m_buffer_len)
		{
			m_pdata_start = m_buffer;
			m_pdata_end = m_pdata_start;

			std::copy(static_cast<const T*>(pdata), static_cast<const T*>(pdata) + nbytes, m_pdata_end);
			m_pdata_end += nbytes;
			return true;
		}

		return false;
	}

	int _compare(const void *pdata, ssize_t nbytes) const
	{
		if (evunlike(nbytes < 0 || (pdata == nullptr && nbytes > 0)))
			assert(false && "invalid param");

		const T *tdata = static_cast<const T*>(pdata);

		ssize_t sz = _size();
		ssize_t len = sz > nbytes ? nbytes : sz;
		for (ssize_t i = 0; i < len; i++)
		{
			if (_at(i) == tdata[i])
				continue;

			if (_at(i) > tdata[i])
				return 1;
			return -1;
		}

		if (sz > nbytes)
			return 1;
		else if (sz < nbytes)
			return -1;

		return 0;
	}

	template <class K>
	int _compare(const dlgtringbuf<K> &buf) const
	{
		ssize_t sz = _size();
		ssize_t bsz = buf._size();
		ssize_t len = sz > bsz ? bsz : sz;
		for (ssize_t i = 0; i < len; i++)
		{
			if (_at(i) == static_cast<T>(buf._at(i)))
				continue;

			if (_at(i) > static_cast<T>(buf._at(i)))
				return 1;
			return -1;
		}

		if (sz > bsz)
			return 1;
		else if (sz < bsz)
			return -1;

		return 0;
	}

private:
	ssize_t  m_buffer_len;
	T*       m_buffer;
	T*       m_pdata_start;
	T*       m_pdata_end;
};


}


#endif


