

#ifndef __UVTL_ACCEPTOR_H__
#define __UVTL_ACCEPTOR_H__


namespace uvtl { namespace tcp {


template <class T>
class acceptor
{
public:
	acceptor()
	{}
};


} }


#endif


