

#ifndef __UVTL_EVENTLOOP_H__
#define __UVTL_EVENTLOOP_H__

#include <uv/uv.h>


namespace uvtl
{


class looprefer
{
public:
	looprefer(): m_loop(nullptr)
	{}

	looprefer(uv_loop_t *loop): m_loop(loop)
	{}

	looprefer(const looprefer &that) = default;
	looprefer& operator = (const looprefer &that) = default;

	bool operator == (const looprefer &that) const
	{
		return m_loop == that.m_loop;
	}

	bool operator != (const looprefer &that) const
	{
		return !(m_loop == that.m_loop);
	}

	bool is_null() const
	{
		return m_loop == nullptr;
	}

	operator uv_loop_t * () const
	{
		return m_loop;
	}

	uv_loop_t * ref() const
	{
		return m_loop;
	}

	uv_loop_t * raw_loop() const
	{
		return m_loop;
	}

	int run(uv_run_mode mode)
	{
		return ::uv_run(m_loop, mode);
	}

	bool is_alive() const
	{
		return uv_loop_alive(m_loop) != 0;
	}

private:
	uv_loop_t *m_loop;
};


}


#endif


