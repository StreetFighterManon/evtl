

#ifndef __EVCL_HTTP_RESPONSEFILTER_H__
#define __EVCL_HTTP_RESPONSEFILTER_H__

#include <sys/types.h>
#include <assert.h>

#include <cstdint>
#include <string>
#include <utility>
#include <type_traits>

#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_ringbuf.h>
#include <evtl/evtl_pcre2.h>


namespace evcl { namespace http {


struct content_length_forminfo
{
	content_length_forminfo(): totaldata_size(0), outputdata_size(0)
	{}

	void reset()
	{
		totaldata_size = 0;
		outputdata_size = 0;
	}

	int64_t totaldata_size;
	int64_t outputdata_size;
};

struct encode_chunked_forminfo
{
	encode_chunked_forminfo()
		: segment_ready(false), segment_size(0), segment_outputsize(0), reach_end(false),
		  chunked_totalsize(0), chunked_totalcount(0), output_totalsize(0)
	{}

	void reset()
	{
		segment_ready = false;
		segment_size = 0;
		segment_outputsize = 0;
		reach_end = false;

		chunked_totalsize = 0;
		chunked_totalcount = 0;
		output_totalsize = 0;
	}

	bool    segment_ready;
	int64_t segment_size;
	int64_t segment_outputsize;
	bool    reach_end;

	int64_t chunked_totalsize;
	int64_t chunked_totalcount;
	int64_t output_totalsize;
};


class responsefilter
{
public:
	enum statustype
	{
		status_allright,
		status_header_overflow,
		status_searchheader_exception,
		status_segsize_hexlen_zero,
		status_segsize_hexlen_overflow,
		status_segsize_negative,
		status_segsize_not_crlf_terminated,
		status_segment_not_crlf_terminated
	};

	enum dataform
	{
		dataform_unknown,
		dataform_content_length,
		dataform_encode_chunked
	};

	responsefilter(): m_response_code(0), m_content_length(0)
	{}

	void set_headbuf_size(int64_t size)
	{
		if (size < 1024)
			m_headbuf.reset_capacity(1024 + 128);
		else if (size > 1024*128)
			m_headbuf.reset_capacity(1024*128 + 128);
		else
			m_headbuf.reset_capacity(size + 128);
	}

	void set_databuf_size(int64_t size)
	{
		if (size < 1024)
			m_databuf.reset_capacity(1024);
		else
			m_databuf.reset_capacity(size);
	}

	ssize_t recvbuf_space() const
	{
		if (_get_status() != status_allright)
			return 0;

		if (!m_header.isset())
			return m_headbuf.space();
		else
			return m_databuf.space();
	}

	ssize_t receive(const void *pdata, ssize_t nbytes)
	{
		if (nbytes == 0)
			return 0;

		if (_get_status() != status_allright)
			return 0;

		if (pdata == nullptr || nbytes < 0)
		{
			assert(false && "invalid param");
			return 0;
		}

		if (!m_header.isset())
			return headreceive(pdata, nbytes);
		else
			return datareceive(pdata, nbytes);
	}

	char * recv_headptr()
	{
		if (_get_status() != status_allright)
			return nullptr;

		if (!m_header.isset())
			return m_headbuf.headptr();
		else
			return m_databuf.headptr();
	}

	ssize_t recv_headspace() const
	{
		if (_get_status() != status_allright)
			return 0;

		if (!m_header.isset())
			return m_headbuf.headspace();
		else
			return m_databuf.headspace();
	}

	ssize_t received(ssize_t nbytes)
	{
		if (nbytes < 0)
		{
			assert(false && "negative nbytes");
			return 0;
		}

		if (_get_status() != status_allright)
			return 0;

		if (!m_header.isset())
			return m_headbuf.head_eaten(nbytes);
		else
			return m_databuf.head_eaten(nbytes);
	}

	bool received_whole(ssize_t nbytes)
	{
		if (nbytes < 0)
		{
			assert(false && "negative nbytes");
			return false;
		}

		if (_get_status() != status_allright)
			return false;

		if (!m_header.isset())
			return m_headbuf.head_eaten_whole(nbytes);
		else
			return m_databuf.head_eaten_whole(nbytes);
	}

	void filterprocess()
	{
		if (_get_status() != status_allright)
			return;

		if (!m_header.isset())
		{
			filter_header();
			if (_get_status() != status_allright)
				return;
			if (!m_header.isset())
				return;
		}

		filter_databody();
	}

	statustype get_status() const
	{
		return m_status;
	}

	std::string get_status_str() const
	{
		return m_status_str;
	}

	bool header_ready() const
	{
		return m_header.isset();
	}

	const evtl::linearbuf<char>& get_header() const
	{
		return m_header.refer();
	}

	int get_response_code() const
	{
		return m_response_code;
	}

	dataform get_dataform() const
	{
		return m_dataform;
	}

	int64_t get_content_length() const
	{
		return m_content_length;
	}

	int64_t get_chunked_totalsize() const
	{
		return m_chunked_form.chunked_totalsize;
	}

	int64_t get_chunked_totalcount() const
	{
		return m_chunked_form.chunked_totalcount;
	}

	ssize_t output_databody(void *buffer, ssize_t bufsize)
	{
		if (bufsize == 0)
			return 0;

		if (buffer == nullptr || bufsize < 0)
		{
			assert(false && "invalid buffer");
			return 0;
		}

		ssize_t sz = 0;
		if (m_dataform == dataform_content_length)
		{
			sz = content_length_output(buffer, bufsize);
		}
		else if (m_dataform == dataform_encode_chunked)
		{
			sz = encode_chunked_output(buffer, bufsize);
		}

		return sz;
	}

	template <class C>
	ssize_t output_databody(evtl::linearbuf<C> &buf, ssize_t max_bytes = 0, bool auto_crowd = false, ssize_t crowd_top_size = -1)
	{
		if (buf.space() <= 0)
			return 0;

		ssize_t sz = 0;
		if (m_dataform == dataform_content_length)
		{
			sz = content_length_output(buf, max_bytes, auto_crowd, crowd_top_size);
		}
		else if (m_dataform == dataform_encode_chunked)
		{
			sz = encode_chunked_output(buf, max_bytes, auto_crowd, crowd_top_size);
		}

		return sz;
	}

	template <class C>
	ssize_t output_databody(evtl::ringbuf<C> &buf, ssize_t max_bytes = 0)
	{
		if (buf.space() <= 0)
			return 0;

		ssize_t sz = 0;
		if (m_dataform == dataform_content_length)
		{
			sz = content_length_output(buf, max_bytes);
		}
		else if (m_dataform == dataform_encode_chunked)
		{
			sz = encode_chunked_output(buf, max_bytes);
		}

		return sz;
	}

	bool reached_end() const
	{
		if (m_dataform == dataform_content_length)
		{
			if (m_length_form.outputdata_size >= m_length_form.totaldata_size)
				return true;
		}
		else if (m_dataform == dataform_encode_chunked)
		{
			if (m_chunked_form.reach_end)
				return true;
		}

		return false;
	}

	int64_t get_output_totalsize() const
	{
		if (m_dataform == dataform_content_length)
			return m_length_form.outputdata_size;

		if (m_dataform == dataform_encode_chunked)
			return m_chunked_form.output_totalsize;

		return 0;
	}

	void reset()
	{
		m_status.reset();
		m_status_str.clear();

		m_header.reset();
		m_response_code = 0;
		m_dataform.reset();
		m_content_length = 0;

		m_headbuf.reset();
		m_databuf.reset();

		m_length_form.reset();
		m_chunked_form.reset();
	}

	void reset_status()
	{
		m_status.reset();
		m_status_str.clear();

		m_header.reset();
		m_response_code = 0;
		m_dataform.reset();
		m_content_length = 0;

		m_length_form.reset();
		m_chunked_form.reset();
	}

private:
	statustype _get_status() const
	{
		return m_status;
	}

	ssize_t headreceive(const void *pdata, ssize_t nbytes)
	{
		if (m_headbuf.empty_capacity())
			assert(false && "headbuf empty capacity");

		ssize_t eatn = m_headbuf.append(pdata, nbytes, true);
		if (eatn > 0)
			return eatn;
		return 0;
	}

	ssize_t datareceive(const void *pdata, ssize_t nbytes)
	{
		if (m_databuf.empty_capacity())
			assert(false && "databuf empty capacity");

		ssize_t eatn = m_databuf.append(pdata, nbytes);
		if (eatn > 0)
			return eatn;
		return 0;
	}

	void filter_header()
	{
		std::stringstream ss;
		try
		{
			evtl::pcre2_8::regex reg(R"(HTTP/1.[01][ \t]+(\d+)[ \t]+.*?\r\n\r\n)");
			evtl::pcre2_8::match_results<char> matches;

			bool br = evtl::pcre2_8::regex_search(m_headbuf.dataptr(), m_headbuf.dataptr() + m_headbuf.size(), matches, reg);
			if (br)
			{
				if (matches.size() != 2)
					assert(false && "wrong matches size");

				const evtl::pcre2_8::sub_match<char> &header_match = matches[0];
				const evtl::pcre2_8::sub_match<char> &code_match = matches[1];

				if (!header_match.matched || !code_match.matched)
					assert(false && "anomalous unmatch");

				ss << code_match.str();
				ss >> m_response_code;

				search_header_field(header_match.first, header_match.second);

				m_header.refer().extens_store_whole(header_match.first, header_match.second - header_match.first);
				m_header.set();

				ssize_t shitn = header_match.second - m_headbuf.dataptr();
				if (shitn <= 0)
					assert(false && "bad header_match");
				if (m_headbuf.shit(shitn) != shitn)
					assert(false && "shit error");

				m_databuf.extens_store_whole(m_headbuf);
				m_headbuf.reset();
			}
			else
			{
				if (m_headbuf.full())
				{
					ss << "header overflow upon " << m_headbuf.size() << " bytes";
					set_status(status_header_overflow, ss.str());
					return;
				}
			}
		}
		catch (std::exception &e)
		{
			std::string str = std::string("search header exception: ") + e.what();
			set_status(status_searchheader_exception, std::move(str));
		}
	}

	void search_header_field(const char *first, const char *last)
	{
		m_dataform = dataform_content_length;

		bool content_length_found = false;

		try
		{
			evtl::pcre2_8::regex reg(R"(\r\n[ \t]*Content-Length[ \t]*:[ \t]*(\d+)\r\n)", PCRE2_DOTALL | PCRE2_CASELESS);
			evtl::pcre2_8::match_results<char> matches;

			bool br = evtl::pcre2_8::regex_search(first, last, matches, reg);
			if (br)
			{
				if (matches.size() != 2)
					assert(false && "bad matches size");

				const evtl::pcre2_8::sub_match<char> &sub = matches[1];
				if (!sub.matched)
					assert(false && "anomalous unmatch");

				std::stringstream ss;
				ss << sub.str();
				ss >> m_content_length;

				content_length_found = true;
			}
			else
			{
				m_content_length = 0;
			}
		}
		catch (std::exception &e)
		{
			m_content_length = 0;
		}

		if (!content_length_found)
		{
			try
			{
				evtl::pcre2_8::regex reg(R"(\r\n[ \t]*Transfer-Encoding[ \t]*:[ \t]*chunked[ \t]*\r\n)", PCRE2_DOTALL | PCRE2_CASELESS);
				bool br = evtl::pcre2_8::regex_search(first, last, reg);
				if (br)
				{
					m_dataform = dataform_encode_chunked;
				}
			}
			catch (std::exception &e)
			{}
		}

		if (m_dataform == dataform_content_length)
		{
			if (m_content_length > 0)
				m_length_form.totaldata_size = m_content_length;
			else
				m_length_form.totaldata_size = 0;

			m_length_form.outputdata_size = 0;
		}
		else
		{
			m_chunked_form.segment_ready = false;
			m_chunked_form.segment_size = 0;
			m_chunked_form.segment_outputsize = 0;
			m_chunked_form.reach_end = false;

			m_chunked_form.chunked_totalsize = 0;
			m_chunked_form.chunked_totalcount = 0;
			m_chunked_form.output_totalsize = 0;
		}
	}

	void filter_databody()
	{
		if (m_dataform == dataform_content_length)
			return;
		else if (m_dataform == dataform_encode_chunked)
		{
			if (!m_chunked_form.reach_end)
			{
				if (!m_chunked_form.segment_ready)
				{
					filter_segment_size();
					return;
				}
				else
				{
					if (m_chunked_form.segment_size <= 0)
						assert(false && "zero segment size");

					if (m_chunked_form.segment_outputsize >= m_chunked_form.segment_size)
					{
						hit_segment_crlf();

						if (_get_status() != status_allright)
							return;

						if (!m_chunked_form.segment_ready)
							filter_segment_size();
						return;
					}
				}
			}
		}
		else
		{
			assert(false && "invalid dataform");
		}
	}

	void filter_segment_size()
	{
		if (m_databuf.empty())
			return;

		int         hexlen  = 0;
		int64_t     hexval = 0;
		std::string hexstr;

		_find_segsize(&hexlen, &hexval, hexstr);
		if (hexlen <= 0)
		{
			set_status(status_segsize_hexlen_zero);
			return;
		}
		if (hexlen > 16)
		{
			set_status(status_segsize_hexlen_overflow, std::move(hexstr));
			return;
		}
		if (hexval < 0)
		{
			set_status(status_segsize_negative, std::move(hexstr));
			return;
		}

		if (m_databuf.size() < hexlen + 2)
			return;

		if (m_databuf[hexlen] != '\r' || m_databuf[hexlen + 1] != '\n')
		{
			set_status(status_segsize_not_crlf_terminated, std::move(hexstr));
			return;
		}

		if (m_databuf.shit(hexlen + 2) != hexlen + 2)
			assert(false && "shit error");

		m_chunked_form.segment_size = hexval;
		m_chunked_form.segment_outputsize = 0;
		if (hexval > 0)
		{
			m_chunked_form.chunked_totalsize += hexval;
			m_chunked_form.chunked_totalcount++;
		}
		else
			m_chunked_form.reach_end = true;

		m_chunked_form.segment_ready = true;
	}

	void hit_segment_crlf()
	{
		if (m_databuf.size() < 2)
			return;

		if (m_databuf[0] != '\r' || m_databuf[1] != '\n')
		{
			set_status(status_segment_not_crlf_terminated);
			return;
		}

		if (m_databuf.shit(2) != 2)
			assert(false && "shit error");

		m_chunked_form.segment_ready = false;
	}

	ssize_t content_length_output(void *buffer, ssize_t bufsize)
	{
		if (m_length_form.outputdata_size < 0 || m_length_form.totaldata_size < 0)
			assert(false && "invalid form status");

		ssize_t nbytes = m_length_form.totaldata_size - m_length_form.outputdata_size;
		if (nbytes <= 0)
			return 0;

		if (nbytes > bufsize)
			nbytes = bufsize;

		ssize_t cp_size = m_databuf.copy_out(buffer, nbytes);
		if (cp_size > nbytes)
			assert(false && "copy too much");

		if (cp_size > 0)
		{
			if (m_databuf.shit(cp_size) != cp_size)
				assert(false && "shit error");
		}

		if (cp_size < 0)
			cp_size = 0;

		m_length_form.outputdata_size += cp_size;
		return cp_size;
	}

	template <class C>
	ssize_t content_length_output(evtl::linearbuf<C> &buf, ssize_t max_bytes, bool auto_crowd, ssize_t crowd_top_size)
	{
		if (m_length_form.outputdata_size < 0 || m_length_form.totaldata_size < 0)
			assert(false && "invalid form status");

		ssize_t nbytes = m_length_form.totaldata_size - m_length_form.outputdata_size;
		if (nbytes <= 0)
			return 0;

		if (max_bytes > 0 && nbytes > max_bytes)
			nbytes = max_bytes;

		ssize_t eat_bytes = buf.eat(m_databuf, nbytes, auto_crowd, crowd_top_size);
		if (eat_bytes > nbytes)
			assert(false && "eat too much");

		if (eat_bytes < 0)
			eat_bytes = 0;

		m_length_form.outputdata_size += eat_bytes;
		return eat_bytes;
	}

	template <class C>
	ssize_t content_length_output(evtl::ringbuf<C> &buf, ssize_t max_bytes)
	{
		if (m_length_form.outputdata_size < 0 || m_length_form.totaldata_size < 0)
			assert(false && "invalid form status");

		ssize_t nbytes = m_length_form.totaldata_size - m_length_form.outputdata_size;
		if (nbytes <= 0)
			return 0;

		if (max_bytes > 0 && nbytes > max_bytes)
			nbytes = max_bytes;

		ssize_t eat_bytes = buf.eat(m_databuf, nbytes);
		if (eat_bytes > nbytes)
			assert(false && "eat too much");

		if (eat_bytes < 0)
			eat_bytes = 0;

		m_length_form.outputdata_size += eat_bytes;
		return eat_bytes;
	}

	ssize_t encode_chunked_output(void *buffer, ssize_t bufsize)
	{
		if (m_chunked_form.reach_end)
			return 0;
		if (!m_chunked_form.segment_ready)
			return 0;

		if (m_chunked_form.segment_outputsize < 0 || m_chunked_form.segment_size < 0)
			assert(false && "invalid form status");

		ssize_t nbytes = m_chunked_form.segment_size - m_chunked_form.segment_outputsize;
		if (nbytes <= 0)
			return 0;

		if (nbytes > bufsize)
			nbytes = bufsize;

		ssize_t cp_size = m_databuf.copy_out(buffer, nbytes);
		if (cp_size > nbytes)
			assert(false && "copy too much");

		if (cp_size > 0)
		{
			if (m_databuf.shit(cp_size) != cp_size)
				assert(false && "shit error");
		}

		if (cp_size < 0)
			cp_size = 0;

		m_chunked_form.segment_outputsize += cp_size;
		m_chunked_form.output_totalsize += cp_size;
		return cp_size;
	}

	template <class C>
	ssize_t encode_chunked_output(evtl::linearbuf<C> &buf, ssize_t max_bytes, bool auto_crowd, ssize_t crowd_top_size)
	{
		if (m_chunked_form.reach_end)
			return 0;
		if (!m_chunked_form.segment_ready)
			return 0;

		if (m_chunked_form.segment_outputsize < 0 || m_chunked_form.segment_size < 0)
			assert(false && "invalid form status");

		ssize_t nbytes = m_chunked_form.segment_size - m_chunked_form.segment_outputsize;
		if (nbytes <= 0)
			return 0;

		if (max_bytes > 0 && nbytes > max_bytes)
			nbytes = max_bytes;

		ssize_t eat_bytes = buf.eat(m_databuf, nbytes, auto_crowd, crowd_top_size);
		if (eat_bytes > nbytes)
			assert(false && "eat too much");

		if (eat_bytes < 0)
			eat_bytes = 0;

		m_chunked_form.segment_outputsize += eat_bytes;
		m_chunked_form.output_totalsize += eat_bytes;
		return eat_bytes;
	}

	template <class C>
	ssize_t encode_chunked_output(evtl::ringbuf<C> &buf, ssize_t max_bytes)
	{
		if (m_chunked_form.reach_end)
			return 0;
		if (!m_chunked_form.segment_ready)
			return 0;

		if (m_chunked_form.segment_outputsize < 0 || m_chunked_form.segment_size < 0)
			assert(false && "invalid form status");

		ssize_t nbytes = m_chunked_form.segment_size - m_chunked_form.segment_outputsize;
		if (nbytes <= 0)
			return 0;

		if (max_bytes > 0 && nbytes > max_bytes)
			nbytes = max_bytes;

		ssize_t eat_bytes = buf.eat(m_databuf, nbytes);
		if (eat_bytes > nbytes)
			assert(false && "eat too much");

		if (eat_bytes < 0)
			eat_bytes = 0;

		m_chunked_form.segment_outputsize += eat_bytes;
		m_chunked_form.output_totalsize += eat_bytes;
		return eat_bytes;
	}

private:
	void set_status(statustype status)
	{
		m_status = status;
		m_status_str.clear();
	}

	void set_status(statustype status, const std::string &str)
	{
		m_status = status;
		m_status_str = str;
	}

	void set_status(statustype status, std::string &&str)
	{
		m_status = status;
		m_status_str = std::move(str);
	}

	void _find_segsize(int *hexlen, int64_t *hexval, std::string &hexstr)
	{
		ssize_t size = m_databuf.size();
		if (size <= 0)
			assert(false && "empty databuf");

		hexstr.clear();
		uint64_t value = 0;
		int len = 0;
		for (ssize_t i = 0; i < size; i++)
		{
			unsigned char c = m_databuf[i];
			if (c >= '0' && c <= '9')
			{
				value <<= 4;
				value |= (c - '0');
				len++;
				hexstr.append(1, c);
			}
			else if (c >= 'a' && c <= 'f')
			{
				value <<= 4;
				value |= (c - 'a' + 10);
				len++;
				hexstr.append(1, c);
			}
			else if (c >= 'A' && c <= 'F')
			{
				value <<= 4;
				value |= (c - 'A' + 10);
				len++;
				hexstr.append(1, c);
			}
			else
			{
				break;
			}

			if (len > 16)
				break;
		}

		*hexlen = len;
		*hexval = (int64_t)value;
	}

private:
	evtl::intflag<statustype, status_allright>   m_status;
	std::string                                  m_status_str;

	evtl::var<evtl::linearbuf<char>>  m_header;
	int      m_response_code;
	evtl::intflag<dataform, dataform_unknown>   m_dataform;
	int64_t  m_content_length;

	evtl::linearbuf<char>  m_headbuf;
	evtl::ringbuf<char>    m_databuf;

	content_length_forminfo  m_length_form;
	encode_chunked_forminfo  m_chunked_form;
};


} }


#endif


