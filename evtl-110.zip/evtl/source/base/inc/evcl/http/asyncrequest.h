

#ifndef __EVCL_HTTP_ASYNCREQUEST_H__
#define __EVCL_HTTP_ASYNCREQUEST_H__

#include <assert.h>
#include <sys/types.h>
#include <errno.h>

#include <cstdint>
#include <string>
#include <sstream>
#include <functional>
#include <utility>

#include <evtl/evtl_error.h>
#include <evtl/evtl_copyable.h>
#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_connector.h>
#include <evtl/evtl_watcher_io.h>
#include <evtl/evtl_com.h>
#include <evtl/evtl_wrapper.h>

#include "requestprocess.h"


namespace evcl { namespace http {


template <class T>
class asyncrequest : public evtl::evtl_error, public evtl::nocopyc
{
public:
	enum error_code
	{
		success,
		invalid_param,
		set_request_failed,
		empty_request_buffer,
		null_loop,
		connector_busy,
		connect_failed,
		receive_uncomplete,
		send_uncomplete,
		header_overflow,
		regex_exception,
		content_length_toobig,
		unknown_error
	};

	enum request_result
	{
		request_success,
		request_connect_failed,
		request_receive_uncomplete,
		request_send_uncomplete,
		request_header_overflow,
		request_regex_exception,
		request_content_length_toobig,
		request_failed
	};

	typedef std::function<void (T &request, request_result result)>  reqeust_callback_t;

	asyncrequest(): m_loop(nullptr), m_server_port(0)
	{
		m_request_cb = std::bind(&asyncrequest::request_callback, static_cast<T*>(this), std::placeholders::_1, std::placeholders::_2);
	}

	void set_loop(evtl::looprefer loop)
	{
		m_loop = loop;
	}

	void set_callback()
	{
		m_request_cb = std::bind(&asyncrequest::request_callback, static_cast<T*>(this), std::placeholders::_1, std::placeholders::_2);
	}

	void set_callback(reqeust_callback_t cb)
	{
		m_request_cb = std::move(cb);
	}

	void set_server(const std::string &ip, int port)
	{
		m_server_ip   = ip;
		m_server_port = port;
	}

	void set_response_limit(int max_headersize, int64_t max_contentlength)
	{
		m_process.set_max_headersize(max_headersize);
		m_process.set_max_contentlength(max_contentlength);
	}

	void set_reqeust_data(const void *pdata, ssize_t nbytes)
	{
		m_process.set_reqeust_data(pdata, nbytes);
	}

	void set_reqeust_data(const std::string &reqdata)
	{
		m_process.set_reqeust_data(reqdata.c_str(), reqdata.size());
	}

	template <class C>
	void set_reqeust_data(const evtl::linearbuf<C> &databuf)
	{
		m_process.set_reqeust_data(databuf);
	}

	template <class C>
	void set_reqeust_data(evtl::linearbuf<C> &&databuf)
	{
		m_process.set_reqeust_data(std::move(databuf));
	}

	bool request()
	{
		if (!m_loop.is_null())
		{
			set_error(null_loop);
			return false;
		}

		if (!m_connector.is_idle())
		{
			set_error(connector_busy);
			return false;
		}

		m_connector.set_loop(m_loop);
		m_connector.set_callback(std::bind(&asyncrequest::connect_callback, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3));
		bool br = m_connector.async_connect(evtl::makeipaddr(m_server_ip, m_server_port), true);
		if (!br)
		{
			std::string errstr = std::string("connect failed") + m_connector.get_error_combine();
			set_error(connect_failed, std::move(errstr));
			return false;
		}

		return true;
	}

	const evtl::linearbuf<char>& get_header() const
	{
		return m_process.get_header();
	}

	void moveout_header(evtl::linearbuf<char> &header)
	{
		m_process.moveout_header(header);
	}

	int get_response_code() const
	{
		return m_process.get_response_code();
	}

	int64_t get_content_length() const
	{
		return m_process.get_content_length();
	}

	const evtl::linearbuf<char>& get_databody() const
	{
		return m_process.get_databody();
	}

	void moveout_databody(evtl::linearbuf<char> &databody)
	{
		m_process.moveout_databody(databody);
	}

	void deinit()
	{
		m_connector.stop_close();
		m_io.stop_close();

		m_iostatus.reset();
		m_process.reset();
	}

private:
	void request_callback(T &request, request_result result) { assert(false && "unset callback"); }

	void connect_callback(evtl::simpconnector &connector, int errcode, int errnocode)
	{
		if (&connector != &m_connector)
			assert(false && "unexpected connector");

		if (errcode == evtl::simpconnector::success)
		{
			int fd = connector.get_fd();
			connector.only_reset();
			if (fd == -1)
				assert(false && "invalid fd");

			m_io.set(m_loop);
			m_io.set_callback(std::bind(&asyncrequest::io_callback, this, std::placeholders::_1, std::placeholders::_2));
			m_io.set(fd, ev::WRITE);
			m_io.start();
		}
		else
		{
			std::string errstr = std::string("connect callback failed") + connector.get_error_combine();
			set_error(connect_failed, std::move(errstr));
			m_request_cb(*static_cast<T*>(this), request_connect_failed);
		}
	}

	void io_callback(evtl::simpwio &watcher, int revents)
	{
		if ((revents & ev::ERROR) != 0)
			assert(false && "ev_error");
		if (&watcher != &m_io)
			assert(false && "unexpected watcher");

		evtl::linearbuf<char> &sendbuf = m_process.sendbuf();
		evtl::linearbuf<char> &recvbuf = m_process.recvbuf();

		if ((revents & ev::READ) != 0)
		{
			recvbuf.crowd(1024*10);
			ssize_t space = recvbuf.headspace();
			if (space > 0)
			{
				ssize_t r = m_io.read(recvbuf.headptr(), space);
				if (r > 0)
				{
					if (r > space)
						assert(false && "read overflow");
					if (recvbuf.head_eaten(r) != r)
						assert(false && "head_eaten error");
				}
				else if (r < 0)
				{
					if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
						m_iostatus |= evtl::com::rwresult_read_error;
				}
				else
				{
					m_iostatus |= evtl::com::rwresult_read_end;
				}
			}
		}

		if ((revents & ev::WRITE) != 0)
		{
			ssize_t size = sendbuf.size();
			if (size > 0)
			{
				ssize_t r = m_io.write(sendbuf.dataptr(), size);
				if (r > 0)
				{
					if (r > size)
						assert(false && "write overflow");
					if (sendbuf.shit(r) != r)
						assert(false && "shit error");
				}
				else if (r < 0)
				{
					if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
						m_iostatus |= evtl::com::rwresult_write_error;
				}
				else
				{
					assert(false && "write zero");
				}
			}
		}

		process();
	}

private:
	void process()
	{
		m_process.process();

		evtl::com::process_nextstep result = m_process.get_process_nextstep();

		switch (result)
		{
		case evtl::com::nextstep_wait_to_receive:
			{
				if ((m_iostatus & (evtl::com::rwresult_read_error | evtl::com::rwresult_read_end)) != 0)
				{
					m_io.stop_close();
					set_error(receive_uncomplete, m_iostatus, "read error - maybe peer closed connection");
					m_request_cb(*static_cast<T*>(this), request_receive_uncomplete);
					return;
				}

				if (m_io.get_events() != ev::READ)
				{
					m_io.stop();
					m_io.set_events(ev::READ);
					m_io.start();
				}
			}
			break;
		case evtl::com::nextstep_wait_to_send:
			{
				if ((m_iostatus & evtl::com::rwresult_write_error) != 0)
				{
					m_io.stop_close();
					set_error(send_uncomplete, m_iostatus, "write error - maybe peer closed connection");
					m_request_cb(*static_cast<T*>(this), request_send_uncomplete);
					return;
				}

				if (m_io.get_events() != ev::WRITE)
				{
					m_io.stop();
					m_io.set_events(ev::WRITE);
					m_io.start();
				}
			}
			break;
		case evtl::com::nextstep_error:
			{
				m_io.stop_close();
				if (m_process.get_status() == reqeust_process::status_header_overflow)
				{
					set_error(header_overflow, m_process.get_strerror());
					m_request_cb(*static_cast<T*>(this), request_header_overflow);
				}
				else if (m_process.get_status() == reqeust_process::status_regexsearch_exception)
				{
					set_error(regex_exception, m_process.get_strerror());
					m_request_cb(*static_cast<T*>(this), request_regex_exception);
				}
				else if (m_process.get_status() == reqeust_process::status_content_length_toobig)
				{
					set_error(content_length_toobig, m_process.get_strerror());
					m_request_cb(*static_cast<T*>(this), request_content_length_toobig);
				}
				else
				{
					set_error(unknown_error, m_process.get_strerror());
					m_request_cb(*static_cast<T*>(this), request_failed);
				}
				return;
			}
			break;
		case evtl::com::nextstep_done:
			{
				m_io.stop_close();
				m_request_cb(*static_cast<T*>(this), request_success);
				return;
			}
			break;
		default:
			assert(false && "invalid process result");
			break;
		}
	}

private:
	evtl::looprefer  m_loop;

	reqeust_callback_t  m_request_cb;

	std::string  m_server_ip;
	int          m_server_port;

	evtl::intflag<int, 0>  m_iostatus;
	reqeust_process        m_process;

	evtl::simpconnector  m_connector;
	evtl::simpwio  m_io;
};

class simpasyncrequest : public asyncrequest<simpasyncrequest>
{};


} }


#endif


