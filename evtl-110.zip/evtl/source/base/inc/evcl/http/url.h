

#ifndef __EVCL_HTTP_URL_H__
#define __EVCL_HTTP_URL_H__

#include <assert.h>
#include <string>
#include <utility>


namespace evcl { namespace http {


class url
{
public:	 
	static std::string encode(const std::string &str)
	{
		std::string result;

		size_t len = str.size();
		for (size_t i = 0; i < len; i++)
		{
			char c = str[i];

			if (c == '-' || c == '_' || c == '.' || c == '~' || url::isaz09(c))
				result.append(1, c);
			else if (c == ' ')
				result.append(1, '+');
			else
			{
				char cs[4] = { 0 };
				cs[0] = '%';
				cs[1] = url::tohex(((unsigned char)c >> 4) & 0x0F);
				cs[2] = url::tohex((unsigned char)c & 0x0F);
				cs[3] = '\0';

				result.append(cs, 3);
			}
		}

		return result;
	}

	static std::pair<bool, std::string> decode(const std::string& str)
	{
		std::pair<bool, std::string> result = std::make_pair(false, std::string());

		size_t len = str.size();
		for (size_t i = 0; i < len; i++)
		{
			if (str[i] == '+')
				result.second.append(1, ' ');
			else if (str[i] == '%')
			{
				if (i + 2 >= len)
					return result;

				char c1 = str[i + 1];
				char c2 = str[i + 2];

				if (!url::ishexc(c1) || !url::ishexc(c2))
					return result;

				unsigned char high = url::fromhex((unsigned char)str[i + 1]);
				unsigned char low = url::fromhex((unsigned char)str[i + 2]);
				unsigned char c = (high << 4) | low;
				result.second.append(1, c);

				i += 2;
			}
			else
				result.second.append(1, str[i]);
		}

		result.first = true;
		return result;
	}

private:
	static bool isaz09(char c)
	{
		if ((c >= '0' && c <= '9')
			|| (c >= 'a' && c <= 'z')
			|| (c >= 'A' && c <= 'Z')
			)
			return true;
		return false;
	}

	static bool ishexc(char c)
	{
		if ((c >= '0' && c <= '9')
			|| (c >= 'a' && c <= 'f')
			|| (c >= 'A' && c <= 'F')
			)
			return true;
		return false;
	}

	static char tohex(int n)
	{
		switch (n)
		{
		case 0:
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
			return '0' + n;
		case 10:
		case 11:
		case 12:
		case 13:
		case 14:
		case 15:
			return 'A' + (n - 10);
		default:
			break;
		}

		assert(false && "invalid param");
		return 0xff;
	}

	static unsigned char fromhex(unsigned char c) 
	{ 
		unsigned char val = 0;

		if (c >= 'A' && c <= 'F')
			val = c - 'A' + 10;
		else if (c >= 'a' && c <= 'f')
			val = c - 'a' + 10;
		else if (c >= '0' && c <= '9')
			val = c - '0';
		else
			assert(false && "not hex");

		return val;
	}
};


} }


#endif


