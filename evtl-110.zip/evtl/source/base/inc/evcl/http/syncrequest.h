

#ifndef __EVCL_HTTP_SYNCREQUEST_H__
#define __EVCL_HTTP_SYNCREQUEST_H__

#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <assert.h>
#include <signal.h>
#include <poll.h>

#include <cstdint>
#include <string>
#include <cstring>

#include <evtl/evtl_error.h>
#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_tcpconnector.h>
#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_time.h>

#include "requestprocess.h"


namespace evcl { namespace http {


class syncrequest : public evtl::evtl_error
{
public:
	enum error_code
	{
		success,
		request_busy,
		connect_failed,
		loopprocess_timeout,
		ppoll_timeout,
		ppoll_failed,
		receive_uncomplete,
		send_uncomplete,
		header_overflow,
		regex_exception,
		content_length_toobig,
		unknown_error
	};

	enum process_status
	{
		procstat_success,
		procstat_failed,
		procstat_continue
	};

	syncrequest(): m_server_port(0), m_starttime_us(0), m_events(0)
	{}

	void set_server(const std::string &ip, int port)
	{
		m_server_ip   = ip;
		m_server_port = port;
	}

	void set_response_limit(int max_headersize, int64_t max_contentlength)
	{
		m_process.set_max_headersize(max_headersize);
		m_process.set_max_contentlength(max_contentlength);
	}

	void set_request_data(const void *pdata, ssize_t nbytes)
	{
		m_process.set_reqeust_data(pdata, nbytes);
	}

	void set_reqeust_data(const std::string &reqdata)
	{
		m_process.set_reqeust_data(reqdata.c_str(), reqdata.size());
	}

	template <class C>
	void set_reqeust_data(const evtl::linearbuf<C> &databuf)
	{
		m_process.set_reqeust_data(databuf);
	}

	template <class C>
	void set_reqeust_data(evtl::linearbuf<C> &&databuf)
	{
		m_process.set_reqeust_data(std::move(databuf));
	}

	bool request(int64_t wait_us = -1)
	{
		if (m_starttime_us != 0)
		{
			set_error(request_busy, m_starttime_us);
			return false;
		}

		m_starttime_us = evtl::timec::usec();

		evtl::tcp::simptcpconnector connector;

		int fd = connector.wait_connect(m_server_ip, m_server_port, wait_us, true);
		if (fd == -1)
		{
			set_error(connect_failed, connector.get_error_combine());
			return false;
		}

		m_events   = POLLOUT;
		m_iostatus.reset();
		bool br = loop_process(fd, wait_us);

		::close(fd);
		return br;
	}

	const evtl::linearbuf<char>& get_header() const
	{
		return m_process.get_header();
	}

	void moveout_header(evtl::linearbuf<char> &header)
	{
		m_process.moveout_header(header);
	}

	int get_response_code() const
	{
		return m_process.get_response_code();
	}

	int64_t get_content_length() const
	{
		return m_process.get_content_length();
	}

	const evtl::linearbuf<char>& get_databody() const
	{
		return m_process.get_databody();
	}

	void moveout_databody(evtl::linearbuf<char> &databody)
	{
		m_process.moveout_databody(databody);
	}

	void reset()
	{
		m_starttime_us = 0;
		m_events = 0;
		m_iostatus.reset();
		m_process.reset();
	}

private:
	bool loop_process(int fd, int64_t wait_us)
	{
		while (true)
		{
			int64_t now_us = evtl::timec::usec();

			int64_t rest_us = -1;
			if (wait_us >= 0)
			{
				if (now_us < m_starttime_us)
				{
					m_starttime_us = now_us;
					rest_us = wait_us;
				}
				else
					rest_us = wait_us - (now_us - m_starttime_us);
				if (rest_us <= 0)
				{
					set_error(loopprocess_timeout, wait_us);
					return false;
				}
			}

			if ((m_events & (POLLIN | POLLOUT)) == 0)
				assert(false && "invalid events");

			struct pollfd fds;
			memset(&fds, 0, sizeof(fds));
			fds.fd      = fd;
			fds.events  = m_events & (POLLIN | POLLOUT);
			fds.revents = 0;

			struct timespec tsp;
			memset(&tsp, 0, sizeof(tsp));
			tsp.tv_sec  = rest_us/1000000;
			tsp.tv_nsec = (rest_us%1000000)*1000;

			int ret = 0;
			if (rest_us >= 0)
				ret = ::ppoll(&fds, 1, &tsp, nullptr);
			else
				ret = ::ppoll(&fds, 1, nullptr, nullptr);

			if (ret > 0)
			{
				evtl::linearbuf<char> &recvbuf = m_process.recvbuf();
				evtl::linearbuf<char> &sendbuf = m_process.sendbuf();

				if ((fds.revents & POLLIN) != 0)
				{
					recvbuf.crowd(1024*10);
					ssize_t space = recvbuf.headspace();
					if (space > 0)
					{
						ssize_t r = ::read(fd, recvbuf.headptr(), space);
						if (r > 0)
						{
							if (r > space)
								assert(false && "read overflow");
							if (recvbuf.head_eaten(r) != r)
								assert(false && "head_eaten error");
						}
						else if (r < 0)
						{
							if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
								m_iostatus |= evtl::com::rwresult_read_error;
						}
						else
						{
							m_iostatus |= evtl::com::rwresult_read_end;
						}
					}
				}
			
				if ((fds.revents & POLLOUT) != 0)
				{
					ssize_t size = sendbuf.size();
					if (size > 0)
					{
						ssize_t r = ::write(fd, sendbuf.dataptr(), size);
						if (r > 0)
						{
							if (r > size)
								assert(false && "write overflow");
							if (sendbuf.shit(r) != r)
								assert(false && "shit error");
						}
						else if (r < 0)
						{
							if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
								m_iostatus |= evtl::com::rwresult_write_error;
						}
						else
						{
							assert(false && "write zero");
						}
					}
				}

				process_status status = process();
				if (status == procstat_success)
					return true;
				else if (status == procstat_failed)
					return false;
			}
			else if (ret == 0)
			{
				set_error(ppoll_timeout, wait_us);
				return false;
			}
			else
			{
				if (errno != EINTR)
				{
					set_error(ppoll_failed, errno);
					return false;
				}
			}
		}
	}

	process_status process()
	{
		m_process.process();

		evtl::com::process_nextstep result = m_process.get_process_nextstep();

		switch (result)
		{
		case evtl::com::nextstep_wait_to_receive:
			{
				if ((m_iostatus & (evtl::com::rwresult_read_error | evtl::com::rwresult_read_end)) != 0)
				{
					set_error(receive_uncomplete, m_iostatus, "read error - maybe peer closed connection");
					return procstat_failed;
				}

				m_events = POLLIN;
			}
			break;
		case evtl::com::nextstep_wait_to_send:
			{
				if ((m_iostatus & evtl::com::rwresult_write_error) != 0)
				{
					set_error(send_uncomplete, m_iostatus, "write error - maybe peer closed connection");
					return procstat_failed;
				}

				m_events = POLLOUT;
			}
			break;
		case evtl::com::nextstep_error:
			{
				if (m_process.get_status() == reqeust_process::status_header_overflow)
				{
					set_error(header_overflow, m_process.get_strerror());
				}
				else if (m_process.get_status() == reqeust_process::status_regexsearch_exception)
				{
					set_error(regex_exception, m_process.get_strerror());
				}
				else if (m_process.get_status() == reqeust_process::status_content_length_toobig)
				{
					set_error(content_length_toobig, m_process.get_strerror());
				}
				else
				{
					set_error(unknown_error, m_process.get_strerror());
				}
				return procstat_failed;
			}
			break;
		case evtl::com::nextstep_done:
			{
				return procstat_success;
			}
			break;
		default:
			assert(false && "invalid process result");
			break;
		}

		return procstat_continue;
	}

private:
	std::string   m_server_ip;
	int           m_server_port;

	int64_t  m_starttime_us;
	int      m_events;
	evtl::intflag<int, 0>  m_iostatus;
	reqeust_process        m_process;
};


} }


#endif


