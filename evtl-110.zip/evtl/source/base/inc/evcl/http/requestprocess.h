

#ifndef __EVCL_HTTP_REQUESTPROCESS_H__
#define __EVCL_HTTP_REQUESTPROCESS_H__

#include <sys/types.h>
#include <assert.h>

#include <cstdint>
#include <string>
#include <sstream>
#include <utility>

#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_pcre2.h>
#include <evtl/evtl_com.h>


namespace evcl { namespace http {


class reqeust_process
{
public:
	enum error_status
	{
		status_normal,
		status_header_overflow,
		status_regexsearch_exception,
		status_content_length_toobig
	};

	enum header_got_status
	{
		header_got_success,
		header_got_failed
	};

	reqeust_process()
		: m_nextstep(evtl::com::nextstep_unknown),
		  m_sendbuf(96*1024), m_recvbuf(100*1024),
		  m_max_headersize(12*1024), m_max_contentlength(5*1024*1024),
		  m_response_code(0), m_content_length(0)
	{}

	void set_max_headersize(int size)
	{
		if (size < 1024)
			m_max_headersize = 1024;
		else if (size > 1024*64)
			m_max_headersize = 1024*64;
		else
			m_max_headersize = size;
	}

	void set_max_contentlength(int64_t length)
	{
		if (length < 1024)
			m_max_contentlength = 1024;
		else
			m_max_contentlength = length;
	}

	void set_reqeust_data(const void *pdata, ssize_t nbytes)
	{
		if (nbytes == 0)
			m_request_data.clear();
		else if (nbytes > 0)
		{
			if (pdata == nullptr)
			{
				assert(false && "pdata nullptr");
				return;
			}
			m_request_data.extens_store_whole(pdata, nbytes);
		}
		else
		{
			assert(false && "negative nbytes");
		}
	}

	template <class C>
	void set_reqeust_data(const evtl::linearbuf<C> &databuf)
	{
		m_request_data = databuf;
	}

	template <class C>
	void set_reqeust_data(evtl::linearbuf<C> &&databuf)
	{
		m_request_data = std::move(databuf);
	}

	evtl::linearbuf<char>& sendbuf()
	{
		return m_sendbuf;
	}

	evtl::linearbuf<char>& recvbuf()
	{
		return m_recvbuf;
	}

	void process()
	{
		if (!m_send_finished)
		{
			m_sendbuf.eat(m_request_data, 0, true, 1024*10);
			if (m_sendbuf.empty())
			{
				if (!m_request_data.empty())
					assert(false && "eat exception");

				m_send_finished = true;
				set_process_nextstep(evtl::com::nextstep_wait_to_receive);
			}
			else
			{
				set_process_nextstep(evtl::com::nextstep_wait_to_send);
			}
		}
		else
		{
			std::stringstream ss;
			if (!m_header_status.isset())
			{
				search_header();
			}

			if (!m_header_status.isset())
			{
				m_recvbuf.crowd(m_max_headersize);
				set_process_nextstep(evtl::com::nextstep_wait_to_receive);
			}
			else
			{
				if (m_header_status != header_got_success)
				{
					set_process_nextstep(evtl::com::nextstep_error);
				}
				else
				{
					if (m_content_length <= 0)
					{
						m_data_body.reset();
						set_process_nextstep(evtl::com::nextstep_done);
					}
					else if (m_content_length <= m_max_contentlength)
					{
						if (!m_data_body.isset())
						{
							m_data_body.refer().reset_capacity(m_content_length);
							m_data_body.set();
						}

						evtl::linearbuf<char> &databody = m_data_body.refer();
						databody.eat(m_recvbuf, 0, true);

						if (databody.full())
						{
							set_process_nextstep(evtl::com::nextstep_done);
						}
						else
						{
							if (!m_recvbuf.empty())
								assert(false && "eat exception");

							set_process_nextstep(evtl::com::nextstep_wait_to_receive);
						}
					}
					else
					{
						m_data_body.reset();
						m_status = status_content_length_toobig;
						ss << "content length too large: " << m_content_length;
						m_strerror = ss.str();
						set_process_nextstep(evtl::com::nextstep_error);
					}
				}
			}
		}
	}

	evtl::com::process_nextstep get_process_nextstep() const
	{
		return m_nextstep;
	}

	error_status get_status() const
	{
		return m_status;
	}

	std::string get_strerror() const
	{
		return m_strerror;
	}

	const evtl::linearbuf<char>& get_header() const
	{
		return m_header;
	}

	void moveout_header(evtl::linearbuf<char> &header)
	{
		header = std::move(m_header);
	}

	int get_response_code() const
	{
		return m_response_code;
	}

	int64_t get_content_length() const
	{
		return m_content_length;
	}

	const evtl::linearbuf<char>& get_databody() const
	{
		return m_data_body.refer();
	}

	void moveout_databody(evtl::linearbuf<char> &databody)
	{
		if (!m_data_body.isset())
			databody.clear();
		else
		{
			databody = std::move(m_data_body.refer());
			m_data_body.unset();
		}
	}

	void reset()
	{
		m_nextstep = evtl::com::nextstep_unknown;
		m_sendbuf.clear();
		m_recvbuf.clear();

		m_max_headersize = 12*1024;
		m_max_contentlength = 5*1024*1024;

		m_request_data.reset();
		m_send_finished.reset();

		m_status.reset();
		m_strerror.clear();

		m_header_status.reset();
		m_header.reset();
		m_response_code = 0;
		m_content_length = 0;

		m_data_body.reset();
	}

private:
	void set_process_nextstep(evtl::com::process_nextstep step)
	{
		m_nextstep = step;
	}

	void search_header()
	{
		try
		{
			evtl::pcre2_8::regex reg(R"(HTTP/1.[01][ \t]+(\d+)[ \t]+.*?\r\n\r\n)");
			evtl::pcre2_8::match_results<char> matches;

			bool br = evtl::pcre2_8::regex_search(m_recvbuf.dataptr(), m_recvbuf.dataptr() + m_recvbuf.size(), matches, reg);
			if (br)
			{
				if (matches.size() != 2)
					assert(false && "wrong matches size");

				const evtl::pcre2_8::sub_match<char> &header_match = matches[0];
				const evtl::pcre2_8::sub_match<char> &code_match = matches[1];

				if (!header_match.matched || !code_match.matched)
					assert(false && "anomalous unmatch");

				m_header.extens_store_whole(header_match.first, header_match.second - header_match.first);

				std::stringstream ss;
				ss << code_match.str();
				ss >> m_response_code;

				search_content_length(header_match.first, header_match.second);

				m_header_status.set_assign(header_got_success);
				ssize_t shitsize = header_match.second - m_recvbuf.dataptr();
				if (shitsize >= 0)
				{
					if (m_recvbuf.shit(shitsize) != shitsize)
						assert(false && "shit error");
				}
				else
				{
					assert(false && "invalid shitsize");
				}
			}
			else
			{
				if (m_recvbuf.capacity() < m_max_headersize)
					assert(false && "bad capacity");

				if (m_recvbuf.size() >= m_max_headersize)
				{
					m_status = status_header_overflow;
					m_strerror = "header receive overflow";
					m_header_status.set_assign(header_got_failed);
				}
			}
		}
		catch (std::exception &e)
		{
			m_status = status_regexsearch_exception;
			m_strerror = std::string("regex search header exception: ") + e.what();
			m_header_status.set_assign(header_got_failed);
		}
	}

	void search_content_length(const char *first, const char *last)
	{
		try
		{
			evtl::pcre2_8::regex reg(R"(\r\n[ \t]*Content-Length[ \t]*:[ \t]*(\d+)[ \t]*\r\n)", PCRE2_DOTALL | PCRE2_CASELESS);
			evtl::pcre2_8::match_results<char> matches;

			bool br = evtl::pcre2_8::regex_search(first, last, matches, reg);
			if (br)
			{
				if (matches.size() != 2)
					assert(false && "bad matches size");

				const evtl::pcre2_8::sub_match<char> &sub = matches[1];
				if (!sub.matched)
					assert(false && "anomalous unmatch");

				std::stringstream ss;
				ss << sub.str();
				ss >> m_content_length;
			}
			else
			{
				m_content_length = 0;
			}
		}
		catch (std::exception &e)
		{
			m_content_length = 0;
		}
	}

private:
	evtl::com::process_nextstep  m_nextstep;

	evtl::linearbuf<char>  m_sendbuf;
	evtl::linearbuf<char>  m_recvbuf;

	int      m_max_headersize;
	int64_t  m_max_contentlength;

	evtl::linearbuf<char>  m_request_data;
	evtl::boolflag<false>  m_send_finished;

	evtl::intflag<error_status, status_normal>  m_status;
	std::string  m_strerror;

	evtl::st_var<header_got_status>  m_header_status;
	evtl::linearbuf<char>  m_header;
	int                    m_response_code;
	int64_t                m_content_length;

	evtl::dn_var<evtl::linearbuf<char>>  m_data_body;
};


} }


#endif


