

#ifndef __EVCL_TCP_SENDER_H__
#define __EVCL_TCP_SENDER_H__

#include <sys/types.h>
#include <sys/socket.h>
#include <errno.h>
#include <assert.h>
#include <signal.h>
#include <poll.h>

#include <cstdint>
#include <cstring>
#include <utility>

#include <evtl/evtl_error.h>
#include <evtl/evtl_time.h>
#include <evtl/evtl_linearbuf.h>


namespace evcl { namespace tcp {


class sender : public evtl::evtl_error
{
public:
	enum error_code
	{
		success,
		invalid_fd,
		invalid_param,
		send_timeout,
		unexpected_revents,
		send_failed,
		ppoll_timeout,
		ppoll_failed
	};

	bool wait_send(int fd, const void *pdata, ssize_t nbytes, int64_t wait_us = -1)
	{
		return _wait_send(fd, pdata, nbytes, wait_us);
	}

	template <class C>
	bool wait_send(int fd, const evtl::linearbuf<C> &buf, int64_t wait_us = -1)
	{
		return _wait_send(fd, buf.dataptr(), buf.size(), wait_us);
	}

private:
	bool _wait_send(int fd, const void *pdata, ssize_t nbytes, int64_t wait_us)
	{
		if (fd == -1)
		{
			set_error(invalid_fd, fd);
			return false;
		}

		if (pdata == nullptr || nbytes <= 0)
		{
			assert(false && "invalid data buffer");
			return false;
		}

		const char *pdatac = static_cast<const char *>(pdata);
		ssize_t nsent = 0;

		int64_t start_us = evtl::timec::usec();

		while (true)
		{
			if (nsent >= nbytes)
				break;

			int64_t rest_us = -1;
			if (wait_us >= 0)
			{
				int64_t now_us = evtl::timec::usec();

				if (now_us < start_us)
				{
					start_us = now_us;
					rest_us = wait_us;
				}
				else
					rest_us = wait_us - (now_us - start_us);
				if (rest_us <= 0)
				{
					set_error(send_timeout, wait_us);
					return false;
				}
			}

			struct pollfd fds;
			memset(&fds, 0, sizeof(fds));
			fds.fd      = fd;
			fds.events  = POLLOUT;
			fds.revents = 0;

			struct timespec tsp;
			memset(&tsp, 0, sizeof(tsp));
			tsp.tv_sec  = rest_us/1000000;
			tsp.tv_nsec = (rest_us%1000000)*1000;

			int ret = 0;
			if (rest_us < 0)
				ret = ::ppoll(&fds, 1, nullptr, nullptr);
			else
				ret = ::ppoll(&fds, 1, &tsp, nullptr);

			if (ret > 0)
			{
				if ((fds.revents & POLLOUT) == 0)
				{
					set_error(unexpected_revents, fds.revents);
					return false;
				}

				ssize_t r = ::send(fd, pdatac + nsent, nbytes - nsent, 0);
				if (r > 0)
				{
					if (r > nbytes - nsent)
						assert(false && "send too much");
					nsent += r;
				}
				else if (r < 0)
				{
					if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
					{
						set_error(send_failed, errno);
						return false;
					}
				}
				else
					assert(false && "send zero");
			}
			else if (ret == 0)
			{
				set_error(ppoll_timeout, wait_us);
				return false;
			}
			else
			{
				if (errno != EINTR)
				{
					set_error(ppoll_failed, errno);
					return false;
				}
			}
		}

		return true;
	}
};


} }


#endif


