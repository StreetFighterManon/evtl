

#ifndef __EVTL_DLGTLINBUF_H__
#define __EVTL_DLGTLINBUF_H__

#include <sys/types.h>
#include <assert.h>

#include <type_traits>
#include <utility>
#include <algorithm>
#include <string>

#include "evtl_gcc.h"
#include "evtl_exception.h"


namespace evtl
{


template <class T>
class linearbuf;

template <class T>
class ringbuf;

template <class T>
class dlgtringbuf;

template <class T>
class dlgtlinbuf
{
	static_assert(std::is_same<T, char>::value || std::is_same<T, unsigned char>::value,
		"template parameter should be char or unsigned char");

	template <class K> friend class linearbuf;
	template <class K> friend class ringbuf;
	template <class K> friend class dlgtringbuf;
	template <class K> friend class dlgtlinbuf;

public:
	typedef T elem_type;

public:
	dlgtlinbuf()
		: m_buffer_len(0), m_buffer(nullptr), m_pdata_start(nullptr), m_pdata_end(nullptr)
	{}

	dlgtlinbuf(void *pbuffer, ssize_t len)
		: m_buffer_len(0), m_buffer(nullptr), m_pdata_start(nullptr), m_pdata_end(nullptr)
	{
		if (pbuffer == nullptr)
		{
			if (len == 0)
				return;
			else
			{
				assert(false && "invalid buffer");
				return;
			}
		}
		else
		{
			if (len < 0)
			{
				assert(false && "negative len");
				return;
			}
		}

		if (len <= 0)
			m_buffer = nullptr;
		else
			m_buffer = static_cast<T*>(pbuffer);

		m_buffer_len  = len;
		m_pdata_start = m_buffer;
		m_pdata_end   = m_pdata_start;
	}

	dlgtlinbuf(void *pbuffer, ssize_t len, void *pdatastart, void *pdataend)
		: m_buffer_len(0), m_buffer(nullptr), m_pdata_start(nullptr), m_pdata_end(nullptr)
	{
		if (pbuffer == nullptr)
		{
			if (len == 0)
				return;
			else
			{
				assert(false && "invalid buffer");
				return;
			}
		}
		else
		{
			if (len < 0)
			{
				assert(false && "negative len");
				return;
			}
		}

		if (pdatastart < pbuffer || pdatastart > static_cast<T*>(pbuffer) + len)
		{
			assert(false && "bad datastart");
			return;
		}

		if (pdataend < pbuffer || pdataend > static_cast<T*>(pbuffer) + len)
		{
			assert(false && "bad dataend");
			return;
		}

		if (len <= 0)
		{
			m_buffer      = nullptr;
			m_buffer_len  = 0;
			m_pdata_start = m_buffer;
			m_pdata_end   = m_pdata_start;
		}
		else
		{
			m_buffer      = static_cast<T*>(pbuffer);
			m_buffer_len  = len;
			m_pdata_start = static_cast<T*>(pdatastart);
			m_pdata_end   = static_cast<T*>(pdataend);

			if (m_pdata_end <= m_pdata_start)
			{
				m_pdata_start = m_buffer;
				m_pdata_end = m_pdata_start;
			}
		}
	}

	dlgtlinbuf(const dlgtlinbuf &that) = delete;

	dlgtlinbuf(dlgtlinbuf &&that) noexcept = delete;

	~dlgtlinbuf()
	{
		m_buffer      = nullptr;
		m_buffer_len  = 0;
		m_pdata_start = nullptr;
		m_pdata_end   = nullptr;
	}

	void reset()
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		m_buffer      = nullptr;
		m_pdata_start = m_buffer;
		m_pdata_end   = m_pdata_start;
		m_buffer_len  = 0;
	}

	void set_buffer(void *pbuffer, ssize_t len)
	{
		if (pbuffer == nullptr)
		{
			if (len == 0)
			{
				m_buffer = nullptr;
				m_buffer_len = 0;
				m_pdata_start = m_buffer;
				m_pdata_end = m_pdata_start;
			}
			else
			{
				assert(false && "invalid buffer");
				return;
			}
		}
		else
		{
			if (len < 0)
			{
				assert(false && "invalid buffer");
				return;
			}

			if (len <= 0)
				m_buffer = nullptr;
			else
				m_buffer = static_cast<T*>(pbuffer);

			m_buffer_len  = len;
			m_pdata_start = m_buffer;
			m_pdata_end   = m_pdata_start;
		}
	}

	void set_buffer(void *pbuffer, ssize_t len, void *pdatastart, void *pdataend)
	{
		if (pbuffer == nullptr)
		{
			if (len != 0)
			{
				assert(false && "invalid buffer");
				return;
			}
		}
		else
		{
			if (len < 0)
			{
				assert(false && "invalid buffer");
				return;
			}
		}

		if (pdatastart < pbuffer || pdatastart > static_cast<T*>(pbuffer) + len)
		{
			assert(false && "bad datastart");
			return;
		}

		if (pdataend < pbuffer || pdataend > static_cast<T*>(pbuffer) + len)
		{
			assert(false && "bad dataend");
			return;
		}

		if (len <= 0)
		{
			m_buffer = nullptr;
			m_buffer_len = 0;
			m_pdata_start = m_buffer;
			m_pdata_end = m_pdata_start;
		}
		else
		{
			m_buffer      = static_cast<T*>(pbuffer);
			m_buffer_len  = len;
			m_pdata_start = static_cast<T*>(pdatastart);
			m_pdata_end   = static_cast<T*>(pdataend);

			if (m_pdata_end <= m_pdata_start)
			{
				m_pdata_start = m_buffer;
				m_pdata_end = m_pdata_start;
			}
		}
	}

	dlgtlinbuf& operator = (const dlgtlinbuf &that) = delete;

	dlgtlinbuf& operator = (dlgtlinbuf &&that) noexcept = delete;

	bool operator < (const dlgtlinbuf &that) const
	{
		return this->operator < <T>(that);
	}

	bool operator <= (const dlgtlinbuf &that) const
	{
		return this->operator <= <T>(that);
	}

	bool operator > (const dlgtlinbuf &that) const
	{
		return this->operator > <T>(that);
	}

	bool operator >= (const dlgtlinbuf &that) const
	{
		return this->operator >= <T>(that);
	}

	bool operator == (const dlgtlinbuf &that) const
	{
		return this->operator == <T>(that);
	}

	bool operator != (const dlgtlinbuf &that) const
	{
		return this->operator != <T>(that);
	}

	template <class K>
	bool operator < (const dlgtlinbuf<K> &that) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!that._verify()))
			assert(false && "that verify error");
		if (static_cast<const void *>(&that) == this)
			assert(false && "self compare");

		return _compare(that.m_pdata_start, that._size()) < 0;
	}

	template <class K>
	bool operator <= (const dlgtlinbuf<K> &that) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!that._verify()))
			assert(false && "that verify error");
		if (static_cast<const void *>(&that) == this)
			assert(false && "self compare");

		return _compare(that.m_pdata_start, that._size()) <= 0;
	}

	template <class K>
	bool operator > (const dlgtlinbuf<K> &that) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!that._verify()))
			assert(false && "that verify error");
		if (static_cast<const void *>(&that) == this)
			assert(false && "self compare");

		return _compare(that.m_pdata_start, that._size()) > 0;
	}

	template <class K>
	bool operator >= (const dlgtlinbuf<K> &that) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!that._verify()))
			assert(false && "that verify error");
		if (static_cast<const void *>(&that) == this)
			assert(false && "self compare");

		return _compare(that.m_pdata_start, that._size()) >= 0;
	}

	template <class K>
	bool operator == (const dlgtlinbuf<K> &that) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!that._verify()))
			assert(false && "that verify error");
		if (static_cast<const void *>(&that) == this)
			assert(false && "self compare");

		return _compare(that.m_pdata_start, that._size()) == 0;
	}

	template <class K>
	bool operator != (const dlgtlinbuf<K> &that) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!that._verify()))
			assert(false && "that verify error");
		if (static_cast<const void *>(&that) == this)
			assert(false && "self compare");

		return _compare(that.m_pdata_start, that._size()) != 0;
	}

	bool internal_verify() const
	{
		return _verify();
	}

	ssize_t capacity() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return m_buffer_len;
	}

	bool empty_capacity() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return m_buffer_len <= 0;
	}

	bool store_whole(const void *pdata, ssize_t nbytes)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return _store_whole(pdata, nbytes);
	}

	bool store_whole(const std::string &str)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return _store_whole(str.c_str(), (ssize_t)str.size());
	}

	template <class K>
	bool store_whole(const linearbuf<K> &buf, ssize_t nbytes = -1)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(static_cast<const void *>(&buf) == this))
			assert(false && "store myself");
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		ssize_t size = buf.m_pdata_end - buf.m_pdata_start;
		if (nbytes > size)
		{
			assert(false && "out of bounds");
			return false;
		}
		if (nbytes >= 0)
			size = nbytes;

		return _store_whole(buf.m_pdata_start, size);
	}

	template <class K>
	bool store_whole(const dlgtlinbuf<K> &buf, ssize_t nbytes = -1)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(nbytes < 0))
			assert(false && "invalid bytes");
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		ssize_t size = buf.m_pdata_end - buf.m_pdata_start;
		if (nbytes > size)
		{
			assert(false && "out of bounds");
			return false;
		}
		if (nbytes >= 0)
			size = nbytes;

		return _store_whole(buf.m_pdata_start, size);
	}

	template <class K>
	bool store_whole(const ringbuf<K> &buf, ssize_t nbytes = -1)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		ssize_t storesz = buf._size();
		if (nbytes >= 0)
		{
			if (nbytes <= storesz)
				storesz = nbytes;
			else
			{
				assert(false && "out of bounds");
				return false;
			}
		}
		if (storesz > m_buffer_len)
			return false;

		m_pdata_start = m_buffer;
		m_pdata_end = m_pdata_start;

		if (storesz <= 0)
			return true;

		if (buf.m_pdata_end >= buf.m_pdata_start)
		{
			if (buf.m_pdata_start + storesz > buf.m_pdata_end)
				assert(false && "buf error");
			std::copy(buf.m_pdata_start, buf.m_pdata_start + storesz, m_pdata_end);
		}
		else
		{
			ssize_t r_sz = buf.m_buffer + buf.m_buffer_len - buf.m_pdata_start;
			if (storesz <= r_sz)
				std::copy(buf.m_pdata_start, buf.m_pdata_start + storesz, m_pdata_end);
			else
			{
				ssize_t l_sz = buf.m_pdata_end - buf.m_buffer;
				if (storesz > r_sz + l_sz)
					assert(false && "buf error");

				std::copy(buf.m_pdata_start, buf.m_pdata_start + r_sz, m_pdata_end);
				std::copy(buf.m_buffer, buf.m_buffer + storesz - r_sz, m_pdata_end + r_sz);
			}
		}

		m_pdata_end += storesz;
		return true;
	}

	template <class K>
	bool store_whole(const dlgtringbuf<K> &buf, ssize_t nbytes = -1)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		ssize_t storesz = buf._size();
		if (nbytes >= 0)
		{
			if (nbytes <= storesz)
				storesz = nbytes;
			else
			{
				assert(false && "out of bounds");
				return false;
			}
		}
		if (storesz > m_buffer_len)
			return false;

		m_pdata_start = m_buffer;
		m_pdata_end = m_pdata_start;

		if (storesz <= 0)
			return true;

		if (buf.m_pdata_end >= buf.m_pdata_start)
		{
			if (buf.m_pdata_start + storesz > buf.m_pdata_end)
				assert(false && "buf error");
			std::copy(buf.m_pdata_start, buf.m_pdata_start + storesz, m_pdata_end);
		}
		else
		{
			ssize_t r_sz = buf.m_buffer + buf.m_buffer_len - buf.m_pdata_start;
			if (storesz <= r_sz)
				std::copy(buf.m_pdata_start, buf.m_pdata_start + storesz, m_pdata_end);
			else
			{
				ssize_t l_sz = buf.m_pdata_end - buf.m_buffer;
				if (storesz > r_sz + l_sz)
					assert(false && "buf error");

				std::copy(buf.m_pdata_start, buf.m_pdata_start + r_sz, m_pdata_end);
				std::copy(buf.m_buffer, buf.m_buffer + storesz - r_sz, m_pdata_end + r_sz);
			}
		}

		m_pdata_end += storesz;
		return true;
	}

	ssize_t append(const void *pdata, ssize_t nbytes, bool auto_crowd = false, ssize_t crowd_top_size = -1)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (nbytes == 0)
			return 0;

		if (pdata == nullptr || nbytes < 0)
		{
			assert(false && "invalid param");
			return 0;
		}

		if (auto_crowd && _head_space() < nbytes)
		{
			if (crowd_top_size < 0 || _size() <= crowd_top_size)
				_crowd();
		}

		ssize_t maxeat = _head_space();
		if (maxeat > nbytes)
			maxeat = nbytes;
		if (maxeat <= 0)
			return 0;

		std::copy(static_cast<const T*>(pdata), static_cast<const T*>(pdata) + maxeat, m_pdata_end);
		m_pdata_end += maxeat;
		return maxeat;
	}

	template <class K>
	ssize_t append(const linearbuf<K> &buf, ssize_t max_bytes = -1, bool auto_crowd = false, ssize_t crowd_top_size = -1)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(static_cast<const void *>(&buf) == this))
			assert(false && "append myself");
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		ssize_t datasz = buf.m_pdata_end - buf.m_pdata_start;

		if (datasz <= 0 || max_bytes == 0)
			return 0;

		if (max_bytes > 0 && max_bytes < datasz)
			datasz = max_bytes;

		if (auto_crowd && _head_space() < datasz)
		{
			if (crowd_top_size < 0 || _size() <= crowd_top_size)
				_crowd();
		}

		ssize_t maxappend = _head_space();
		if (maxappend > datasz)
			maxappend = datasz;
		if (maxappend <= 0)
			return 0;

		std::copy(buf.m_pdata_start, buf.m_pdata_start + maxappend, m_pdata_end);

		m_pdata_end += maxappend;
		return maxappend;
	}

	template <class K>
	ssize_t append(const dlgtlinbuf<K> &buf, ssize_t max_bytes = -1, bool auto_crowd = false, ssize_t crowd_top_size = -1)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		ssize_t datasz = buf.m_pdata_end - buf.m_pdata_start;

		if (datasz <= 0 || max_bytes == 0)
			return 0;

		if (max_bytes > 0 && max_bytes < datasz)
			datasz = max_bytes;

		if (auto_crowd && _head_space() < datasz)
		{
			if (crowd_top_size < 0 || _size() <= crowd_top_size)
				_crowd();
		}

		ssize_t maxappend = _head_space();
		if (maxappend > datasz)
			maxappend = datasz;
		if (maxappend <= 0)
			return 0;

		std::copy(buf.m_pdata_start, buf.m_pdata_start + maxappend, m_pdata_end);

		m_pdata_end += maxappend;
		return maxappend;
	}

	template <class K>
	ssize_t append(const ringbuf<K> &buf, ssize_t max_bytes = -1, bool auto_crowd = false, ssize_t crowd_top_size = -1)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "lnbuf verify error");
		if (evunlike(!buf._verify()))
			assert(false && "rnbuf verify error");

		ssize_t appendsz = buf._size();

		if (appendsz <= 0 || max_bytes == 0)
			return 0;

		if (max_bytes > 0 && max_bytes < appendsz)
			appendsz = max_bytes;

		if (auto_crowd && _head_space() < appendsz)
		{
			if (crowd_top_size < 0 || _size() < crowd_top_size)
				_crowd();
		}

		ssize_t maxappend = _head_space();
		if (maxappend > appendsz)
			maxappend = appendsz;
		if (maxappend <= 0)
			return 0;

		if (buf.m_pdata_end > buf.m_pdata_start)
		{
			ssize_t ringsz = buf.m_pdata_end - buf.m_pdata_start;
			if (maxappend > ringsz)
				maxappend = ringsz;

			std::copy(buf.m_pdata_start, buf.m_pdata_start + maxappend, m_pdata_end);
			m_pdata_end += maxappend;
		}
		else if (buf.m_pdata_end < buf.m_pdata_start)
		{
			ssize_t r_sz = buf.m_buffer + buf.m_buffer_len - buf.m_pdata_start;
			ssize_t l_sz = buf.m_pdata_end - buf.m_buffer;

			if (r_sz <= 0 || l_sz < 0)
				assert(false && "buf error");

			if (maxappend > r_sz + l_sz)
				maxappend = r_sz + l_sz;

			if (maxappend <= r_sz)
			{
				std::copy(buf.m_pdata_start, buf.m_pdata_start + maxappend, m_pdata_end);
				m_pdata_end += maxappend;
			}
			else
			{
				std::copy(buf.m_pdata_start, buf.m_pdata_start + r_sz, m_pdata_end);
				std::copy(buf.m_buffer, buf.m_buffer + (maxappend - r_sz), m_pdata_end + r_sz);
				m_pdata_end += maxappend;
			}
		}
		else
		{
			maxappend = 0;
		}

		return maxappend;
	}

	template <class K>
	ssize_t append(const dlgtringbuf<K> &buf, ssize_t max_bytes = -1, bool auto_crowd = false, ssize_t crowd_top_size = -1)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "lnbuf verify error");
		if (evunlike(!buf._verify()))
			assert(false && "rnbuf verify error");

		ssize_t appendsz = buf._size();

		if (appendsz <= 0 || max_bytes == 0)
			return 0;

		if (max_bytes > 0 && max_bytes < appendsz)
			appendsz = max_bytes;

		if (auto_crowd && _head_space() < appendsz)
		{
			if (crowd_top_size < 0 || _size() < crowd_top_size)
				_crowd();
		}

		ssize_t maxappend = _head_space();
		if (maxappend > appendsz)
			maxappend = appendsz;
		if (maxappend <= 0)
			return 0;

		if (buf.m_pdata_end > buf.m_pdata_start)
		{
			ssize_t ringsz = buf.m_pdata_end - buf.m_pdata_start;
			if (maxappend > ringsz)
				maxappend = ringsz;

			std::copy(buf.m_pdata_start, buf.m_pdata_start + maxappend, m_pdata_end);
			m_pdata_end += maxappend;
		}
		else if (buf.m_pdata_end < buf.m_pdata_start)
		{
			ssize_t r_sz = buf.m_buffer + buf.m_buffer_len - buf.m_pdata_start;
			ssize_t l_sz = buf.m_pdata_end - buf.m_buffer;

			if (r_sz <= 0 || l_sz < 0)
				assert(false && "buf error");

			if (maxappend > r_sz + l_sz)
				maxappend = r_sz + l_sz;

			if (maxappend <= r_sz)
			{
				std::copy(buf.m_pdata_start, buf.m_pdata_start + maxappend, m_pdata_end);
				m_pdata_end += maxappend;
			}
			else
			{
				std::copy(buf.m_pdata_start, buf.m_pdata_start + r_sz, m_pdata_end);
				std::copy(buf.m_buffer, buf.m_buffer + (maxappend - r_sz), m_pdata_end + r_sz);
				m_pdata_end += maxappend;
			}
		}
		else
		{
			maxappend = 0;
		}

		return maxappend;
	}

	bool append_whole(const void *pdata, ssize_t nbytes, bool auto_crowd = false, ssize_t crowd_top_size = -1)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (nbytes == 0)
			return true;
		if (pdata == nullptr || nbytes < 0)
		{
			assert(false && "invalid param");
			return false;
		}
		if (auto_crowd && _head_space() < nbytes)
		{
			if (_space() < nbytes)
				return false;
			if (crowd_top_size < 0 || _size() <= crowd_top_size)
				_crowd();
		}
		if (_head_space() < nbytes)
			return false;

		std::copy(static_cast<const T*>(pdata), static_cast<const T*>(pdata) + nbytes, m_pdata_end);
		m_pdata_end += nbytes;

		return true;
	}

	template <class K>
	bool append_whole(const linearbuf<K> &buf, ssize_t nbytes = -1, bool auto_crowd = false, ssize_t crowd_top_size = -1)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(static_cast<const void *>(&buf) == this))
			assert(false && "append myself");
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		ssize_t datasz = buf.m_pdata_end - buf.m_pdata_start;
		if (nbytes >= 0)
		{
			if (nbytes <= datasz)
				datasz = nbytes;
			else
			{
				assert(false && "nbytes overflow");
				return false;
			}
		}

		if (datasz <= 0)
			return true;

		if (auto_crowd && _head_space() < datasz)
		{
			if (_space() < datasz)
				return false;
			if (crowd_top_size < 0 || _size() <= crowd_top_size)
				_crowd();
		}

		if (_head_space() < datasz)
			return false;

		std::copy(buf.m_pdata_start, buf.m_pdata_start + datasz, m_pdata_end);
		m_pdata_end += datasz;

		return true;
	}

	template <class K>
	bool append_whole(const dlgtlinbuf<K> &buf, ssize_t nbytes = -1, bool auto_crowd = false, ssize_t crowd_top_size = -1)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(static_cast<const void *>(&buf) == this))
			assert(false && "append myself");
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		ssize_t datasz = buf.m_pdata_end - buf.m_pdata_start;
		if (nbytes >= 0)
		{
			if (nbytes <= datasz)
				datasz = nbytes;
			else
			{
				assert(false && "nbytes overflow");
				return false;
			}
		}

		if (datasz <= 0)
			return true;

		if (auto_crowd && _head_space() < datasz)
		{
			if (_space() < datasz)
				return false;
			if (crowd_top_size < 0 || _size() <= crowd_top_size)
				_crowd();
		}

		if (_head_space() < datasz)
			return false;

		std::copy(buf.m_pdata_start, buf.m_pdata_start + datasz, m_pdata_end);
		m_pdata_end += datasz;

		return true;
	}

	template <class K>
	bool append_whole(const ringbuf<K> &buf, ssize_t nbytes = -1, bool auto_crowd = false, ssize_t crowd_top_size = -1)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "lnbuf verify error");
		if (evunlike(!buf._verify()))
			assert(false && "rnbuf verify error");

		if (nbytes >= 0 && nbytes > buf._size())
		{
			assert(false && "out of bounds");
			return false;
		}

		ssize_t appendsz = buf._size();
		if (nbytes >= 0)
			appendsz = nbytes;

		if (appendsz <= 0)
			return true;

		if (auto_crowd && _head_space() < appendsz)
		{
			if (_space() < appendsz)
				return false;
			if (crowd_top_size < 0 || _size() <= crowd_top_size)
				_crowd();
		}
		if (_head_space() < appendsz)
			return false;

		if (buf.m_pdata_end >= buf.m_pdata_start)
		{
			if (buf.m_pdata_end - buf.m_pdata_start < appendsz)
				assert(false && "rnbuf error");
	
			std::copy(buf.m_pdata_start, buf.m_pdata_start + appendsz, m_pdata_end);
			m_pdata_end += appendsz;
		}
		else
		{
			ssize_t r_sz = buf.m_buffer + buf.m_buffer_len - buf.m_pdata_start;
			ssize_t l_sz = buf.m_pdata_end - buf.m_buffer;

			if (r_sz <= 0 || l_sz < 0)
				assert(false && "buf error");

			if (appendsz <= r_sz)
			{
				r_sz = appendsz;
				l_sz = 0;
			}
			else if (appendsz <= r_sz + l_sz)
			{
				l_sz = appendsz - r_sz;
			}
			else
			{
				assert(false && "buf size error");
			}

			std::copy(buf.m_pdata_start, buf.m_pdata_start + r_sz, m_pdata_end);
			if (l_sz > 0)
				std::copy(buf.m_buffer, buf.m_buffer + l_sz, m_pdata_end + r_sz);

			m_pdata_end += appendsz;
		}

		return true;
	}

	template <class K>
	bool append_whole(const dlgtringbuf<K> &buf, ssize_t nbytes = -1, bool auto_crowd = false, ssize_t crowd_top_size = -1)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "lnbuf verify error");
		if (evunlike(!buf._verify()))
			assert(false && "rnbuf verify error");

		if (nbytes >= 0 && nbytes > buf._size())
		{
			assert(false && "out of bounds");
			return false;
		}

		ssize_t appendsz = buf._size();
		if (nbytes >= 0)
			appendsz = nbytes;

		if (appendsz <= 0)
			return true;

		if (auto_crowd && _head_space() < appendsz)
		{
			if (_space() < appendsz)
				return false;
			if (crowd_top_size < 0 || _size() <= crowd_top_size)
				_crowd();
		}
		if (_head_space() < appendsz)
			return false;

		if (buf.m_pdata_end >= buf.m_pdata_start)
		{
			if (buf.m_pdata_end - buf.m_pdata_start < appendsz)
				assert(false && "rnbuf error");
	
			std::copy(buf.m_pdata_start, buf.m_pdata_start + appendsz, m_pdata_end);
			m_pdata_end += appendsz;
		}
		else
		{
			ssize_t r_sz = buf.m_buffer + buf.m_buffer_len - buf.m_pdata_start;
			ssize_t l_sz = buf.m_pdata_end - buf.m_buffer;

			if (r_sz <= 0 || l_sz < 0)
				assert(false && "buf error");

			if (appendsz <= r_sz)
			{
				r_sz = appendsz;
				l_sz = 0;
			}
			else if (appendsz <= r_sz + l_sz)
			{
				l_sz = appendsz - r_sz;
			}
			else
			{
				assert(false && "buf size error");
			}

			std::copy(buf.m_pdata_start, buf.m_pdata_start + r_sz, m_pdata_end);
			if (l_sz > 0)
				std::copy(buf.m_buffer, buf.m_buffer + l_sz, m_pdata_end + r_sz);

			m_pdata_end += appendsz;
		}

		return true;
	}

	template <class K>
	ssize_t eat(linearbuf<K> &buf, ssize_t max_bytes = -1, bool auto_crowd = false, ssize_t crowd_top_size = -1)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(static_cast<void *>(&buf) == this))
			assert(false && "eat myself");
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		ssize_t datasz = buf.m_pdata_end - buf.m_pdata_start;

		if (datasz <= 0 || max_bytes == 0)
			return 0;

		if (max_bytes > 0 && max_bytes < datasz)
			datasz = max_bytes;

		if (auto_crowd && _head_space() < datasz)
		{
			if (crowd_top_size < 0 || _size() <= crowd_top_size)
				_crowd();
		}

		ssize_t maxeat = _head_space();
		if (maxeat > datasz)
			maxeat = datasz;
		if (maxeat <= 0)
			return 0;

		std::copy(buf.m_pdata_start, buf.m_pdata_start + maxeat, m_pdata_end);

		m_pdata_end += maxeat;
		buf.m_pdata_start += maxeat;
		if (buf.m_pdata_start >= buf.m_pdata_end)
		{
			buf.m_pdata_start = buf.m_buffer;
			buf.m_pdata_end = buf.m_pdata_start;
		}

		return maxeat;
	}

	template <class K>
	ssize_t eat(dlgtlinbuf<K> &buf, ssize_t max_bytes = -1, bool auto_crowd = false, ssize_t crowd_top_size = -1)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		ssize_t datasz = buf.m_pdata_end - buf.m_pdata_start;

		if (datasz <= 0 || max_bytes == 0)
			return 0;

		if (max_bytes > 0 && max_bytes < datasz)
			datasz = max_bytes;

		if (auto_crowd && _head_space() < datasz)
		{
			if (crowd_top_size < 0 || _size() <= crowd_top_size)
				_crowd();
		}

		ssize_t maxeat = _head_space();
		if (maxeat > datasz)
			maxeat = datasz;
		if (maxeat <= 0)
			return 0;

		std::copy(buf.m_pdata_start, buf.m_pdata_start + maxeat, m_pdata_end);

		m_pdata_end += maxeat;
		buf.m_pdata_start += maxeat;
		if (buf.m_pdata_start >= buf.m_pdata_end)
		{
			buf.m_pdata_start = buf.m_buffer;
			buf.m_pdata_end = buf.m_pdata_start;
		}

		return maxeat;
	}

	template <class K>
	ssize_t eat(ringbuf<K> &buf, ssize_t max_bytes = -1, bool auto_crowd = false, ssize_t crowd_top_size = -1)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "lnbuf verify error");
		if (evunlike(!buf._verify()))
			assert(false && "rnbuf verify error");

		ssize_t eatsz = buf._size();

		if (eatsz <= 0 || max_bytes == 0)
			return 0;

		if (max_bytes > 0 && max_bytes < eatsz)
			eatsz = max_bytes;

		if (auto_crowd && _head_space() < eatsz)
		{
			if (crowd_top_size < 0 || _size() < crowd_top_size)
				_crowd();
		}

		ssize_t maxeat = _head_space();
		if (maxeat > eatsz)
			maxeat = eatsz;
		if (maxeat <= 0)
			return 0;

		if (buf.m_pdata_end > buf.m_pdata_start)
		{
			ssize_t ringsz = buf.m_pdata_end - buf.m_pdata_start;
			if (maxeat > ringsz)
				maxeat = ringsz;

			std::copy(buf.m_pdata_start, buf.m_pdata_start + maxeat, m_pdata_end);
			m_pdata_end += maxeat;
			buf._start_forward(maxeat);
		}
		else if (buf.m_pdata_end < buf.m_pdata_start)
		{
			ssize_t r_sz = buf.m_buffer + buf.m_buffer_len - buf.m_pdata_start;
			ssize_t l_sz = buf.m_pdata_end - buf.m_buffer;

			if (r_sz <= 0 || l_sz < 0)
				assert(false && "buf error");

			if (maxeat > r_sz + l_sz)
				maxeat = r_sz + l_sz;

			if (maxeat <= r_sz)
			{
				std::copy(buf.m_pdata_start, buf.m_pdata_start + maxeat, m_pdata_end);
				m_pdata_end += maxeat;
				buf._start_forward(maxeat);
			}
			else
			{
				std::copy(buf.m_pdata_start, buf.m_pdata_start + r_sz, m_pdata_end);
				std::copy(buf.m_buffer, buf.m_buffer + (maxeat - r_sz), m_pdata_end + r_sz);
				m_pdata_end += maxeat;
				buf._start_forward(maxeat);
			}
		}
		else
		{
			maxeat = 0;
		}

		return maxeat;
	}

	template <class K>
	ssize_t eat(dlgtringbuf<K> &buf, ssize_t max_bytes = -1, bool auto_crowd = false, ssize_t crowd_top_size = -1)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "lnbuf verify error");
		if (evunlike(!buf._verify()))
			assert(false && "rnbuf verify error");

		ssize_t eatsz = buf._size();

		if (eatsz <= 0 || max_bytes == 0)
			return 0;

		if (max_bytes > 0 && max_bytes < eatsz)
			eatsz = max_bytes;

		if (auto_crowd && _head_space() < eatsz)
		{
			if (crowd_top_size < 0 || _size() < crowd_top_size)
				_crowd();
		}

		ssize_t maxeat = _head_space();
		if (maxeat > eatsz)
			maxeat = eatsz;
		if (maxeat <= 0)
			return 0;

		if (buf.m_pdata_end > buf.m_pdata_start)
		{
			ssize_t ringsz = buf.m_pdata_end - buf.m_pdata_start;
			if (maxeat > ringsz)
				maxeat = ringsz;

			std::copy(buf.m_pdata_start, buf.m_pdata_start + maxeat, m_pdata_end);
			m_pdata_end += maxeat;
			buf._start_forward(maxeat);
		}
		else if (buf.m_pdata_end < buf.m_pdata_start)
		{
			ssize_t r_sz = buf.m_buffer + buf.m_buffer_len - buf.m_pdata_start;
			ssize_t l_sz = buf.m_pdata_end - buf.m_buffer;

			if (r_sz <= 0 || l_sz < 0)
				assert(false && "buf error");

			if (maxeat > r_sz + l_sz)
				maxeat = r_sz + l_sz;

			if (maxeat <= r_sz)
			{
				std::copy(buf.m_pdata_start, buf.m_pdata_start + maxeat, m_pdata_end);
				m_pdata_end += maxeat;
				buf._start_forward(maxeat);
			}
			else
			{
				std::copy(buf.m_pdata_start, buf.m_pdata_start + r_sz, m_pdata_end);
				std::copy(buf.m_buffer, buf.m_buffer + (maxeat - r_sz), m_pdata_end + r_sz);
				m_pdata_end += maxeat;
				buf._start_forward(maxeat);
			}
		}
		else
		{
			maxeat = 0;
		}

		return maxeat;
	}

	template <class K>
	bool eat_whole(linearbuf<K> &buf, ssize_t nbytes = -1, bool auto_crowd = false, ssize_t crowd_top_size = -1)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(static_cast<void *>(&buf) == this))
			assert(false && "eat myself");
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		ssize_t datasz = buf.m_pdata_end - buf.m_pdata_start;
		if (nbytes >= 0)
		{
			if (nbytes <= datasz)
				datasz = nbytes;
			else
			{
				assert(false && "nbytes overflow");
				return false;
			}
		}

		if (datasz <= 0)
			return true;

		if (auto_crowd && _head_space() < datasz)
		{
			if (_space() < datasz)
				return false;
			if (crowd_top_size < 0 || _size() <= crowd_top_size)
				_crowd();
		}

		if (_head_space() < datasz)
			return false;

		std::copy(buf.m_pdata_start, buf.m_pdata_start + datasz, m_pdata_end);

		m_pdata_end += datasz;
		buf.m_pdata_start += datasz;
		if (buf.m_pdata_start >= buf.m_pdata_end)
		{
			buf.m_pdata_start = buf.m_buffer;
			buf.m_pdata_end = buf.m_pdata_start;
		}

		return true;
	}

	template <class K>
	bool eat_whole(dlgtlinbuf<K> &buf, ssize_t nbytes = -1, bool auto_crowd = false, ssize_t crowd_top_size = -1)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(static_cast<void *>(&buf) == this))
			assert(false && "eat myself");
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		ssize_t datasz = buf.m_pdata_end - buf.m_pdata_start;
		if (nbytes >= 0)
		{
			if (nbytes <= datasz)
				datasz = nbytes;
			else
			{
				assert(false && "nbytes overflow");
				return false;
			}
		}

		if (datasz <= 0)
			return true;

		if (auto_crowd && _head_space() < datasz)
		{
			if (_space() < datasz)
				return false;
			if (crowd_top_size < 0 || _size() <= crowd_top_size)
				_crowd();
		}

		if (_head_space() < datasz)
			return false;

		std::copy(buf.m_pdata_start, buf.m_pdata_start + datasz, m_pdata_end);

		m_pdata_end += datasz;
		buf.m_pdata_start += datasz;
		if (buf.m_pdata_start >= buf.m_pdata_end)
		{
			buf.m_pdata_start = buf.m_buffer;
			buf.m_pdata_end = buf.m_pdata_start;
		}

		return true;
	}

	template <class K>
	bool eat_whole(ringbuf<K> &buf, ssize_t nbytes = -1, bool auto_crowd = false, ssize_t crowd_top_size = -1)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "lnbuf verify error");
		if (evunlike(!buf._verify()))
			assert(false && "rnbuf verify error");

		if (nbytes >= 0 && nbytes > buf._size())
		{
			assert(false && "out of bounds");
			return false;
		}

		ssize_t eatsz = buf._size();
		if (nbytes >= 0)
			eatsz = nbytes;

		if (eatsz <= 0)
			return true;

		if (auto_crowd && _head_space() < eatsz)
		{
			if (_space() < eatsz)
				return false;
			if (crowd_top_size < 0 || _size() <= crowd_top_size)
				_crowd();
		}
		if (_head_space() < eatsz)
			return false;

		if (buf.m_pdata_end >= buf.m_pdata_start)
		{
			if (buf.m_pdata_end - buf.m_pdata_start < eatsz)
				assert(false && "rnbuf error");
	
			std::copy(buf.m_pdata_start, buf.m_pdata_start + eatsz, m_pdata_end);
			m_pdata_end += eatsz;
			buf._start_forward(eatsz);
		}
		else
		{
			ssize_t r_sz = buf.m_buffer + buf.m_buffer_len - buf.m_pdata_start;
			ssize_t l_sz = buf.m_pdata_end - buf.m_buffer;

			if (r_sz <= 0 || l_sz < 0)
				assert(false && "buf error");

			if (eatsz <= r_sz)
			{
				r_sz = eatsz;
				l_sz = 0;
			}
			else if (eatsz <= r_sz + l_sz)
			{
				l_sz = eatsz - r_sz;
			}
			else
			{
				assert(false && "buf size error");
			}

			std::copy(buf.m_pdata_start, buf.m_pdata_start + r_sz, m_pdata_end);
			if (l_sz > 0)
				std::copy(buf.m_buffer, buf.m_buffer + l_sz, m_pdata_end + r_sz);

			m_pdata_end += eatsz;
			buf._start_forward(eatsz);
		}

		return true;
	}

	template <class K>
	bool eat_whole(dlgtringbuf<K> &buf, ssize_t nbytes = -1, bool auto_crowd = false, ssize_t crowd_top_size = -1)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "lnbuf verify error");
		if (evunlike(!buf._verify()))
			assert(false && "rnbuf verify error");

		if (nbytes >= 0 && nbytes > buf._size())
		{
			assert(false && "out of bounds");
			return false;
		}

		ssize_t eatsz = buf._size();
		if (nbytes >= 0)
			eatsz = nbytes;

		if (eatsz <= 0)
			return true;

		if (auto_crowd && _head_space() < eatsz)
		{
			if (_space() < eatsz)
				return false;
			if (crowd_top_size < 0 || _size() <= crowd_top_size)
				_crowd();
		}
		if (_head_space() < eatsz)
			return false;

		if (buf.m_pdata_end >= buf.m_pdata_start)
		{
			if (buf.m_pdata_end - buf.m_pdata_start < eatsz)
				assert(false && "rnbuf error");
	
			std::copy(buf.m_pdata_start, buf.m_pdata_start + eatsz, m_pdata_end);
			m_pdata_end += eatsz;
			buf._start_forward(eatsz);
		}
		else
		{
			ssize_t r_sz = buf.m_buffer + buf.m_buffer_len - buf.m_pdata_start;
			ssize_t l_sz = buf.m_pdata_end - buf.m_buffer;

			if (r_sz <= 0 || l_sz < 0)
				assert(false && "buf error");

			if (eatsz <= r_sz)
			{
				r_sz = eatsz;
				l_sz = 0;
			}
			else if (eatsz <= r_sz + l_sz)
			{
				l_sz = eatsz - r_sz;
			}
			else
			{
				assert(false && "buf size error");
			}

			std::copy(buf.m_pdata_start, buf.m_pdata_start + r_sz, m_pdata_end);
			if (l_sz > 0)
				std::copy(buf.m_buffer, buf.m_buffer + l_sz, m_pdata_end + r_sz);

			m_pdata_end += eatsz;
			buf._start_forward(eatsz);
		}

		return true;
	}

	ssize_t shit(ssize_t nbytes)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (nbytes < 0)
		{
			assert(false && "negative bytes");
			return 0;
		}

		if (nbytes == 0)
			return 0;

		ssize_t ln = m_pdata_end - m_pdata_start;
		if (nbytes > ln)
			nbytes = ln;
		if (nbytes == 0)
			return 0;

		m_pdata_start += nbytes;
		if (m_pdata_start >= m_pdata_end)
		{
			m_pdata_start = m_buffer;
			m_pdata_end = m_pdata_start;
		}

		return nbytes;
	}

	bool shit_whole(ssize_t nbytes)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (nbytes < 0)
		{
			assert(false && "negative bytes");
			return false;
		}

		if (nbytes == 0)
			return true;

		ssize_t ln = m_pdata_end - m_pdata_start;
		if (ln < nbytes)
			return false;

		m_pdata_start += nbytes;
		if (m_pdata_start >= m_pdata_end)
		{
			m_pdata_start = m_buffer;
			m_pdata_end = m_pdata_start;
		}

		return true;
	}

	ssize_t shit_to(ssize_t left_bytes)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		ssize_t shtsz = _size();

		if (left_bytes > 0)
			shtsz -= left_bytes;
		if (shtsz < 0)
			shtsz = 0;

		m_pdata_start += shtsz;
		if (m_pdata_start >= m_pdata_end)
		{
			m_pdata_start = m_buffer;
			m_pdata_end = m_pdata_start;
		}

		return shtsz;
	}

	int compare(const void *pdata, ssize_t nbytes) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return _compare(pdata, nbytes);
	}

	int compare(const std::string &str) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return _compare(str.c_str(), (ssize_t)str.size());
	}

	template <class K>
	int compare(const dlgtlinbuf<K> &buf) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");
		if (evunlike(static_cast<const void *>(&buf) == this))
			assert(false && "compare myself");

		return _compare(buf.m_pdata_start, buf._size());
	}

	template <class K>
	linearbuf<K> subbuf(ssize_t pos, ssize_t len = -1) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		ssize_t sz = _size();

		if (pos < 0 || pos > sz)
			assert(false && "bad pos");

		if (len != -1)
		{
			if (len < 0 || pos + len > sz)
				assert(false && "bad len");

			return linearbuf<K>(m_pdata_start + pos, len);
		}

		return linearbuf<K>(m_pdata_start + pos, sz - pos);
	}

	std::string substr(ssize_t pos, ssize_t len = -1) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		ssize_t sz = _size();

		if (pos < 0 || pos > sz)
			assert(false && "bad pos");

		if (len != -1)
		{
			if (len < 0 || pos + len > sz)
				assert(false && "bad len");

			if (len > 0)
				return std::string(reinterpret_cast<const char *>(m_pdata_start + pos), len);
			else
				return std::string();
		}

		if (sz - pos > 0)
			return std::string(reinterpret_cast<const char *>(m_pdata_start + pos), sz - pos);

		return std::string();
	}

	void crowd(ssize_t crowd_top_size = -1)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (crowd_top_size < 0 || _size() <= crowd_top_size)
			_crowd();
	}

	void crowdac(ssize_t data_top_size = -1, ssize_t head_top_size = -1)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		bool dcrw = false;
		bool hcrw = false;

		if (data_top_size < 0 || _size() <= data_top_size)
			dcrw = true;
		if (head_top_size < 0 || _head_space() <= head_top_size)
			hcrw = true;

		if (dcrw && hcrw)
			_crowd();
	}

	void crowdct(ssize_t data_top_size = -1, ssize_t datahead_top_size = -1)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		bool dcrw = false;
		bool dhcrw = false;

		ssize_t sz = _size();
		ssize_t hdsp = _head_space();

		if (data_top_size < 0 || sz <= data_top_size)
			dcrw = true;
		if (datahead_top_size < 0 || sz + hdsp <= datahead_top_size)
			dhcrw = true;

		if (dcrw && dhcrw)
			_crowd();
	}

	void clear()
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		m_pdata_start = m_buffer;
		m_pdata_end = m_pdata_start;
	}

	ssize_t size() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return _size();
	}

	bool empty() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return m_pdata_end <= m_pdata_start;
	}

	bool full() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return (m_pdata_end - m_pdata_start >= m_buffer_len);
	}

	ssize_t space() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return _space();
	}

	ssize_t tailspace() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return _tail_space();
	}

	ssize_t headspace() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return _head_space();
	}

	const T& at(ssize_t index) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (evunlike(index < 0 || index >= m_pdata_end - m_pdata_start))
			assert(false && "index out of bounds");

		return m_pdata_start[index];
	}

	T& at(ssize_t index)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (evunlike(index < 0 || index >= m_pdata_end - m_pdata_start))
			assert(false && "index out of bounds");

		return m_pdata_start[index];
	}

	const T& operator [] (ssize_t index) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (evunlike(index < 0 || index >= m_pdata_end - m_pdata_start))
			assert(false && "index out of bounds");

		return m_pdata_start[index];
	}

	T& operator [] (ssize_t index)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (evunlike(index < 0 || index >= m_pdata_end - m_pdata_start))
			assert(false && "index out of bounds");

		return m_pdata_start[index];
	}

	const T* dataptr() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return m_pdata_start;
	}

	const T* headptr() const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return m_pdata_end;
	}

	T* headptr()
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		return m_pdata_end;
	}

	ssize_t head_eaten(ssize_t nbytes)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (nbytes < 0)
			assert(false && "negative nbytes");

		if (nbytes <= 0)
			return 0;

		ssize_t maxsize = _head_space();
		if (nbytes > maxsize)
			nbytes = maxsize;

		m_pdata_end += nbytes;
		return nbytes;
	}

	bool head_eaten_whole(ssize_t nbytes)
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (nbytes < 0)
		{
			assert(false && "negative nbytes");
			return false;
		}

		if (nbytes > _head_space())
			return false;

		m_pdata_end += nbytes;
		return true;
	}

	ssize_t copy_out(void *pbuf, ssize_t nbytes, ssize_t from_pos = 0) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (from_pos < 0)
		{
			assert(false && "negative frompos");
			return 0;
		}

		if (nbytes == 0)
			return 0;

		if (pbuf == nullptr || nbytes < 0)
		{
			assert(false && "invalid buffer");
			return 0;
		}

		if (from_pos >= m_pdata_end - m_pdata_start)
			return 0;

		ssize_t maxcopy = m_pdata_end - m_pdata_start - from_pos;
		if (maxcopy > nbytes)
			maxcopy = nbytes;

		std::copy(m_pdata_start + from_pos, m_pdata_start + from_pos + maxcopy, static_cast<T*>(pbuf));
		return maxcopy;
	}

	bool copy_out_whole(void *pbuf, ssize_t nbytes, ssize_t from_pos = 0) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (from_pos < 0)
		{
			assert(false && "negative frompos");
			return false;
		}

		if (nbytes == 0)
			return false;

		if (pbuf == nullptr || nbytes < 0)
		{
			assert(false && "invalid param");
			return false;
		}

		if (from_pos >= m_pdata_end - m_pdata_start)
			return false;

		ssize_t maxcopy = m_pdata_end - m_pdata_start - from_pos;
		if (maxcopy < nbytes)
			return false;

		std::copy(m_pdata_start + from_pos, m_pdata_start + from_pos + nbytes, static_cast<T*>(pbuf));
		return true;
	}

	ssize_t find(T c, ssize_t from_pos = 0, ssize_t max_search_bytes = 0) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (from_pos < 0)
		{
			assert(false && "negative frompos");
			return -1;
		}

		if (from_pos >= m_pdata_end - m_pdata_start)
			return -1;

		const T* p_end = m_pdata_end;
		if (max_search_bytes > 0 && from_pos + max_search_bytes < m_pdata_end - m_pdata_start)
			p_end = m_pdata_start + from_pos + max_search_bytes;

		const T* p = std::find(static_cast<const T*>(m_pdata_start) + from_pos, p_end, c);
		if (p == p_end)
			return -1;

		return p - m_pdata_start;
	}

	ssize_t finds(const void *pmatch, ssize_t match_bytes, ssize_t from_pos = 0, ssize_t max_search_bytes = 0) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		if (from_pos < 0)
		{
			assert(false && "negative frompos");
			return -1;
		}

		if (match_bytes == 0)
			return -1;

		if (pmatch == nullptr || match_bytes < 0)
		{
			assert(false && "invalid match bytes");
			return -1;
		}

		if (from_pos >= m_pdata_end - m_pdata_start)
			return -1;

		const T* p_end = m_pdata_end;
		if (max_search_bytes > 0 && from_pos + max_search_bytes < m_pdata_end - m_pdata_start)
			p_end = m_pdata_start + from_pos + max_search_bytes;

		const T* p = std::search(static_cast<const T*>(m_pdata_start) + from_pos, p_end, static_cast<const T*>(pmatch), static_cast<const T*>(pmatch) + match_bytes);
		if (p == p_end)
			return -1;

		return p - m_pdata_start;
	}

	template <class K>
	void swap(dlgtlinbuf<K> &buf)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "verify error");
		if (evunlike(!buf._verify()))
			assert(false && "buf verify error");

		if (evunlike(static_cast<void *>(&buf) == this))
			return;

		_swap(buf);
	}

	template <class K>
	linearbuf<K> min_clone() const
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		if (evunlike(!_verify()))
			assert(false && "verify error");

		linearbuf<K> buf;

		if (m_pdata_end > m_pdata_start)
		{
			ssize_t datesz = m_pdata_end - m_pdata_start;

			K *buffer = new K[datesz];
			if (buffer == nullptr)
				throw simpexception("malloc failed");
			else
			{
				std::copy(m_pdata_start, m_pdata_end, buffer);
				buf.m_buffer      = buffer;
				buf.m_buffer_len  = datesz;
				buf.m_pdata_start = buf.m_buffer;
				buf.m_pdata_end   = buf.m_pdata_start + datesz;
			}
		}

		return buf;
	}

	std::string tostring(ssize_t max_size = 0) const
	{
		if (evunlike(!_verify()))
			assert(false && "verify error");

		std::string s;

		if (m_pdata_end > m_pdata_start)
		{
			ssize_t sz = m_pdata_end - m_pdata_start;
			if (max_size > 0 && max_size < sz)
				sz = max_size;

			s.assign(reinterpret_cast<const char *>(m_pdata_start), sz);
		}

		return s;
	}

	ssize_t member_buflen() const
	{
		return m_buffer_len;
	}

	const T* member_bufptr() const
	{
		return m_buffer;
	}

	T* member_bufptr()
	{
		return m_buffer;
	}

	const T* member_startptr() const
	{
		return m_pdata_start;
	}

	T* member_startptr()
	{
		return m_pdata_start;
	}

	const T* member_endptr() const
	{
		return m_pdata_end;
	}

	T* member_endptr()
	{
		return m_pdata_end;
	}

private:
	bool _verify() const
	{
		if (m_buffer_len > 0)
		{
			if (m_buffer == nullptr)
				return false;
			if (m_pdata_start < m_buffer || m_pdata_start - m_buffer >= m_buffer_len)
				return false;
			if (m_pdata_end < m_pdata_start || m_pdata_end - m_buffer > m_buffer_len)
				return false;
		}
		else if (m_buffer_len == 0)
		{
			if (m_buffer != nullptr || m_pdata_start != nullptr || m_pdata_end != nullptr)
				return false;
		}
		else
		{
			return false;
		}

		return true;
	}

	ssize_t _space() const
	{
		return m_buffer_len - (m_pdata_end - m_pdata_start);
	}

	ssize_t _tail_space() const
	{
		return m_pdata_start - m_buffer;
	}

	ssize_t _head_space() const
	{
		return m_buffer + m_buffer_len - m_pdata_end;
	}

	void _crowd()
	{
		if (m_pdata_start <= m_buffer)
			return;

		ssize_t dist = m_pdata_end - m_pdata_start;
		if (dist > 0)
			std::copy(m_pdata_start, m_pdata_end, m_buffer);
		m_pdata_start = m_buffer;
		m_pdata_end = m_pdata_start + dist;
	}

	ssize_t _size() const
	{
		return m_pdata_end - m_pdata_start;
	}

	bool _store_whole(const void *pdata, ssize_t nbytes)
	{
		if (nbytes == 0)
		{
			m_pdata_start = m_buffer;
			m_pdata_end = m_pdata_start;
			return true;
		}

		if (pdata == nullptr || nbytes < 0)
		{
			assert(false && "invalid param");
			return false;
		}

		if (nbytes <= m_buffer_len)
		{
			m_pdata_start = m_buffer;
			m_pdata_end = m_pdata_start;

			std::copy(static_cast<const T*>(pdata), static_cast<const T*>(pdata) + nbytes, m_pdata_end);
			m_pdata_end += nbytes;
			return true;
		}

		return false;
	}

	template <class K>
	void _swap(linearbuf<K> &buf)
	{
		static_assert(sizeof(T) == sizeof(K), "T and K not the same size");

		ssize_t buffer_len  = m_buffer_len;
		T*      buffer      = m_buffer;
		T*      pdata_start = m_pdata_start;
		T*      pdata_end   = m_pdata_end;

		m_buffer_len  = buf.m_buffer_len;
		m_buffer      = reinterpret_cast<T*>(buf.m_buffer);
		m_pdata_start = reinterpret_cast<T*>(buf.m_pdata_start);
		m_pdata_end   = reinterpret_cast<T*>(buf.m_pdata_end);

		buf.m_buffer_len  = buffer_len;
		buf.m_buffer      = reinterpret_cast<K*>(buffer);
		buf.m_pdata_start = reinterpret_cast<K*>(pdata_start);
		buf.m_pdata_end   = reinterpret_cast<K*>(pdata_end);
	}

	int _compare(const void *pdata, ssize_t nbytes) const
	{
		if (evunlike(nbytes < 0 || (pdata == nullptr && nbytes > 0)))
			assert(false && "invalid param");

		const T *tdata = static_cast<const T*>(pdata);

		ssize_t sz = _size();
		ssize_t len = sz > nbytes ? nbytes : sz;
		for (ssize_t i = 0; i < len; i++)
		{
			if (m_pdata_start[i] == tdata[i])
				continue;

			if (m_pdata_start[i] > tdata[i])
				return 1;
			return -1;
		}

		if (sz > nbytes)
			return 1;
		else if (sz < nbytes)
			return -1;

		return 0;
	}

private:
	ssize_t  m_buffer_len;
	T*       m_buffer;
	T*       m_pdata_start;
	T*       m_pdata_end;
};


}


#endif


