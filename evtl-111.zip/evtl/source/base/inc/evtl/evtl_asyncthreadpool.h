

#ifndef __EVTL_ASYNCTHREADPOOL_H__
#define __EVTL_ASYNCTHREADPOOL_H__

#include <sys/types.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/prctl.h>
#include <pthread.h>
#include <assert.h>
#include <limits.h>

#include <cstdint>
#include <unordered_set>
#include <atomic>
#include <string>
#include <sstream>
#include <vector>
#include <utility>
#include <tuple>
#include <memory>

#include "evtl_gcc.h"
#include "evtl_lock.h"
#include "evtl_time.h"
#include "evtl_interface.h"


namespace evtl { namespace thread {


template <class PT, class LockPolicy>
class _task_queue
{
public:
	_task_queue(): m_semaphore(false)
	{}

	bool init()
	{
		m_semaphore.store(false);
		return m_lock.init();
	}

	void deinit()
	{
		m_lock.deinit();
	}

	void inqueue(const PT &ptask)
	{
		evtl::lock::lockguard<LockPolicy> lg(m_lock);

		m_oque_tasks.erase(ptask);
		m_ique_tasks.insert(ptask);
	}

	void outqueue(const PT &ptask)
	{
		evtl::lock::lockguard<LockPolicy> lg(m_lock);

		m_ique_tasks.erase(ptask);
		m_oque_tasks.insert(ptask);
	}

	std::pair<bool, bool> pop(PT &pitask, PT &potask)
	{
		evtl::lock::lockguard<LockPolicy> lg(m_lock);

		std::pair<bool, bool> result = std::make_pair(false, false);

		typename std::unordered_set<PT>::iterator initer = m_ique_tasks.begin();
		if (initer != m_ique_tasks.end())
		{
			pitask = *initer;
			m_ique_tasks.erase(initer);
			result.first = true;
		}

		typename std::unordered_set<PT>::iterator outiter = m_oque_tasks.begin();
		if (outiter != m_oque_tasks.end())
		{
			potask = *outiter;
			m_oque_tasks.erase(outiter);
			result.second = true;
		}

		return result;
	}

	bool readsem()
	{
		return m_semaphore.exchange(false, std::memory_order_seq_cst);
	}

	void feedsem()
	{
		m_semaphore.store(true, std::memory_order_seq_cst);
	}

private:
	std::atomic<bool>       m_semaphore;
	std::unordered_set<PT>  m_ique_tasks;
	std::unordered_set<PT>  m_oque_tasks;
	LockPolicy              m_lock;
};


template
<
	class T,
	class PT,
	class CONTROLLER,
	class PCONTROLLER,

	void (T::*_method_run)(void *arg),

	void (CONTROLLER::*_method_circle_begin)(void *arg, int64_t id),
	void (CONTROLLER::*_method_accompany)(void *arg, int64_t id, const PT &ptask),
	void (CONTROLLER::*_method_circle_end)(void *arg, int64_t id, int64_t taskcount, int64_t consumed_us)
>
class asexcutor
{
public:
	asexcutor(PCONTROLLER pcontroller = nullptr, void *task_arg = nullptr, void *ctrl_arg = nullptr)
		: m_pcontroller(pcontroller),
		  m_task_arg(task_arg),
		  m_ctrl_arg(ctrl_arg)
	{}

	void set_controller(PCONTROLLER pcontroller)
	{
		m_pcontroller = pcontroller;
	}

	void set_args(void *task_arg, void *ctrl_arg)
	{
		m_task_arg = task_arg;
		m_ctrl_arg = ctrl_arg;
	}

	void ctrl_circle_begin(int64_t id)
	{
		((*m_pcontroller).*_method_circle_begin)(m_ctrl_arg, id);
	}

	void task_run(const PT &ptask)
	{
		((*ptask).*_method_run)(m_task_arg);
	}

	void ctrl_accompany(int64_t id, const PT &ptask)
	{
		((*m_pcontroller).*_method_accompany)(m_ctrl_arg, id, ptask);
	}

	void ctrl_circle_end(int64_t id, int64_t taskcount, int64_t consumed_us)
	{
		((*m_pcontroller).*_method_circle_end)(m_ctrl_arg, id, taskcount, consumed_us);
	}

private:
	PCONTROLLER  m_pcontroller;

	void *m_task_arg;
	void *m_ctrl_arg;
};


template
<
	class T,
	class PT,
	class CONTROLLER,
	class PCONTROLLER,

	void (T::*_method_run)(void *arg),

	void (CONTROLLER::*_method_circle_begin)(void *arg, int64_t id),
	void (CONTROLLER::*_method_accompany)(void *arg, int64_t id, const PT &ptask),
	void (CONTROLLER::*_method_circle_end)(void *arg, int64_t id, int64_t taskcount, int64_t consumed_us),

	class QLock,

	template
	<
		class _a_T,
		class _a_PT,
		class _a_CONTROLLER,
		class _a_PCONTROLLER,

		void (_a_T::*_a__method_run)(void *arg),

		void (_a_CONTROLLER::*_a__method_circle_begin)(void *arg, int64_t id),
		void (_a_CONTROLLER::*_a__method_accompany)(void *arg, int64_t id, const _a_PT &ptask),
		void (_a_CONTROLLER::*_a__method_circle_end)(void *arg, int64_t id, int64_t taskcount, int64_t consumed_us)
	>
	class EXCUTOR
>
class ascontext
{
public:
	ascontext(PCONTROLLER pcontroller, void *tsk_arg, void *ctl_arg, int64_t id, const std::string &poolname = std::string())
		: m_id(id),
		  m_poolname(poolname),
		  m_task_count(0),
		  m_excutor(pcontroller, tsk_arg, ctl_arg)
	{}

	bool init()
	{
		m_task_count.store(0);
		return m_que_tasks.init();
	}

	void deinit()
	{
		m_que_tasks.deinit();
	}

	int64_t get_id() const
	{
		return m_id;
	}

	bool create_thread(ssize_t stacksize)
	{
		if (stacksize > 0 && stacksize < PTHREAD_STACK_MIN)
			stacksize = PTHREAD_STACK_MIN;

		pthread_attr_t attr;
		if (pthread_attr_init(&attr) != 0)
			return false;
		pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
		if (stacksize >= PTHREAD_STACK_MIN)
			pthread_attr_setstacksize(&attr, stacksize);

		pthread_t tid = 0;
		int ret = pthread_create(&tid, &attr, ascontext::threadproc, this);
		pthread_attr_destroy(&attr);

		return ret == 0;
	}

	void async_addtask(const PT &ptask)
	{
		m_que_tasks.inqueue(ptask);
		gcc_thread_fence;
		m_que_tasks.feedsem();

		m_stock_tasks.insert(ptask);
		m_task_count.store(m_stock_tasks.size());
	}

	void async_removetask(const PT &ptask)
	{
		m_que_tasks.outqueue(ptask);
		gcc_thread_fence;
		m_que_tasks.feedsem();

		m_stock_tasks.erase(ptask);
		m_task_count.store(m_stock_tasks.size());
	}

	bool find_task(const PT &ptask) const
	{
		if (m_stock_tasks.find(ptask) != m_stock_tasks.end())
			return true;
		return false;
	}

	int64_t task_count() const
	{
		return m_task_count.load(std::memory_order_relaxed);
	}

private:
	static void * threadproc(void *arg)
	{
		ascontext *pctx = static_cast<ascontext *>(arg);
		assert(pctx != nullptr);

		std::stringstream tname;
		tname << pctx->m_poolname << "-ap" << pctx->m_id;
		return pctx->threadproc_O0(tname.str(), ::syscall(SYS_gettid), pthread_self());
	}

#pragma GCC push_options
#pragma GCC optimize ("O0")
	void * threadproc_O0(const std::string &thread_name, long kernel_tid, pthread_t posix_tid)
	{
		if (!thread_name.empty())
			::prctl(PR_SET_NAME, thread_name.c_str());

		return running();
	}
#pragma GCC pop_options

	void * running()
	{
		while (true)
		{
			m_excutor.ctrl_circle_begin(m_id);

			int64_t start_utime = evtl::timec::fast_usec();
			inspect_queue();
			int64_t taskcount = traverse_tasking();
			int64_t end_utime = evtl::timec::fast_usec();

			int64_t takeus = end_utime - start_utime;
			if (takeus < 0)
				takeus = 0;

			m_excutor.ctrl_circle_end(m_id, taskcount, takeus);
		}

		return nullptr;
	}

	int64_t traverse_tasking()
	{
		int64_t count = 0;
		for (typename std::unordered_set<PT>::const_iterator iter = m_tasks.begin(); iter != m_tasks.end(); ++iter)
		{
			const PT &ptask = *iter;

			if (ptask != nullptr)
			{
				m_excutor.task_run(ptask);
				m_excutor.ctrl_accompany(m_id, ptask);
				++count;
			}
		}
		return count;
	}

	void inspect_queue()
	{
		if (m_que_tasks.readsem())
		{
			PT pitask = nullptr;
			PT potask = nullptr;

			std::pair<bool, bool> rt = m_que_tasks.pop(pitask, potask);
			if (rt.first)
			{
				if (pitask == nullptr)
					assert(false && "null pitask");

				m_tasks.insert(pitask);
				m_que_tasks.feedsem();
			}

			if (rt.second)
			{
				if (potask == nullptr)
					assert(false && "null potask");

				m_tasks.erase(potask);
				m_que_tasks.feedsem();
			}
		}
	}

private:
	int64_t      m_id;
	std::string  m_poolname;

	std::unordered_set<PT>  m_tasks;
	_task_queue<PT, QLock>  m_que_tasks;

	std::unordered_set<PT>  m_stock_tasks;
	std::atomic<int64_t>    m_task_count;

	EXCUTOR<T, PT, CONTROLLER, PCONTROLLER, _method_run, _method_circle_begin, _method_accompany, _method_circle_end>  m_excutor;
};


template <class CONTEXT>
class aspayload
{
public:
	static int64_t calc_payload(const CONTEXT *p_context)
	{
		if (p_context == nullptr)
			assert(false && "null context");

		return p_context->task_count();
	}
};


template
<
	class T,
	class PT,
	class CONTROLLER,
	class PCONTROLLER,

	void (T::*_method_run)(void *arg),

	void (CONTROLLER::*_method_circle_begin)(void *arg, int64_t id),
	void (CONTROLLER::*_method_accompany)(void *arg, int64_t id, const PT &ptask),
	void (CONTROLLER::*_method_circle_end)(void *arg, int64_t id, int64_t taskcount, int64_t consumed_us),

	class MLock = evtl::lock::null_lock,
	class QLock = evtl::lock::mutex_lock,

	template
	<
		class _a_T,
		class _a_PT,
		class _a_CONTROLLER,
		class _a_PCONTROLLER,

		void (_a_T::*_a__method_run)(void *arg),

		void (_a_CONTROLLER::*_a__method_circle_begin)(void *arg, int64_t id),
		void (_a_CONTROLLER::*_a__method_accompany)(void *arg, int64_t id, const _a_PT &ptask),
		void (_a_CONTROLLER::*_a__method_circle_end)(void *arg, int64_t id, int64_t taskcount, int64_t consumed_us)
	>
	class EXCUTOR = asexcutor,

	template
	<
		class _b_T,
		class _b_PT,
		class _b_CONTROLLER,
		class _b_PCONTROLLER,

		void (_b_T::*_b__method_run)(void *arg),

		void (_b_CONTROLLER::*_b__method_circle_begin)(void *arg, int64_t id),
		void (_b_CONTROLLER::*_b__method_accompany)(void *arg, int64_t id, const _b_PT &ptask),
		void (_b_CONTROLLER::*_b__method_circle_end)(void *arg, int64_t id, int64_t taskcount, int64_t consumed_us),

		class _b_QLock,

		template
		<
			class _c_T,
			class _c_PT,
			class _c_CONTROLLER,
			class _c_PCONTROLLER,

			void (_c_T::*_c__method_run)(void *arg),

			void (_c_CONTROLLER::*_c__method_circle_begin)(void *arg, int64_t id),
			void (_c_CONTROLLER::*_c__method_accompany)(void *arg, int64_t id, const _c_PT &ptask),
			void (_c_CONTROLLER::*_c__method_circle_end)(void *arg, int64_t id, int64_t taskcount, int64_t consumed_us)
		>
		class _b_EXCUTOR
	>
	class CONTEXT = ascontext
>
class asyncthreadpool
{
public:
	typedef CONTEXT<T, PT, CONTROLLER, PCONTROLLER, _method_run, _method_circle_begin, _method_accompany, _method_circle_end, QLock, EXCUTOR>  CONTEXT_T;

	asyncthreadpool(): m_poolname("pool"), m_task_arg(nullptr), m_ctrl_arg(nullptr)
	{}

	bool init()
	{
		return m_lock.init();
	}

	void set_poolname(const std::string &poolname)
	{
		m_poolname = poolname;
	}

	void set_args(void *task_arg, void *ctrl_arg)
	{
		m_task_arg = task_arg;
		m_ctrl_arg = ctrl_arg;
	}

	std::string poolname() const
	{
		return m_poolname;
	}

	const void * task_arg() const
	{
		return m_task_arg;
	}

	const void * ctrl_arg() const
	{
		return m_ctrl_arg;
	}

	bool make_thread(PCONTROLLER pcontroller, int64_t first_id, int thread_count = 1, ssize_t stacksize = 0)
	{
		if (pcontroller == nullptr || thread_count <= 0)
			return false;

		for (int i = 0; i < thread_count; i++)
		{
			if (!_make_one_thread(pcontroller, first_id + i, stacksize))
				return false;
		}

		return true;
	}

	template <template <class> class PAYLOADER = aspayload>
	const CONTEXT_T * async_addtask(PT ptask)
	{
		if (ptask == nullptr)
		{
			assert(false && "null ptask");
			return nullptr;
		}

		evtl::lock::lockguard<MLock> lg(m_lock);

		if (m_contexts.empty())
			return nullptr;

		if (task_exist(ptask))
			return nullptr;

		CONTEXT_T *p_context = find_minload_context<PAYLOADER>();
		if (p_context == nullptr)
			return nullptr;

		p_context->async_addtask(ptask);
		return p_context;
	}

	const CONTEXT_T * async_removetask(PT ptask)
	{
		if (ptask == nullptr)
		{
			assert(false && "null ptask");
			return nullptr;
		}

		evtl::lock::lockguard<MLock> lg(m_lock);

		if (m_contexts.empty())
			return nullptr;

		for (typename std::vector<CONTEXT_T *>::const_iterator iter = m_contexts.begin(); iter != m_contexts.end(); ++iter)
		{
			CONTEXT_T *p = *iter;
			if (p != nullptr)
			{
				if (p->find_task(ptask))
				{
					p->async_removetask(ptask);
					return p;
				}
			}
			else
			{
				assert(false && "null context");
			}
		}

		return nullptr;
	}

	int64_t thread_count() const
	{
		return (int64_t)m_contexts.size();
	}

	// tuple<result, context id, task count>
	std::tuple<bool, int64_t, int64_t> thread_status(int64_t index) const
	{
		std::tuple<bool, int64_t, int64_t> result = std::make_tuple(false, -1, -1);

		if (index < 0 || index >= (int64_t)m_contexts.size())
			return result;

		CONTEXT_T *pctx = m_contexts[index];

		std::get<1>(result) = pctx->get_id();
		std::get<2>(result) = pctx->task_count();
		std::get<0>(result) = true;

		return result;
	}

	int64_t total_task_count() const
	{
		int64_t total = 0;
		for (typename std::vector<CONTEXT_T *>::const_iterator iter = m_contexts.begin(); iter != m_contexts.end(); ++iter)
		{
			CONTEXT_T *pc = *iter;
			if (pc != nullptr)
				total += pc->task_count();
		}
		return total;
	}

private:
	bool _make_one_thread(const PCONTROLLER &pcontroller, int64_t id, ssize_t stacksize)
	{
		if (pcontroller == nullptr)
			return false;

		CONTEXT_T *p_context = new CONTEXT_T(pcontroller, m_task_arg, m_ctrl_arg, id, m_poolname);
		if (p_context == nullptr)
			return false;

		p_context->init();
		gcc_thread_fence;
		if (!p_context->create_thread(stacksize))
		{
			p_context->deinit();
			delete p_context;
			return false;
		}

		m_contexts.push_back(p_context);
		return true;
	}

	template <template <class> class PAYLOADER>
	CONTEXT_T * find_minload_context()
	{
		typename std::vector<CONTEXT_T *>::iterator iter = m_contexts.begin();
		if (iter == m_contexts.end())
			return nullptr;
		if (*iter == nullptr)
			assert(false && "null context");

		CONTEXT_T  *p_context  = *iter;
		int64_t     payload    = PAYLOADER<CONTEXT_T>::calc_payload(p_context);

		while (++iter != m_contexts.end())
		{
			if (*iter == nullptr)
				assert(false && "null context");

			int64_t pld = PAYLOADER<CONTEXT_T>::calc_payload(*iter);
			if (pld < 0)
				continue;
			if (payload < 0 || pld < payload)
			{
				p_context = *iter;
				payload = pld;
			}
		}

		return p_context;
	}

	bool task_exist(const PT &ptask)
	{
		for (typename std::vector<CONTEXT_T *>::const_iterator iter = m_contexts.begin(); iter != m_contexts.end(); ++iter)
		{
			CONTEXT_T *pc = *iter;
			if (pc != nullptr)
			{
				if (pc->find_task(ptask))
					return true;
			}
		}
		return false;
	}

private:
	std::string  m_poolname;

	void *  m_task_arg;
	void *  m_ctrl_arg;

	std::vector<CONTEXT_T *>   m_contexts;
	MLock   m_lock;
};


template
<
	class T = evtl::itask,
	void (T::*_method_run)(void *arg) = &T::run,

	class MLock = evtl::lock::null_lock,
	class QLock = evtl::lock::mutex_lock
>
using ptpc_asyncthreadpool = asyncthreadpool
<
	T, T*,
	evtl::ictrl<T*>, evtl::ictrl<T*> *,
	_method_run, &evtl::ictrl<T*>::circle_begin, &evtl::ictrl<T*>::circle_accompany, &evtl::ictrl<T*>::circle_end,
	MLock,
	QLock
>;

template
<
	class T = evtl::itask,
	void (T::*_method_run)(void *arg) = &T::run,

	class MLock = evtl::lock::null_lock,
	class QLock = evtl::lock::mutex_lock
>
using sptpc_asyncthreadpool = asyncthreadpool
<
	T, std::shared_ptr<T>,
	evtl::ictrl<std::shared_ptr<T>>, evtl::ictrl<std::shared_ptr<T>> *,
	_method_run,
	&evtl::ictrl<std::shared_ptr<T>>::circle_begin,
	&evtl::ictrl<std::shared_ptr<T>>::circle_accompany,
	&evtl::ictrl<std::shared_ptr<T>>::circle_end,
	MLock,
	QLock
>;

template
<
	class T = evtl::itask,
	void (T::*_method_run)(void *arg) = &T::run,

	class MLock = evtl::lock::null_lock,
	class QLock = evtl::lock::mutex_lock
>
using ptspc_asyncthreadpool = asyncthreadpool
<
	T, T*,
	evtl::ictrl<T*>, std::shared_ptr<evtl::ictrl<T*>>,
	_method_run, &evtl::ictrl<T*>::circle_begin, &evtl::ictrl<T*>::circle_accompany, &evtl::ictrl<T*>::circle_end,
	MLock,
	QLock
>;

template
<
	class T = evtl::itask,
	void (T::*_method_run)(void *arg) = &T::run,

	class MLock = evtl::lock::null_lock,
	class QLock = evtl::lock::mutex_lock
>
using sptspc_asyncthreadpool = asyncthreadpool
<
	T, std::shared_ptr<T>,
	evtl::ictrl<std::shared_ptr<T>>, std::shared_ptr<evtl::ictrl<std::shared_ptr<T>>>,
	_method_run,
	&evtl::ictrl<std::shared_ptr<T>>::circle_begin,
	&evtl::ictrl<std::shared_ptr<T>>::circle_accompany,
	&evtl::ictrl<std::shared_ptr<T>>::circle_end,
	MLock,
	QLock
>;


} }


#endif


