

#ifndef __EVTL_ERROR_H__
#define __EVTL_ERROR_H__

#include <string>
#include <cstdint>
#include <sstream>
#include <utility>


namespace evtl
{


class evtlerror
{
public:
	evtlerror(): m_error_code(0), m_error_int(0)
	{}

	evtlerror(const evtlerror &that) = default;
	evtlerror(evtlerror &&that) noexcept = default;

	evtlerror& operator = (const evtlerror &that) = default;
	evtlerror& operator = (evtlerror &&that) = default;

	void set_error(int err_code)
	{
		m_error_code = err_code;
		m_error_int = 0;
		m_error_str.clear();
	}

	void set_error(int err_code, int64_t errint)
	{
		m_error_code = err_code;
		m_error_int = errint;
		m_error_str.clear();
	}

	void set_error(int err_code, const std::string &errstr)
	{
		m_error_code = err_code;
		m_error_int = 0;
		m_error_str = errstr;
	}

	void set_error(int err_code, std::string &&errstr)
	{
		m_error_code = err_code;
		m_error_int = 0;
		m_error_str = std::move(errstr);
	}

	void set_error(int err_code, int64_t errint, const std::string &errstr)
	{
		m_error_code = err_code;
		m_error_int = errint;
		m_error_str = errstr;
	}

	void set_error(int err_code, int64_t errint, std::string &&errstr)
	{
		m_error_code = err_code;
		m_error_int = errint;
		m_error_str = std::move(errstr);
	}

	void set_error(const evtlerror &other)
	{
		*this = other;
	}

	int get_error_code() const
	{
		return m_error_code;
	}

	int64_t get_error_int() const
	{
		return m_error_int;
	}

	std::string get_error_string() const
	{
		return m_error_str;
	}

	std::string get_error_combine() const
	{
		std::stringstream ss;
		ss << "<" << m_error_code << ":" << m_error_int << "," << m_error_str << ">";
		return ss.str();
	}

	void reset()
	{
		m_error_code = 0;
		m_error_int = 0;
		m_error_str.clear();
	}

private:
	int          m_error_code;

	int64_t      m_error_int;
	std::string  m_error_str;
};


}


#endif


