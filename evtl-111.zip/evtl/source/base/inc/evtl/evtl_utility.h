

#ifndef __EVTL_UTILITY_H__
#define __EVTL_UTILITY_H__

#include <sys/types.h>
#include <assert.h>
#include <string>
#include <cstring>


namespace evtl { namespace util {


inline int stoi(const std::string &str, int base = 10, int defaultvalue = 0)
{
	int val = defaultvalue;

	try
	{
		val = std::stoi(str, nullptr, base);
	}
	catch (std::exception &)
	{}

	return val;
}

inline long long stoll(const std::string &str, int base = 10, long long defaultvalue = 0)
{
	long long val = defaultvalue;

	try
	{
		val = std::stoll(str, nullptr, base);
	}
	catch (std::exception &)
	{}

	return val;
}

inline unsigned long long stoull(const std::string &str, int base = 10, unsigned long long defaultvalue = 0)
{
	long long val = defaultvalue;

	try
	{
		val = std::stoull(str, nullptr, base);
	}
	catch (std::exception &)
	{}

	return val;
}

inline unsigned int stoui(const std::string &str, int base = 10, unsigned int defaultvalue = 0)
{
	unsigned long long val = stoull(str, base, (unsigned long long)defaultvalue);
	if (val > 0xffffffffuLL)
		return defaultvalue;

	return (unsigned int)val;
}

inline float stof(const std::string &str, float defaultvalue = 0.f)
{
	float val = defaultvalue;

	try
	{
		val = std::stof(str, nullptr);
	}
	catch (std::exception &)
	{}

	return val;
}

inline double stod(const std::string &str, double defaultvalue = 0.)
{
	double val = defaultvalue;

	try
	{
		val = std::stod(str, nullptr);
	}
	catch (std::exception &)
	{}

	return val;
}

inline bool isprefixwith(const char *str, ssize_t size, const std::string &prefix)
{
	if (str == nullptr || size < 0)
	{
		assert(false && "invalid str");
		return false;
	}

	ssize_t prefsize = (ssize_t)prefix.size();
	if (prefsize > size)
		return false;

	for (ssize_t i = 0; i < prefsize; i++)
	{
		if (str[i] != prefix[i])
			return false;
	}

	return true;
}

inline bool isprefixwith(const std::string &str, const std::string &prefix)
{
	return isprefixwith(str.c_str(), (ssize_t)str.size(), prefix);
}

inline bool issuffixwith(const char *str, ssize_t size, const std::string &suffix)
{
	if (str == nullptr || size < 0)
	{
		assert(false && "invalid str");
		return false;
	}

	ssize_t sufsize = (ssize_t)suffix.size();
	if (sufsize > size)
		return false;

	for (ssize_t i = 0; i < sufsize; i++)
	{
		if (str[size - 1 - i] != suffix[sufsize - 1 - i])
			return false;
	}

	return true;
}

inline bool issuffixwith(const std::string &str, const std::string &suffix)
{
	return issuffixwith(str.c_str(), (ssize_t)str.size(), suffix);
}

inline bool strcasecmp(const std::string &s1, const std::string &s2)
{
	if (s1.size() != s2.size())
		return false;

	return ::strcasecmp(s1.c_str(), s2.c_str()) == 0;
}

inline bool strequal(const char *str1, ssize_t len1, const char *str2, ssize_t len2)
{
	if (len1 != len2)
		return false;

	return ::memcmp(str1, str2, len1) == 0;
}

inline bool strequal(const char *str1, ssize_t len1, const std::string &str2)
{
	if (len1 != (ssize_t)str2.size())
		return false;

	return ::memcmp(str1, str2.c_str(), len1) == 0;
}


} }


#endif


