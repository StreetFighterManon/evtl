

#ifndef __MPEG_TS_H__
#define __MPEG_TS_H__

#include <map>


namespace mpeg { namespace ts {


inline int search_pmtpid(const unsigned char *pTS, int length)
{
	if (pTS == nullptr || length <= 188)
		return -1;

	const unsigned char *ph = pTS;
	const unsigned char * const pt = pTS + length;
	int pmt_pid = -1;

	while (true)
	{
		while (ph < pt)
		{
			if (*ph == 0x47)
			{
				if (pt - ph > 188)
				{
					if (ph[188] == 0x47)
						break;
				}
				else
					return -1;
			}
			++ph;
		}

		if (ph >= pt)
			return -1;
		if (pt - ph < 5)
			return -1;

		int pid = ((ph[1] & 0x1f) << 8) | (ph[2] & 0xff);

		if ((ph[3] & 0x20) == 0x20)
			ph += (ph[4] + 6);
		else
			ph += 5;

		if (pid == 0)
		{
			if (pt - ph < 3)
				return -1;

			int sectionlen = ((ph[1] & 0xf) << 8) | (ph[2] & 0xff);
			sectionlen -= 9;
			ph += 8;
			while (sectionlen > 0)
			{
				if (pt - ph < 4)
					return -1;

				unsigned int sval = ((ph[0] & 0xff) << 8) | (ph[1] & 0xff);
				if (sval != 0)
				{
					pmt_pid = (ph[2] & 0x1f) << 8 | ph[3];
					return pmt_pid;
				}
				sectionlen -= 4;
				ph += 4;
			}
		}
	}

	return -1;
}

inline int search_pcrpid(const unsigned char *pTS, int length, int pmtpid)
{
	if (pTS == nullptr || length <= 188 || pmtpid < 0)
		return -1;

	const unsigned char *ph = pTS;
	const unsigned char * const pt = pTS + length;
	int pcr_pid = -1;

	while (true)
	{
		while (ph < pt)
		{
			if (*ph == 0x47)
			{
				if (pt - ph > 188)
				{
					if (ph[188] == 0x47)
						break;
				}
				else
					return -1;
			}
			++ph;
		}

		if (ph >= pt)
			return -1;
		if (pt - ph < 5)
			return -1;

		int pid = ((ph[1] & 0x1f) << 8) | (ph[2] & 0xff);

		if ((ph[3] & 0x20) == 0x20)
			ph += (ph[4] + 6);
		else
			ph += 5;

		if (pid == pmtpid)
		{
			if (pt - ph < 10)
				return -1;

			pcr_pid = ((ph[8] & 0x1f) << 8) | ph[9];

			ph += 12;
			if (pcr_pid == -1)
				continue;

			return pcr_pid;
		}
	}

	return -1;
}

bool search_pcr(const unsigned char *pTS, int length, int pcrpid, long long *pcr /*27000000HZ*/, int *pcrpos)
{
	if (pTS == nullptr || length <= 188 || pcr == nullptr)
		return false;

	if (pcrpid == -1)
		return false;

	const unsigned char *ph = pTS;
	const unsigned char *pc = ph;
	const unsigned char *pt = pTS + length;

	while (true)
	{
		if (*pc == 0x47)
		{
			if (pt - pc > 188)
			{
				unsigned char next_sync = *(pc + 188);
				if (next_sync == 0x47)
				{
					int pid = ((pc[1] & 0x1f) << 8) | pc[2];
					if (pid == pcrpid && (0x20 == (pc[3] & 0x20)) && (6 < pc[4]) && 0x10 == (pc[5] & 0x10))
					{
						unsigned long long pcr_base = 0, pcr_ext = 0, real_pcr = 0;
						pcr_base = (((unsigned long long)pc[6]) << 25) + (pc[7] << 17) + (pc[8] << 9) + (pc[9] << 1) + (pc[10] >> 7);
						pcr_ext  = ((pc[10] & 1) << 8) + pc[11];

						real_pcr = pcr_base*300 + pcr_ext;
						*pcr = (long long)real_pcr;
						if (pcrpos != nullptr)
							*pcrpos = pc - ph;

						return true;
					}
					else
					{
						pc += 188;
					}
				}
				else
				{
					while (++pc < pt && *pc != 0x47);
					if (pc < pt)
					{
					}
					else
					{
						return false;
					}
				}
			}
			else
			{
				return false;
			}
		}
		else
		{
			while (++pc < pt && *pc != 0x47);
			if (pc < pt)
			{
			}
			else
			{
				return false;
			}
		}
	}

	return false;
}


struct stream_info
{
	stream_info()
	{}

	/* map<es_type, pid> */
	std::map<int, int>  videoinfo;
	std::map<int, int>  audioinfo;
};

void search_streaminfo(const unsigned char* buffer, int length, int pmtpid, stream_info& streaminfo)
{
	if (buffer == nullptr || length <= 0)
		return;

	if (pmtpid <= 0)
		return;

	streaminfo.videoinfo.clear();
	streaminfo.audioinfo.clear();

	int srpos = 0;
	while (true)
	{
		while (srpos + 188 * 2 < length)
		{
			if (buffer[srpos] != 0x47 || buffer[srpos + 188] != 0x47 || buffer[srpos + 188 * 2] != 0x47)
				++srpos;
			else
				break;
		}
		if (srpos + 188 * 2 >= length)
			return;

		int pid = ((buffer[srpos + 1] & 0x1f) << 8) | (buffer[srpos + 2] & 0xff);
		if (pid == pmtpid)
		{
			const unsigned char* pmtpkt = buffer + srpos;
			int offset = 0;

			if ((pmtpkt[3] & 0x20) == 0x20)
				offset += (pmtpkt[4] + 6);
			else
				offset += 5;

			if (offset >= 188)
			{
				srpos += 188;
				continue;
			}

			const unsigned char* pmttable = pmtpkt + offset;
			int pos = 12;

			int secionlen = ((pmttable[1] & 0xf) << 8) | (pmttable[2] & 0xff);
			int program_info_length = ((pmttable[10] & 0x0f) << 8) | pmttable[11];

			if (secionlen > 188)
			{
				srpos += 188;
				continue;
			}

			pos += program_info_length;

			while (pos < secionlen + 2 - 4)
			{
				int es_type = 0, es_pid = 0;

				es_type = pmttable[pos];
				es_pid = ((pmttable[pos + 1] << 8) | pmttable[pos + 2]) & 0x1FFF;

				int es_info_length = ((pmttable[pos + 3] & 0x0F) << 8) | pmttable[pos + 4];

				if (es_pid != pmtpid)
				{
					if (es_type == 0x01 || es_type == 0x02 || es_type == 0x1b || es_type == 0x42 || es_type == 0x10
						|| es_type == 0x24
						)
					{
						//video info
						streaminfo.videoinfo[es_type] = es_pid;
					}
					else if (es_type == 0x03 || es_type == 0x04 || es_type == 0x0f || es_type == 0x11 || es_type == 0x80
						|| es_type == 0x81 || es_type == 0x83 || es_type == 0x86
						)
					{
						//audio info
						streaminfo.audioinfo[es_type] = es_pid;
					}
					else if (es_type == 0x06)
					{
						//extension
						const unsigned char* descriptor_ptr = &(pmttable[pos + 5]);
						while (descriptor_ptr < pmttable + pos + 5 + es_info_length)
						{
							int descriptor_tag = descriptor_ptr[0];
							if (descriptor_tag == 0x6a)
							{
								es_type = 0x81;
								streaminfo.audioinfo[es_type] = es_pid;
								break;
							}
							else if (descriptor_tag == 0x7a)
							{
								es_type = 0x11;
								streaminfo.audioinfo[es_type] = es_pid;
								break;
							}
							descriptor_ptr += (2 + descriptor_ptr[1]);
						}
					}
				}

				pos += 5;
				pos += es_info_length;
			}
			srpos += 188;
		}
		else
		{
			srpos += 188;
		}
	}
}


} }


#endif

