

#ifndef __EVPL_C_ARES_ASYNCDIG_H__
#define __EVPL_C_ARES_ASYNCDIG_H__

#include <assert.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <arpa/nameser.h>

#include <cstdint>
#include <vector>
#include <string>
#include <sstream>
#include <cstring>
#include <map>
#include <functional>
#include <utility>

#include <c-ares/ares.h>
#include <ev/ev++.h>

#include <evtl/evtl_error.h>
#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_inet.h>
#include <evtl/evtl_copyable.h>

#include "caresbase.h"


namespace evpl { namespace cares {


template <class T>
class asyncdig : public evtl::evtlerror, public evtl::nocopyc
{
public:
	static int library_init()
	{
		return ::ares_library_init(ARES_LIB_INIT_ALL);
	}

	static void library_cleanup()
	{
		::ares_library_cleanup();
	}

	enum error_code
	{
		success,
		invalid_param,
		channel_exist,
		watcher_active,
		init_channel_failed,
		null_loop,
		null_channel,
		invalid_ip,
		invalid_family,
		set_servers_failed
	};

	typedef std::function<void (T &dig, resolve_except exceptcode)>  dig_callback_t;

	asyncdig(): m_loop(nullptr), m_channel(nullptr), m_callback_invoked(false), m_data(nullptr)
	{
		m_timer.set(0., 0.);
		m_timer.set<asyncdig, &asyncdig::timer_callback>(this);
		m_dig_cb = std::bind(&T::dig_callback, static_cast<T*>(this), std::placeholders::_1, std::placeholders::_2);
	}

	void set_loop(evtl::looprefer loop)
	{
		m_loop = loop;
	}

	void set_callback()
	{
		m_dig_cb = std::bind(&T::dig_callback, static_cast<T*>(this), std::placeholders::_1, std::placeholders::_2);
	}

	void set_callback(dig_callback_t cb)
	{
		m_dig_cb = std::move(cb);
	}

	void set_data(void *pdata)
	{
		m_data = pdata;
	}

	void setopt_flags(int flags)
	{
		m_options.flags.set_assign(flags);
	}

	void unsetopt_flags()
	{
		m_options.flags.unset();
	}

	bool setopt_timeoutms(int timeoutms)
	{
		if (timeoutms <= 0)
		{
			set_error(invalid_param, timeoutms);
			return false;
		}

		m_options.timeout_ms.set_assign(timeoutms);
		return true;
	}

	void unsetopt_timeoutms()
	{
		m_options.timeout_ms.unset();
	}

	bool setopt_tries(int tries)
	{
		if (tries <= 0)
		{
			set_error(invalid_param, tries);
			return false;
		}

		m_options.tries.set_assign(tries);
		return true;
	}

	void unsetopt_tries()
	{
		m_options.tries.unset();
	}

	bool setopt_ndots(int ndots)
	{
		if (ndots < 0)
		{
			set_error(invalid_param, ndots);
			return false;
		}

		m_options.ndots.set_assign(ndots);
		return true;
	}

	void unsetopt_ndots()
	{
		m_options.ndots.unset();
	}

	bool setopt_sendbuf(int size)
	{
		if (size <= 0)
		{
			set_error(invalid_param, size);
			return false;
		}

		m_options.sendbuf_size = size;
		return true;
	}

	void unsetopt_sendbuf()
	{
		m_options.sendbuf_size = 0;
	}

	bool setopt_recvbuf(int size)
	{
		if (size <= 0)
		{
			set_error(invalid_param, size);
			return false;
		}

		m_options.recvbuf_size = size;
		return true;
	}

	void unsetopt_recvbuf()
	{
		m_options.recvbuf_size = 0;
	}

	void addopt_domain(const std::string &domain)
	{
		m_options.domains.refer().push_back(domain);
		m_options.domains.set();
	}

	void clearopt_domain()
	{
		m_options.domains.reset();
	}

	bool setopt_lookups(const std::string &lookups = "fb")
	{
		if (lookups.empty())
		{
			set_error(invalid_param);
			return false;
		}

		m_options.lookups = lookups;
		return true;
	}

	void unsetopt_lookups()
	{
		m_options.lookups.clear();
	}

	bool setopt_resolvconf_path(const std::string &path = "/etc/resolv.conf")
	{
		if (path.empty())
		{
			set_error(invalid_param);
			return false;
		}

		m_options.resolvconf_path = path;
		return true;
	}

	void unsetopt_resolvconf_path()
	{
		m_options.resolvconf_path.clear();
	}

	bool setopt_ednspsz(int ednspsz)
	{
		if (ednspsz <= 0)
		{
			set_error(invalid_param, ednspsz);
			return false;
		}

		m_options.ednspsz = ednspsz;
		return true;
	}

	void unsetopt_ednspsz()
	{
		m_options.ednspsz = 0;
	}

	void reset_options()
	{
		m_options.reset();
	}

	bool add_ipv4_nameserver(const std::string &ipv4, int udp_port, int tcp_port)
	{
		nameserver server;
		server.family = AF_INET;
		std::pair<bool, in_addr> addr = evtl::inetc::inet_pton4(ipv4);
		if (!addr.first)
		{
			set_error(invalid_ip, 4, ipv4);
			return false;
		}
		server.addr4 = addr.second;
		server.udp_port = udp_port;
		server.tcp_port = tcp_port;

		m_nameservers.push_back(server);
		return true;
	}

	bool add_ipv6_nameserver(const std::string &ipv6, int udp_port, int tcp_port)
	{
		nameserver server;
		server.family = AF_INET6;
		std::pair<bool, in6_addr> addr = evtl::inetc::inet_pton6(ipv6);
		if (!addr.first)
		{
			set_error(invalid_ip, 6, ipv6);
			return false;
		}
		server.addr6 = addr.second;
		server.udp_port = udp_port;
		server.tcp_port = tcp_port;

		m_nameservers.push_back(server);
		return true;
	}

	void reset_nameservers()
	{
		m_nameservers.clear();
	}

	bool queryhostbyname(const std::string &name, int family = AF_INET)
	{
		if (m_loop.is_null())
		{
			set_error(null_loop);
			return false;
		}

		if (m_channel != nullptr)
		{
			set_error(channel_exist);
			return false;
		}

		if (!_all_watcher_stoped())
		{
			set_error(watcher_active, (int64_t)m_io_wacthers.size());
			return false;
		}

		if (name.empty())
		{
			set_error(invalid_param, name);
			return false;
		}

		int dnsclass = C_IN;
		int type = T_A;

		if (family == AF_INET)
		{
			type = T_A;
		}
		else if (family == AF_INET6)
		{
			type = T_AAAA;
		}
		else
		{
			set_error(invalid_family, family);
			return false;
		}

		if (!_init_channel_with_option())
			return false;

		if (!_set_nameservers())
		{
			_destroy_channel();
			return false;
		}

		m_callback_invoked = false;
		m_dighost_result.reset();

		::ares_query(m_channel, name.c_str(), dnsclass, type, asyncdig::_query_callback, this);

		ev::tstamp timeout_s = 0.;
		struct timeval tv;
		memset(&tv, 0, sizeof(tv));

		struct timeval *tvp = ::ares_timeout(m_channel, nullptr, &tv);
		if (tvp != nullptr)
			timeout_s = tvp->tv_sec + tvp->tv_usec/1000000.;
		if (timeout_s < 0.0000001)
			timeout_s = 0.0000001;
		if (timeout_s > 2.)
			timeout_s = 2.;

		m_timer.set(m_loop.ref());
		m_timer.set(0., timeout_s + m_loop.now_difference());
		m_timer.set<asyncdig, &asyncdig::timer_callback>(this);
		m_timer.again();

		return true;
	}

	bool queryhostbyaddr(const std::string &ip, int family = AF_INET)
	{
		if (m_loop.is_null())
		{
			set_error(null_loop);
			return false;
		}

		if (m_channel != nullptr)
		{
			set_error(channel_exist);
			return false;
		}

		if (!_all_watcher_stoped())
		{
			set_error(watcher_active, (int64_t)m_io_wacthers.size());
			return false;
		}

		static_assert(sizeof(struct in6_addr) == sizeof(struct ares_in6_addr), "in6_addr and ares_in6_addr is not the same size");

		std::string name;

		int dnsclass = C_IN;
		int type = T_PTR;

		if (family == AF_INET)
		{
			name = make_ptr_rr_name(ip, family);
		}
		else if (family == AF_INET6)
		{
			name = make_ptr_rr_name(ip, family);
		}
		else
		{
			set_error(invalid_family, family);
			return false;
		}

		if (name.empty())
		{
			set_error(invalid_ip, family, ip);
			return false;
		}

		if (!_init_channel_with_option())
			return false;

		if (!_set_nameservers())
		{
			_destroy_channel();
			return false;
		}

		m_callback_invoked = false;
		m_dighost_result.reset();

		::ares_query(m_channel, name.c_str(), dnsclass, type, asyncdig::_query_callback, this);

		ev::tstamp timeout_s = 0.;
		struct timeval tv;
		memset(&tv, 0, sizeof(tv));

		struct timeval *tvp = ::ares_timeout(m_channel, nullptr, &tv);
		if (tvp != nullptr)
			timeout_s = tvp->tv_sec + tvp->tv_usec/1000000.;
		if (timeout_s < 0.0000001)
			timeout_s = 0.0000001;
		if (timeout_s > 2.)
			timeout_s = 2.;

		m_timer.set(m_loop.ref());
		m_timer.set(0., timeout_s + m_loop.now_difference());
		m_timer.set<asyncdig, &asyncdig::timer_callback>(this);
		m_timer.again();

		return true;
	}

	const dighost_result& get_dighost_result() const
	{
		return m_dighost_result;
	}

	void * get_data() const
	{
		return m_data;
	}

	void deinit()
	{
		_destroy_channel();
		_clear_iowatchers();
		m_timer.stop();

		m_options.reset();
		m_nameservers.clear();

		m_callback_invoked = false;
		m_dighost_result.reset();
	}

private:
	bool _init_channel_with_option()
	{
		ares_options option;
		int optmask = 0;

		memset(&option, 0, sizeof(option));
		m_options.build_option(option, &optmask);
		option.sock_state_cb      = asyncdig::_sockstate_callback;
		option.sock_state_cb_data = this;
		optmask |= ARES_OPT_SOCK_STATE_CB;

		int rt = ::ares_init_options(&m_channel, &option, optmask);

		optionset::free_option(option);

		if (rt != ARES_SUCCESS)
		{
			m_channel = nullptr;
			set_error(init_channel_failed, rt);
			return false;
		}

		if (m_channel == nullptr)
		{
			set_error(null_channel);
			return false;
		}

		return true;
	}

	bool _set_nameservers()
	{
		if (m_nameservers.empty())
		{
			//use local dns resolver config, such as /etc/resolv.conf
			return true;
		}

		auto destroy_node_list = [](ares_addr_port_node *head) -> void
		{
			while (head != nullptr)
			{
				ares_addr_port_node *pdel = head;
				head = head->next;
				delete pdel;
			}
		};

		ares_addr_port_node *prev = nullptr;
		for (std::vector<nameserver>::const_reverse_iterator iter = m_nameservers.rbegin(); iter != m_nameservers.rend(); ++iter)
		{
			ares_addr_port_node *pthis = new ares_addr_port_node;
			if (pthis == nullptr)
				assert(false && "malloc failed");

			pthis->next   = prev;
			pthis->family = iter->family;
			if (pthis->family == AF_INET)
				pthis->addr.addr4 = iter->addr4;
			else if (pthis->family == AF_INET6)
			{
				static_assert(sizeof(pthis->addr.addr6) == sizeof(iter->addr6), "ares_in6_addr and in6_addr is not the same size");
				memcpy(&pthis->addr.addr6, &iter->addr6, sizeof(iter->addr6));
			}
			else
			{
				set_error(invalid_family, pthis->family);
				delete pthis;
				destroy_node_list(prev);
				return false;
			}
			pthis->udp_port = iter->udp_port;
			pthis->tcp_port = iter->tcp_port;

			prev = pthis;
		}

		if (prev == nullptr)
			assert(false && "null server node");

		int rt = ::ares_set_servers_ports(m_channel, prev);

		destroy_node_list(prev);

		if (rt != ARES_SUCCESS)
		{
			set_error(set_servers_failed, rt);
			return false;
		}

		return true;
	}

	void _destroy_channel()
	{
		if (m_channel != nullptr)
			::ares_destroy(m_channel);
		m_channel = nullptr;
	}

	void _clear_iowatchers()
	{
		for (std::map<int, ev::io*>::iterator iter = m_io_wacthers.begin(); iter != m_io_wacthers.end(); ++iter)
		{
			ev::io *pwatcher = iter->second;
			if (pwatcher != nullptr)
			{
				pwatcher->stop();
				delete pwatcher;
				iter->second = nullptr;
			}
			else
			{
				assert(false && "null io watcher");
			}
		}

		m_io_wacthers.clear();
	}

private:
	bool _all_watcher_stoped() const
	{
		if (!m_io_wacthers.empty())
			return false;
		if (m_timer.is_active())
			return false;

		return true;
	}

private:
	void dig_callback(T &dig, resolve_except exceptcode) { assert(false && "unset callback"); }

	static void _sockstate_callback(void *data, ares_socket_t socket_fd, int readable, int writable)
	{
		asyncdig *dig = static_cast<asyncdig*>(data);
		if (dig == nullptr)
			assert(false && "null dig ptr");

		dig->sockstate_callback(socket_fd, readable, writable);
	}

	void sockstate_callback(ares_socket_t socket_fd, int readable, int writable)
	{
		if (m_loop.is_null())
			assert(false && "null loop");

		if (socket_fd != -1)
		{
			int events = 0;
			if (readable != 0) events |= ev::READ;
			if (writable != 0) events |= ev::WRITE;

			if (events != 0)
			{
				std::map<int, ev::io*>::iterator iter = m_io_wacthers.find(socket_fd);
				if (iter == m_io_wacthers.end())
				{
					ev::io *pwatcher = new ev::io;
					if (pwatcher == nullptr)
						assert(false && "malloc failed");

					pwatcher->set(m_loop.ref());
					pwatcher->set<asyncdig, &asyncdig::io_callback>(this);
					pwatcher->start(socket_fd, events);

					m_io_wacthers[socket_fd] = pwatcher;
				}
				else
				{
					ev::io *pwatcher = iter->second;
					if (pwatcher == nullptr)
						assert(false && "null watcher");
					if (pwatcher->fd != socket_fd)
						assert(false && "unmatched fd");

					pwatcher->stop();
					pwatcher->set(m_loop.ref());
					pwatcher->set<asyncdig, &asyncdig::io_callback>(this);
					pwatcher->start(socket_fd, events);
				}
			}
			else
			{
				std::map<int, ev::io*>::iterator iter = m_io_wacthers.find(socket_fd);
				if (iter != m_io_wacthers.end())
				{
					ev::io *pwatcher = iter->second;
					if (pwatcher == nullptr)
						assert(false && "null watcher");
					if (pwatcher->fd != socket_fd)
						assert(false && "unmatched fd");

					pwatcher->stop();
					delete pwatcher;
					m_io_wacthers.erase(iter);
				}
			}
		}
	}

	static void _query_callback(void *arg, int status, int timeouts, unsigned char *abuf, int alen)
	{
		asyncdig *dig = static_cast<asyncdig*>(arg);
		if (dig == nullptr)
			assert(false && "null dig ptr");

		dig->query_callback(status, timeouts, abuf, alen);
	}

	void query_callback(int status, int timeouts, unsigned char *abuf, int alen)
	{
		m_callback_invoked = true;

		m_dighost_result.reset();
		m_dighost_result.status = status;
		m_dighost_result.status_str = ::ares_strerror(status);
		m_dighost_result.timeout_times = timeouts;

		if (status == ARES_SUCCESS && abuf != nullptr && alen > 0)
		{
			dighost_parser parser(m_dighost_result.hostinfo, abuf, alen);
			parser.parse();
		}
	}

	void io_callback(ev::io &watcher, int revents)
	{
		if ((revents & ev::ERROR) != 0)
			assert(false && "ev_error");
		if (watcher.fd == -1)
			assert(false && "bad fd");
		if (m_channel == nullptr)
			assert(false && "null channel");

		int readfd  = ARES_SOCKET_BAD;
		int writefd = ARES_SOCKET_BAD;

		if ((revents & ev::READ) != 0)
			readfd = watcher.fd;
		if ((revents & ev::WRITE) != 0)
			writefd = watcher.fd;

		::ares_process_fd(m_channel, readfd, writefd);

		_after_process();
	}

	void timer_callback(ev::timer &watcher, int revents)
	{
		if ((revents & ev::ERROR) != 0)
			assert(false && "ev_error");
		if (&watcher != &m_timer)
			assert(false && "unexpected watcher");
		if (m_channel == nullptr)
			assert(false && "null channel");

		::ares_process_fd(m_channel, ARES_SOCKET_BAD, ARES_SOCKET_BAD);

		_after_process();
	}

	void _after_process()
	{
		if (m_callback_invoked)
		{
			_destroy_channel();
			_clear_iowatchers();
			m_timer.stop();
			m_dig_cb(*static_cast<T*>(this), except_none);
			return;
		}
		else
		{
			struct timeval tv;
			memset(&tv, 0, sizeof(tv));

			struct timeval *tvp = ::ares_timeout(m_channel, nullptr, &tv);
			if (tvp == nullptr)
			{
				_destroy_channel();
				_clear_iowatchers();
				m_timer.stop();
				m_dig_cb(*static_cast<T*>(this), except_null_timeout);
				return;
			}
			else
			{
				ev::tstamp timeout_s = tvp->tv_sec + tvp->tv_usec/1000000.;
				if (timeout_s < 0.001)
					timeout_s = 0.001;
				if (timeout_s > 2.)
					timeout_s = 2.;

				m_timer.repeat = timeout_s + m_loop.now_difference();
				m_timer.again();
			}
		}
	}

private:
	std::string make_ptr_rr_name(const std::string &ip, int family)
	{
		std::string name;

		if (family == AF_INET)
		{
			std::pair<bool, struct in_addr> addr = evtl::inetc::inet_pton4(ip);
			if (!addr.first)
				return std::string();

			static_assert(sizeof(addr.second) == 4, "sizeof struct in_addr is not 4");

			const unsigned char *bytes = (const unsigned char *)&addr.second;
			std::stringstream ss;
			ss << (unsigned int)bytes[3] << '.'
				<< (unsigned int)bytes[2] << '.'
				<< (unsigned int)bytes[1] << '.'
				<< (unsigned int)bytes[0] << ".in-addr.arpa";

			name = ss.str();
			return name;
		}
		else if (family == AF_INET6)
		{
			std::pair<bool, struct in6_addr> addr = evtl::inetc::inet_pton6(ip);
			if (!addr.first)
				return std::string();

			static_assert(sizeof(addr.second) == 16, "sizeof struct in6_addr is not 16");

			const unsigned char *bytes = (const unsigned char *)&addr.second;
			std::stringstream ss;
			ss << std::hex
				<< (unsigned int)(bytes[15] & 0x0f) << '.' << (unsigned int)((bytes[15] >> 4) & 0x0f) << '.'
				<< (unsigned int)(bytes[14] & 0x0f) << '.' << (unsigned int)((bytes[14] >> 4) & 0x0f) << '.'
				<< (unsigned int)(bytes[13] & 0x0f) << '.' << (unsigned int)((bytes[13] >> 4) & 0x0f) << '.'
				<< (unsigned int)(bytes[12] & 0x0f) << '.' << (unsigned int)((bytes[12] >> 4) & 0x0f) << '.'
				<< (unsigned int)(bytes[11] & 0x0f) << '.' << (unsigned int)((bytes[11] >> 4) & 0x0f) << '.'
				<< (unsigned int)(bytes[10] & 0x0f) << '.' << (unsigned int)((bytes[10] >> 4) & 0x0f) << '.'
				<< (unsigned int)(bytes[9] & 0x0f) << '.' << (unsigned int)((bytes[9] >> 4) & 0x0f) << '.'
				<< (unsigned int)(bytes[8] & 0x0f) << '.' << (unsigned int)((bytes[8] >> 4) & 0x0f) << '.'
				<< (unsigned int)(bytes[7] & 0x0f) << '.' << (unsigned int)((bytes[7] >> 4) & 0x0f) << '.'
				<< (unsigned int)(bytes[6] & 0x0f) << '.' << (unsigned int)((bytes[6] >> 4) & 0x0f) << '.'
				<< (unsigned int)(bytes[5] & 0x0f) << '.' << (unsigned int)((bytes[5] >> 4) & 0x0f) << '.'
				<< (unsigned int)(bytes[4] & 0x0f) << '.' << (unsigned int)((bytes[4] >> 4) & 0x0f) << '.'
				<< (unsigned int)(bytes[3] & 0x0f) << '.' << (unsigned int)((bytes[3] >> 4) & 0x0f) << '.'
				<< (unsigned int)(bytes[2] & 0x0f) << '.' << (unsigned int)((bytes[2] >> 4) & 0x0f) << '.'
				<< (unsigned int)(bytes[1] & 0x0f) << '.' << (unsigned int)((bytes[1] >> 4) & 0x0f) << '.'
				<< (unsigned int)(bytes[0] & 0x0f) << '.' << (unsigned int)((bytes[0] >> 4) & 0x0f) << ".ip6.arpa";

			name = ss.str();
			return name;
		}

		return std::string();
	}

private:
	evtl::looprefer  m_loop;
	dig_callback_t   m_dig_cb;

	optionset  m_options;
	std::vector<nameserver>  m_nameservers;
	ares_channel  m_channel;

	std::map<int, ev::io*>  m_io_wacthers;
	ev::timer  m_timer;

	bool  m_callback_invoked;
	dighost_result  m_dighost_result;
	void *  m_data;
};

class simpasyncdig : public asyncdig<simpasyncdig>
{};


} }


#endif


