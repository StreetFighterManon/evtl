

#ifndef __EVPL_UTIL_SEGMENTSEND_H__
#define __EVPL_UTIL_SEGMENTSEND_H__

#include <sys/types.h>
#include <assert.h>
#include <string>
#include <map>
#include <sstream>
#include <utility>

#include <evtl/evtl_interface.h>
#include <evtl/evtl_com.h>
#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_linearbuf.h>


namespace evpl { namespace util {


template <class IIO = evtl::iio,
	ssize_t (IIO::*IOWrite)(const void *buffer, ssize_t nbytes) = &IIO::io_write
	>
class segmentsend : public evtl::once
{
public:
	segmentsend(): m_iio(nullptr)
	{}

	void set(IIO *iio)
	{
		m_iio = iio;
	}

	void set_segment(const char *data, ssize_t nbytes)
	{
		if (m_segment.isset())
			assert(false && "segment isset");

		m_segment.refer().extens_store_whole(data, nbytes);
		m_segment.set();
	}

	void set_segment(const std::string &data)
	{
		set_segment(data.c_str(), (ssize_t)data.size());
	}

	void set_segment(const evtl::linearbuf<char> &data)
	{
		set_segment(data.dataptr(), data.size());
	}

	void set_segment(evtl::linearbuf<char> &&data)
	{
		if (m_segment.isset())
			assert(false && "segment isset");

		m_segment.set_assign(std::move(data));
	}

	void sendsegment()
	{
		if (!m_segment.isset())
			assert(false && "segment unset");

		evtl::linearbuf<char> &segment = m_segment.refer();
		ssize_t size = segment.size();
		if (size > 0)
		{
			ssize_t n = (m_iio->*IOWrite)(segment.dataptr(), size);
			if (n > 0)
			{
				if (n > size)
					assert(false && "write exception");

				if (!segment.shit_whole(n))
					assert(false && "shit error");
			}
		}
	}

	bool sendfinished() const
	{
		if (m_segment.isset() && m_segment.refer().empty())
			return true;
		return false;
	}

	void reset()
	{
		evtl::once::reset();
		m_segment.reset();
	}

private:
	IIO  *m_iio;
	evtl::dn_var<evtl::linearbuf<char>>  m_segment;
};


class httpresponse
{
public:
	httpresponse(): m_protocol("HTTP/1.1")
	{}

	void set_protocol(const std::string &protocol)
	{
		m_protocol = protocol;
	}

	std::string get_protocol() const
	{
		return m_protocol;
	}

	void set_statuscode(int code)
	{
		m_statuscode = code;
	}

	int get_statuscode() const
	{
		return m_statuscode;
	}

	void set_reasonphrase(const std::string &phrase)
	{
		m_reasonphrase = phrase;
	}

	std::string get_reasonphrase() const
	{
		return m_reasonphrase;
	}

	bool add_header(const std::string &key, const std::string &value, bool force_insert = true)
	{
		if (!force_insert)
		{
			std::pair<std::map<std::string, std::string>::const_iterator, bool> rt = m_headers.insert(std::make_pair(key, value));
			return rt.second;
		}

		m_headers[key] = value;
		return true;
	}

	void del_header(const std::string &key)
	{
		m_headers.erase(key);
	}

	std::pair<bool, std::string> get_header(const std::string &key) const
	{
		std::map<std::string, std::string>::const_iterator iter = m_headers.find(key);
		if (iter == m_headers.end())
			return std::make_pair(false, std::string());

		return std::make_pair(true, iter->second);
	}

	void clear_header()
	{
		m_headers.clear();
	}

	void set_content_length(long long len)
	{
		m_headers["Content-Length"] = std::to_string(len);
	}

	void set_content_range(long long firstbyte, long long lastbyte, long long entitylength)
	{
		m_headers["Content-Range"] = std::string("bytes ") +
			std::to_string(firstbyte) + "-" + std::to_string(lastbyte) + "/" + std::to_string(entitylength);
	}

	std::string to_string() const
	{
		std::stringstream ss;

		std::string phrase = m_reasonphrase;
		if (phrase.empty())
			phrase = get_reasonphrase(m_statuscode);

		ss << m_protocol << " " << std::to_string(m_statuscode) << " " << phrase << "\r\n";
		for (std::map<std::string, std::string>::const_iterator iter = m_headers.begin(); iter != m_headers.end(); ++iter)
		{
			ss << iter->first << ": " << iter->second << "\r\n";
		}
		ss << "\r\n";

		return ss.str();
	}

	void clear()
	{
		m_protocol.clear();
		m_statuscode = 0;
		m_reasonphrase.clear();
		m_headers.clear();
	}

public:
	static std::string get_reasonphrase(int statuscode)
	{
		switch (statuscode)
		{
		case 200: return "OK";
		case 206: return "Partial Content";
		case 400: return "Bad Request";
		case 404: return "Not Found";
		default:  break;
		};

		return "Unknown";
	}

private:
	std::string  m_protocol;
	int          m_statuscode;
	std::string  m_reasonphrase;

	std::map<std::string, std::string>  m_headers;
};


template <class IIO = evtl::iio,
	ssize_t (IIO::*IOWrite)(const void *buffer, ssize_t nbytes) = &IIO::io_write
	>
class httpresponsesend : public segmentsend<IIO, IOWrite>, httpresponse
{
public:
	httpresponsesend()
	{}

	void reset()
	{
		segmentsend<IIO, IOWrite>::reset();
		httpresponse::reset();
	}
};


} }


#endif


