

#ifndef __EVPL_UTIL_ACCEPTOR_H__
#define __EVPL_UTIL_ACCEPTOR_H__

#include <assert.h>
#include <functional>
#include <utility>
#include <vector>

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_acceptor.h>
#include <evtl/evtl_listener.h>
#include <evtl/evtl_in.h>


namespace evpl { namespace util {


class _acceptor : public evtl::acceptor<_acceptor>
{
public:
	void set(void *accptor, void (*accptcb)(void *accptor, std::vector<evtl::connection> &connections))
	{
		m_accptor = accptor;
		m_accptcb = accptcb;
	}

	void accept_callback(_acceptor &accptor, std::vector<evtl::connection> &connections)
	{
		if (&accptor != this)
			assert(false && "acceptor error");

		m_accptcb(m_accptor, connections);
	}

private:
	void  *m_accptor;
	void (*m_accptcb)(void *accptor, std::vector<evtl::connection> &connections);
};

class acceptor
{
public:
	acceptor()
	{}

	typedef std::function<void (acceptor &acceptor, std::vector<evtl::connection> &connections)>  accept_callback_t;

	void set_loop(evtl::looprefer loop)
	{
		return m_acceptor.set_loop(loop);
	}

	bool set_address(const evtl::address &addr)
	{
		bool br = m_listener.set_address(addr);
		if (!br)
			set_error("listener: ", m_listener.get_error_combine());
		return br;
	}

	void set_callback(accept_callback_t cb)
	{
		m_accept_cb = std::move(cb);
	}

	void set_socketcallback(evtl::listener::socket_callback_t cb)
	{
		m_listener.set_socketcallback(std::move(cb));
	}

	void clear_socketcallback()
	{
		m_listener.clear_socketcallback();
	}

	bool tcplisten(int backlog, bool nonblock = true, bool reuseport = false)
	{
		bool br = m_listener.tcplisten(backlog, nonblock, reuseport);
		if (!br)
			set_error("listener: ", m_listener.get_error_combine());
		return br;
	}

	bool unixlisten(int backlog, bool nonblock = true)
	{
		bool br = m_listener.unixlisten(backlog, nonblock);
		if (!br)
			set_error("listener: ", m_listener.get_error_combine());
		return br;
	}

	bool watch()
	{
		m_acceptor.set(this, &acceptor::_accept_callback);
		m_acceptor.set_listener(&m_listener);
		m_acceptor.set_callback();
		bool br = m_acceptor.watch();
		if (!br)
			set_error("acceptor: ", m_acceptor.get_error_combine());
		return br;
	}

	bool is_watching() const
	{
		return m_acceptor.is_watching();
	}

	void unwatch()
	{
		m_acceptor.unwatch();
	}

	evtl::connection accept(int flags = 0)
	{
		m_acceptor.set_listener(&m_listener);
		return m_acceptor.accept(flags);
	}

	evtl::looprefer get_loop() const
	{
		return m_acceptor.get_loop();
	}

	void stop_close()
	{
		m_acceptor.deinit();
		m_listener.close();
	}

	std::string get_error() const
	{
		return m_errstr;
	}

private:
	void set_error(const std::string &whose, const std::string &errstr)
	{
		m_errstr = whose + errstr;
	}

	static void _accept_callback(void *accptor, std::vector<evtl::connection> &connections)
	{
		acceptor *acc = static_cast<acceptor*>(accptor);
		if (acc == nullptr)
			assert(false && "null acceptor");

		acc->m_accept_cb(*acc, connections);
	}

private:
	_acceptor       m_acceptor;
	evtl::listener  m_listener;

	accept_callback_t  m_accept_cb;
	std::string     m_errstr;
};


} }


#endif


