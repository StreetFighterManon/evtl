

#ifndef __EVPL_UTIL_UTILITY_H__
#define __EVPL_UTIL_UTILITY_H__

#include <vector>
#include <string>

#include <evtl/evtl_com.h>


namespace evpl { namespace util {


class baseprocess
{
public:
	baseprocess(): m_step(evtl::com::nextstep_unknown)
	{}

	evtl::com::process_nextstep get_nextstep() const
	{
		return m_step;
	}

protected:
	void set_nextstep(evtl::com::process_nextstep step)
	{
		m_step = step;
	}

private:
	evtl::com::process_nextstep  m_step;
};


inline void extractlines(const char *text, int len, std::vector<std::string> &lines, bool preserve_crlf = false)
{
	int lastpos = 0;
	for (int i = 0; i < len; i++)
	{
		if (text[i] == '\n')
		{
			if (!preserve_crlf)
			{
				if (i > 0 && text[i - 1] == '\r')
					lines.push_back(std::string(text + lastpos, i - 1 - lastpos));
				else
					lines.push_back(std::string(text + lastpos, i - lastpos));
			}
			else
			{
				lines.push_back(std::string(text + lastpos, i + 1 - lastpos));
			}
			lastpos = i + 1;
		}
	}
	if (lastpos < len)
		lines.push_back(std::string(text + lastpos, len - lastpos));
}

inline void extractlines(const std::string &text, std::vector<std::string> &lines, bool preserve_crlf = false)
{
	return extractlines(text.c_str(), (int)text.size(), lines, preserve_crlf);
}


} }


#endif


