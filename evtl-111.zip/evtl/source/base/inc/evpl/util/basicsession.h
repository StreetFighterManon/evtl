

#ifndef __EVPL_UTIL_BASICSESSION_H__
#define __EVPL_UTIL_BASICSESSION_H__

#include <sys/types.h>
#include <errno.h>
#include <assert.h>
#include <functional>
#include <utility>

#include <evtl/evtl_com.h>
#include <evtl/evtl_watcher_io.h>
#include <evtl/evtl_interface.h>


namespace evpl { namespace util {


template <class T>
class basicsession : public evtl::watcher_io<T>, public evtl::iio
{
public:
	basicsession() = default;

	typedef std::function<void (T *sess)>  recycle_callback_t;

	virtual ssize_t io_read(void *buf, ssize_t nbytes) override
	{
		if (buf == nullptr || nbytes <= 0)
			assert(false && "bad buffer");

		ssize_t n = this->read(buf, nbytes);
		if (n > 0)
		{
			if (n > nbytes)
				assert(false && "read exception");
		}
		else if (n < 0)
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
				m_iostatus.orset(evtl::com::rwresult_read_error, errno);
		}
		else
		{
			m_iostatus.orset(evtl::com::rwresult_read_end, 0);
		}

		return n;
	}

	virtual ssize_t io_write(const void *buf, ssize_t nbytes) override
	{
		if (buf == nullptr || nbytes <= 0)
			assert(false && "bad buffer");

		ssize_t n = this->write(buf, nbytes);
		if (n > 0)
		{
			if (n > nbytes)
				assert(false && "write exception");
		}
		else if (n < 0)
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
				m_iostatus.orset(evtl::com::rwresult_write_error, errno);
		}
		else
		{
			assert(false && "write zero");
		}

		return n;
	}

	void set_callback_recycle(recycle_callback_t cb)
	{
		m_recycle_cb = std::move(cb);
	}

	void reset()
	{
		m_iostatus.reset();
	}

protected:
	void recycle()
	{
		T *sess = static_cast<T*>(this);
		m_recycle_cb(sess);
	}

protected:
	evtl::com::rwstatus  m_iostatus;
	recycle_callback_t   m_recycle_cb;
};


} }


#endif

