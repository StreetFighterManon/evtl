

#ifndef __EVPL_UTIL_HTTPPARSER_H__
#define __EVPL_UTIL_HTTPPARSER_H__

#include <sys/types.h>
#include <assert.h>
#include <cstring>
#include <string>
#include <vector>
#include <map>
#include <utility>

#include <evtl/evtl_error.h>
#include <evtl/evtl_com.h>
#include <evtl/evtl_utility.h>


namespace evpl { namespace util {


struct httpvalue
{
	httpvalue(): number(0)
	{}

	httpvalue(const std::string &s, long long n): str(s), number(n)
	{}

	std::string  str;
	long long    number;

	void reset()
	{
		str.clear();
		number = 0;
	}
};

struct httprequest
{
	httprequest() = default;

	std::string  m_method;
	std::string  m_url;
	std::string  m_path;
	std::string  m_pathprefix;
	std::string  m_filename;
	std::string  m_paramstr;
	std::map<std::string, httpvalue>  m_params;

	std::string  m_protocol;
	std::map<std::string, httpvalue>  m_headers;

	bool param_exist(const std::string &key) const
	{
		std::map<std::string, httpvalue>::const_iterator iter = m_params.find(key);
		if (iter == m_params.end())
			return false;
		return true;
	}

	std::pair<bool, httpvalue> get_param(const std::string &key) const
	{
		std::map<std::string, httpvalue>::const_iterator iter = m_params.find(key);
		if (iter == m_params.end())
			return std::make_pair(false, httpvalue());
		return std::make_pair(true, iter->second);
	}

	bool header_exist(const std::string &key) const
	{
		std::map<std::string, httpvalue>::const_iterator iter = m_headers.find(key);
		if (iter == m_headers.end())
			return false;
		return true;
	}

	std::pair<bool, httpvalue> get_header(const std::string &key) const
	{
		std::map<std::string, httpvalue>::const_iterator iter = m_headers.find(key);
		if (iter == m_headers.end())
			return std::make_pair(false, httpvalue());
		return std::make_pair(true, iter->second);
	}

	void reset()
	{
		m_method.clear();
		m_url.clear();
		m_path.clear();
		m_pathprefix.clear();
		m_filename.clear();
		m_paramstr.clear();
		m_params.clear();
		m_protocol.clear();
		m_headers.clear();
	}
};

struct httpresponse
{
	httpresponse() = default;

	std::string  m_protocol;
	httpvalue    m_statuscode;
	std::string  m_statusmsg;

	std::map<std::string, httpvalue>  m_headers;

	bool header_exist(const std::string &key) const
	{
		std::map<std::string, httpvalue>::const_iterator iter = m_headers.find(key);
		if (iter == m_headers.end())
			return false;
		return true;
	}

	std::pair<bool, httpvalue> get_header(const std::string &key) const
	{
		std::map<std::string, httpvalue>::const_iterator iter = m_headers.find(key);
		if (iter == m_headers.end())
			return std::make_pair(false, httpvalue());
		return std::make_pair(true, iter->second);
	}

	void reset()
	{
		m_protocol.clear();
		m_statuscode.reset();
		m_statusmsg.clear();
		m_headers.clear();
	}
};


class httprequestparser : public evtl::once, public evtl::evtlerror
{
public:
	httprequestparser(): m_parse_succeed(false), m_buf(nullptr), m_len(0)
	{}

	enum errorcode
	{
		success,
		lack_cr_before_lf,
		incomplete_request,
		bad_url,
		bad_method,
		bad_protocol
	};

	void parse(const char *request, ssize_t len)
	{
		m_parse_succeed = false;

		if (request == nullptr || len <= 0)
		{
			assert(false && "invalid request");
			return;
		}

		m_buf = request;
		m_len = len;

		std::vector<std::string> lines;
		if (!extract_lines(lines))
			return;

		if (lines.empty())
		{
			set_error(incomplete_request);
			return;
		}

		if (!parse_firstline(lines[0]))
			return;

		for (size_t i = 1; i < lines.size(); i++)
		{
			if (!parse_header(lines[i]))
				return;
		}

		set_error(success);
		m_parse_succeed = true;
	}

	bool parse_success() const
	{
		return m_parse_succeed;
	}

	const httprequest& get_request() const
	{
		return m_request;
	}

	void reset()
	{
		evtl::once::reset();
		evtl::evtlerror::reset();
		m_parse_succeed = false;
		m_buf = nullptr;
		m_len = 0;
		m_request.reset();
	}

private:
	bool extract_lines(std::vector<std::string> &lines)
	{
		ssize_t startpos = 0;

		for (ssize_t i = 0; i < m_len; i++)
		{
			if (m_buf[i] == '\n')
			{
				if (i < 1 || m_buf[i - 1] != '\r')
				{
					set_error(lack_cr_before_lf);
					return false;
				}

				if (startpos < i - 1)
				{
					lines.push_back(std::string(m_buf + startpos, i - 1 - startpos));
					startpos = i + 1;
				}
				else
					return true;
			}
		}

		set_error(incomplete_request);
		return false;
	}

	bool parse_firstline(const std::string &str)
	{
		size_t space_pos = std::string::npos;
		for (size_t i = 0; i < str.size(); i++)
		{
			if (str[i] == ' ' || str[i] == '\t')
			{
				space_pos = i;
				break;
			}
		}
		if (space_pos == std::string::npos)
		{
			set_error(bad_url);
			return false;
		}

		if (!identify_method(str.c_str(), space_pos))
		{
			set_error(bad_method);
			return false;
		}

		size_t urlpos = space_pos + 1;
		while (urlpos < str.size() && (str[urlpos] == ' ' || str[urlpos] == '\t'))
			urlpos++;
		if (urlpos >= str.size())
		{
			set_error(bad_url);
			return false;
		}

		size_t urlendpos = urlpos + 1;
		while (urlendpos < str.size() && (str[urlendpos] != ' ' && str[urlendpos] != '\t'))
			urlendpos++;
		if (urlendpos >= str.size())
		{
			set_error(bad_url);
			return false;
		}

		if (!parse_url(str.c_str() + urlpos, urlendpos - urlpos))
		{
			set_error(bad_url);
			return false;
		}

		size_t protocolpos = urlendpos + 1;
		while (protocolpos < str.size() && (str[protocolpos] == ' ' || str[protocolpos] == '\t'))
			protocolpos++;
		if (protocolpos >= str.size())
		{
			set_error(bad_protocol);
			return false;
		}

		if (!identify_protocol(str.c_str() + protocolpos, str.size() - protocolpos))
		{
			set_error(bad_protocol);
			return false;
		}

		return true;
	}

	bool identify_method(const char *str, size_t len)
	{
		const char *methods[] = { "GET", "POST", "HEAD", nullptr };

		for (size_t i = 0; i < sizeof(methods)/sizeof(methods[0]); i++)
		{
			if (methods[i] != nullptr)
			{
				if (evtl::util::strequal(str, len, methods[i], ::strlen(methods[i])))
				{
					m_request.m_method = methods[i];
					return true;
				}

			}
		}

		return false;
	}

	bool parse_url(const char *url, size_t len)
	{
		m_request.m_url.assign(url, len);

		size_t qmaskpos = m_request.m_url.find('?');
		if (qmaskpos == std::string::npos)
			return true;
		if (qmaskpos >= len)
			assert(false);

		m_request.m_path.assign(m_request.m_url.begin(), m_request.m_url.begin() + qmaskpos);
		size_t slashpos = m_request.m_path.rfind('/');
		if (slashpos == std::string::npos)
			m_request.m_filename = m_request.m_path;
		else
		{
			m_request.m_pathprefix.assign(m_request.m_path.begin(), m_request.m_path.begin() + slashpos + 1);
			m_request.m_filename.assign(m_request.m_path.begin() + slashpos + 1, m_request.m_path.end());
		}

		m_request.m_paramstr.assign(m_request.m_url.begin() + qmaskpos + 1, m_request.m_url.end());
		size_t parampos = 0;
		while (parampos < m_request.m_paramstr.size())
		{
			size_t i;
			for (i = parampos; i < m_request.m_paramstr.size(); i++)
			{
				if (m_request.m_paramstr[i] == '&')
				{
					if (!parse_param(m_request.m_paramstr.c_str() + parampos, i - parampos))
						return false;
					parampos = i + 1;
					break;
				}
			}
			if (i >= m_request.m_paramstr.size())
			{
				if (!parse_param(m_request.m_paramstr.c_str() + parampos, i - parampos))
					return false;
				break;
			}
		}

		return true;
	}

	bool parse_param(const char *str, size_t len)
	{
		if (len == 0)
			return true;

		size_t equalpos = 0;
		for ( ; equalpos < len; equalpos++)
		{
			if (str[equalpos] == '=')
				break;
		}
		if (equalpos < len)
		{
			std::string key(str, equalpos);
			std::string value(str + equalpos + 1, len - equalpos - 1);
			long long num = evtl::util::stoll(value);
			m_request.m_params[key] = httpvalue(value, num);
		}
		else
		{
			std::string key(str, len);
			m_request.m_params[key] = httpvalue();
		}

		return true;
	}

	bool identify_protocol(const char *protocol, size_t len)
	{
		if (evtl::util::strequal(protocol, len, "HTTP/1.0")
			|| evtl::util::strequal(protocol, len, "HTTP/1.1")
			)
		{
			m_request.m_protocol.assign(protocol, len);
			return true;
		}

		return false;
	}

	bool parse_header(const std::string &header)
	{
		if (header.empty())
			return true;

		size_t equalpos = header.find(':');
		if (equalpos != std::string::npos)
		{
			std::string key(header.c_str(), equalpos);
			std::string value(header.c_str() + equalpos + 1, header.size() - equalpos - 1);
			size_t i;
			for (i = 0; i < value.size(); i++)
			{
				if (value[i] != ' ' && value[i] != '\t')
					break;
			}
			value = value.substr(i);
			long long num = evtl::util::stoll(value);
			m_request.m_headers[key] = httpvalue(value, num);
		}
		else
		{
			m_request.m_headers[header] = httpvalue();
		}

		return true;
	}

private:
	bool         m_parse_succeed;

	const char  *m_buf;
	ssize_t      m_len;

	httprequest  m_request;
};

class httpresponseparser : public evtl::once, public evtl::evtlerror
{
public:
	httpresponseparser(): m_parse_succeed(false), m_buf(nullptr), m_len(0)
	{}

	enum errorcode
	{
		success,
		lack_cr_before_lf,
		incomplete_response,
		bad_status_line,
		bad_statuscode
	};

	void parse(const char *response, ssize_t len)
	{
		m_parse_succeed = false;

		if (response == nullptr || len <= 0)
		{
			assert(false && "invalid response");
			return;
		}

		m_buf = response;
		m_len = len;

		std::vector<std::string> lines;
		if (!extract_lines(lines))
			return;

		if (lines.empty())
		{
			set_error(incomplete_response);
			return;
		}

		if (!parse_firstline(lines[0]))
			return;

		for (size_t i = 1; i < lines.size(); i++)
		{
			if (!parse_header(lines[i]))
				return;
		}

		set_error(success);
		m_parse_succeed = true;
	}

	bool parse_success() const
	{
		return m_parse_succeed;
	}

	const httpresponse& get_response() const
	{
		return m_response;
	}

	void reset()
	{
		evtl::once::reset();
		evtl::evtlerror::reset();
		m_parse_succeed = false;
		m_buf = nullptr;
		m_len = 0;
		m_response.reset();
	}

private:
	bool extract_lines(std::vector<std::string> &lines)
	{
		ssize_t startpos = 0;

		for (ssize_t i = 0; i < m_len; i++)
		{
			if (m_buf[i] == '\n')
			{
				if (i < 1 || m_buf[i - 1] != '\r')
				{
					set_error(lack_cr_before_lf);
					return false;
				}

				if (startpos < i - 1)
				{
					lines.push_back(std::string(m_buf + startpos, i - 1 - startpos));
					startpos = i + 1;
				}
				else
					return true;
			}
		}

		set_error(incomplete_response);
		return false;
	}

	bool parse_firstline(const std::string &str)
	{
		size_t space_pos = std::string::npos;
		for (size_t i = 0; i < str.size(); i++)
		{
			if (str[i] == ' ' || str[i] == '\t')
			{
				space_pos = i;
				break;
			}
		}
		if (space_pos == std::string::npos)
		{
			set_error(bad_status_line);
			return false;
		}

		if (!identify_protocol(str.c_str(), space_pos))
		{
			set_error(bad_status_line);
			return false;
		}

		size_t codepos = space_pos + 1;
		while (codepos < str.size() && (str[codepos] == ' ' || str[codepos] == '\t'))
			codepos++;
		if (codepos >= str.size())
		{
			set_error(bad_status_line);
			return false;
		}

		size_t codeendpos = codepos + 1;
		while (codeendpos < str.size() && (str[codeendpos] != ' ' && str[codeendpos] != '\t'))
			codeendpos++;
		if (codeendpos >= str.size())
		{
			set_error(bad_status_line);
			return false;
		}

		if (!parse_statuscode(str.c_str() + codepos, codeendpos - codepos))
		{
			set_error(bad_statuscode);
			return false;
		}

		size_t msgpos = codeendpos + 1;
		while (msgpos < str.size() && (str[msgpos] == ' ' || str[msgpos] == '\t'))
			msgpos++;
		if (msgpos >= str.size())
		{
			set_error(bad_status_line);
			return false;
		}

		if (!parse_statusmsg(str.c_str() + msgpos, str.size() - msgpos))
		{
			set_error(bad_status_line);
			return false;
		}

		return true;
	}

	bool identify_protocol(const char *protocol, size_t len)
	{
		if (evtl::util::strequal(protocol, len, "HTTP/1.0")
			|| evtl::util::strequal(protocol, len, "HTTP/1.1")
			)
		{
			m_response.m_protocol.assign(protocol, len);
			return true;
		}

		return false;
	}

	bool parse_statuscode(const char *code, size_t len)
	{
		if (len <= 0)
			return false;
		for (size_t i = 0; i < len; i++)
		{
			if (code[i] < '0' || code[i] > '9')
				return false;
		}

		m_response.m_statuscode.str.assign(code, len);
		m_response.m_statuscode.number = evtl::util::stoll(m_response.m_statuscode.str);
		return true;
	}

	bool parse_statusmsg(const char *msg, size_t len)
	{
		if (len <= 0)
			return false;

		m_response.m_statusmsg.assign(msg, len);
		return true;
	}

	bool parse_header(const std::string &header)
	{
		if (header.empty())
			return true;

		size_t equalpos = header.find(':');
		if (equalpos != std::string::npos)
		{
			std::string key(header.c_str(), equalpos);
			std::string value(header.c_str() + equalpos + 1, header.size() - equalpos - 1);
			size_t i;
			for (i = 0; i < value.size(); i++)
			{
				if (value[i] != ' ' && value[i] != '\t')
					break;
			}
			value = value.substr(i);
			long long num = evtl::util::stoll(value);
			m_response.m_headers[key] = httpvalue(value, num);
		}
		else
		{
			m_response.m_headers[header] = httpvalue();
		}

		return true;
	}

private:
	bool          m_parse_succeed;

	const char   *m_buf;
	ssize_t       m_len;

	httpresponse  m_response;
};


} }


#endif

