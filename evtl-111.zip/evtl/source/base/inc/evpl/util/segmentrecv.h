

#ifndef __EVPL_UTIL_SEGMENTRECV_H__
#define __EVPL_UTIL_SEGMENTRECV_H__

#include <sys/types.h>
#include <assert.h>
#include <cstdint>

#include <evtl/evtl_error.h>
#include <evtl/evtl_interface.h>
#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_utility.h>
#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_pcre2.h>


namespace evpl { namespace util {


template <class T,
	class IIO = evtl::iio,
	ssize_t (IIO::*IORead)(void *buffer, ssize_t nbytes) = &IIO::io_read
	>
class segmentrecv : public evtl::evtlerror
{
public:
	segmentrecv(): m_iio(nullptr), m_recvbuf(nullptr),
		m_maxlength(128*1024)
	{}

	enum class searchresult
	{
		success,
		need_receive,
		need_continue,
		error
	};

	enum errorcode
	{
		success,
		data_illegal,
		recv_toomuch,
		recvbuf_full
	};

	void set(IIO *iio, evtl::linearbuf<char> *recvbuf)
	{
		m_iio = iio;
		m_recvbuf = recvbuf;
	}

	void set_maxlength(ssize_t maxlen)
	{
		m_maxlength = maxlen;
	}

	bool got_segment() const
	{
		return m_segment.isset();
	}

	searchresult receive()
	{
		if (m_iio == nullptr || m_recvbuf == nullptr)
			assert(false && "null member");

		if (m_segment.isset())
			return searchresult::success;

		/* extract_segment:
		  return segment length
		  return 0 means data not enough,
		  return -1 means data illegal */
		ssize_t seglen = static_cast<T*>(this)->extract_segment(*m_recvbuf);
		if (seglen > m_recvbuf->size())
			assert(false && "seglen too large");

		if (seglen > 0)
		{
			m_segment.refer().extens_store_whole(m_recvbuf->dataptr(), seglen);
			m_segment.set();

			if (!m_recvbuf->shit_whole(seglen))
				assert(false);
			return searchresult::success;
		}
		else
		{
			if (seglen < 0)
			{
				set_error(data_illegal);
				return searchresult::error;
			}

			if (m_recvbuf->size() >= m_maxlength)
			{
				set_error(recv_toomuch, m_recvbuf->size());
				return searchresult::error;
			}

			m_recvbuf->crowdct(m_maxlength, m_maxlength);
			ssize_t headspace = m_recvbuf->headspace();
			if (headspace <= 0)
			{
				set_error(recvbuf_full, m_recvbuf->size());
				return searchresult::error;
			}
			else
			{
				ssize_t rt = (m_iio->*IORead)(m_recvbuf->headptr(), headspace);
				if (rt > 0)
				{
					if (rt > headspace)
						assert(false && "read exception");
					if (!m_recvbuf->head_eaten_whole(rt))
						assert(false && "head eaten fail");

					return searchresult::need_continue;
				}
				else
					return searchresult::need_receive;
			}
		}
	}

	const evtl::linearbuf<char>& get_segment() const
	{
		return m_segment.refer();
	}

	void reset()
	{
		m_segment.reset();
	}

protected:
	ssize_t extract_segment(const evtl::linearbuf<char> &recvbuf) const
	{
		return extract_httprequest(recvbuf, false);
	}

	ssize_t extract_httprequest(const evtl::linearbuf<char> &recvbuf, bool extract_body) const
	{
		if (recvbuf.size() > 5)
		{
			if (!evtl::util::isprefixwith(recvbuf.dataptr(), recvbuf.size(), "GET ")
				&& !evtl::util::isprefixwith(recvbuf.dataptr(), recvbuf.size(), "POST ")
				&& !evtl::util::isprefixwith(recvbuf.dataptr(), recvbuf.size(), "HEAD ")
				&& !evtl::util::isprefixwith(recvbuf.dataptr(), recvbuf.size(), "GET\t")
				&& !evtl::util::isprefixwith(recvbuf.dataptr(), recvbuf.size(), "POST\t")
				&& !evtl::util::isprefixwith(recvbuf.dataptr(), recvbuf.size(), "HEAD\t")
				)
			return -1;
		}
		else
			return 0;

		ssize_t pos = recvbuf.finds("\r\n\r\n", 4);
		if (pos < 0)
			return 0;

		if (recvbuf.finds("HTTP/1.", 7) < 0)
			return -1;

		if (!extract_body)
			return pos + 4;

		evtl::pcre2_8::regex reg(R"(\r\nContent-Length:[ \t]*(\d+)\r\n)", 0, PCRE2_DOTALL | PCRE2_CASELESS);
		evtl::pcre2_8::match_results<char> matchs;
		bool br = evtl::pcre2_8::regex_search(recvbuf.dataptr(), recvbuf.dataptr() + pos + 4, matchs, reg);
		if (br)
		{
			if (matchs.size() != 2)
				assert(false && "matches size error");

			const evtl::pcre2_8::sub_match<char> &sub = matchs[1];
			if (!sub.matched)
				assert(false && "not matched");

			long long contlen = evtl::util::stoll(sub.str());
			if (contlen <= 0 || contlen + pos + 4 <= 0)
				return pos + 4;
			if (contlen + pos + 4 <= recvbuf.size())
				return contlen + pos + 4;

			return 0;
		}

		return pos + 4;
	}

	ssize_t extract_httpresponse(const evtl::linearbuf<char> &recvbuf, bool extract_body) const
	{
		if (recvbuf.size() > 7)
		{
			if (!evtl::util::isprefixwith(recvbuf.dataptr(), recvbuf.size(), "HTTP/1."))
				return -1;
		}
		else
			return 0;

		ssize_t pos = recvbuf.finds("\r\n\r\n", 4);
		if (pos < 0)
			return 0;

		if (!extract_body)
			return pos + 4;

		evtl::pcre2_8::regex reg(R"(\r\nContent-Length:[ \t]*(\d+)\r\n)", 0, PCRE2_DOTALL | PCRE2_CASELESS);
		evtl::pcre2_8::match_results<char> matchs;
		bool br = evtl::pcre2_8::regex_search(recvbuf.dataptr(), recvbuf.dataptr() + pos + 4, matchs, reg);
		if (br)
		{
			if (matchs.size() != 2)
				assert(false && "matches size error");

			const evtl::pcre2_8::sub_match<char> &sub = matchs[1];
			if (!sub.matched)
				assert(false && "not matched");

			long long contlen = evtl::util::stoll(sub.str());
			if (contlen <= 0 || contlen + pos + 4 <= 0)
				return pos + 4;
			if (contlen + pos + 4 <= recvbuf.size())
				return contlen + pos + 4;

			return 0;
		}

		return pos + 4;
	}

private:
	IIO  *m_iio;
	evtl::linearbuf<char>  *m_recvbuf;
	ssize_t  m_maxlength;
	evtl::var<evtl::linearbuf<char>>  m_segment;
};


class httprequestrecv : public segmentrecv<httprequestrecv>
{
public:
	httprequestrecv(bool exb = false): m_extract_body(exb)
	{}

	void set_extract_body(bool exb)
	{
		m_extract_body = exb;
	}

	ssize_t extract_segment(const evtl::linearbuf<char> &recvbuf) const
	{
		return extract_httprequest(recvbuf, m_extract_body); 
	}

private:
	bool  m_extract_body;
};


class httpresponserecv : public segmentrecv<httpresponserecv>
{
public:
	httpresponserecv(bool exb = false): m_extract_body(exb)
	{}

	void set_extract_body(bool exb)
	{
		m_extract_body = exb;
	}

	ssize_t extract_segment(const evtl::linearbuf<char> &recvbuf) const
	{
		return extract_httpresponse(recvbuf, m_extract_body); 
	}

private:
	bool  m_extract_body;
};


} }


#endif


