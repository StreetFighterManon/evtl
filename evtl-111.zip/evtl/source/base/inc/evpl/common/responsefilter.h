

#ifndef __EVPL_COMMON_RESPONSEFILTER_H__
#define __EVPL_COMMON_RESPONSEFILTER_H__

#include <sys/types.h>
#include <assert.h>

#include <cstdint>
#include <string>
#include <utility>

#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_ringbuf.h>


namespace evpl { namespace common {


struct chunked_info
{
	chunked_info()
		: segment_ready(false), segment_size(0), segment_outputsize(0), reach_end(false),
		  chunked_totalsize(0), chunked_totalcount(0), output_totalsize(0)
	{}

	void reset()
	{
		segment_ready = false;
		segment_size = 0;
		segment_outputsize = 0;
		reach_end = false;

		chunked_totalsize = 0;
		chunked_totalcount = 0;
		output_totalsize = 0;
	}

	bool    segment_ready;
	int64_t segment_size;
	int64_t segment_outputsize;
	bool    reach_end;

	int64_t chunked_totalsize;
	int64_t chunked_totalcount;
	int64_t output_totalsize;
};


class chunkedfilter
{
public:
	enum statustype
	{
		status_allright,
		status_segsize_hexlen_zero,
		status_segsize_hexlen_overflow,
		status_segsize_negative,
		status_segsize_not_crlf_terminated,
		status_segment_not_crlf_terminated
	};

	chunkedfilter(): m_status(status_allright), m_databuf(1024*16), m_needmoredata(true)
	{}

	void resize_databuf(ssize_t size = 1024*16)
	{
		m_databuf.reset_capacity(size);
	}

	bool needmoredata() const
	{
		return m_needmoredata;
	}

	template <class T>
	void first_receive_eat(evtl::linearbuf<T> &data)
	{
		m_databuf.extens_store_whole(data);
		data.clear();
	}

	template <class T>
	void first_receive_eat(evtl::ringbuf<T> &data)
	{
		m_databuf.extens_store_whole(data);
		data.clear();
	}

	ssize_t receive(const void *pdata, ssize_t nbytes)
	{
		if (pdata == nullptr || nbytes <= 0)
		{
			assert(false && "invalid param");
			return 0;
		}

		if (_get_status() != status_allright)
			return 0;

		if (m_databuf.empty_capacity())
			assert(false && "databuf empty capacity");

		ssize_t appn = m_databuf.append(pdata, nbytes);
		if (appn > 0)
		{
			m_needmoredata = false;
			return appn;
		}
		return 0;
	}

	char * recv_headptr()
	{
		if (_get_status() != status_allright)
			return nullptr;

		return m_databuf.headptr();
	}

	ssize_t recv_headspace() const
	{
		if (_get_status() != status_allright)
			return 0;

		return m_databuf.headspace();
	}

	ssize_t received(ssize_t nbytes)
	{
		if (nbytes < 0)
		{
			assert(false && "negative nbytes");
			return 0;
		}

		if (_get_status() != status_allright)
			return 0;

		ssize_t eaten = m_databuf.head_eaten(nbytes);
		if (eaten > 0)
			m_needmoredata = false;

		return eaten;
	}

	bool received_whole(ssize_t nbytes)
	{
		if (nbytes < 0)
		{
			assert(false && "negative nbytes");
			return false;
		}

		if (_get_status() != status_allright)
			return false;

		bool br = m_databuf.head_eaten_whole(nbytes);
		if (br && nbytes > 0)
			m_needmoredata = false;

		return br;
	}

	void filterprocess()
	{
		if (_get_status() != status_allright)
			return;

		if (!m_chunkinfo.reach_end)
		{
			if (!m_chunkinfo.segment_ready)
			{
				filter_segment_size();
				return;
			}
			else
			{
				if (m_chunkinfo.segment_outputsize >= m_chunkinfo.segment_size)
				{
					hit_segment_crlf();
				}
			}
		}
	}

	bool status_good() const
	{
		return m_status == status_allright;
	}

	ssize_t output_databody(void *buffer, ssize_t bufsize)
	{
		if (bufsize == 0)
			return 0;

		if (buffer == nullptr || bufsize < 0)
		{
			assert(false && "invalid buffer");
			return 0;
		}

		if (m_chunkinfo.reach_end)
			return 0;
		if (!m_chunkinfo.segment_ready)
			return 0;

		if (m_chunkinfo.segment_outputsize < 0 || m_chunkinfo.segment_size < 0)
			assert(false && "invalid form status");

		ssize_t nbytes = m_chunkinfo.segment_size - m_chunkinfo.segment_outputsize;
		if (nbytes <= 0)
			return 0;

		if (nbytes > bufsize)
			nbytes = bufsize;

		ssize_t cp_size = m_databuf.copy_out(buffer, nbytes);
		if (cp_size > nbytes)
			assert(false && "copy too much");

		if (cp_size > 0)
		{
			if (!m_databuf.shit_whole(cp_size))
				assert(false && "shit error");
		}
		else
		{
			if (nbytes > 0)
				m_needmoredata = true;
		}

		if (cp_size < 0)
			cp_size = 0;

		m_chunkinfo.segment_outputsize += cp_size;
		m_chunkinfo.output_totalsize += cp_size;
		return cp_size;
	}

	bool reached_end() const
	{
		return m_chunkinfo.reach_end;
	}

	evtl::ringbuf<char>& left_data()
	{
		return m_databuf;
	}

	statustype get_status() const
	{
		return m_status;
	}

	std::string get_status_str() const
	{
		return m_status_str;
	}

	int64_t get_chunked_totalsize() const
	{
		return m_chunkinfo.chunked_totalsize;
	}

	int64_t get_chunked_totalcount() const
	{
		return m_chunkinfo.chunked_totalcount;
	}

	int64_t get_output_totalsize() const
	{
		return m_chunkinfo.output_totalsize;
	}

	void reset()
	{
		m_status = status_allright;
		m_status_str.clear();
		m_databuf.clear();
		m_chunkinfo.reset();
		m_needmoredata = true;
	}

private:
	statustype _get_status() const
	{
		return m_status;
	}

	void filter_segment_size()
	{
		if (m_databuf.empty())
		{
			m_needmoredata = true;
			return;
		}

		int         hexlen  = 0;
		int64_t     hexval = 0;
		std::string hexstr;

		_find_segsize(&hexlen, &hexval, hexstr);
		if (hexlen <= 0)
		{
			set_status(status_segsize_hexlen_zero);
			return;
		}
		if (hexlen > 16)
		{
			set_status(status_segsize_hexlen_overflow, std::move(hexstr));
			return;
		}
		if (hexval < 0)
		{
			set_status(status_segsize_negative, std::move(hexstr));
			return;
		}

		if (m_databuf.size() < hexlen + 2)
		{
			m_needmoredata = true;
			return;
		}

		if (m_databuf[hexlen] != '\r' || m_databuf[hexlen + 1] != '\n')
		{
			set_status(status_segsize_not_crlf_terminated, std::move(hexstr));
			return;
		}

		if (m_databuf.shit(hexlen + 2) != hexlen + 2)
			assert(false && "shit error");

		m_chunkinfo.segment_size = hexval;
		m_chunkinfo.segment_outputsize = 0;
		if (hexval > 0)
		{
			m_chunkinfo.chunked_totalsize += hexval;
			m_chunkinfo.chunked_totalcount++;
		}

		m_chunkinfo.segment_ready = true;
	}

	void hit_segment_crlf()
	{
		if (m_databuf.size() < 2)
		{
			m_needmoredata = true;
			return;
		}

		if (m_databuf[0] != '\r' || m_databuf[1] != '\n')
		{
			set_status(status_segment_not_crlf_terminated);
			return;
		}

		if (m_databuf.shit(2) != 2)
			assert(false && "shit error");

		if (m_chunkinfo.segment_size <= 0)
			m_chunkinfo.reach_end = true;

		m_chunkinfo.segment_ready = false;
	}

private:
	void set_status(statustype status)
	{
		m_status = status;
		m_status_str.clear();
	}

	void set_status(statustype status, const std::string &str)
	{
		m_status = status;
		m_status_str = str;
	}

	void _find_segsize(int *hexlen, int64_t *hexval, std::string &hexstr)
	{
		ssize_t size = m_databuf.size();
		if (size <= 0)
			assert(false && "empty databuf");

		hexstr.clear();
		uint64_t value = 0;
		int len = 0;
		for (ssize_t i = 0; i < size; i++)
		{
			unsigned char c = m_databuf[i];
			if (c >= '0' && c <= '9')
			{
				value <<= 4;
				value |= (c - '0');
				len++;
				hexstr.append(1, c);
			}
			else if (c >= 'a' && c <= 'f')
			{
				value <<= 4;
				value |= (c - 'a' + 10);
				len++;
				hexstr.append(1, c);
			}
			else if (c >= 'A' && c <= 'F')
			{
				value <<= 4;
				value |= (c - 'A' + 10);
				len++;
				hexstr.append(1, c);
			}
			else
			{
				break;
			}

			if (len > 16)
				break;
		}

		*hexlen = len;
		*hexval = (int64_t)value;
	}

private:
	statustype   m_status;
	std::string  m_status_str;

	evtl::ringbuf<char>  m_databuf;
	chunked_info         m_chunkinfo;
	bool                 m_needmoredata;
};


class headerfilter
{
public:
	headerfilter(): m_databuf(1024*12), m_cutheader(false)
	{}

	void resize_databuf(ssize_t size = 1024*12)
	{
		m_databuf.reset_capacity(size);
	}

	template <class T>
	void first_receive_eat(evtl::linearbuf<T> &data)
	{
		m_databuf.extens_store_whole(data);
		data.clear();
	}

	template <class T>
	void first_receive_eat(evtl::ringbuf<T> &data)
	{
		m_databuf.extens_store_whole(data);
		data.clear();
	}

	ssize_t receive(const char *pdata, int len)
	{
		if (len == 0)
			return 0;
		if (pdata == nullptr || len < 0)
		{
			assert(false && "invalid data");
			return 0;
		}

		return m_databuf.append(pdata, len, true);
	}

	char * recv_headptr()
	{
		return m_databuf.headptr();
	}

	ssize_t recv_headspace() const
	{
		return m_databuf.headspace();
	}

	bool received_whole(ssize_t nbytes)
	{
		return m_databuf.head_eaten_whole(nbytes);
	}

	void filter()
	{
		if (m_cutheader)
			return;

		ssize_t pos = m_databuf.finds("\r\n\r\n", 4);
		if (pos < 0)
			return;

		m_header.extens_store_whole(m_databuf, pos + 4);
		if (!m_databuf.shit_whole(pos + 4))
			assert(false);

		m_databuf.crowd();
		m_cutheader = true;
	}

	bool is_header_cut() const
	{
		return m_cutheader;
	}

	bool space_not_enough() const
	{
		return m_databuf.full();
	}

	evtl::linearbuf<char>& get_header()
	{
		return m_header;
	}

	evtl::linearbuf<char>& left_data()
	{
		return m_databuf;
	}

	void reset()
	{
		m_databuf.clear();
		m_cutheader = false;
		m_header.clear();
	}

private:
	evtl::linearbuf<char>  m_databuf;
	bool  m_cutheader;
	evtl::linearbuf<char>  m_header;
};


} }


#endif

