

#ifndef __EVPL_COMMON_CHUNKENCODER_H__
#define __EVPL_COMMON_CHUNKENCODER_H__

#include <sys/types.h>
#include <assert.h>
#include <string>
#include <sstream>
#include <iomanip>

#include <evtl/evtl_ringbuf.h>


namespace evpl { namespace common {


class chunkencoder
{
public:
	chunkencoder(): m_maxchunksize(0x1000), m_chunksbuf((0x1000 + 64)*4), m_encodedend(false)
	{}

	void set_chunkparams(ssize_t max_chunksize, ssize_t chunkbuf_capacity)
	{
		if (chunkbuf_capacity < max_chunksize + 64)
		{
			assert(false && "chunk buf too small");
			return;
		}

		m_maxchunksize = max_chunksize;
		m_chunksbuf.reset_capacity(chunkbuf_capacity);
	}

	ssize_t encode(const char *data, ssize_t len)
	{
		if (data == nullptr || len <= 0)
		{
			assert(false && "invalid data");
			return 0;
		}

		if (m_chunksbuf.capacity() < m_maxchunksize + 64)
			assert(false && "chunk buf too small");

		if (m_encodedend)
			return 0;

		ssize_t encoded_len = 0;
		while (encoded_len < len)
		{
			ssize_t chunkspace = _get_chunkspace(len - encoded_len);
			if (chunkspace <= 0)
				break;

			ssize_t chunksize = (len - encoded_len) > chunkspace ? chunkspace : (len - encoded_len);

			std::stringstream ss;
			ss << std::hex << std::uppercase << chunksize;
			std::string s(ss.str());
			if (!m_chunksbuf.append_whole(s.c_str(), s.size()))
				assert(false && "space not enough");
			if (!m_chunksbuf.append_whole("\r\n", 2))
				assert(false && "space not enough");
			if (!m_chunksbuf.append_whole(data + encoded_len, chunksize))
				assert(false && "space not enough");
			if (!m_chunksbuf.append_whole("\r\n", 2))
				assert(false && "space not enough");

			encoded_len += chunksize;
		}

		return encoded_len;
	}

	bool encode_end()
	{
		if (m_encodedend)
			return true;

		if (m_chunksbuf.capacity() < m_maxchunksize + 64)
			assert(false && "chunk buf too small");

		if (m_chunksbuf.space() < 5)
			return false;

		if (!m_chunksbuf.append_whole("0\r\n\r\n", 5))
			assert(false && "space not enough");
		m_encodedend = true;

		return true;
	}

	bool is_end_encoded() const
	{
		return m_encodedend;
	}

	const char * chunk_dataptr() const
	{
		return m_chunksbuf.dataptr();
	}

	ssize_t chunk_datasize() const
	{
		return m_chunksbuf.headsize();
	}

	bool chunk_shitwhole(ssize_t nbytes)
	{
		return m_chunksbuf.shit_whole(nbytes);
	}

	ssize_t chunk_copy_out(void *buffer, ssize_t nbytes)
	{
		if (buffer == nullptr || nbytes <= 0)
		{
			assert(false && "invalid buffer");
			return 0;
		}

		ssize_t ret = m_chunksbuf.copy_out(buffer, nbytes);
		if (ret > 0)
		{
			if (ret > nbytes)
				assert(false && "copy_out error");
			if (!m_chunksbuf.shit_whole(ret))
				assert(false && "shit error");
		}

		return ret;
	}

	void reset()
	{
		m_chunksbuf.clear();
		m_encodedend = false;
	}

private:
	ssize_t _get_chunkspace(ssize_t datasize) const
	{
		ssize_t space = m_chunksbuf.space() - 64;
		if (space <= 0)
			return 0;

		if (space >= datasize)
			return space;

		if (space >= m_maxchunksize)
			return m_maxchunksize;

		return 0;
	}

private:
	ssize_t   m_maxchunksize;
	evtl::ringbuf<char>    m_chunksbuf;
	bool      m_encodedend;
};


} }


#endif


