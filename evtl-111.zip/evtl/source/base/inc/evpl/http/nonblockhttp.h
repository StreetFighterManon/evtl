

#ifndef __EVPL_HTTP_NONBLOCKHTTP_H__
#define __EVPL_HTTP_NONBLOCKHTTP_H__

#include <sys/types.h>
#include <unistd.h>
#include <assert.h>
#include <string>
#include <cstdint>

#include <evtl/evtl_in.h>
#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_connector.h>
#include <evtl/evtl_interface.h>

#include "httptypes.h"
#include "sessbase.h"
#include "process.h"


namespace evpl { namespace http {


class nonblockhttp : public evtl::iio
{
public:
	nonblockhttp(): m_fd(-1)
	{}

	enum iocbresult
	{
		iocb_continue,
		iocb_done,
		iocb_error
	};

	void set_address(const evtl::address &addr)
	{
		m_addr = addr;
	}

	void set_request(const std::string &str)
	{
		m_process.set_request(str);
	}

	void set_max_respheader_size(ssize_t nbytes = 12*1024)
	{
		if (nbytes <= 0)
		{
			assert(false);
			return;
		}
		m_base.maxheadersize = nbytes;
	}

	void set_max_respbody_size(ssize_t nbytes = 1024*1024)
	{
		if (nbytes <= 0)
		{
			assert(false);
			return;
		}
		m_base.maxbodysize = nbytes;
	}

	nonblockstatus requestprocess()
	{
		if (!m_connect_result.isset())
		{
			if (!m_connect_started)
			{
				int fd = m_connector.nonblock_connect(m_addr);
				if (fd == -1)
				{
					m_base.err.set_error(http_connect_fail, m_connector.get_error_combine());
					m_connect_result.set_assign(false);
					return nonblock_connect_failed;
				}
				m_connect_started = true;
			}

			evtl::simpconnector::connect_status status = m_connector.connection_status();
			switch (status.result)
			{
			case evtl::simpconnector::connect_result_success:
				m_connect_result.set_assign(true);
				break;
			case evtl::simpconnector::connect_result_waiting:
				return nonblock_connecting;
			case evtl::simpconnector::connect_result_failed:
				m_base.err.set_error(http_connect_fail, status.tostring());
				m_connect_result.set_assign(false);
				m_connector.only_close();
				return nonblock_connect_failed;
			default:
				assert(false);
				break;
			};
		}

		if (!m_connect_result.refer())
			return nonblock_connect_failed;

		if (m_fd == -1)
		{
			m_fd = m_connector.get_fd();
			m_connector.only_reset();
			if (m_fd == -1)
				assert(false);

			m_base.siio = this;
			m_process.setbase(&m_base);
			m_process.prepare();
		}

		if (!m_request_result.isset())
		{
			iocbresult res = io_callback();
			switch (res)
			{
			case iocb_continue:
				return nonblock_requesting;
			case iocb_done:
				m_request_result.set_assign(true);
				return nonblock_success;
			case iocb_error:
				m_request_result.set_assign(false);
				return nonblock_request_failed;
			default:
				m_request_result.set_assign(false);
				assert(false);
				break;
			}
		}

		if (!m_request_result.isset())
			assert(false);

		if (!m_request_result.refer())
			return nonblock_request_failed;
		return nonblock_success;
	}

	const evtl::evtlerror& get_error() const
	{
		return m_base.err;
	}

	const header& get_header() const
	{
		return m_process.get_header();
	}

	const evtl::linearbuf<char>& get_body() const
	{
		return m_process.get_body();
	}

	void deinit()
	{
		m_base.err.reset();
		m_connector.only_close();
		m_connect_started.reset();
		m_connect_result.reset();

		if (m_fd != -1)
			::close(m_fd);
		m_fd = -1;

		m_process.reset();
		m_iostatus.reset();
		m_request_result.reset();
	}

private:
	ssize_t io_read(void *buffer, ssize_t nbytes) override
	{
		if (buffer == nullptr || nbytes <= 0)
			assert(false);

		ssize_t r = ::read(m_fd, buffer, nbytes);
		if (r < 0)
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
				m_iostatus.orset(evtl::com::rwresult_read_error, errno);
		}
		else if (r == 0)
		{
			m_iostatus.orset(evtl::com::rwresult_read_end, 0);
		}

		return r;
	}

	ssize_t io_write(const void *buffer, ssize_t nbytes) override
	{
		if (buffer == nullptr || nbytes <= 0)
			assert(false);

		ssize_t r = ::write(m_fd, buffer, nbytes);
		if (r < 0)
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
				m_iostatus.orset(evtl::com::rwresult_write_error, errno);
		}

		return r;
	}

	iocbresult io_callback()
	{
		m_process.doprocess();

		if (m_iostatus.error_raised())
		{
			m_base.err.set_error(http_sockio_fail, m_iostatus.tostring());
			return iocb_error;
		}

		evtl::com::process_nextstep step = m_process.get_nextstep();
		switch (step)
		{
		case evtl::com::nextstep_wait_to_receive:
		case evtl::com::nextstep_wait_to_send:
		case evtl::com::nextstep_continue:
			break;
		case evtl::com::nextstep_done:
			return iocb_done;
		case evtl::com::nextstep_error:
			return iocb_error;
		default:
			assert(false);
			return iocb_error;
		};

		return iocb_continue;
	}

private:
	sessbase       m_base;
	evtl::address  m_addr;

	evtl::simpconnector    m_connector;
	evtl::boolflag<false>  m_connect_started;
	evtl::var<bool>        m_connect_result;

	int  m_fd;
	process          m_process;
	evtl::com::rwstatus  m_iostatus;
	evtl::var<bool>  m_request_result;
};


} }


#endif

