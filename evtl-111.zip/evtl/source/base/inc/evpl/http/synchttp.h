

#ifndef __EVPL_HTTP_SYNCHTTP_H__
#define __EVPL_HTTP_SYNCHTTP_H__

#include <sys/types.h>
#include <unistd.h>
#include <poll.h>
#include <assert.h>
#include <errno.h>
#include <string>
#include <cstring>
#include <cstdint>

#include <evtl/evtl_in.h>
#include <evtl/evtl_error.h>
#include <evtl/evtl_interface.h>
#include <evtl/evtl_connector.h>
#include <evtl/evtl_time.h>
#include <evtl/evtl_com.h>

#include "sessbase.h"
#include "httptypes.h"
#include "process.h"


namespace evpl { namespace http {


class synchttp : public evtl::iio
{
public:
	synchttp(): m_fd(-1)
	{}

	enum iocbresult
	{
		iocb_continue,
		iocb_done,
		iocb_error,
		iocb_timeout
	};

	void set_address(const evtl::address &addr)
	{
		m_addr = addr;
	}

	void set_request(const std::string &str)
	{
		m_process.set_request(str);
	}

	void set_timeout(int minisecond = -1)
	{
		m_base.timeout_ms = minisecond;
	}

	void set_max_respheader_size(ssize_t nbytes = 12*1024)
	{
		if (nbytes <= 0)
		{
			assert(false);
			return;
		}
		m_base.maxheadersize = nbytes;
	}

	void set_max_respbody_size(ssize_t nbytes = 1024*1024)
	{
		if (nbytes <= 0)
		{
			assert(false);
			return;
		}
		m_base.maxbodysize = nbytes;
	}

	bool request()
	{
		m_base.starttime_ms = evtl::timec::msec();

		evtl::simpconnector c;
		int fd = c.wait_connect(m_addr, m_base.timeout_ms < 0 ? -1 : m_base.timeout_ms*1000LL);
		if (fd == -1)
		{
			m_base.err.set_error(http_connect_fail, c.get_error_combine());
			return false;
		}
		m_fd = fd;

		m_base.siio = this;
		m_process.setbase(&m_base);
		m_process.prepare();

		bool br = false;
		while (true)
		{
			iocbresult res = io_callback();
			switch (res)
			{
			case iocb_continue:
				continue;
			case iocb_done:
				br = true;
				break;
			case iocb_error:
			case iocb_timeout:
				break;
			default:
				assert(false);
				break;
			}
			break;
		}

		::close(m_fd);
		m_fd = -1;
		return br;
	}

	const evtl::evtlerror& get_error() const
	{
		return m_base.err;
	}

	const header& get_header() const
	{
		return m_process.get_header();
	}

	const evtl::linearbuf<char>& get_body() const
	{
		return m_process.get_body();
	}

	void reset()
	{
		m_base.err.reset();
		m_base.starttime_ms = 0;
		m_process.reset();
		m_iostatus.reset();
	}

private:
	ssize_t io_read(void *buffer, ssize_t nbytes) override
	{
		if (buffer == nullptr || nbytes <= 0)
			assert(false);

		ssize_t r = ::read(m_fd, buffer, nbytes);
		if (r < 0)
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
				m_iostatus.orset(evtl::com::rwresult_read_error, errno);
		}
		else if (r == 0)
		{
			m_iostatus.orset(evtl::com::rwresult_read_end, 0);
		}

		return r;
	}

	ssize_t io_write(const void *buffer, ssize_t nbytes) override
	{
		if (buffer == nullptr || nbytes <= 0)
			assert(false);

		ssize_t r = ::write(m_fd, buffer, nbytes);
		if (r < 0)
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
				m_iostatus.orset(evtl::com::rwresult_write_error, errno);
		}

		return r;
	}

	iocbresult io_callback()
	{
		m_process.doprocess();

		if (m_iostatus.error_raised())
		{
			m_base.err.set_error(http_sockio_fail, m_iostatus.tostring());
			return iocb_error;
		}

		int events = 0;

		evtl::com::process_nextstep step = m_process.get_nextstep();
		switch (step)
		{
		case evtl::com::nextstep_wait_to_receive:
			events = POLLIN;
			break;
		case evtl::com::nextstep_wait_to_send:
			events = POLLOUT;
			break;
		case evtl::com::nextstep_continue:
			events = POLLOUT;
			break;
		case evtl::com::nextstep_done:
			return iocb_done;
		case evtl::com::nextstep_error:
			return iocb_error;
		default:
			assert(false);
			return iocb_error;
		};

		int64_t now_ms = evtl::timec::msec();
		int rest_ms = m_base.restms(now_ms);
		if (rest_ms == 0)
		{
			m_base.err.set_error(http_timeout);
			return iocb_timeout;
		}

		struct pollfd fds;
		memset(&fds, 0, sizeof(fds));
		fds.fd      = m_fd;
		fds.events  = events;
		fds.revents = 0;

		int ret = ::poll(&fds, 1, rest_ms > 0 ? rest_ms : -1);
		if (ret > 0)
		{
			if ((fds.revents & (POLLERR | POLLHUP | POLLNVAL)) != 0)
			{
				m_base.err.set_error(http_fdpoll_error, fds.revents);
				return iocb_error;
			}
			return iocb_continue;
		}
		else if (ret == 0)
		{
			m_base.err.set_error(http_timeout);
			return iocb_timeout;
		}

		if (errno == EINTR)
			return iocb_continue;

		m_base.err.set_error(http_poll_failed, errno);
		return iocb_error;
	}

private:
	sessbase       m_base;
	evtl::address  m_addr;
	int      m_fd;
	process  m_process;
	evtl::com::rwstatus  m_iostatus;
};


} }


#endif


