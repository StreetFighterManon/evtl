

#ifndef __EVPL_HTTP_ASYNCHTTP_H__
#define __EVPL_HTTP_ASYNCHTTP_H__

#include <sys/types.h>
#include <assert.h>

#include <functional>
#include <utility>
#include <string>
#include <cstdint>

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_watcher_io.h>
#include <evtl/evtl_interface.h>
#include <evtl/evtl_in.h>
#include <evtl/evtl_watcher_timer.h>
#include <evtl/evtl_connector.h>
#include <evtl/evtl_error.h>
#include <evtl/evtl_linearbuf.h>

#include "httptypes.h"
#include "sessbase.h"
#include "process.h"


namespace evpl { namespace http {


template <class T>
class asynchttp : public evtl::watcher_io<asynchttp<T>>,
	public evtl::iio
{
public:
	asynchttp(): m_data(nullptr)
	{}

	typedef std::function<void (T& http, bool succeed)>  http_callback_t;

	void set_loop(evtl::looprefer loop)
	{
		m_loop = loop;
	}

	void set_httpcallback(http_callback_t cb)
	{
		m_httpcb = std::move(cb);
	}

	void set_address(const evtl::address &addr)
	{
		m_addr = addr;
	}

	void set_request(const std::string &str)
	{
		m_process.set_request(str);
	}

	void set_timeout(int minisecond = -1)
	{
		m_base.timeout_ms = minisecond;
	}

	void set_max_respheader_size(ssize_t nbytes = 12*1024)
	{
		if (nbytes <= 0)
		{
			assert(false);
			return;
		}
		m_base.maxheadersize = nbytes;
	}

	void set_max_respbody_size(ssize_t nbytes = 1024*1024)
	{
		if (nbytes <= 0)
		{
			assert(false);
			return;
		}
		m_base.maxbodysize = nbytes;
	}

	void set_data(void *pdata)
	{
		m_data = pdata;
	}

	bool request()
	{
		if (m_base.timeout_ms >= 0)
		{
			m_timer.set(m_loop, m_base.timeout_ms/1000. + m_loop.now_difference(), 0.);
			m_timer.set_callback(std::bind(&asynchttp::timer_callback, this, std::placeholders::_1, std::placeholders::_2));
			m_timer.start();
		}
		m_connector.set_loop(m_loop);
		m_connector.set_callback(std::bind(&asynchttp::connect_callback, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3));
		bool br = m_connector.async_connect(m_addr);
		if (!br)
		{
			m_base.err.set_error(http_connect_fail, m_connector.get_error_combine());
			return false;
		}
		return true;
	}

	const evtl::evtlerror& get_error() const
	{
		return m_base.err;
	}

	const header& get_header() const
	{
		return m_process.get_header();
	}

	const evtl::linearbuf<char>& get_body() const
	{
		return m_process.get_body();
	}

	void * get_data() const
	{
		return m_data;
	}

	void reset()
	{
		m_base.err.reset();
		m_process.reset();
		m_iostatus.reset();
	}

	void deinit()
	{
		this->stop_close();
		m_connector.stop_close();
		m_timer.stop();

		reset();
	}

	void io_callback(asynchttp &watcher, int revents)
	{
		if (&watcher != this)
			assert(false);

		m_process.doprocess();

		if (m_iostatus.error_raised())
		{
			m_base.err.set_error(http_sockio_fail, m_iostatus.tostring());
			_end_clean();
			m_httpcb(*static_cast<T*>(this), false);
			return;
		}

		evtl::com::process_nextstep step = m_process.get_nextstep();
		switch (step)
		{
		case evtl::com::nextstep_wait_to_receive:
			this->start_events(ev::READ);
			break;
		case evtl::com::nextstep_wait_to_send:
			this->start_events(ev::WRITE);
			break;
		case evtl::com::nextstep_continue:
			this->start_events(ev::WRITE);
			break;
		case evtl::com::nextstep_done:
			{
				m_base.err.set_error(http_success);
				_end_clean();
				m_httpcb(*static_cast<T*>(this), true);
			}
			return;
		case evtl::com::nextstep_error:
			{
				_end_clean();
				m_httpcb(*static_cast<T*>(this), false);
			}
			return;
		default:
			assert(false);
			break;
		};
	}

private:
	ssize_t io_read(void *buffer, ssize_t nbytes) override
	{
		if (buffer == nullptr || nbytes <= 0)
			assert(false);

		ssize_t r = this->read(buffer, nbytes);
		if (r < 0)
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
				m_iostatus.orset(evtl::com::rwresult_read_error, errno);
		}
		else if (r == 0)
		{
			m_iostatus.orset(evtl::com::rwresult_read_end, 0);
		}

		return r;
	}

	ssize_t io_write(const void *buffer, ssize_t nbytes) override
	{
		if (buffer == nullptr || nbytes <= 0)
			assert(false);

		ssize_t r = this->write(buffer, nbytes);
		if (r < 0)
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
				m_iostatus.orset(evtl::com::rwresult_write_error, errno);
		}

		return r;
	}

	void connect_callback(evtl::simpconnector &connector, int errcode, int errnocode)
	{
		if (&connector != &m_connector)
			assert(false);

		if (errcode == evtl::simpconnector::success)
		{
			int fd = connector.get_fd();
			connector.only_reset();

			m_base.siio = this;
			m_process.setbase(&m_base);
			m_process.prepare();

			this->set(m_loop);
			this->set_callback();
			this->set(fd, ev::WRITE);
			this->start();
		}
		else
		{
			m_base.err.set_error(http_connect_fail, connector.get_error_combine());
			if (m_timer.is_active())
				m_timer.stop();

			m_httpcb(*static_cast<T*>(this), false);
		}
	}

	void timer_callback(evtl::simpwtimer &watcher, int revents)
	{
		if (&watcher != &m_timer)
			assert(false);

		m_base.err.set_error(http_timeout, "timer");

		watcher.stop();
		this->stop_close();
		m_connector.stop_close();

		m_httpcb(*static_cast<T*>(this), false);
	}

	void _end_clean()
	{
		this->stop_close();
		if (m_timer.is_active())
			m_timer.stop();
	}

private:
	sessbase          m_base;
	evtl::looprefer   m_loop;
	http_callback_t   m_httpcb;
	evtl::address     m_addr;

	evtl::simpconnector  m_connector;
	evtl::simpwtimer     m_timer;
	process  m_process;

	evtl::com::rwstatus  m_iostatus;
	void *   m_data;
};

class simpasynchttp : public asynchttp<simpasynchttp>
{};


} }


#endif

