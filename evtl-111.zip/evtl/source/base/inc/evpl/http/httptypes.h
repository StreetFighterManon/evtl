

#ifndef __EVPL_HTTP_HTTPTYPES_H__
#define __EVPL_HTTP_HTTPTYPES_H__

#include <string>
#include <map>
#include <cstdint>

#include <evtl/evtl_wrapper.h>


namespace evpl { namespace http {


enum errorcode
{
	http_success,
	http_connect_fail,
	http_sockio_fail,
	http_badheader,
	http_bad_contentlength,
	http_fdpoll_error,
	http_timeout,
	http_poll_failed,
	http_chunkstatus_error,
	http_chunkspace_not_enough
};

enum nonblockstatus
{
	nonblock_success,
	nonblock_connecting,
	nonblock_connect_failed,
	nonblock_requesting,
	nonblock_request_failed
};

struct header
{
	header(): code(0)
	{}

	std::string  original_header;
	std::string  proto;
	int          code;
	std::string  statusstr;
	std::map<std::string, std::string>  m_headers;

	evtl::var<int64_t>  content_length;

	std::string get_header(const std::string &key) const
	{
		std::map<std::string, std::string>::const_iterator iter = m_headers.find(key);
		if (iter != m_headers.end())
			return iter->second;
		return std::string();
	}
};


} }


#endif


