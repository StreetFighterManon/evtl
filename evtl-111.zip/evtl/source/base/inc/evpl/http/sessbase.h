

#ifndef __EVPL_HTTP_SESSBASE_H__
#define __EVPL_HTTP_SESSBASE_H__

#include <sys/types.h>
#include <cstdint>

#include <evtl/evtl_error.h>
#include <evtl/evtl_interface.h>


namespace evpl { namespace http {


struct sessbase
{
	sessbase(): siio(nullptr), timeout_ms(-1), starttime_ms(0),
		maxheadersize(12*1024), maxbodysize(1024*1024)
	{}

	evtl::evtlerror  err;
	evtl::iio       *siio;

	int      timeout_ms;
	int64_t  starttime_ms;
	ssize_t  maxheadersize;
	ssize_t  maxbodysize;

	int restms(int64_t now_ms)
	{
		if (timeout_ms < 0)
			return -1;

		int64_t spent = now_ms - starttime_ms;
		if (spent < 0)
		{
			spent = 0;
			starttime_ms = now_ms;
		}

		int64_t rest = (int64_t)timeout_ms - spent;
		if (rest < 0)
			rest = 0;
		else if (rest > 0x7FFFFFFFLL)
			rest = 0x7FFFFFFF;

		return (int)rest;
	}
};


} }


#endif

