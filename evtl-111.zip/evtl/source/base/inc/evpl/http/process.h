

#ifndef __EVPL_HTTP_PROCESS_H_
#define __EVPL_HTTP_PROCESS_H_

#include <sys/types.h>
#include <assert.h>
#include <string>

#include <evtl/evtl_com.h>
#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_pcre2.h>
#include <evtl/evtl_utility.h>
#include <evtl/evtl_wrapper.h>

#include "sessbase.h"
#include "httptypes.h"
#include "../common/responsefilter.h"


namespace evpl { namespace http {


class process
{
public:
	process(): m_base(nullptr), m_step(evtl::com::nextstep_unknown),
		m_transfer_chunked(false)
	{}

	enum class headerresult
	{
		success,
		needrecv,
		needsend,
		needcontinue,
		readerror,
		badheader
	};

	enum class bodyresult
	{
		success,
		needrecv,
		needsend,
		needcontinue,
		readerror,
		chunkerror
	};

	void setbase(sessbase *base)
	{
		m_base = base;
	}

	void set_request(const std::string &str)
	{
		m_sendbuf.extens_store_whole(str);
	}

	void prepare()
	{
		m_headerbuf.reset_capacity(m_base->maxheadersize);
	}

	void doprocess()
	{
		set_nextstep(evtl::com::nextstep_unknown);

		if (!m_sendbuf.empty())
		{
			ssize_t ret = m_base->siio->io_write(m_sendbuf.dataptr(), m_sendbuf.size());
			if (ret > 0)
			{
				if (!m_sendbuf.shit_whole(ret))
					assert(false && "shit failed");
			}
			if (!m_sendbuf.empty())
			{
				set_nextstep(evtl::com::nextstep_wait_to_send);
				return;
			}
		}

		const header &head = m_header.refer();
		if (!m_header.isset())
		{
			headerresult res = recvheader();
			switch (res)
			{
			case headerresult::success:
				if (!m_header.isset())
					assert(false);
				break;
			case headerresult::needrecv:
				set_nextstep(evtl::com::nextstep_wait_to_receive);
				return;
			case headerresult::needsend:
				set_nextstep(evtl::com::nextstep_wait_to_send);
				return;
			case headerresult::needcontinue:
				set_nextstep(evtl::com::nextstep_wait_to_send);
				return;
			case headerresult::readerror:
				set_nextstep(evtl::com::nextstep_error);
				return;
			case headerresult::badheader:
				set_nextstep(evtl::com::nextstep_error);
				return;
			default:
				assert(false);
				set_nextstep(evtl::com::nextstep_error);
				return;
			}

			if (!m_header.isset())
				assert(false);
			if (head.content_length.isset() || head.get_header("Transfer-Encoding") != "chunked")
			{
				m_transfer_chunked = false;
				int64_t content_length = 0;
				if (head.content_length.isset())
					content_length = head.content_length;
				if (content_length < 0 || content_length > m_base->maxbodysize)
				{
					m_base->err.set_error(http_bad_contentlength, content_length);
					set_nextstep(evtl::com::nextstep_error);
					return;
				}

				m_body.reset_capacity(content_length);
				if (m_body.capacity() != content_length)
					assert(false);
			}
			else
			{
				m_transfer_chunked = true;
				m_filter.resize_databuf(1024*1024);
				ssize_t cap = m_base->maxbodysize < 1024*1024 ? m_base->maxbodysize : 1024*1024;
				m_body.reset_capacity(cap);
				if (m_body.capacity() != cap)
					assert(false);
			}
		}

		bodyresult bodyres = bodyresult::success;
		if (!m_transfer_chunked)
			bodyres = recvbody();
		else
			bodyres = recvchunkedbody();

		switch (bodyres)
		{
		case bodyresult::success:
			break;
		case bodyresult::needrecv:
			set_nextstep(evtl::com::nextstep_wait_to_receive);
			return;
		case bodyresult::needsend:
			set_nextstep(evtl::com::nextstep_wait_to_send);
			return;
		case bodyresult::needcontinue:
			set_nextstep(evtl::com::nextstep_continue);
			return;
		case bodyresult::readerror:
			set_nextstep(evtl::com::nextstep_error);
			return;
		case bodyresult::chunkerror:
			set_nextstep(evtl::com::nextstep_error);
			return;
		default:
			assert(false);
			set_nextstep(evtl::com::nextstep_error);
			return;
		};

		set_nextstep(evtl::com::nextstep_done);
	}

	evtl::com::process_nextstep get_nextstep() const
	{
		return m_step;
	}

	const header& get_header() const
	{
		return m_header.refer();
	}

	const evtl::linearbuf<char>& get_body() const
	{
		return m_body;
	}

	void reset()
	{
		m_sendbuf.clear();
		m_headerbuf.clear();
		m_header.reset();

		m_transfer_chunked = false;
		m_body.clear();
		m_filter.reset();
	}

private:
	void set_nextstep(evtl::com::process_nextstep step)
	{
		m_step = step;
	}

	headerresult recvheader()
	{
		ssize_t pos = m_headerbuf.finds("\r\n\r\n", 4);
		if (pos < 0)
		{
			if (m_headerbuf.full())
			{
				m_base->err.set_error(http_badheader);
				return headerresult::badheader;
			}
			m_headerbuf.crowd();
			ssize_t headspace = m_headerbuf.headspace();
			if (headspace <= 0)
				assert(false);

			ssize_t r = m_base->siio->io_read(m_headerbuf.headptr(), headspace);
			if (r > 0)
			{
				if (!m_headerbuf.head_eaten_whole(r))
					assert(false);
				return headerresult::needcontinue;
			}
			return headerresult::needrecv;
		}

		ssize_t endpos = pos + 4;
		header &head = m_header.refer();

		evtl::pcre2_8::regex reg(R"(^(HTTP/1\.[01]) *(\d+) *(.+?)\r\n)");
		evtl::pcre2_8::match_results<char> matches;
		bool br = evtl::pcre2_8::regex_search(m_headerbuf.dataptr(), m_headerbuf.dataptr() + endpos, matches, reg);
		if (br)
		{
			if (matches.size() != 4)
				assert(false);
			const evtl::pcre2_8::sub_match<char> &sub1 = matches[1];
			const evtl::pcre2_8::sub_match<char> &sub2 = matches[2];
			const evtl::pcre2_8::sub_match<char> &sub3 = matches[3];
			if (!sub1.matched || !sub2.matched || !sub3.matched)
				assert(false);

			head.original_header = m_headerbuf.tostring(endpos);
			head.proto = sub1.str();
			head.code = evtl::util::stoi(sub2.str());
			head.statusstr = sub3.str();
		}
		else
		{
			m_base->err.set_error(http_badheader);
			return headerresult::badheader;
		}

		if (matches[0].second > m_headerbuf.dataptr() + endpos)
			assert(false);

		evtl::pcre2_8::regex  reg2(R"((.+?): *(.*?)\r\n)");
		evtl::pcre2_8::regex_iterator<char> iter(matches[0].second, m_headerbuf.dataptr() + endpos, reg2);
		evtl::pcre2_8::regex_iterator<char> end;
		for ( ; iter != end; ++iter)
		{
			const evtl::pcre2_8::match_results<char> &match = *iter;
			if (!match[1].matched || !match[2].matched)
				assert(false);

			std::string key = match[1].str();
			head.m_headers[key] = match[2].str();
			if (evtl::util::strcasecmp(key, "Content-Length"))
				head.content_length.set_assign(evtl::util::stoll(match[2].str()));
		}

		if (!m_headerbuf.shit_whole(endpos))
			assert(false);

		m_header.set();
		return headerresult::success;
	}

	bodyresult recvbody()
	{
		if (!m_headerbuf.empty())
			m_body.eat(m_headerbuf);

		int64_t contentlength = m_header.refer().content_length;
		if (m_body.size() >= contentlength)
			return bodyresult::success;

		if (!m_headerbuf.empty())
			assert(false);

		ssize_t headspace = m_body.headspace();
		if (headspace <= 0)
			assert(false);
		ssize_t r = m_base->siio->io_read(m_body.headptr(), headspace);
		if (r > 0)
		{
			if (!m_body.head_eaten_whole(r))
				assert(false);
			if (m_body.size() >= contentlength)
				return bodyresult::success;
		}

		return bodyresult::needrecv;
	}

	bodyresult recvchunkedbody()
	{
		if (!m_filter.reached_end())
		{
			for (int i = 0; i < 30; i++)
			{
				if (!filteroutput())
					return bodyresult::chunkerror;
				if (m_filter.reached_end())
					return bodyresult::success;
				if (!m_filter.status_good())
					return bodyresult::chunkerror;

				if (m_filter.needmoredata())
					break;
			}

			if (m_filter.needmoredata())
				return filterinput();
			return bodyresult::needcontinue;
		}

		return bodyresult::success;
	}

	bodyresult filterinput()
	{
		if (!m_headerbuf.empty())
		{
			ssize_t r = m_filter.receive(m_headerbuf.dataptr(), m_headerbuf.size());
			if (r > 0)
			{
				if (!m_headerbuf.shit_whole(r))
					assert(false);
			}
			if (!m_headerbuf.empty())
				return bodyresult::needcontinue;
		}

		ssize_t headspace = m_filter.recv_headspace();
		if (headspace <= 0)
			return bodyresult::needcontinue;
		ssize_t r = m_base->siio->io_read(m_filter.recv_headptr(), headspace);
		if (r > 0)
		{
			if (!m_filter.received_whole(r))
				assert(false);
			return bodyresult::needcontinue;
		}
		return bodyresult::needrecv;
	}

	bool filteroutput()
	{
		m_filter.filterprocess();

		if (!m_filter.status_good())
		{
			m_base->err.set_error(http_chunkstatus_error, m_filter.get_status());
			return false;
		}
		if (m_filter.reached_end())
			return true;

		if (m_body.headspace() <= 0)
		{
			if (m_body.capacity() >= m_base->maxbodysize)
			{
				m_base->err.set_error(http_chunkspace_not_enough, m_body.capacity());
				return false;
			}

			if (m_body.capacity()*2 >= m_base->maxbodysize)
				m_body.expand_capacity(m_base->maxbodysize);
			else
				m_body.expand_capacity(m_body.capacity()*2);
		}

		ssize_t headspace = m_body.headspace();
		if (headspace <= 0)
			assert(false);

		ssize_t r = m_filter.output_databody(m_body.headptr(), headspace);
		if (r > 0)
		{
			if (!m_body.head_eaten_whole(r))
				assert(false);
		}
		return true;
	}

private:
	sessbase  *m_base;
	evtl::com::process_nextstep  m_step;
	evtl::linearbuf<char>   m_sendbuf;
	evtl::linearbuf<char>   m_headerbuf;
	evtl::var<header>       m_header;

	bool  m_transfer_chunked;
	evtl::linearbuf<char>   m_body;
	common::chunkedfilter   m_filter;
};


} }


#endif


