

#ifndef __EVPL_HTTPS_SSLCTX_H__
#define __EVPL_HTTPS_SSLCTX_H__

#include <assert.h>
#include <openssl/ssl.h>

#include <evtl/evtl_error.h>


namespace evpl { namespace https {


class sslctx : public evtl::evtlerror
{
public:
	sslctx(): m_ctx(nullptr)
	{}

	enum errorcode
	{
		success,
		new_context_failed
	};

	bool new_context()
	{
		if (m_ctx != nullptr)
			assert(false && "m_ctx exists");

		const SSL_METHOD *meth = TLS_method();
		if (meth == nullptr)
		{
			set_error(new_context_failed, "TLS_method failed");
			return false;
		}

		m_ctx = SSL_CTX_new(meth);
		if (m_ctx == nullptr)
		{
			set_error(new_context_failed, "SSL_CTX_new failed");
			return false;
		}

		SSL_CTX_set_mode(m_ctx, SSL_MODE_AUTO_RETRY | SSL_MODE_ENABLE_PARTIAL_WRITE);
		SSL_CTX_set_read_ahead(m_ctx, 1);

		SSL_CTX_set_session_cache_mode(m_ctx, SSL_SESS_CACHE_OFF);
		SSL_CTX_set_verify(m_ctx, SSL_VERIFY_NONE, nullptr);

		return true;
	}

	SSL * new_ssl()
	{
		if (m_ctx == nullptr)
			assert(false && "null ctx");

		return SSL_new(m_ctx);
	}

	void free()
	{
		if (m_ctx != nullptr)
			SSL_CTX_free(m_ctx);
		m_ctx = nullptr;
	}

private:
	SSL_CTX  *m_ctx;
};


} }


#endif


