

#ifndef __EVPL_HTTPS_HTTPTYPES_H__
#define __EVPL_HTTPS_HTTPTYPES_H__

#include <string>
#include <map>
#include <cstdint>

#include <evtl/evtl_wrapper.h>


namespace evpl { namespace https {


enum errorcode
{
	https_success,
	https_connect_fail,
	https_sslio_fail,
	https_badheader,
	https_bad_contentlength,
	https_fdpoll_error,
	https_timeout,
	https_poll_failed,
	https_chunkstatus_error,
	https_chunkspace_not_enough
};

enum nonblockstatus
{
	nonblock_success,
	nonblock_connecting,
	nonblock_connect_failed,
	nonblock_requesting,
	nonblock_request_failed
};

struct header
{
	header(): code(0)
	{}

	std::string  original_header;
	std::string  proto;
	int          code;
	std::string  statusstr;
	std::map<std::string, std::string>  m_headers;

	evtl::var<int64_t>  content_length;

	std::string get_header(const std::string &key) const
	{
		std::map<std::string, std::string>::const_iterator iter = m_headers.find(key);
		if (iter != m_headers.end())
			return iter->second;
		return std::string();
	}
};


} }


#endif


