

#ifndef __EVPL_HTTPS_ASYNCHTTPS_H__
#define __EVPL_HTTPS_ASYNCHTTPS_H__

#include <sys/types.h>
#include <assert.h>

#include <functional>
#include <utility>
#include <string>
#include <cstdint>

#include <openssl/ssl.h>

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_watcher_io.h>
#include <evtl/evtl_interface.h>
#include <evtl/evtl_in.h>
#include <evtl/evtl_watcher_timer.h>
#include <evtl/evtl_connector.h>
#include <evtl/evtl_error.h>
#include <evtl/evtl_linearbuf.h>
#include <evpl/openssl/sslcom.h>

#include "httptypes.h"
#include "sessbase.h"
#include "process.h"


namespace evpl { namespace https {


template <class T>
class asynchttps : public evtl::watcher_io<asynchttps<T>>,
	public evtl::isslio
{
public:
	asynchttps(): m_data(nullptr)
	{}

	typedef std::function<void (T& https, bool succeed)>  https_callback_t;

	void set_loop(evtl::looprefer loop)
	{
		m_loop = loop;
	}

	void set_httpscallback(https_callback_t cb)
	{
		m_httpscb = std::move(cb);
	}

	void set_ssl(SSL *ssl)
	{
		m_base.ssl.set_ssl(ssl);
	}

	void set_address(const evtl::address &addr)
	{
		m_addr = addr;
	}

	void set_request(const std::string &str)
	{
		m_process.set_request(str);
	}

	void set_timeout(int minisecond = -1)
	{
		m_base.timeout_ms = minisecond;
	}

	void set_max_respheader_size(ssize_t nbytes = 12*1024)
	{
		if (nbytes <= 0)
		{
			assert(false);
			return;
		}
		m_base.maxheadersize = nbytes;
	}

	void set_max_respbody_size(ssize_t nbytes = 1024*1024)
	{
		if (nbytes <= 0)
		{
			assert(false);
			return;
		}
		m_base.maxbodysize = nbytes;
	}

	void set_data(void *pdata)
	{
		m_data = pdata;
	}

	bool request()
	{
		if (m_base.timeout_ms >= 0)
		{
			m_timer.set(m_loop, m_base.timeout_ms/1000. + m_loop.now_difference(), 0.);
			m_timer.set_callback(std::bind(&asynchttps::timer_callback, this, std::placeholders::_1, std::placeholders::_2));
			m_timer.start();
		}
		m_connector.set_loop(m_loop);
		m_connector.set_callback(std::bind(&asynchttps::connect_callback, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3));
		bool br = m_connector.async_connect(m_addr);
		if (!br)
		{
			m_base.ssl.free();
			m_base.err.set_error(https_connect_fail, m_connector.get_error_combine());
			return false;
		}
		return true;
	}

	const evtl::evtlerror& get_error() const
	{
		return m_base.err;
	}

	const header& get_header() const
	{
		return m_process.get_header();
	}

	const evtl::linearbuf<char>& get_body() const
	{
		return m_process.get_body();
	}

	void * get_data() const
	{
		return m_data;
	}

	void reset()
	{
		m_base.err.reset();
		m_process.reset();
		m_ioresult.reset();
	}

	void deinit()
	{
		m_base.ssl.shutdown();
		m_base.ssl.free();
		this->stop_close();
		m_connector.stop_close();
		m_timer.stop();

		reset();
	}

	void io_callback(asynchttps &watcher, int revents)
	{
		if (&watcher != this)
			assert(false);

		m_process.doprocess();

		if (m_ioresult.error_raised())
		{
			m_base.err.set_error(https_sslio_fail, m_ioresult.tostring());
			_end_clean();
			m_httpscb(*static_cast<T*>(this), false);
			return;
		}

		evtl::com::process_nextstep step = m_process.get_nextstep();
		switch (step)
		{
		case evtl::com::nextstep_wait_to_receive:
			this->start_events(ev::READ);
			break;
		case evtl::com::nextstep_wait_to_send:
			this->start_events(ev::WRITE);
			break;
		case evtl::com::nextstep_continue:
			this->start_events(ev::WRITE);
			break;
		case evtl::com::nextstep_done:
			{
				m_base.err.set_error(https_success);
				_end_clean();
				m_httpscb(*static_cast<T*>(this), true);
			}
			return;
		case evtl::com::nextstep_error:
			{
				_end_clean();
				m_httpscb(*static_cast<T*>(this), false);
			}
			return;
		default:
			assert(false);
			break;
		};
	}

private:
	int64_t sslread(void *buffer, int64_t nbytes) override
	{
		assert(false);
		return 0;
	}

	int64_t sslwrite(const void *buffer, int64_t nbytes) override
	{
		assert(false);
		return 0;
	}

	int64_t sslreadv(void *buffer, int64_t nbytes, int retry, int *trytimes) override
	{
		int64_t ret = m_base.ssl.readv(buffer, nbytes, retry, trytimes);
		if (ret <= 0)
		{
			const evpl::openssl::ioresult &result = m_base.ssl.get_result();
			m_ioresult.set_ifnoerror(result);
		}
		return ret;
	}

	int64_t sslwritev(const void *buffer, int64_t nbytes, int retry, int *trytimes) override
	{
		int64_t ret = m_base.ssl.writev(buffer, nbytes, retry, trytimes);
		if (ret <= 0)
		{
			const evpl::openssl::ioresult &result = m_base.ssl.get_result();
			m_ioresult.set_ifnoerror(result);
		}
		return ret;
	}

	void connect_callback(evtl::simpconnector &connector, int errcode, int errnocode)
	{
		if (&connector != &m_connector)
			assert(false);

		if (errcode == evtl::simpconnector::success)
		{
			int fd = connector.get_fd();
			connector.only_reset();

			m_base.ssl.set_fd(fd);
			m_base.sslio = this;
			m_process.setbase(&m_base);
			m_process.prepare();

			this->set(m_loop);
			this->set_callback();
			this->set(fd, ev::WRITE);
			this->start();
		}
		else
		{
			m_base.err.set_error(https_connect_fail, connector.get_error_combine());
			m_base.ssl.free();
			if (m_timer.is_active())
				m_timer.stop();

			m_httpscb(*static_cast<T*>(this), false);
		}
	}

	void timer_callback(evtl::simpwtimer &watcher, int revents)
	{
		if (&watcher != &m_timer)
			assert(false);

		m_base.err.set_error(https_timeout, "timer");

		watcher.stop();
		m_base.ssl.shutdown();
		m_base.ssl.free();
		this->stop_close();
		m_connector.stop_close();

		m_httpscb(*static_cast<T*>(this), false);
	}

	void _end_clean()
	{
		m_base.ssl.shutdown();
		m_base.ssl.free();
		this->stop_close();
		if (m_timer.is_active())
			m_timer.stop();
	}

private:
	sessbase          m_base;
	evtl::looprefer   m_loop;
	https_callback_t  m_httpscb;
	evtl::address     m_addr;

	evtl::simpconnector  m_connector;
	evtl::simpwtimer     m_timer;
	process  m_process;

	evpl::openssl::ioresult  m_ioresult;
	void *   m_data;
};

class simpasynchttps : public asynchttps<simpasynchttps>
{};


} }


#endif

