

#ifndef __EVPL_HTTPS_NONBLOCKHTTPS_H__
#define __EVPL_HTTPS_NONBLOCKHTTPS_H__

#include <sys/types.h>
#include <unistd.h>
#include <assert.h>
#include <string>
#include <cstdint>

#include <openssl/ssl.h>
#include <evtl/evtl_in.h>
#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_connector.h>
#include <evtl/evtl_interface.h>
#include <evpl/openssl/sslcom.h>

#include "httptypes.h"
#include "sessbase.h"
#include "process.h"


namespace evpl { namespace https {


class nonblockhttps : public evtl::isslio
{
public:
	nonblockhttps(): m_fd(-1)
	{}

	enum iocbresult
	{
		iocb_continue,
		iocb_done,
		iocb_error
	};

	void set_ssl(SSL *ssl)
	{
		m_base.ssl.set_ssl(ssl);
	}

	void set_address(const evtl::address &addr)
	{
		m_addr = addr;
	}

	void set_request(const std::string &str)
	{
		m_process.set_request(str);
	}

	void set_max_respheader_size(ssize_t nbytes = 12*1024)
	{
		if (nbytes <= 0)
		{
			assert(false);
			return;
		}
		m_base.maxheadersize = nbytes;
	}

	void set_max_respbody_size(ssize_t nbytes = 1024*1024)
	{
		if (nbytes <= 0)
		{
			assert(false);
			return;
		}
		m_base.maxbodysize = nbytes;
	}

	nonblockstatus requestprocess()
	{
		if (!m_connect_result.isset())
		{
			if (!m_connect_started)
			{
				int fd = m_connector.nonblock_connect(m_addr);
				if (fd == -1)
				{
					m_base.err.set_error(https_connect_fail, m_connector.get_error_combine());
					m_connect_result.set_assign(false);
					return nonblock_connect_failed;
				}
				m_connect_started = true;
			}

			evtl::simpconnector::connect_status status = m_connector.connection_status();
			switch (status.result)
			{
			case evtl::simpconnector::connect_result_success:
				m_connect_result.set_assign(true);
				break;
			case evtl::simpconnector::connect_result_waiting:
				return nonblock_connecting;
			case evtl::simpconnector::connect_result_failed:
				m_base.err.set_error(https_connect_fail, status.tostring());
				m_connect_result.set_assign(false);
				m_connector.only_close();
				return nonblock_connect_failed;
			default:
				assert(false);
				break;
			};
		}

		if (!m_connect_result.refer())
			return nonblock_connect_failed;

		if (m_fd == -1)
		{
			m_fd = m_connector.get_fd();
			m_connector.only_reset();
			if (m_fd == -1)
				assert(false);

			m_base.ssl.set_fd(m_fd);
			m_base.sslio = this;
			m_process.setbase(&m_base);
			m_process.prepare();
		}

		if (!m_request_result.isset())
		{
			iocbresult res = io_callback();
			switch (res)
			{
			case iocb_continue:
				return nonblock_requesting;
			case iocb_done:
				m_request_result.set_assign(true);
				return nonblock_success;
			case iocb_error:
				m_request_result.set_assign(false);
				return nonblock_request_failed;
			default:
				m_request_result.set_assign(false);
				assert(false);
				break;
			}
		}

		if (!m_request_result.isset())
			assert(false);

		if (!m_request_result.refer())
			return nonblock_request_failed;
		return nonblock_success;
	}

	const evtl::evtlerror& get_error() const
	{
		return m_base.err;
	}

	const header& get_header() const
	{
		return m_process.get_header();
	}

	const evtl::linearbuf<char>& get_body() const
	{
		return m_process.get_body();
	}

	void deinit()
	{
		m_base.err.reset();
		m_base.ssl.shutdown();
		m_base.ssl.free();
		m_connector.only_close();
		m_connect_started.reset();
		m_connect_result.reset();

		if (m_fd != -1)
			::close(m_fd);
		m_fd = -1;

		m_process.reset();
		m_ioresult.reset();
		m_request_result.reset();
	}

private:
	int64_t sslread(void *buffer, int64_t nbytes) override
	{
		assert(false);
		return 0;
	}

	int64_t sslwrite(const void *buffer, int64_t nbytes) override
	{
		assert(false);
		return 0;
	}

	int64_t sslreadv(void *buffer, int64_t nbytes, int retry, int *trytimes) override
	{
		int64_t ret = m_base.ssl.readv(buffer, nbytes, retry, trytimes);
		if (ret <= 0)
		{
			const evpl::openssl::ioresult &result = m_base.ssl.get_result();
			m_ioresult.set_ifnoerror(result);
		}
		return ret;
	}

	int64_t sslwritev(const void *buffer, int64_t nbytes, int retry, int *trytimes) override
	{
		int64_t ret = m_base.ssl.writev(buffer, nbytes, retry, trytimes);
		if (ret <= 0)
		{
			const evpl::openssl::ioresult &result = m_base.ssl.get_result();
			m_ioresult.set_ifnoerror(result);
		}
		return ret;
	}

	iocbresult io_callback()
	{
		m_process.doprocess();

		if (m_ioresult.error_raised())
		{
			m_base.err.set_error(https_sslio_fail, m_ioresult.tostring());
			return iocb_error;
		}

		evtl::com::process_nextstep step = m_process.get_nextstep();
		switch (step)
		{
		case evtl::com::nextstep_wait_to_receive:
		case evtl::com::nextstep_wait_to_send:
		case evtl::com::nextstep_continue:
			break;
		case evtl::com::nextstep_done:
			return iocb_done;
		case evtl::com::nextstep_error:
			return iocb_error;
		default:
			assert(false);
			return iocb_error;
		};

		return iocb_continue;
	}

private:
	sessbase       m_base;
	evtl::address  m_addr;

	evtl::simpconnector    m_connector;
	evtl::boolflag<false>  m_connect_started;
	evtl::var<bool>        m_connect_result;

	int  m_fd;
	process          m_process;
	evpl::openssl::ioresult  m_ioresult;
	evtl::var<bool>  m_request_result;
};


} }


#endif

