

#ifndef __EVPL_OPENSSL_SSLCONTEXT_H__
#define __EVPL_OPENSSL_SSLCONTEXT_H__

#include <string>
#include <assert.h>
#include <openssl/ssl.h>

#include "sslerr.h"


namespace evpl { namespace openssl {


class clientsslcontext
{
public:
	clientsslcontext(): m_ctx(nullptr)
	{}

	bool new_context()
	{
		if (m_ctx != nullptr)
			assert(false && "m_ctx exists");

		const SSL_METHOD *meth = TLS_method();
		if (meth == nullptr)
			return false;

		m_ctx = SSL_CTX_new(meth);
		if (m_ctx == nullptr)
			return false;

		//SSL_CTX_set_max_proto_version(m_ctx, TLS1_2_VERSION);

		SSL_CTX_set_mode(m_ctx, SSL_MODE_AUTO_RETRY | SSL_MODE_ENABLE_PARTIAL_WRITE);
		SSL_CTX_set_read_ahead(m_ctx, 1);

		SSL_CTX_set_session_cache_mode(m_ctx, SSL_SESS_CACHE_OFF);
		SSL_CTX_set_verify(m_ctx, SSL_VERIFY_NONE, nullptr);
		return true;
	}

	SSL * new_ssl() const
	{
		if (m_ctx == nullptr)
			assert(false && "null ctx");
		return SSL_new(m_ctx);
	}

	void free()
	{
		if (m_ctx != nullptr)
			SSL_CTX_free(m_ctx);
		m_ctx = nullptr;
	}

private:
	SSL_CTX  *m_ctx;
};

class serversslcontext
{
public:
	serversslcontext(): m_ctx(nullptr)
	{}

	bool new_context(const char *certfile, const char *privkeyfile)
	{
		if (m_ctx != nullptr)
			assert(false && "m_ctx exists");

		const SSL_METHOD *meth = TLS_method();
		if (meth == nullptr)
			return false;

		m_ctx = SSL_CTX_new(meth);
		if (m_ctx == nullptr)
			return false;

		//SSL_CTX_set_max_proto_version(m_ctx, TLS1_2_VERSION);

		SSL_CTX_set_mode(m_ctx, SSL_MODE_AUTO_RETRY | SSL_MODE_ENABLE_PARTIAL_WRITE);
		SSL_CTX_set_read_ahead(m_ctx, 1);

		SSL_CTX_set_session_cache_mode(m_ctx, SSL_SESS_CACHE_OFF);

		int ret = 0;

		//use RSA to debug with wireshark
		//ret = SSL_CTX_set_cipher_list(m_ctx, "RSA");
		//if (ret != 1)
		//{
		//	set_error("SSL_CTX_set_cipher_list failed");
		//	return false;
		//}

		ret = SSL_CTX_use_certificate_chain_file(m_ctx, certfile);
		if (ret != 1)
		{
			set_error(evpl::openssl::sslerr::get_errstr());
			return false;
		}

		ret = SSL_CTX_use_PrivateKey_file(m_ctx, privkeyfile, SSL_FILETYPE_PEM);
		if (ret != 1)
		{
			set_error(evpl::openssl::sslerr::get_errstr());
			return false;
		}

		ret = SSL_CTX_check_private_key(m_ctx);
		if (ret != 1)
		{
			set_error(evpl::openssl::sslerr::get_errstr());
			return false;
		}

		return true;
	}

	SSL * new_ssl() const
	{
		if (m_ctx == nullptr)
			assert(false && "null ctx");
		return SSL_new(m_ctx);
	}

	void free()
	{
		if (m_ctx != nullptr)
			SSL_CTX_free(m_ctx);
		m_ctx = nullptr;
	}

	std::string get_error() const
	{
		return m_error;
	}

private:
	void set_error(const std::string &err)
	{
		m_error = err;
	}

private:
	SSL_CTX  *m_ctx;
	std::string  m_error;
};


} }


#endif

