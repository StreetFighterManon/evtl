
#include <unistd.h>

#include <iostream>
using namespace std;

#include <string>

#include <evtl/evtl_signal.h>
#include <evtl/evtl_watcher_timer.h>
#include <evtl/evtl_eio.h>


class aaa
{
public:
	aaa()
	{}

	void asc()
	{
		void *p = evtl::eio_readm<aaa, &aaa::readc, &aaa::destcb>(6, nullptr, 7, 0, this);
		cout<<p<<endl;
		evtl::eio_writem<aaa, &aaa::resc, &aaa::destcb>(-1, nullptr, 0, 0, this);

		evtl::eio_readf<&readf, &destf>(-1, nullptr, 0, 0, nullptr);
		evtl::eio_writef<&rescf, &destf>(-1, nullptr, 0, 0, nullptr);
	}

	int readc(ssize_t res, char *buf)
	{
		return 0;
	}

	int resc(ssize_t res)
	{
		return 0;
	}

	void destcb(eio_req *)
	{}

	static int readf(ssize_t result, char *buf)
	{
		return 0;
	}

	static int rescf(ssize_t result)
	{
		return 0;
	}

	static void destf(eio_req *req)
	{
	}
};

void timerx(evtl::simpwtimer &t, int revents)
{
	static int n = 0;
	n++;
	cout<<"111 n:"<<n<<endl;
	sleep(3);
	cout<<"222 n:"<<n<<endl;

	t.stop();
	t.set(1. + t.get_loop().now_difference(), 0);
	t.start();
}

int main(int argc,char *argv[])
{
	evtl::simpeventloop<evtl::default_loop>  loop;
	evtl::simpwtimer  timer;
	timer.set(loop.ref(), 1, 0);
	timer.set_callback(std::bind(&timerx, std::placeholders::_1, std::placeholders::_2));
	timer.start();
	loop.run_loop();

	evtl::geio::init();
	evtl::eio_read(-1, nullptr, 0, 0, nullptr, nullptr);
	aaa a;
	a.asc();

	evtl::simpeio  e;
	e.submit_read(-1, nullptr, 0, 0);
	e.submit_write(-1, nullptr, 0, 0);

	evtl::signalc::typical_unblock();
	evtl::signalc::typical_block();

	while (evtl::geio::nreqs() > 0)
		evtl::geio::poll();

	while (true)
		sleep(1);
	return 0;
}


