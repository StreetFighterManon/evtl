

#include <assert.h>

#include <iostream>
using namespace std;

#include <evtl/evtl_signal.h>
#include <evtl/evtl_listener.h>
#include <evtl/evtl_acceptor.h>

#include <openssl/ssl.h>
#include <openssl/err.h>

#include "asc.h"


std::string get_sslerr()
{
	char buffer[256] = { 0 };
	unsigned long e = ERR_get_error();
	ERR_error_string_n(e, buffer, sizeof(buffer));
	buffer[255] = '\0';
	return buffer;
}


int default_passwd_callback(char *buf, int size, int rwflag, void *u)
{
	if (rwflag == 0)
	{
		cout<<"password for reading/decryption, size = "<<size<<endl;
		strncpy(buf, (char *)u, size);
		buf[size - 1] = '\0';
		return strlen(buf);
	}
	else
	{
		cout<<"rwflag = "<<rwflag<<endl;
	}

	return 0;
}


bool load_cert(SSL_CTX *ctx)
{
	int ret = SSL_CTX_use_certificate_file(ctx, "../bin/cert.crt", SSL_FILETYPE_PEM);
	if (ret != 1)
	{
		cout<<"SSL_CTX_use_certificate_file failed, errstr = "<<get_sslerr()<<endl;
		return false;
	}

	ret = SSL_CTX_use_PrivateKey_file(ctx, "../bin/rsa_private.key", SSL_FILETYPE_PEM);
	if (ret != 1)
	{
		cout<<"SSL_CTX_use_PrivateKey_file failed, errstr = "<<get_sslerr()<<endl;
		return false;
	}

	ret = SSL_CTX_check_private_key(ctx);
	if (ret != 1)
	{
		cout<<"SSL_CTX_check_private_key failed, errstr = "<<get_sslerr()<<endl;
		return false;
	}

	return true;
}

bool load_cert1(SSL_CTX *ctx)
{
	int ret = SSL_CTX_use_certificate_chain_file(ctx, "../bin/chain/server_ca_ca1.crt");
	if (ret != 1)
	{
		cout<<"SSL_CTX_use_certificate_file failed, errstr = "<<get_sslerr()<<endl;
		return false;
	}

	//ret = SSL_CTX_build_cert_chain(ctx, SSL_BUILD_CHAIN_FLAG_CHECK);
	//if (ret != 1)
	//{
	//	cout<<"SSL_CTX_build_cert_chain failed, ret = "<<ret<<endl;
		//return false;
	//}

	char passsword[] = "12345";

	SSL_CTX_set_default_passwd_cb(ctx, default_passwd_callback);
	SSL_CTX_set_default_passwd_cb_userdata(ctx, passsword);

	ret = SSL_CTX_use_PrivateKey_file(ctx, "../bin/chain/server.key", SSL_FILETYPE_PEM);
	if (ret != 1)
	{
		cout<<"SSL_CTX_use_PrivateKey_file failed, errstr = "<<get_sslerr()<<endl;
		return false;
	}

	ret = SSL_CTX_check_private_key(ctx);
	if (ret != 1)
	{
		cout<<"SSL_CTX_check_private_key failed, errstr = "<<get_sslerr()<<endl;
		return false;
	}

	//SSL_CTX_set_client_CA_list(ctx, SSL_load_client_CA_file("../bin/chain/ca.crt"));
	//SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, nullptr);

	return true;
}

int sslaccept(SSL *ssl)
{
	while (true)
	{
		int ret = SSL_accept(ssl);
		if (ret != 1)
		{
			int errcode = SSL_get_error(ssl, ret);
			switch (errcode)
			{
			case SSL_ERROR_WANT_READ:
				{
					cout<<"SSL_accept: "<<ret<<" SSL_ERROR_WANT_READ"<<endl;
				}
				break;
			case SSL_ERROR_WANT_WRITE:
				{
					cout<<"SSL_accept: "<<ret<<" SSL_ERROR_WANT_WRITE"<<endl;
				}
				break;
			default:
				{
					if (errcode == SSL_ERROR_SYSCALL)
					{
						int errn = errno;
						cout<<"SSL_accept failed: SSL_ERROR_SYSCALL errno = "<<errn<<", ERR_peek_error() = " << ERR_peek_error()<<endl;
					}
					else if (errcode == SSL_ERROR_ZERO_RETURN)
					{
						cout<<"SSL_accept failed: SSL_ERROR_ZERO_RETURN"<<", ERR_peek_error() = " << ERR_peek_error()<<endl;
					}
					else
					{
						cout<<"SSL_accept failed: "<<errcode<<", ERR_peek_error() = " << ERR_peek_error()<<", sslerr = "<<get_sslerr()<<endl;
					}

					//if (errcode == SSL_ERROR_ZERO_RETURN || ERR_peek_error() == 0)
					//{
					//    说明对端断开了连接或者shutdown了SSL连接，来自nginx
					//}
					return -1;
				}
				break;
			}
		}
		else
		{
			cout<<"SSL_accept success"<<endl;
			break;
		}
		usleep(1000*200);
	}

	return 0;
}


int sslreadonce(SSL *ssl)
{
	char buffer[100] = { 0 };
	int ret = SSL_read(ssl, buffer, 99);
	if (ret > 0)
	{
		cout<<"SSL_read: ret = "<<ret<<", buf = "<<buffer<<endl;
		return 1;
	}
	else
	{
		int errcode = SSL_get_error(ssl, ret);
		switch (errcode)
		{
		case SSL_ERROR_WANT_READ:
			{
				cout<<"SSL_read: ret = "<<ret<<", SSL_ERROR_WANT_READ"<<endl;
			}
			return 0;
		case SSL_ERROR_WANT_WRITE:
			{
				cout<<"SSL_read, ret = "<<ret<<", SSL_ERROR_WANT_WRITE"<<endl;
			}
			return 0;
		default:
			{
				if (errcode == SSL_ERROR_SYSCALL)
				{
					int errn = errno;
					cout<<"11 SSL_read: SSL_ERROR_SYSCALL, errno = "<<errn<<", ERR_peek_error() = " << ERR_peek_error() <<endl;
				}
				else if (errcode == SSL_ERROR_ZERO_RETURN)
				{
					cout<<"11 SSL_read: SSL_ERROR_SYSCALL, ERR_peek_error() = " << ERR_peek_error() <<endl;
				}
				else
				{
					cout<<"11 SSL_read: "<<errcode<<", ERR_peek_error() = "<<ERR_peek_error()<<endl;
				}
				//if (errcode == SSL_ERROR_ZERO_RETURN || ERR_peek_error() == 0)
				//{
				//    说明对端断开了连接或者shutdown了SSL连接，来自nginx
				//}

				return -1;
			}
			break;
		}
	}

	assert(false);
}

int sslwriteonce(SSL *ssl, const char *buf, int len)
{
	int ret = SSL_write(ssl, buf, len);
	if (ret > 0)
	{
		cout<<"SSL_write: ret = "<<ret<<", buf = "<<buf<<endl;
		return 1;
	}
	else
	{
		int errcode = SSL_get_error(ssl, ret);
		switch (errcode)
		{
		case SSL_ERROR_WANT_READ:
			{
				cout<<"SSL_write: ret = "<<ret<<", SSL_ERROR_WANT_READ"<<endl;
			}
			return 0;
		case SSL_ERROR_WANT_WRITE:
			{
				cout<<"SSL_write, ret = "<<ret<<", SSL_ERROR_WANT_WRITE"<<endl;
			}
			return 0;
		default:
			{
				if (errcode == SSL_ERROR_SYSCALL)
				{
					int errn = errno;
					cout<<"SSL_write: SSL_ERROR_SYSCALL, errno = "<<errn<<", sslerr = " << get_sslerr() <<endl;
				}
				else if (errcode == SSL_ERROR_ZERO_RETURN)
				{
					cout<<"SSL_write: SSL_ERROR_SYSCALL, sslerr = " << get_sslerr() <<endl;
				}
				else
				{
					cout<<"SSL_write: "<<errcode<<", sslerr = "<<get_sslerr()<<endl;
				}
				//if (errcode == SSL_ERROR_ZERO_RETURN || ERR_peek_error() == 0)
				//{
				//    说明对端断开了连接或者shutdown了SSL连接，来自nginx
				//}

				return -1;
			}
			break;
		}
	}

	assert(false);
}


int main()
{
	evtl::signalc::sig_ignore(SIGPIPE);

	SSL_library_init();

	const SSL_METHOD *meth = TLS_method();
	SSL_CTX *ctx = SSL_CTX_new(meth);

	SSL_CTX_set_security_level(ctx, 1);

	SSL_CTX_set_mode(ctx, SSL_MODE_AUTO_RETRY|SSL_MODE_ENABLE_PARTIAL_WRITE);
	SSL_CTX_set_read_ahead(ctx, 1);

	if (!load_cert1(ctx))
		return 0;

	evtl::tcp::listener listener;
	listener.set_address("127.0.0.1", 443);
	bool br = listener.listen(12, false);
	if (!br)
	{
		cout<<"listen error"<<endl;
		return 0;
	}

	evtl::tcp::simpacceptor  accp;
	accp.set_listener(listener);

	evtl::connection conn = accp.accept(SOCK_NONBLOCK);
	if (conn.fd < 0)
	{
		cout<<"accept error"<<endl;
		return 0;
	}

	SSL *ssl = SSL_new(ctx);
	if (ssl == nullptr)
	{
		cout << "SSL_new failed, errstr = " << get_sslerr() <<endl;
		return 0;
	}

	int ret = SSL_set_fd(ssl, conn.fd);
	if (ret != 1)
	{
		cout<<"SSL_set_fd failed, errstr = " << get_sslerr() <<endl;
		return 0;
	}

	ret = sslaccept(ssl);
	if (ret != 0)
	{
		cout<<"ssl accept failed"<<endl;
		return 0;
	}

	int i = 0;
	std::string str;
	while (true)
	{
		std::stringstream ss;
		ss << "asc" << i++;
		ss >> str;

		//cout<<"re pend: "<<SSL_renegotiate_pending(ssl)<<endl;

		//if (i == 7)
		//	sslreadonce(ssl);

		ret = sslwriteonce(ssl, str.c_str(), str.size());
		if (ret == -1)
		{
			SSL_shutdown(ssl);
			SSL_free(ssl);
			break;
		}
		sleep(1);
	}

	close(conn.fd);

	return 0;
}


