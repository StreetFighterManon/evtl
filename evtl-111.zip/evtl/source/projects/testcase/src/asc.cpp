
#include <poll.h>
#include <cstring>

#include <iostream>
using namespace std;

#include <evtl/evtl_time.h>

#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_dlgtlinbuf.h>
#include <evtl/evtl_ringbuf.h>
#include <evtl/evtl_dlgtringbuf.h>

#include <evtl/evtl_random.h>

#include <evpl/hiredis/async_hiredis.h>
#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_tcpconnector.h>
#include <evtl/evtl_socket.h>
#include <evtl/evtl_acceptor.h>
#include <evtl/evtl_listener.h>
#include <evtl/evtl_thread.h>


class buftest
{
public:
	buftest(): resource(1024), ring(1024)
	{}

	void init()
	{
		char s[256];
		for (int i = 0; i < 256; i++)
			s[i] = (char)i;

		while (!resource.full())
		{
			resource.append(s, sizeof(s));
		}

		a = new char[1024];
		dlin.set_buffer(a, 1024);
		b = new char[1024 + 1];
		dring.set_buffer(b, 1024 + 1);
	}

	void deinit()
	{
		delete []a;
		delete []b;
	}

	void test()
	{
		test_assign();
		test_storewhole();
		test_acc();
	}

	void test2()
	{
		test_assign();
		test_storewhole();
		test_acc2();
	}

private:
	void test_assign()
	{
		evtl::linearbuf<char>  a = resource;
		evtl::linearbuf<char>  b;
		b = resource;

		evtl::linearbuf<unsigned char> a_copy = a.min_clone<unsigned char>();
		evtl::linearbuf<unsigned char> b_copy = b.min_clone<unsigned char>();

		assert(a_copy.size() == b_copy.size());
		int n = ::memcmp(a_copy.dataptr(), b_copy.dataptr(), a_copy.size());
		assert(n == 0);
	}

	void test_storewhole()
	{
		int n = 100;

		dlin.store_whole(resource);
		assert(dlin.size() == resource.size());
		n = ::memcmp(dlin.dataptr(), resource.dataptr(), resource.size());
		assert(n == 0);

		dring.store_whole(resource);
		assert(dring.headsize() == resource.size());
		n = ::memcmp(dring.dataptr(), resource.dataptr(), resource.size());
		assert(n == 0);

		dlin.store_whole(dring);
		dring.store_whole(dlin);
		assert(dlin.size() == resource.size());
		n = ::memcmp(dlin.dataptr(), resource.dataptr(), resource.size());
		assert(n == 0);

		assert(dring.headsize() == resource.size());
		n = ::memcmp(dring.dataptr(), resource.dataptr(), resource.size());
		assert(n == 0);

	}

	void test_acc()
	{
		evtl::linearbuf<char> back(resource);
		dlin.clear();
		dring.clear();
		ring.clear();

		int64_t starttime = evtl::timec::msec();

		int n;
		int64_t total = 0;
		while (true)
		{
			ssize_t n1 = evtl::rand::urandom::ui64()%(62);
			ssize_t n2 = evtl::rand::urandom::ui64()%(62);
			ssize_t n3 = evtl::rand::urandom::ui64()%(62);
			ssize_t n4 = evtl::rand::urandom::ui64()%(62);

			if ((n1%3) > 0)
				dlin.eat(resource, n1, true);
			else
				dlin.eat_whole(resource, true);

			if ((n2%3) > 0)
				dring.eat(dlin, n2);
			else
				dring.eat_whole(dlin);

			if ((n3%10) < 7)
				ring.eat(dring, n3);
			else
				ring.eat_whole(dring);

			if ((n4%8) < 6)
				total += resource.eat(ring, n4, true);
			else
			{
				ssize_t ssz = ring.size();
				bool br = resource.eat_whole(ring, true);
				if (br)
					total += ssz;
			}

			if (evtl::timec::fast_msec() - starttime > 2000)
			{
				cout << "30s: " << resource.size() << " " << dlin.size() << " " << dring.size() << " " << ring.size() << endl;
				break;
			}
		}

		while (true)
		{
			dring.eat(dlin);
			ring.eat(dring);
			total += resource.eat(ring, 0, true);
			if (resource.full())
			{
				assert(dlin.empty());
				assert(dring.empty());
				assert(ring.empty());
				cout<<"full"<<endl;
				break;
			}
		}

		cout<<"test total: " << total<< endl;

		int64_t aftern = total%(1024);
		int64_t beforen = 1024 - aftern;

		evtl::linearbuf<char> tmp(beforen);
		tmp.eat(resource, 0, true);
		resource.crowd();
		resource.eat(tmp, 0, true);

		assert(resource.full());
		assert(resource.size() == back.size());
		n = ::memcmp(resource.dataptr(), back.dataptr(), resource.size());
		assert(n == 0);
	}

	void test_acc2()
	{
		evtl::linearbuf<char> back(resource);
		dlin.clear();
		dring.clear();
		ring.clear();

		int64_t starttime = evtl::timec::msec();

		int n;
		int64_t total = 0;
		while (true)
		{
			ssize_t n1 = evtl::rand::urandom::ui64()%(61);
			ssize_t n2 = evtl::rand::urandom::ui64()%(61);
			ssize_t n3 = evtl::rand::urandom::ui64()%(61);
			ssize_t n4 = evtl::rand::urandom::ui64()%(61);

			if ((n1%3) > 0)
				dring.eat(resource, n1);
			else
				dring.eat_whole(resource);

			if ((n2%3) > 0)
				dlin.eat(dring, n2);
			else
				dlin.eat_whole(dring, true);

			if ((n3%10) < 7)
				ring.eat(dlin, n3);
			else
				ring.eat_whole(dlin);

			if ((n4%8) < 6)
				total += resource.eat(ring, n4, true);
			else
			{
				ssize_t ssz = ring.size();
				bool br = resource.eat_whole(ring, true);
				if (br)
					total += ssz;
			}

			if (evtl::timec::fast_msec() - starttime > 2000)
			{
				cout << "30s: " << resource.size() << " " << dlin.size() << " " << dring.size() << " " << ring.size() << endl;
				break;
			}
		}

		while (true)
		{
			dlin.eat(dring, 0, true);
			ring.eat(dlin);
			total += resource.eat(ring, 0, true);
			if (resource.full())
			{
				assert(dlin.empty());
				assert(dring.empty());
				assert(ring.empty());
				cout<<"full"<<endl;
				break;
			}
		}

		cout<<"test2 total: " << total<< endl;

		int64_t aftern = total%(1024);
		int64_t beforen = 1024 - aftern;

		evtl::linearbuf<char> tmp(beforen);
		tmp.eat(resource, 0, true);
		resource.crowd();
		resource.eat(tmp, 0, true);

		assert(resource.full());
		assert(resource.size() == back.size());
		n = ::memcmp(resource.dataptr(), back.dataptr(), resource.size());
		assert(n == 0);
	}

private:
	char *a;
	char *b;

	evtl::linearbuf<char>  resource;
	evtl::dlgtlinbuf<char>  dlin;
	evtl::dlgtringbuf<char>  dring;
	evtl::ringbuf<char>  ring;
};


class asyncredis : public evpl::hiredis::async_session<asyncredis>
{
public:
	void connect_callback(const asyncredis &session, int status, const std::string &errstr)
	{}

	void disconnect_callback(const asyncredis &session, int status)
	{}
};


void acc_callback(evtl::tcp::simpacceptor &acceptor, std::vector<evtl::tcp::connection> &connections)
{
	int fd = connections[0].fd;
	sleep(1);

	const char *p = "HTTP/1.0 200 OK\r\n"
		"Content-Type: text/html; charset=utf-8\r\n"
		"Content-Length: 2\r\n"
		"Server: Werkzeug/1.0.1 Python/3.8.2\r\n"
		"Date: Sun, 06 Sep 2020 03:34:49 GMT\r\n"
		"Connection: keep-alive\r\n"
		"\r\n"
		"ok";

	::write(fd, p, strlen(p));
}


void * meth(void *)
{
	cout<<"kasmc"<<endl;
	while (true)
		sleep(1);
}


void asc()
{
	evtl::thread::make_detached(&meth, nullptr, 50*1024*1024);
	while (true)
		sleep(1);
}


int main(int argc, char** argv)
{
	asc();
	return 0;

	evtl::timec::background_update();

	while (true)
	{
		buftest ss;
		ss.init();
		ss.test();
		ss.deinit();

		buftest ss2;
		ss2.init();
		ss2.test2();
		ss2.deinit();
	}
	return 0;
}



