

#include <iostream>
using namespace std;
#include <fstream>

#include <evpl/util/utility.h>
#include <evtl/evtl_pcre2.h>

std::string readFile(const std::string& filePath) {  
    std::ifstream file(filePath, std::ios::in | std::ios::binary);  
    if (!file) {  
        // 如果文件打开失败，返回空字符串  
		cout<<"read file failed: "<<filePath<<endl;
        return "";  
    }  
  
    std::ostringstream buffer;  
    buffer << file.rdbuf(); // 读取文件内容到buffer  
  
    return buffer.str(); // 将buffer转换为std::string并返回  
}

bool replace(std::vector<std::string> &lines)
{
	bool ret = false;

	evtl::pcre2_8::regex   reg(R"(ils_\w+?\((?:con->log|ils->log|p_log), *"(?:\[ils_qam\])?\[(usertrace-%(?:" *PRId64 *"|d))\].*?", *(con->traceinfo.m_da|con->asset->da|asset->da|con->rtsp\.da|query_asset\.da|pUrlDecoder->nDA|decoder\.nDA|s1_ctx->rtsp.da|context->s1_context->rtsp.da))");

	auto f = [](const evtl::pcre2_8::match_results<char> &m, int32_t index) -> std::string
	{
		if (index == 1)
			return "sessionid-%s";
		if (index == 2)
		{
			if (m[2].equal("s1_ctx->rtsp.da"))
				return "s1_ctx->traceinfo.m_rtsp_sessionid.c_str()";
			else if (m[2].equal("context->s1_context->rtsp.da"))
				return "context->s1_context->traceinfo.m_rtsp_sessionid.c_str()";
			else
				return "con->traceinfo.m_rtsp_sessionid.c_str()";
		}

		assert(false);
	};

	std::set<int32_t, std::less<int32_t>>  rep;
	rep.insert(1);
	rep.insert(2);

	for (auto iter = lines.begin(); iter != lines.end(); ++iter)
	{
		std::string &s = *iter;
		std::string rs = evtl::pcre2_8::regex_replace_func(s, reg, rep, f, 1);
		if (rs != s)
		{
			s = rs;
			ret = true;
		}
	}

	return ret;
}

void replace2(std::vector<std::string> &lines)
{
	evtl::pcre2_8::regex   reg(R"(ils_\w+?\((?:con->log|ils->log|p_log), *"\[sessionid-%s\] *(sessionid: %s, *).*?con->traceinfo.m_rtsp_sessionid.c_str.*?(con->traceinfo.m_rtsp_sessionid.c_str\(\), *))");

	auto f = [](const evtl::pcre2_8::match_results<char> &m, int32_t index) -> std::string
	{
		if (index == 1)
			return "";
		if (index == 2)
		{
			return "";
		}

		assert(false);
	};

	std::set<int32_t, std::less<int32_t>>  rep;
	rep.insert(1);
	rep.insert(2);

	for (auto iter = lines.begin(); iter != lines.end(); ++iter)
	{
		std::string &s = *iter;
		std::string rs = evtl::pcre2_8::regex_replace_func(s, reg, rep, f, 1);
		if (rs != s)
		{
			s = rs;
		}
	}
}

bool replace3(std::vector<std::string> &lines)
{
	bool ret = false;

	evtl::pcre2_8::regex   reg(R"(ils_\w+?\((?:con->log|ils->log|p_log), *"(?:\[ils_qam\])?\[(usertrace-%(?:" *PRId64 *"|d))\])");
	evtl::pcre2_8::regex   reg2(R"(\s*(con->traceinfo.m_da|con->asset->da|asset->da|con->rtsp\.da|query_asset.da|pUrlDecoder->nDA|decoder\.nDA|s1_ctx->rtsp\.da|context->s1_context->rtsp.da))");

	auto f = [](const evtl::pcre2_8::match_results<char> &m, int32_t index) -> std::string
	{
		if (index == 1)
			return "sessionid-%s";

		assert(false);
	};

	auto f2 = [](const evtl::pcre2_8::match_results<char> &m, int32_t index) -> std::string
	{
		if (index == 1)
		{
			if (m[1].equal("s1_ctx->rtsp.da"))
				return "s1_ctx->traceinfo.m_rtsp_sessionid.c_str()";
			else if (m[1].equal("context->s1_context->rtsp.da"))
				return "context->s1_context->traceinfo.m_rtsp_sessionid.c_str()";
			else
				return "con->traceinfo.m_rtsp_sessionid.c_str()";
		}

		assert(false);
	};

	std::set<int32_t, std::less<int32_t>>  rep;
	rep.insert(1);

	for (size_t i = 0; i < lines.size() - 1; i++)
	{
		std::string &s = lines[i];
		std::string &s1 = lines[i+1];

		if (evtl::pcre2_8::regex_search(s, reg) && s.find(';') == std::string::npos && evtl::pcre2_8::regex_search(s1, reg2))
		{
			std::string rs = evtl::pcre2_8::regex_replace_func(s, reg, rep, f, 1);
			if (rs != s)
			{
				ret = true;
				s = rs;
			}

			rs = evtl::pcre2_8::regex_replace_func(s1, reg2, rep, f2, 1);
			if (rs != s1)
			{
				ret = true;
				s1 = rs;
			}
		}
	}

	return ret;
}

void replace4(std::vector<std::string> &lines)
{
	evtl::pcre2_8::regex   reg(R"(ils_\w+?\((?:con->log|ils->log|p_log), *"\[sessionid-%s\] *(sessionid: *%s, *))");
	evtl::pcre2_8::regex   reg2(R"(\s*con->traceinfo.m_rtsp_sessionid.c_str.*?(con->traceinfo.m_rtsp_sessionid.c_str\(\) *, *))");

	auto f = [](const evtl::pcre2_8::match_results<char> &m, int32_t index) -> std::string
	{
		if (index == 1)
			return "";

		assert(false);
	};

	auto f2 = [](const evtl::pcre2_8::match_results<char> &m, int32_t index) -> std::string
	{
		if (index == 1)
			return "";

		assert(false);
	};

	std::set<int32_t, std::less<int32_t>>  rep;
	rep.insert(1);

	for (size_t i = 0; i < lines.size() - 1; i++)
	{
		std::string &s = lines[i];
		std::string &s1 = lines[i+1];

		if (evtl::pcre2_8::regex_search(s, reg) && s.find(';') == std::string::npos && evtl::pcre2_8::regex_search(s1, reg2))
		{
			std::string rs = evtl::pcre2_8::regex_replace_func(s, reg, rep, f, 1);
			if (rs != s)
			{
				s = rs;
			}

			rs = evtl::pcre2_8::regex_replace_func(s1, reg2, rep, f2, 1);
			if (rs != s1)
			{
				s1 = rs;
			}
		}
	}
}

void writefile(std::vector<std::string> &lines, const char *name)
{
    // 创建一个字符串流，用于拼接所有行  
    std::ostringstream oss;  
  
    // 遍历每一行  
    for (const auto &line : lines) {  
        // 在每行末尾添加\r\n  
        oss << line << "\r\n";  
    }  
  
    // 将拼接后的字符串流转换为std::string  
    std::string content = oss.str();  
  
    // 打开文件，准备写入  
    std::ofstream file(name);  
  
    // 检查文件是否成功打开  
    if (!file.is_open()) {  
        std::cerr << "无法打开文件: " << name << std::endl;  
        return;  
    }  
  
    // 写入内容到文件  
    file << content;  
  
    // 关闭文件  
    file.close();  
}


int main(int argc, char* argv[])
{
	if (argc < 2)
	{
		cout<<"error"<<endl;
		return 0;
	}
	const char *name = argv[1];
	cout<<"name: "<<name<<endl;

	std::string text = readFile(name);
	
	std::vector<std::string>  lines;
	evpl::util::extractlines(text, lines);

	bool br = replace(lines);
	bool br2 = replace3(lines);
	if (!br && !br2)
		return 0;

	replace2(lines);
	replace4(lines);
	
	writefile(lines, name);

	return 0;
}


