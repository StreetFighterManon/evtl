

#include <sys/types.h>
#include <unistd.h>
#include <errno.h>

#include <iostream>
using namespace std;

#include <iomanip>

#include <functional>
#include <unordered_set>
#include <string>
#include <cstdint>
#include <memory>


#include <ev/ev++.h>

#include <evtl/evtl_eventloop.h>
#include <evtl/evtl_listener.h>
#include <evtl/evtl_acceptor.h>
#include <evtl/evtl_watcher_io.h>
#include <evtl/evtl_watcher_timer.h>
#include <evtl/evtl_watcher_async.h>
#include <evtl/evtl_tcpconnector.h>
#include <evtl/evtl_signal.h>
#include <evtl/evtl_threadpool.h>
#include <evtl/evtl_uuid.h>
#include <evtl/evtl_container.h>
#include <evtl/evtl_lock.h>
#include <evtl/evtl_gcc.h>
#include <evtl/evtl_wrapper.h>
#include <evtl/evtl_pcre2.h>
#include <evtl/evtl_wasyncs.h>
#include <evtl/evtl_itc.h>
#include <evtl/evtl_linearbuf.h>
#include <evtl/evtl_ringbuf.h>
#include <evtl/evtl_random.h>


template <class T = evtl::default_loop>
class ascloop : public evtl::eventloop<ascloop<T>, T>
{};

class ascacceptor : public evtl::tcp::acceptor<ascacceptor>
{};

class asctimer : public evtl::watcher_timer<asctimer>
{};

class ascasync : public evtl::watcher_async<ascasync>
{};

class asctcpconnector : public evtl::tcp::tcpconnector<asctcpconnector>
{};

struct if_ftask
{
	virtual void run(void *arg) = 0;
};

struct if_control
{
	virtual void circle_begin(void *arg, int64_t id) = 0;

	virtual void circle_accompany(void *arg, int64_t id, if_ftask * const &ptask) = 0;

	virtual void circle_end(void *arg, int64_t id, int64_t taskcount, int64_t consumed_us) = 0;
};

enum interrupt_event
{
	intev_unknown,
	intev_syn_ack,
	intev_fin
};

typedef std::function<void (int event, void *key, const std::string &id)>   interrupt_t;

struct interrupt_detail
{
	interrupt_detail(): event(intev_unknown), key(nullptr)
	{}

	interrupt_detail(int _event, void *_key, const std::string &_id)
		: event(_event), key(_key), id(_id)
	{}

	int          event;
	void        *key;
	std::string  id;
};

struct file_conveyer_belt
{
	file_conveyer_belt()
		: localkey(nullptr),
		fin(false),
		syn_ack(false),
		remotekey(nullptr),
		remote_fin(false),
		received_size(0),
		receive_buffer(1024*64)
	{
		mtx.init();
		cout<<"conveyer construct:"<<this<<endl;
	}

	~file_conveyer_belt()
	{
		mtx.deinit();
		cout<<"conveyer deconstruct:"<<this<<endl;
	}

	void interrupt_local(int event)
	{
		if (localintr)
			localintr(event, localkey, id);
	}

	void interrupt_remote(int event)
	{
		if (remoteintr)
			remoteintr(event, remotekey, id);
	}

	ssize_t move_in(evtl::linearbuf<char> &inbuf, ssize_t maxbytes)
	{
		evtl::lock::lockguard<evtl::lock::mutex_lock> lg(mtx);
		ssize_t r = receive_buffer.eat(inbuf, maxbytes, true, 1024*12);
		received_size += r;
		return r;
	}

	ssize_t move_out(evtl::linearbuf<char> &outbuf)
	{
		evtl::lock::lockguard<evtl::lock::mutex_lock> lg(mtx);
		return outbuf.eat(receive_buffer, 0, true, 1024*12);
	}

	std::string           id;

	void *                localkey;
	interrupt_t           localintr;
	bool                  fin;

	bool                  syn_ack;
	void *                remotekey;
	interrupt_t           remoteintr;
	bool                  remote_fin;

	std::string           filename;

	evtl::st_var<bool, true>     file_exist;
	evtl::st_var<int64_t, true>  total_size;

	evtl::lock::mutex_lock    mtx;
	int64_t                  received_size;
	evtl::linearbuf<char>    receive_buffer;
};

class synasync : public evtl::watcher_async<synasync>
{
public:
	synasync()
	{}

	void init()
	{
		m_lock.init();
	}

	void pushback(std::shared_ptr<file_conveyer_belt> ptr)
	{
		evtl::lock::lockguard<evtl::lock::atomic_lock>  lg(m_lock);
		m_syn_list.pushback(ptr);
	}

	bool popfront(std::shared_ptr<file_conveyer_belt> &ptr)
	{
		evtl::lock::lockguard<evtl::lock::atomic_lock>  lg(m_lock);
		return m_syn_list.popfront(ptr);
	}

	int size()
	{
		evtl::lock::lockguard<evtl::lock::atomic_lock>  lg(m_lock);
		return (int)m_syn_list.size();
	}

	bool empty()
	{
		evtl::lock::lockguard<evtl::lock::atomic_lock>  lg(m_lock);
		return m_syn_list.size();
	}

private:
	evtl::listc<std::shared_ptr<file_conveyer_belt>>  m_syn_list;
	evtl::lock::atomic_lock                           m_lock;
};

class interrupt_async : public evtl::watcher_async<interrupt_async>
{
public:
	interrupt_async()
	{}

	void init()
	{
		m_lock.init();
	}

	void pushback(const interrupt_detail &det)
	{
		evtl::lock::lockguard<evtl::lock::atomic_lock> lg(m_lock);
		m_interrupt_details.pushback(det);
	}

	bool popfront(interrupt_detail &det)
	{
		evtl::lock::lockguard<evtl::lock::atomic_lock> lg(m_lock);
		return m_interrupt_details.popfront(det);
	}

	bool empty()
	{
		evtl::lock::lockguard<evtl::lock::atomic_lock> lg(m_lock);
		return m_interrupt_details.empty();
	}

private:
	evtl::listc<interrupt_detail>   m_interrupt_details;
	evtl::lock::atomic_lock         m_lock;
};

class interrupt_event_async : public evtl::watcher_async<interrupt_event_async>
{
public:
	interrupt_event_async()
	{}

	void init()
	{
		m_lock.init();
	}

	void pushback(int event)
	{
		evtl::lock::lockguard<evtl::lock::atomic_lock> lg(m_lock);
		m_interrupt_events.pushback(event);
	}

	bool popfront(int &event)
	{
		evtl::lock::lockguard<evtl::lock::atomic_lock> lg(m_lock);
		return m_interrupt_events.popfront(event);
	}

	bool empty()
	{
		evtl::lock::lockguard<evtl::lock::atomic_lock> lg(m_lock);
		return m_interrupt_events.empty();
	}

private:
	evtl::dequec<int>         m_interrupt_events;
	evtl::lock::atomic_lock   m_lock;
};

class loopio_async : public evtl::watcher_async<loopio_async>
{
public:
	loopio_async(): m_events(0)
	{}

	void set_io_events(int events)
	{
		m_events = events & (ev::READ | ev::WRITE);
	}

	int get_io_events() const
	{
		return m_events & (ev::READ | ev::WRITE);
	}

private:
	int m_events;
};

class fproxy_process
{
public:
	enum process_result
	{
		process_unknown,

		wait_to_recive_pool,
		process_continue,
		process_done,
		process_error
	};

	fproxy_process(): m_result(process_unknown), m_recvbuf(1024*64)
	{}

	void set_conveyer_belt(std::shared_ptr<file_conveyer_belt> ptr)
	{
		m_conveyer = ptr;
	}

	evtl::linearbuf<char>& recvbuf()
	{
		return m_recvbuf;
	}

	void process()
	{
		if (std::shared_ptr<file_conveyer_belt> ptr = m_conveyer.lock())
		{
			if (!ptr->file_exist.isset())
			{
				search_file_info();
			}
			else
			{
				if (ptr->file_exist.refer())
				{
					if (!ptr->total_size.isset())
					{
						assert(false && "file size unknown");
						return;
					}

					receive_file_data();
				}
			}

			if (file_receive_done())
				set_result(process_done);
			else
			{
				if (!m_recvbuf.empty())
					set_result(process_continue);
				else
					set_result(wait_to_recive_pool);
			}
		}
		else
		{
			assert(false && "null shared ptr");
		}
	}

	process_result get_result() const
	{
		return m_result;
	}

private:
	void set_result(process_result result)
	{
		m_result = result;
	}

	bool search_file_info()
	{
		std::shared_ptr<file_conveyer_belt> ptr = m_conveyer.lock();
		if (!ptr)
			return false;

		ssize_t pos = m_recvbuf.finds("\r\n\r\n", 4);
		if (pos >= 0)
		{
			try
			{
				evtl::pcre2_8::regex regrs(R"(HTTP/1\.1 +200 +OK)");
				evtl::pcre2_8::regex reg(R"([Cc]ontent-[Ll]ength *: *(\d+)\r\n)");
				evtl::pcre2_8::match_results<char> matchs;

				bool br = evtl::pcre2_8::regex_search(m_recvbuf.dataptr(), m_recvbuf.dataptr() + pos + 4, regrs);
				if (!br)
				{
					ptr->file_exist.set_assign(false);
					return true;
				}

				br = evtl::pcre2_8::regex_search(m_recvbuf.dataptr(), m_recvbuf.dataptr() + pos + 4, matchs, reg);
				if (br)
				{
					if (matchs.size() != 2)
						assert(false && "bad matches");

					if (matchs[1].matched)
					{
						cout<<"content-length: "<<matchs[1].str()<<endl;

						int64_t fsize = 0;

						std::stringstream ss;
						ss << matchs[1].str();
						ss >> fsize;

						ptr->file_exist.set_assign(true);
						ptr->total_size.set_assign(fsize);
						ptr->received_size = 0;
						m_recvbuf.shit(pos + 4);
						return true;
					}
				}
			}
			catch (std::exception &e)
			{
				cout<<"pcre exception: "<<e.what()<<endl;
			}

			ptr->file_exist.set_assign(false);
			return true;
		}
		return false;
	}

	void receive_file_data()
	{
		if (std::shared_ptr<file_conveyer_belt> ptr = m_conveyer.lock())
		{
			if (ptr->received_size < ptr->total_size)
			{
				ptr->move_in(m_recvbuf, ptr->total_size - ptr->received_size);
			}
		}
	}

	bool file_receive_done()
	{
		if (std::shared_ptr<file_conveyer_belt> ptr = m_conveyer.lock())
		{
			if (ptr->file_exist.isset())
			{
				if (!ptr->file_exist.refer())
					return true;
				else
				{
					if (ptr->received_size >= ptr->total_size)
						return true;
				}
			}
		}

		return false;
	}

private:
	process_result   m_result;

	evtl::linearbuf<char>    m_recvbuf;
	std::weak_ptr<file_conveyer_belt>   m_conveyer;
};

class file_session : public evtl::watcher_io<file_session>, public if_ftask
{
public:
	typedef std::function<void (file_session *psess)>  recycle_callback_t;
	typedef std::function<void (file_session *psess)>  pool_add_callback_t;
	typedef std::function<void (file_session *psess)>  pool_remove_callback_t;

	enum io_control_e
	{
		iocontrol_unknown,
		iocontrol_loop,
		iocontrol_pool
	};

	file_session(): m_inpool(false), m_iocontrol(iocontrol_unknown)
	{}

	virtual ~file_session()
	{}

	void set_conveyer_belt(std::shared_ptr<file_conveyer_belt> ptr)
	{
		m_conveyer_belt = ptr;
	}

	void set_callback_recycle(recycle_callback_t cb)
	{
		m_recycle_cb = cb;
	}

	void set_callback_pool(pool_add_callback_t addcb, pool_remove_callback_t removecb)
	{
		m_pooladd_cb    = addcb;
		m_poolremove_cb = removecb;
	}

	void set_loop(ascloop<evtl::dynamic_loop> &loop)
	{
		m_ploop = &loop;
	}

	void init_watchers()
	{
		m_intr_async.init();
		m_intr_async.set(m_ploop->ref());
		m_intr_async.set_callback(std::bind(&file_session::intr_async_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_intr_async.start();

		m_loopio_async.set(m_ploop->ref());
		m_loopio_async.set_callback(std::bind(&file_session::loopio_async_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_loopio_async.start();

		m_recycle_async.set(m_ploop->ref());
		m_recycle_async.set_callback(std::bind(&file_session::recycle_async_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_recycle_async.start();
	}

	void async_connect(const std::string &ip, int port)
	{
		m_connector.set_loop(m_ploop->ref());
		m_connector.set_callback(std::bind(&file_session::connect_callback, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3));
		m_connector.async_connect(ip, port);
	}

	std::string conveyer_id() const
	{
		return m_conveyer_belt->id;
	}

	void async_interrupt(int event)
	{
		m_intr_async.pushback(event);
		gcc_thread_fence;
		m_intr_async.send();
	}

	void io_callback(file_session &watcher, int revents)
	{
		if ((revents & ev::ERROR) != 0)
			assert(false && "ev::ERROR");
		if (&watcher != this)
			assert(false && "unexpected watcher");
		if ((revents & ev::READ) != 0)
			assert(false && "ev::READ");
		if (get_iocontrol() != iocontrol_loop)
			assert(false && "not loop control");

		if ((revents & ev::WRITE) != 0)
		{
			if (!m_request_buf.empty())
			{
				ssize_t w = watcher.write(m_request_buf.dataptr(), m_request_buf.size());
				if (w > 0)
				{
					if (w > m_request_buf.size())
						assert(false && "write overflow");
					if (m_request_buf.shit(w) != w)
						assert(false && "shit failed");
				}
				else if (w < 0)
				{
					if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
					{
						watcher.stop();
						m_conveyer_belt->remote_fin = true;
						m_conveyer_belt->interrupt_local(intev_fin);
						m_recycle_cb(this);
						return;
					}
				}
				else
				{
					assert(false && "write zero, unbelivable");
				}
			}
		}

		if (!m_request_buf.empty())
		{
			if (watcher.get_events() != ev::WRITE)
			{
				watcher.stop();
				watcher.set_events(ev::WRITE);
				watcher.start();
			}
		}
		else
		{
			watcher.stop();
			turn_pool_io();
			return;
		}
	}

	void run(void *arg)
	{
		if (get_iocontrol() != iocontrol_pool)
			return;

		if (m_told_to_close)
		{
			cout<<"file_session been told close"<<endl;
			async_recycle();
			return;
		}

		m_process.process();
		fproxy_process::process_result result = m_process.get_result();

		evtl::linearbuf<char> &recvbuf = m_process.recvbuf();

		if (result == fproxy_process::wait_to_recive_pool)
		{
			recvbuf.crowd(1024*4);
			if (recvbuf.headspace() > 0)
			{
				ssize_t r = this->read(recvbuf.headptr(), recvbuf.headspace());
				if (r > 0)
				{
					if (r > recvbuf.headspace())
						assert(false && "read overflow");

					if (!recvbuf.head_eaten(r))
						assert(false && "eaten failed");
				}
				else if (r < 0)
				{
					if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
					{
						//recycle
						m_conveyer_belt->remote_fin = true;
						m_conveyer_belt->interrupt_local(intev_fin);
						async_recycle();
						return;
					}
				}
				else
				{
					//recycle
					m_conveyer_belt->remote_fin = true;
					m_conveyer_belt->interrupt_local(intev_fin);
					async_recycle();
					return;
				}
			}

			return;
		}

		if (result == fproxy_process::process_continue)
		{
			return;
		}

		if (result == fproxy_process::process_done)
		{
			//recycle
			m_conveyer_belt->remote_fin = true;
			m_conveyer_belt->interrupt_local(intev_fin);
			async_recycle();
			return;
		}

		assert(false && result && "bad process result");
	}

	io_control_e get_iocontrol() const
	{
		return m_iocontrol.load();
	}

	void set_iocontrol(io_control_e ctrl)
	{
		m_iocontrol.store(ctrl);
	}

	bool is_inpool() const
	{
		return m_inpool;
	}

	void set_inpool(bool in)
	{
		m_inpool = in;
	}

	void deinit()
	{
		m_intr_async.stop();
		m_loopio_async.stop();
		m_recycle_async.stop();
		this->stop_close();
		m_connector.stop_close();
	}

private:
	void turn_pool_io()
	{
		if (!is_inpool())
		{
			m_pooladd_cb(this);
			set_inpool(true);
		}
		set_iocontrol(iocontrol_pool);
	}

	void async_turn_loop_io(int event)
	{
		set_iocontrol(iocontrol_loop);
		m_loopio_async.set_io_events(event);
		gcc_thread_fence;
		m_loopio_async.send();
	}

	void async_recycle()
	{
		set_iocontrol(iocontrol_loop);
		gcc_thread_fence;
		m_recycle_async.send();
	}

private:
	void connect_callback(asctcpconnector &connector, int errcode, int errnocode)
	{
		if (&connector != &m_connector)
			assert(false && "unexpected connector");
		if (m_ploop == nullptr)
			assert(false && "null loop");

		if (errcode == asctcpconnector::success)
		{
			if (connector.get_fd() == -1)
				assert(false && "bad fd");

			std::stringstream ss;
			ss << "GET " << m_conveyer_belt->filename << " HTTP/1.1\r\n"
				<< "Content-Length: 0\r\n"
				<< "Connection: close\r\n"
				<< "\r\n";

			m_request_buf.extens_store_whole(ss.str());
			m_process.set_conveyer_belt(m_conveyer_belt);

			this->set_iocontrol(iocontrol_loop);
			this->set(m_ploop->ref());
			this->set_callback();
			this->set(connector.get_fd(), ev::WRITE);
			this->start();
			connector.only_reset();
		}
		else
		{
			cout<<"connect 1234 failed, errcode = "<<errcode<<", errnocode = "<<errnocode<<endl;

			if (connector.get_fd() != -1)
				assert(false && "fd not destroy");

			m_conveyer_belt->file_exist.set_assign(false);
			m_conveyer_belt->remote_fin = true;
			m_conveyer_belt->interrupt_local(intev_fin);

			m_recycle_cb(this);
			return;
		}
	}

	void intr_async_callback(interrupt_event_async &watcher, int revents)
	{
		if (&watcher != &m_intr_async)
			assert(false && "bad watcher");

		int event = intev_unknown;
		if (!m_intr_async.popfront(event))
			return;

		if (event == intev_fin)
		{
			if (get_iocontrol() == iocontrol_loop)
				m_recycle_cb(this);
			else
				m_told_to_close = true;
			return;
		}
		else
		{
			assert(false && "unknown interrupt event");
		}

		watcher.send();
	}

	void loopio_async_callback(loopio_async &watcher, int revents)
	{
		if ((revents & ev::ERROR) != 0)
			assert(false && "ev error");
		if (&watcher != &m_loopio_async)
			assert(false && "unexpected watcher");
		if (m_iocontrol.load() != iocontrol_loop)
			assert(false && "not loop ctrl");
		if (watcher.is_active())
			assert(false && "active watchers");

		if (m_told_to_close)
		{
			cout<<"file_session been told close - 2"<<endl;
			m_recycle_cb(this);
			return;
		}

		this->set_events(watcher.get_io_events());
		this->start();
	}

	void recycle_async_callback(ascasync &watcher, int revents)
	{
		if (&watcher != &m_recycle_async)
			assert(false && "unexpected watcher");

		m_recycle_cb(this);
	}

private:
	ascloop<evtl::dynamic_loop>   *m_ploop;
	interrupt_event_async        m_intr_async;
	loopio_async                 m_loopio_async;
	ascasync                     m_recycle_async;

	recycle_callback_t      m_recycle_cb;
	pool_add_callback_t     m_pooladd_cb;
	pool_remove_callback_t  m_poolremove_cb;

	bool                          m_inpool;
	std::atomic<io_control_e>     m_iocontrol;

	asctcpconnector    m_connector;
	std::shared_ptr<file_conveyer_belt>   m_conveyer_belt;

	evtl::linearbuf<char>  m_request_buf;
	fproxy_process         m_process;

	evtl::boolflag<false, true>    m_told_to_close;
};

class fproxy_control : public if_control
{
public:
	void circle_begin(void *arg, int64_t id)
	{
	}

	void circle_accompany(void *arg, int64_t id, if_ftask * const &ptask)
	{
	}

	void circle_end(void *arg, int64_t id, int64_t taskcount, int64_t consumed_us)
	{
		usleep(2000);
	}
};

class fileproxyloop
{
public:
	fileproxyloop()
	{}

	void init()
	{
		m_syn_async.set(m_loop.ref());
		m_syn_async.set_callback(std::bind(&fileproxyloop::syn_async_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_syn_async.start();

		m_intr_async.set(m_loop.ref());
		m_intr_async.set_callback(std::bind(&fileproxyloop::interrupt_async_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_intr_async.start();

		m_pool.set_poolname("fproxy");
		m_pool.make_thread(&m_poolcontrol, 10, 2);
	}

	void run()
	{
		m_loop.run_loop();
	}

	void run_bg()
	{
		m_loop.run_loop(ascloop<evtl::dynamic_loop>::background_thread, "fproxy-loop");
	}

	void syn_knock_door(std::shared_ptr<file_conveyer_belt> ptr)
	{
		m_syn_async.pushback(ptr);
		gcc_thread_fence;
		m_syn_async.send();
	}

	void async_interrupt(int event, void *key, const std::string &id)
	{
		m_intr_async.pushback(interrupt_detail(event, key, id));
		gcc_thread_fence;
		m_intr_async.send();
	}

private:
	void syn_async_callback(synasync &watcher, int revents)
	{
		std::shared_ptr<file_conveyer_belt> ptr;

		if (!m_syn_async.popfront(ptr))
			return;

		if (ptr)
		{
			file_session *psess = new file_session;
			cout<<"create file_session:"<<psess<<endl;

			psess->set_loop(m_loop);
			psess->set_conveyer_belt(ptr);
			psess->set_callback_recycle(std::bind(&fileproxyloop::recycle, this, std::placeholders::_1));
			psess->set_callback_pool(std::bind(&fileproxyloop::pool_add, this, std::placeholders::_1),
				std::bind(&fileproxyloop::pool_remove, this, std::placeholders::_1)
				);
			psess->init_watchers();
			psess->async_connect("127.0.0.1", 1234);

			m_sessions.insert(psess);

			ptr->remotekey = psess;
			ptr->remoteintr = std::bind(&fileproxyloop::async_interrupt, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3);
			ptr->syn_ack = true;

			ptr->interrupt_local(intev_syn_ack);
		}

		m_syn_async.send();
	}

	void interrupt_async_callback(interrupt_async &watcher, int revents)
	{
		interrupt_detail idet;

		if (!m_intr_async.popfront(idet))
			return;

		m_intr_async.send();

		if (idet.key == nullptr)
			assert(false && "bad key");

		file_session *psess = static_cast<file_session *>(idet.key);
		if (m_sessions.find(psess) == m_sessions.end())
			return;

		if (psess->conveyer_id() == idet.id)
		{
			psess->async_interrupt(idet.event);
		}
	}

	void recycle(file_session *psess)
	{
		cout<<"recycle file_session:"<<psess<<endl;

		m_sessions.erase(psess);

		if (psess->is_inpool())
		{
			pool_remove(psess);
			psess->set_inpool(false);
		}

		psess->deinit();
		delete psess;
	}

	void pool_add(file_session *psess)
	{
		if (psess == nullptr)
			assert(false && "null session");

		m_pool.add_task<>(psess);
	}

	void pool_remove(file_session *psess)
	{
		if (psess == nullptr)
			assert(false && "null session");

		m_pool.remove_task(psess);
	}

private:
	ascloop<evtl::dynamic_loop>  m_loop;
	synasync                   m_syn_async;
	interrupt_async            m_intr_async;

	std::unordered_set<file_session *>   m_sessions;

	evtl::thread::threadpool
	<
		if_ftask, if_ftask *, if_control, if_control *,
		&if_ftask::run, &if_control::circle_begin, &if_control::circle_accompany, &if_control::circle_end
	>
	m_pool;
	fproxy_control  m_poolcontrol;
};

class session : public evtl::watcher_io<session>, public if_ftask
{
public:
	typedef  std::function<void (session *psess)>  pooladd_callback_t;
	typedef  std::function<void (session *psess)>  poolremove_callback_t;
	typedef  std::function<void (session *psess)>  recycle_callback_t;

	enum io_control
	{
		iocontrol_unknown,
		iocontrol_loop,
		iocontrol_pool
	};

	enum process_result
	{
		process_unknown,

		wait_to_recive,
		wait_to_send,
		wait_to_recive_send,

		wait_to_recive_loop,
		wait_to_send_loop,
		wait_to_recive_send_loop,

		wait_to_recive_pool,
		wait_to_send_pool,
		wait_to_recive_send_pool,

		process_stop,
		process_continue,

		process_done,
		process_error
	};

	session(): m_ploop(nullptr), m_fproxy(nullptr), m_recvbuf(1024*8), m_sendbuf(1024*512), m_process_result(process_unknown)
	{}

	virtual ~session()
	{}

	void set_loop(ascloop<evtl::default_loop> *ploop)
	{
		m_ploop = ploop;
	}

	void set_fproxy(fileproxyloop *fproxy)
	{
		m_fproxy = fproxy;
	}

	void init_watchers()
	{
		m_switch_loopio_async.set(m_ploop->ref());
		m_switch_loopio_async.set_callback(std::bind(&session::loopio_async_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_switch_loopio_async.start();

		m_recycle_async.set(m_ploop->ref());
		m_recycle_async.set_callback(std::bind(&session::recycle_async_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_recycle_async.start();
	}

	void set_callback_pooladd(pooladd_callback_t cb)
	{
		m_pooladd_cb = cb;
	}

	void set_callback_poolremove(poolremove_callback_t cb)
	{
		m_poolremove_cb = cb;
	}

	void set_callback_recycle(recycle_callback_t cb)
	{
		m_recycle_cb = cb;
	}

	void set_callback_interrupt(interrupt_t intrpt)
	{
		m_interupt_cb = intrpt;
	}

	void io_callback(session &watcher, int revents)
	{
		if ((revents & ev::ERROR) != 0)
			assert(false && "ev::ERROR");
		if (&watcher != this)
			assert(false && "unexpected watcher");
		if (get_iocontrol() != iocontrol_loop)
			assert(false && "not loop control");

		if ((revents & ev::READ) != 0)
		{
			m_recvbuf.crowd(1024*2);
			if (m_recvbuf.headspace() > 0)
			{
				ssize_t r = watcher.read(m_recvbuf.headptr(), m_recvbuf.headspace());
				if (r > 0)
				{
					if (r > m_recvbuf.headspace())
						assert(false && "read overflow");

					if (!m_recvbuf.head_eaten(r))
						assert(false && "eaten failed");
				}
				else if (r < 0)
				{
					if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
					{
						watcher.stop();
						m_recycle_cb(this);
						return;
					}
				}
				else
				{
					watcher.stop();
					m_recycle_cb(this);
					return;
				}
			}
		}

		if ((revents & ev::WRITE) != 0)
		{
			if (!m_sendbuf.empty())
			{
				ssize_t w = watcher.write(m_sendbuf.dataptr(), m_sendbuf.size());
				if (w > 0)
				{
					if (w > m_sendbuf.size())
						assert(false && "write overflow");
					if (!m_sendbuf.shit_whole(w))
						assert(false && "shit failed");
				}
				else if (w < 0)
				{
					if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
					{
						watcher.stop();
						m_recycle_cb(this);
						return;
					}
				}
				else
				{
					assert(false && "write zero, unbelivable");
				}
			}
		}

		process();

		process_result result = get_process_result();
		switch (result)
		{
		case wait_to_recive:
			{
				if (watcher.get_events() != ev::READ)
				{
					watcher.stop();
					watcher.set_events(ev::READ);
					watcher.start();
				}
			}
			break;
		case wait_to_send:
			{
				if (watcher.get_events() != ev::WRITE)
				{
					watcher.stop();
					watcher.set_events(ev::WRITE);
					watcher.start();
				}
			}
			break;
		case wait_to_recive_send:
			{
				if (watcher.get_events() != (ev::READ | ev::WRITE))
				{
					watcher.stop();
					watcher.set_events(ev::READ | ev::WRITE);
					watcher.start();
				}
			}
			break;
		case wait_to_recive_pool:
			{
				watcher.stop();
				switch_to_pool_io();
			}
			break;
		case wait_to_send_pool:
			{
				watcher.stop();
				switch_to_pool_io();
			}
			break;
		case wait_to_recive_send_pool:
			{
				watcher.stop();
				switch_to_pool_io();
			}
			break;
		case process_stop:
			{
				watcher.stop();
			}
			break;
		case process_done:
			{
				watcher.stop();
				m_recycle_cb(this);
				return;
			}
			break;
		case process_continue:
			{
				watcher.stop();
				switch_to_pool_io();
			}
			break;
		case process_error:
			{
				watcher.stop();
				m_recycle_cb(this);
				return;
			}
			break;
		default:
			{
				assert(false && "bad process result");
			}
			break;
		};
	}

	void run(void *arg)
	{
		if (get_iocontrol() != iocontrol_pool)
			return;

		process();

		process_result result = get_process_result();

		if (result == wait_to_recive || result == wait_to_recive_pool)
		{
			m_recvbuf.crowd(1024*2);
			if (m_recvbuf.headspace() > 0)
			{
				ssize_t r = this->read(m_recvbuf.headptr(), m_recvbuf.headspace());
				if (r > 0)
				{
					if (r > m_recvbuf.headspace())
						assert(false && "read overflow");

					if (!m_recvbuf.head_eaten(r))
						assert(false && "eaten failed");
				}
				else if (r < 0)
				{
					if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
					{
						async_recycle();
						return;
					}
				}
				else
				{
					async_recycle();
					return;
				}
			}

			return;
		}

		if (result == wait_to_send || result == wait_to_send_pool)
		{
			if (m_sendbuf.size() > 0)
			{
				ssize_t r = this->write(m_sendbuf.dataptr(), m_sendbuf.size());
				if (r > 0)
				{
					if (r > m_sendbuf.size())
						assert(false && "write overflow");

					if (!m_sendbuf.shit_whole(r))
						assert(false && "shit failed");
				}
				else if (r < 0)
				{
					if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
					{
						//first notify proxy to close
						if (m_file_conveyer)
						{
							if (m_file_conveyer->syn_ack)
							{
								m_file_conveyer->interrupt_remote(intev_fin);
							}
						}
						async_recycle();
						return;
					}
				}
				else
				{
					assert(false && "write no data");
					return;
				}
			}

			return;
		}

		if (result == process_continue)
			return;

		if (result == process_done)
		{
			async_recycle();
			return;
		}

		if (result == process_error)
		{
			async_recycle();
			return;
		}

		assert(false && "unknown result");
	}

	void process()
	{
		if (!m_got_request)
		{
			ssize_t pos = m_recvbuf.finds("\r\n\r\n", 4);
			if (pos < 0)
			{
				if (m_recvbuf.size() >= 1024*2)
					set_process_result(process_error);
				else
					set_process_result(wait_to_recive);
			}
			else if (pos == 0)
			{
				set_process_result(process_error);
			}
			else
			{
				std::string fname;

				try
				{
					evtl::pcre2_8::regex reg(R"(\AGET *(\S+) *HTTP/1.1\r\n.*\r\n\Z)");
					evtl::pcre2_8::match_results<char> matches;

					bool br = evtl::pcre2_8::regex_search(m_recvbuf.dataptr(), m_recvbuf.dataptr() + pos + 4, matches, reg);
					if (br)
					{
						assert(matches.size() == 2);
						if (matches[1].matched)
							fname = matches[1].str();
					}
				}
				catch (std::exception &e)
				{
					cout<<"pcre exception: "<<e.what()<<endl;
				}

				if (fname.empty())
				{
					cout<<"invalid filename"<<endl;
					m_got_request.assign(true);
					set_process_result(process_error);
				}
				else
				{
					m_file_conveyer = std::make_shared<file_conveyer_belt>();
					m_file_conveyer->id = evtl::uuid::generate();
					m_file_conveyer->localkey = this;
					m_file_conveyer->localintr = m_interupt_cb;
					m_file_conveyer->filename = fname;
					m_fproxy->syn_knock_door(m_file_conveyer);

					m_got_request.assign(true);

					set_process_result(process_continue);
				}
			}
		}
		else
		{
			assert(m_file_conveyer);

			if (!m_request_result.isset())
			{
				if (m_file_conveyer->file_exist.isset())
				{
					if (m_file_conveyer->file_exist.refer())
					{
						if (m_file_conveyer->total_size.isset())
						{
							if (m_file_conveyer->total_size.refer() >= 0)
							{
								m_request_result.set_assign(true);
								set_process_result(wait_to_send);
							}
							else
							{
								m_request_result.set_assign(false);
								set_process_result(wait_to_send);
							}
						}
						else
						{
							set_process_result(process_continue);
						}
					}
					else
					{
						m_request_result.set_assign(false);
						set_process_result(wait_to_send);
					}
				}
				else
				{
					set_process_result(process_continue);
				}
			}
			else
			{
				if (!m_request_result.refer())
				{
					if (!m_responce_putted)
					{
						std::stringstream ss;
						ss << "HTTP/1.1 404 Not Found\r\n"
							<< "Server: asc\r\n"
							<< "Content-Type: text/plain\r\n"
							<< "Content-Length: 0\r\n"
							<< "Connection: close\r\n"
							<< "\r\n";

						m_sendbuf.extens_store_whole(ss.str());
						m_responce_putted.assign(true);
						set_process_result(wait_to_send);
					}
					else
					{
						if (!m_sendbuf.empty())
							set_process_result(wait_to_send);
						else
							set_process_result(process_done);
					}
				}
				else
				{
					if (!m_responce_putted)
					{
						std::stringstream ss;
						ss << "HTTP/1.1 200 OK\r\n"
							<< "Server: asc\r\n"
							<< "Content-Type: application/octet-stream\r\n"
							<< "Content-Length: " << m_file_conveyer->total_size.refer() << "\r\n"
							<< "Connection: close\r\n"
							<< "\r\n";

						m_sendbuf.extens_store_whole(ss.str());
						m_responce_putted.assign(true);
						set_process_result(wait_to_send);
					}
					else
					{
						// send file
						if (m_received_size < m_file_conveyer->total_size.refer())
						{
							ssize_t n = m_file_conveyer->move_out(m_sendbuf);
							m_received_size += n;
							set_process_result(wait_to_send);
						}
						else
						{
							if (!m_sendbuf.empty())
								set_process_result(wait_to_send);
							else
							{
								cout<<"send done, size = "<<m_received_size<<endl;
								set_process_result(process_done);
							}
						}
					}
				}
			}
		}
	}

	bool is_inpool() const
	{
		return m_inpool.refer();
	}

	void set_inpool(bool in)
	{
		m_inpool.assign(in);
	}

	void set_iocontrol(io_control ctrl)
	{
		m_iocontrol.assign(ctrl);
	}

	io_control get_iocontrol() const
	{
		return m_iocontrol.refer();
	}

	void async_interrupt(int event)
	{
		cout<<"got event:"<<event<<endl;
	}

	std::string conveyer_id() const
	{
		return m_file_conveyer->id;
	}

	void stop_all_watcher()
	{
		this->stop();
		m_switch_loopio_async.stop();
		m_recycle_async.stop();
	}

	void deinit()
	{
		stop_all_watcher();
		this->only_close();
	}

private:
	process_result get_process_result()
	{
		return m_process_result;
	}

	void set_process_result(process_result result)
	{
		m_process_result = result;
	}

	void switch_to_pool_io()
	{
		if (!is_inpool())
		{
			m_pooladd_cb(this);
			set_inpool(true);
		}
		set_iocontrol(iocontrol_pool);
	}

	void async_switch_to_loopio(int events)
	{
		set_iocontrol(iocontrol_loop);
		m_switch_loopio_async.set_io_events(events);
		gcc_thread_fence;
		m_switch_loopio_async.send();
	}

	void async_recycle()
	{
		set_iocontrol(iocontrol_loop);
		gcc_thread_fence;
		m_recycle_async.send();
	}

private:
	void loopio_async_callback(loopio_async &watcher, int revents)
	{
		if (&watcher != &m_switch_loopio_async)
			assert(false && "bad watcher");
		if (this->is_active())
			assert(false && "this is active watcher");
		if (get_iocontrol() != iocontrol_loop)
			assert(false && "not loop control");

		int event = watcher.get_io_events();

		if ((event & (ev::READ | ev::WRITE)) != 0)
		{
			this->set_events(event);
			this->start();
		}
	}

	void recycle_async_callback(ascasync &watcher, int revents)
	{
		if (&watcher != &m_recycle_async)
			assert(false && "unexpected watcher");
		if (this->is_active())
			assert(false && "this is active watcher");
		if (get_iocontrol() != iocontrol_loop)
			assert(false && "not loop control");

		m_recycle_cb(this);
	}

private:
	ascloop<evtl::default_loop>  *m_ploop;

	fileproxyloop        *m_fproxy;

	loopio_async   m_switch_loopio_async;
	ascasync       m_recycle_async;

	evtl::enumflag<io_control, iocontrol_unknown, true>  m_iocontrol;
	evtl::boolflag<false, true>   m_inpool;

	evtl::linearbuf<char>  m_recvbuf;
	evtl::linearbuf<char>  m_sendbuf;

	pooladd_callback_t     m_pooladd_cb;
	poolremove_callback_t  m_poolremove_cb;
	recycle_callback_t     m_recycle_cb;
	interrupt_t            m_interupt_cb;

	process_result    m_process_result;

	std::shared_ptr<file_conveyer_belt>  m_file_conveyer;

	evtl::boolflag<false>                m_got_request;
	evtl::st_var<bool>                   m_request_result;
	evtl::boolflag<false>                m_responce_putted;

	int64_t  m_received_size = 0;
};

class svcontrol : public if_control
{
public:
	void circle_begin(void *arg, int64_t id)
	{
	}

	void circle_accompany(void *arg, int64_t id, if_ftask * const &ptask)
	{
	}

	void circle_end(void *arg, int64_t id, int64_t taskcount, int64_t consumed_us)
	{
		usleep(200);
	}
};

class fileserver
{
public:
	fileserver(): m_ploop(nullptr), m_fproxy(nullptr)
	{}

	void init(ascloop<evtl::default_loop> &loop)
	{
		m_ploop = &loop;

		init_watchers();

		m_pool.set_poolname("fs");
		m_pool.make_thread(&m_control, 0, 2);
	}

	void setfproxy(fileproxyloop &fproxy)
	{
		m_fproxy = &fproxy;
	}

private:
	void init_watchers()
	{
		m_timer.set(m_ploop->ref(), 0, 1);
		m_timer.set_callback(std::bind(&fileserver::timer_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_timer.again();

		m_listener.set_address("0.0.0.0", 5678);
		m_listener.listen(1);

		m_acceptor.occupy_dummy();
		m_acceptor.set_loop(m_ploop->ref());
		m_acceptor.set_listener(m_listener);
		m_acceptor.set_callback(std::bind(&fileserver::accept_callback, this, std::placeholders::_1, std::placeholders::_2));
		m_acceptor.watch();
	}

private:
	void timer_callback(asctimer &watcher, int revents)
	{
		timer_task();

		watcher.set_repeat(1. + m_ploop->time() - m_ploop->now());
		watcher.again();
	}

	void timer_task()
	{
	}

	void accept_callback(ascacceptor &accptor, const std::vector<evtl::connection> &connections)
	{
		for (std::vector<evtl::connection>::const_iterator iter = connections.begin(); iter != connections.end(); ++iter)
		{
			session *psess = new session;
			cout<<"create session:"<<psess<<endl;

			psess->set_loop(m_ploop);
			psess->set_fproxy(m_fproxy);
			psess->set_callback_pooladd(std::bind(&fileserver::add_to_pool, this, std::placeholders::_1));
			psess->set_callback_poolremove(std::bind(&fileserver::add_to_pool, this, std::placeholders::_1));
			psess->set_callback_recycle(std::bind(&fileserver::recycle, this, std::placeholders::_1));
			psess->set_callback_interrupt(std::bind(&fileserver::interrupt, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3));

			psess->set_iocontrol(session::iocontrol_loop);
			psess->init_watchers();

			psess->set(m_ploop->ref());
			psess->set(iter->fd, ev::READ);
			psess->start();

			m_sessions.insert(psess);
		}
	}

	void recycle(session *psess)
	{
		cout<<"recycle session:"<<psess<<endl;

		m_sessions.erase(psess);

		if (psess->is_inpool())
		{
			remove_from_pool(psess);
			psess->set_inpool(false);
		}

		psess->deinit();
		delete psess;
	}

	void interrupt(int event, void *key, const std::string &id)
	{
		std::unordered_set<session *>::iterator iter = m_sessions.find(static_cast<session *>(key));
		if (iter != m_sessions.end())
		{
			session *psess = *iter;
			if (psess->conveyer_id() == id)
			{
				psess->async_interrupt(event);
			}
		}
	}

	void add_to_pool(session *psess)
	{
		if (psess == nullptr)
			assert(false && "null session");

		m_pool.add_task<>(psess);
	}

	void remove_from_pool(session *psess)
	{
		if (psess == nullptr)
			assert(false && "null session");

		m_pool.remove_task(psess);
	}

private:
	ascloop<evtl::default_loop>   *m_ploop;

	fileproxyloop        *m_fproxy;

	asctimer             m_timer;
	evtl::tcp::listener  m_listener;
	ascacceptor          m_acceptor;

	svcontrol      m_control;
	evtl::thread::threadpool
	<
		if_ftask, if_ftask *, if_control, if_control *,
		&if_ftask::run, &if_control::circle_begin, &if_control::circle_accompany, &if_control::circle_end
	>
	m_pool;

	std::unordered_set<session *>  m_sessions;
};


class svloop
{
public:
	svloop()
	{}

	void init()
	{
		m_filesv.init(m_loop);
	}

	void setfproxy(fileproxyloop &proxy)
	{
		m_filesv.setfproxy(proxy);
	}

	void run()
	{
		m_loop.run_loop();
	}

	void run_bg()
	{
		m_loop.run_loop(ascloop<evtl::default_loop>::background_thread, "fsv-loop");
	}

private:
	ascloop<evtl::default_loop>  m_loop;

	fileserver  m_filesv;
};

class ascservice
{
public:
	ascservice()
	{}

	void init()
	{
		m_svloop.init();
		m_fproxyloop.init();

		m_svloop.setfproxy(m_fproxyloop);
	}

	void run()
	{
		m_fproxyloop.run_bg();
		m_svloop.run();
	}

private:
	svloop           m_svloop;
	fileproxyloop    m_fproxyloop;
};


int main()
{
	evtl::timec::background_update();

	ascservice svs;
	svs.init();

	cout<<"run.."<<endl;
	svs.run();

	return 0;
}


